# 实战：下载 GitHub 私有仓库（2026-08-13，pipykarchu/MV-study）

## 场景

用户要求"下载我 GitHub 里视频学习的应用到 pxy 文件夹"。用户给的账号 `pxy` 名下没有该仓库，
实际账号是 **pipykarchu**，仓库 `MV-study` 是**私有的**（B站视频AI学习助手，344KB）。

## 时间线要点

1. **账号探测**：`pxy` 只有 2 个无关公开仓库；试了 `pixiyu`/`pi-xy`/`Pixy` 等变体都不对。
   用户后来直接给出真实链接 `github.com/pipykarchu/MV-study` 才定位到。
   → 教训：拿不到准确账号时，直接问用户要链接，别猜太多次。

2. **404 不等于不存在**：未认证访问私有仓库 API/网页都是 404。
   拿到 `ghp_` token 后 API 才返回 200，仓库信息：`private=true, branch=main, size=344KB`。

3. **git clone 反复卡死**（两次前台超时 300s、一次后台 180s+ 无输出，即使配置了 Clash 代理）：
   - 排查：`Get-NetTCPConnection` 确认 Clash 代理 127.0.0.1:7897；`curl` 直连 GitHub 实测 0.2s 通
   - **结论：网络没问题，是 git 客户端在本机的问题（gitconfig 含 sslVerify=false 等）**
   - 绕过：curl 下载 codeload zip，1.5s 完成 166KB

4. **目录清理坑**：
   - clone 中断残留 `.git` 目录 + git 进程锁文件（`git.exe`/`git-remote-https`/`git-credential-helper-selector`）
   - `Remove-Item` 报"正由另一进程使用" → `Stop-Process -Id <pid> -Force`
   - shell cwd 在目标目录内时删除失败 → 先 `cd D:\pxy` 再删

## 成功命令序列

```powershell
# 1. 验证 token
$tok = "ghp_..."
curl.exe -s -H "Authorization: Bearer $tok" "https://api.github.com/user" -o "$env:TEMP\gh_user.json"
node -e "const fs=require('fs');let s=fs.readFileSync(process.env.TEMP+'\\gh_user.json','utf8').replace(/^\uFEFF/,'');const d=JSON.parse(s);console.log(d.login?('VALID: '+d.login):(d.message))"

# 2. 写凭证（一次，多工具共用）
Add-Content "$env:USERPROFILE\.git-credentials" "https://pipykarchu:$tok@github.com"

# 3. curl 下载 zip（替代 git clone）
cd D:\pxy
curl.exe -s -L -u "pipykarchu:$tok" -o "D:\pxy\MV-study.zip" --connect-timeout 20 --max-time 240 `
  "https://codeload.github.com/pipykarchu/MV-study/zip/refs/heads/main"
# HTTP 200 size=166293 time=1.48s

# 4. 解压并整理
Expand-Archive -Path "D:\pxy\MV-study.zip" -DestinationPath "D:\pxy\MV-study-extract" -Force
Move-Item "D:\pxy\MV-study-extract\MV-study-main" "D:\pxy\MV-study"
Remove-Item "D:\pxy\MV-study-extract","D:\pxy\MV-study.zip" -Force
```

## 结果

`D:\pxy\MV-study\` 包含：public/ server/ src/ tests/ README.md、B站视频AI学习助手_PRD.md/.html、
handoff.md、package.json、vite.config.js、start.bat（Vite 应用，可启动）。

## 本机环境事实（2026-08-13）

- 系统 PATH 无 gh CLI；git 在 `C:\Users\16543\AppData\Local\hermes\git`（已在 PATH）
- node 在 PATH（官方版自带）；无系统 python
- GitHub 直连快（~0.2s），Clash Verge 代理 127.0.0.1:7897（监听中）
- gitconfig：`sslVerify=false`、`credential.helper=store`、Windows credential manager selector
