---
name: git-repo-download
version: 1.0.0
license: MIT
title: Download/Clone Git Repos (incl. Private) on Windows PowerShell
description: "Use when downloading or cloning a repository from GitHub/GitLab (public or private) on this Windows machine. Triggers on '帮我下载 github 里的 xxx 应用', 'clone 仓库', '下载私有仓库', 'git clone 卡住/超时', '需要 token 访问私有仓库'."
keywords: [git, clone, download, github, gitlab, private-repo, PAT, codeload, powershell]
---

# Download/Clone Git Repos (incl. Private) on Windows PowerShell

## Trigger Conditions

- 用户要求"下载/克隆我 GitHub 里的 XX 应用/仓库"
- 仓库是私有的，需要 PAT 认证
- `git clone` 卡死/超时（本机已知问题，见备用路径）
- 需要确认某个 GitHub 用户/仓库是否存在

## 核心流程

### Step 1: 确认账号与仓库（不知道用户名时）

```powershell
# 探测候选用户名（GitHub API 未认证也够用）
$names = @("pxy","pixiyu","<拼音变体>")
foreach ($n in $names) { $r = curl.exe -s "https://api.github.com/users/$n" | ConvertFrom-Json; if ($r.login) { Write-Output "$n => repos=$($r.public_repos)" } }

# 列出该用户的公开仓库
curl.exe -s "https://api.github.com/users/<user>/repos?per_page=100" -o "$env:TEMP\repos.json"
```

⚠️ **PowerShell 解析 curl 输出坑**：curl.exe 输出可能带 UTF-8 BOM，`ConvertFrom-Json` 报"传入的对象无效"。改用 node 解析（Hermes 自带 node）：
```powershell
node -e "const fs=require('fs');const d=JSON.parse(fs.readFileSync(process.env.TEMP+'\\repos.json','utf8').replace(/^\uFEFF/,''));console.log(d.map(x=>x.name).join('\n'))"
```

### Step 2: 判断仓库是否私有（关键）

**GitHub 私有仓库未认证时 API 和网页一律返回 404**——不能据此断定"仓库不存在"或"链接错了"。

```powershell
$code = curl.exe -s -o NUL -w "%{http_code}" "https://api.github.com/repos/<user>/<repo>"
# 404 + 用户确认仓库存在 → 私有，需要 token
```

### Step 3: 验证 PAT 并存入凭证库（一次性，多工具共用）

用户给的 token（`ghp_` 开头）先验证：
```powershell
$tok = "ghp_xxx"
curl.exe -s -H "Authorization: Bearer $tok" "https://api.github.com/user" -o "$env:TEMP\gh_user.json"
node -e "const fs=require('fs');let s=fs.readFileSync(process.env.TEMP+'\\gh_user.json','utf8').replace(/^\uFEFF/,'');const d=JSON.parse(s);console.log(d.login?('VALID: '+d.login):(d.message||'unknown'))"
```

验证通过后写入本机凭证存储（**codex / Hermes / reasonix 等所有工具共用**）：
```powershell
# gitconfig 需有 [credential] helper = store
Add-Content "$env:USERPROFILE\.git-credentials" "https://<user>:$tok@github.com"
```

🔒 **安全纪律**：token 明文只放 `.git-credentials`，**绝不写进 Hermes memory**（每轮注入会暴露）；memory 只记凭证文件路径和用途。

### Step 4: 下载（两条路径）

**路径 A — git clone（正常情况）：**
```powershell
cd D:\pxy   # 目标目录
git clone https://github.com/<user>/<repo>.git
```

**路径 B — git clone 卡死/超时 → curl 下载 codeload zip（本机已验证可靠）：**
```powershell
$tok = "<从 .git-credentials 读取>"
curl.exe -s -L -u "<user>:$tok" -o "D:\pxy\<repo>.zip" --connect-timeout 20 --max-time 240 `
  "https://codeload.github.com/<user>/<repo>/zip/refs/heads/<branch>"   # GitLab 用 /api/v4/projects/<id>/repository/archive.zip?private_token=...
Expand-Archive -Path "D:\pxy\<repo>.zip" -DestinationPath "D:\pxy\<repo>-extract" -Force
# zip 解压出 <repo>-<branch>/ 子目录，Move-Item 内容到最终目录
```

curl 直连 GitHub 很快（~0.2s）；若网络不通再考虑代理 `-x http://127.0.0.1:7897`。

## Pitfalls

1. **残留 git 进程锁目录**：`git clone` 被中断后，`git.exe` / `git-remote-https` 进程仍在运行会锁住目录，`Remove-Item` 报"正由另一进程使用"。先 `Stop-Process -Id <pid> -Force` 杀掉所有 git 相关进程再删。
2. **不能删除当前工作目录**：shell 的 cwd 在被删目录内时 `Remove-Item` 失败。先 `cd D:\pxy`（或其他目录）再删。
3. **clone 卡住不等于网络问题**：先 `curl -o NUL -w "%{http_code} %{time_total}"` 测连通性再判断。本机 GitHub 直连正常但 git 客户端会卡（gitconfig 有 sslVerify=false 等异常配置），直接走路径 B。
4. **删除后重新 clone 报 "destination path already exists and is not an empty directory"**：通常是旧 `.git` 目录没删干净（进程占用），见 Pitfall 1。
5. **PowerShell 5.1 无 `&&`/`||`**：用 `;` 连接命令。
6. **zip 里的仓库在 `<repo>-<branch>/` 子目录**：解压后要移动内容，别把嵌套目录直接当仓库根。

## 验证

- 下载后 `Get-ChildItem <目标目录>` 应看到 README.md / package.json / 源码目录等
- 若用户给的是 PRD/应用类仓库，检查是否含 `start.bat` / `package.json` 等启动文件并告知用户

## References

- `references/private-repo-download-recipe.md` — 2026-08-13 实战完整流程（pipykarchu/MV-study 私有仓库下载）
