---
name: "hifi-style-guide"
description: "Generates structured Figma design system specification documents including color palette, typography, spacing, radius, and elevation rules. Invoke when user needs to establish visual design tokens or brand guidelines for HiFi prototypes."
license: MIT
---

# HiFi Style Guide Generator

This skill generates **structured Figma-ready design specification documents** for high-fidelity prototype design. It outputs a complete design token system that designers can directly implement in Figma as styles and variables.

## When to Invoke

- When starting a new project and need to establish a visual design system
- When user asks for color palette, typography, or spacing standards
- When creating brand guidelines or visual identity specifications
- Before generating components or page layouts (use this skill first to establish tokens)

## Input Parameters (Ask User First)

Collect these parameters before generating:

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `brand_name` | Yes | — | Product/project name |
| `primary_hue` | Yes | 220 | Base hue for primary color (0-360 on HSL color wheel) |
| `style_tone` | Yes | professional | One of: `professional`, `playful`, `minimal`, `luxury`, `energetic` |
| `font_family` | No | Inter | Preferred font family (e.g., Inter, PingFang SC, Roboto) |
| `radius_scale` | No | medium | `none`, `small`, `medium`, `large`, `full` |
| `dark_mode` | No | true | Whether to include dark mode specifications |

## Output Format

Generate a **structured Markdown document** with the following sections. Each section must include precise numerical values, hex codes, and Figma-style naming conventions.

---

## Section 1: Color System

### 1.1 Brand Colors (Figma Variable Naming Convention)

```
Color / Brand / Primary / 50   →  #XXXXXX
Color / Brand / Primary / 100  →  #XXXXXX
Color / Brand / Primary / 200  →  #XXXXXX
Color / Brand / Primary / 300  →  #XXXXXX
Color / Brand / Primary / 400  →  #XXXXXX
Color / Brand / Primary / 500  →  #XXXXXX  (Base)
Color / Brand / Primary / 600  →  #XXXXXX
Color / Brand / Primary / 700  →  #XXXXXX
Color / Brand / Primary / 800  →  #XXXXXX
Color / Brand / Primary / 900  →  #XXXXXX

Color / Brand / Secondary / 500 → #XXXXXX
Color / Brand / Accent / 500    → #XXXXXX
```

Use HSL scaling: each step varies Lightness by ~8%, Saturation adjusted for visual uniformity.

### 1.2 Neutral Palette

```
Color / Neutral / 0   → #FFFFFF (White)
Color / Neutral / 50  → #FAFAFA
Color / Neutral / 100 → #F5F5F5
Color / Neutral / 200 → #E5E5E5
Color / Neutral / 300 → #D4D4D4
Color / Neutral / 400 → #A3A3A3
Color / Neutral / 500 → #737373
Color / Neutral / 600 → #525252
Color / Neutral / 700 → #404040
Color / Neutral / 800 → #262626
Color / Neutral / 900 → #171717
Color / Neutral / 950 → #0A0A0A
```

### 1.3 Semantic Colors

```
Color / Semantic / Success / 500 → #22C55E
Color / Semantic / Warning / 500 → #F59E0B
Color / Semantic / Error   / 500 → #EF4444
Color / Semantic / Info    / 500 → #3B82F6
```

### 1.4 Dark Mode Overlay (if enabled)

For each color above, provide the dark mode equivalent with naming:
```
Color / Dark / Brand / Primary / 500 → #XXXXXX
Color / Dark / Neutral / 100       → #XXXXXX
...
```

### 1.5 Color Usage Rules Table

| Token | Usage Scenario | Accessibility (Contrast) |
|-------|---------------|--------------------------|
| Primary 600 | CTA buttons, primary actions | ≥ 4.5:1 on white |
| Neutral 700 | Body text | ≥ 4.5:1 on white |
| Neutral 500 | Secondary text | ≥ 4.5:1 on white |
| Neutral 200 | Borders, dividers | — |
| Neutral 50  | Background, surface | — |

---

## Section 2: Typography System

### 2.1 Font Stack Definition

```
Typography / Family / Sans → "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif
Typography / Family / Mono → "JetBrains Mono", Menlo, Consolas, monospace
```

### 2.2 Type Scale (Mobile-first, desktop in parentheses)

Use **modular scale** with ratio 1.25 (Major Third). Base size: 16px.

| Style Token | Font Size | Line Height | Font Weight | Letter Spacing | Figma Text Style Name |
|-------------|-----------|-------------|-------------|----------------|----------------------|
| Display 2XL | 48px (64px) | 1.1 | 700 | -0.02em | `Display / 2XL` |
| Display XL  | 36px (48px) | 1.2 | 700 | -0.01em | `Display / XL` |
| Heading LG  | 28px (36px) | 1.3 | 600 | 0 | `Heading / LG` |
| Heading MD  | 22px (28px) | 1.3 | 600 | 0 | `Heading / MD` |
| Heading SM  | 18px (22px) | 1.4 | 600 | 0 | `Heading / SM` |
| Body LG     | 16px (18px) | 1.5 | 400 | 0 | `Body / LG` |
| Body MD     | 14px (16px) | 1.6 | 400 | 0 | `Body / MD` |
| Body SM     | 12px (14px) | 1.5 | 400 | 0 | `Body / SM` |
| Caption     | 11px (12px) | 1.4 | 400 | 0.02em | `Caption` |
| Overline    | 10px (11px) | 1.4 | 500 | 0.08em | `Overline` |

### 2.3 Font Weights Available

```
Typography / Weight / Regular  → 400
Typography / Weight / Medium   → 500
Typography / Weight / Semibold → 600
Typography / Weight / Bold     → 700
```

### 2.4 Typography Usage Rules

- Use `Display` only for hero sections or marketing pages (max 1 per screen)
- `Heading` levels follow semantic HTML hierarchy (h1→Heading LG, h2→Heading MD, etc.)
- `Body MD` is the default for all paragraph text
- `Overline` must be UPPERCASE — used only for section labels

---

## Section 3: Spacing System

### 3.1 Base Unit: 4px Grid

All spacing must be multiples of **4px**.

| Token | Value | Figma Effect Style Name |
|-------|-------|------------------------|
| space-1 | 4px | `Spacing / 1` |
| space-2 | 8px | `Spacing / 2` |
| space-3 | 12px | `Spacing / 3` |
| space-4 | 16px | `Spacing / 4` |
| space-5 | 20px | `Spacing / 5` |
| space-6 | 24px | `Spacing / 6` |
| space-8 | 32px | `Spacing / 8` |
| space-10 | 40px | `Spacing / 10` |
| space-12 | 48px | `Spacing / 12` |
| space-16 | 64px | `Spacing / 16` |
| space-20 | 80px | `Spacing / 20` |

### 3.2 Spacing Application Rules

| Component | Padding X | Padding Y | Gap Between Items |
|-----------|-----------|-----------|-------------------|
| Button SM | 12px | 6px | — |
| Button MD | 16px | 10px | — |
| Button LG | 20px | 14px | — |
| Card | 20px (24px) | 20px (24px) | — |
| Input SM | 10px | 6px | — |
| Input MD | 12px | 10px | — |
| Form field stack | — | — | 16px |
| Section content | 24px (32px) | 40px (64px) | — |

---

## Section 4: Border Radius

### 4.1 Radius Scale

| Token | Value | Usage | Figma Name |
|-------|-------|-------|------------|
| radius-none | 0px | Checkboxes, tabs | `Radius / None` |
| radius-sm | 4px | Small inputs, badges | `Radius / SM` |
| radius-md | 8px | Buttons, cards (small) | `Radius / MD` |
| radius-lg | 12px | Cards, modals | `Radius / LG` |
| radius-xl | 16px | Large containers, hero cards | `Radius / XL` |
| radius-2xl | 24px | Marketing components | `Radius / 2XL` |
| radius-full | 9999px | Pills, avatar, icon buttons | `Radius / Full` |

### 4.2 Radius Style Adjustment by Tone

| Tone | Button Radius | Card Radius | Input Radius |
|------|---------------|-------------|--------------|
| professional | radius-md | radius-md | radius-sm |
| playful | radius-xl | radius-lg | radius-lg |
| minimal | radius-none | radius-sm | radius-none |
| luxury | radius-sm | radius-md | radius-md |
| energetic | radius-full | radius-xl | radius-lg |

---

## Section 5: Shadow / Elevation

### 5.1 Elevation Scale (Light Mode)

Use layered box-shadows for realism. Each level defines: `y-offset`, `blur`, `spread`, `color`, `opacity`.

| Level | Token | Shadow Composition | Figma Effect Style |
|-------|-------|-------------------|--------------------|
| 0 | elevation-none | none | `Elevation / 0` |
| 1 | elevation-sm | 0 1px 2px rgba(0,0,0,0.05) | `Elevation / 1 / SM` |
| 2 | elevation-md | 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -2px rgba(0,0,0,0.1) | `Elevation / 2 / MD` |
| 3 | elevation-lg | 0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -4px rgba(0,0,0,0.1) | `Elevation / 3 / LG` |
| 4 | elevation-xl | 0 20px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.1) | `Elevation / 4 / XL` |
| 5 | elevation-2xl | 0 25px 50px -12px rgba(0,0,0,0.25) | `Elevation / 5 / 2XL` |

### 5.2 Elevation Usage Rules

| Element | Elevation Level | Hover State |
|---------|-----------------|-------------|
| Card (default) | elevation-sm | elevation-md |
| Dropdown menu | elevation-lg | — |
| Modal / Dialog | elevation-2xl | — |
| Popover / Tooltip | elevation-md | — |
| Floating button | elevation-xl | elevation-2xl |

### 5.3 Dark Mode Shadows

Dark mode shadows use **subtle, lower-opacity** values (multiply opacity by 0.6). Replace the base shadow color with `rgba(0,0,0,0.4)` for dark surfaces.

---

## Section 6: Implementation Checklist for Figma

Provide this as a checklist for the designer:

- [ ] Create **Color Variables** for all tokens in Section 1 (Light + Dark modes)
- [ ] Create **Text Styles** for all typography tokens in Section 2
- [ ] Create **Effect Styles** for all elevation levels in Section 5
- [ ] Set up Auto Layout presets for common spacing stacks:
  - `Stack/Horizontal/spacing-4` (horizontal, gap: 16px)
  - `Stack/Vertical/spacing-6` (vertical, gap: 24px)
- [ ] Verify all text/background combinations pass WCAG AA contrast (≥ 4.5:1)
- [ ] Document style names match exactly the naming convention above for handoff

## Example Style: Visual Reference

Include a **text-based visual mockup** of the style guide page layout (for designer reference):

```
┌────────────────────────────────────────────────────────────────┐
│  [Brand Primary 50 swatch]  ...  [Primary 900 swatch]          │
│  Label: Color / Brand / Primary    Hex: #XXXXXX - #XXXXXX       │
├────────────────────────────────────────────────────────────────┤
│  Display 2XL - The quick brown fox                               │
│  Display XL  - jumps over the lazy dog                           │
│  Heading LG  - Heading Large Sample                              │
│  Body MD     - Body text sample. The five boxing wizards...     │
├────────────────────────────────────────────────────────────────┤
│  Spacing Visual: [4px] [8px] [16px] [24px] [32px] [48px]        │
├────────────────────────────────────────────────────────────────┤
│  Elevation Demo: [E1 Card] [E2 Card] [E3 Card] [E4 Card]        │
└────────────────────────────────────────────────────────────────┘
```
