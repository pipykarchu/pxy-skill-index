# 自动触发验收

安装成功和自动触发成功是两个独立验收项。每个平台都在新会话完成以下检查：

1. 平台能发现目标 Skill。此 Atomic 包不包含 `pm-workflow-router`。
2. 用自然语言描述产品、PRD、交付或工程化任务，不显式点名 Skill。
3. 确认目标 Skill 被实际加载；Atomic 包不单独承诺跨平台路由提醒。
4. 缺少 CLI、MCP、账号或专属平台能力时必须提醒，不得静默跨平台。

## Hermes

先确认 `${HERMES_HOME}`，再比较 `${HERMES_HOME}/skills/.usage.json` 中的调用计数或使用等价运行时证据。目录安装不等于自动触发。

