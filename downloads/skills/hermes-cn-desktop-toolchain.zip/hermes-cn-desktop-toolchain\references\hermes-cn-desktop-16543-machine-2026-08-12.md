# 本机实测记录（2026-08-12，Windows 11，用户 16543）

本次会话为定位 lark-cli / node 花了 20+ 个工具调用，以下为最终确认的事实，未来直接复用。

## 机器身份

- OS: Windows 11，用户目录 `C:\Users\16543`（**不是** hostname，也不是旧机器用户 `皮玺玉`）
- Hermes: CN 桌面版 0.19.0-cn.7，`HERMES_HOME = D:\hermes\data\hermes-home`
- 桌面进程: `hermes-agent-cn-desktop.exe`（D:\hermes\hermes-agent-cn-desktop.exe）、runtime `hermes-agent-cn-runtime-win32-x64.exe`（D:\hermes\data\versions\0.19.0-cn.7\）

## 工具链真相

| 项 | 状态 | 实测值 |
|----|------|--------|
| node | ⚠️ 双源 | `Get-Command node` → `C:\Users\16543\AppData\Local\hermes\node\node.exe`（官方 Hermes v0.20.0 自带，在 PATH）；CN 版内置 `D:\hermes\data\versions\0.19.0-cn.7\node\node.exe` v22.12.0 不在 PATH |
| npm | ⚠️ 视 node 而定 | 官方版 node 同目录；CN 版同目录 `npm.cmd`（用 `cmd /c` 调，不能 `node npm.cmd`） |
| git | ✅ PATH 有 | `C:\Users\16543\AppData\Local\hermes\git\`（mingw64\bin、cmd、bin 三处，v2.54.0.1，官方版自带）；`where.exe git` 可找到 |
| curl | ✅ PATH 有 | `C:\Windows\System32\curl.exe`（另有 hermes\git\mingw64\bin\curl.exe） |
| gh (GitHub CLI) | ❌ 未安装 | GitHub 操作直接用 `curl.exe` 调 api.github.com（未认证限 60 req/hr，看响应头 X-RateLimit-Remaining） |
| GitHub 凭据 | ❌ 本机无 | `~/.gitconfig` 只有公司 GitLab `http://120.237.89.124:8929`（credential store），无 GitHub 项；无 `~/.config/gh/hosts.yml`、`~/.ssh` 空 |
| python | ❌ 完全无 | `python`/`py` 都不可用（Microsoft Store 别名） |
| lark-cli | ❌ 未安装 | 旧脚本路径 `C:\Users\皮玺玉\AppData\Roaming\npm\...` 本机不存在 |
| Edge | ✅ 运行中 | 16:31 起大量进程；History DB 被锁需复制 |

> **2026-08-13 补充**：用户 GitHub 身份未确认——`pxy` 账号存在但只有 2 个无关仓库（Lock-contention-microbenchmark、locklocklock）；`Pixy`/`pi-xy`/`pixiyu` 等变体都不是。用户说"下载我 github 里的应用"时，先跑探测流程再问用户名/链接，别猜。（流程见本技能 `references/github-identity-discovery-no-gh.md`）

## Hermes CLI 可用命令（runtime exe）

```
D:\hermes\data\versions\0.19.0-cn.7\hermes-agent-cn-runtime-win32-x64.exe
  --version          → Hermes Agent v0.19.0 (2026.7.20), Python 3.14.6
  tools list         → 无 feishu 工具集（browser/web/terminal/file/vision 等有）
  mcp list           → No MCP servers configured
  plugins list       → 46 enabled，无 feishu 插件
```

## 飞书接入排查结论

- Hermes _internal 含 `lark_oapi-1.6.8.dist-info`（SDK 存在但未暴露 CLI 通道）
- 桌面 UI API `http://127.0.0.1:9120/api/...` 返回 401（需 token，未深挖）
- `.port-locks` 有 8644-8647 / 9120-9121 锁文件，但 netstat 未发现 4000/8646/8647/9121 监听
- Edge 历史含 `localhost:4000/api/auth/feishu/callback` → 本机历史上跑过 lark-cli OAuth
- **结论：唯一现实路径 = 装 lark-cli（PATH 引导后 npm install -g），或问用户要飞书链接**

## 工作目录与日报

- 工作区: `D:\pxy\AI产品工作\`（汇报/、牧之音/、技能/、github-work-tmp/）
- 日报存档: `D:\pxy\AI产品工作\汇报\daily\皮玺玉_YYYYMMDD_日报.md`
- 技能包源码: `D:\pxy\AI产品工作\汇报\mozin-daily-report\`（SKILL.md 说存档在 `D:\pxy\...` 是旧机器路径）

## 当日（2026-08-12）扫描结果快照

- `D:\pxy\AI产品工作` 当日文件变更 = 0（用户远程操作同事电脑，属正常）
- 桌面 16:34 创建 `GameViewer - 快捷方式.lnk`（远程工具证据）
- Edge 历史关键词: feishu 2795 / docx 785 / wiki 1309 / meeting 13 / remote 121 / todesk 7 / gameviewer 1
- Hermes agent.log 当日 15:07 桌面启动（cron scheduler started）
