# 飞书接入诊断案例（2026-08-12）：disabled 快照 vs 实际已连通

## 场景

用户报"飞书接入失败"，提供桌面端接入诊断 JSON（kind: hermes-im-onboarding-diagnosis）。JSON 显示三条 error：平台未启用（state: disabled）、网关未运行、提示确认飞书后台发布。初看像"只差启用"，但实际**飞书早已连通**。

## 诊断 JSON 关键字段解读

- `gateway.running: true` 但 `officialPlatform.state: "disabled"`、`test.ok: false` → 快照时刻平台确未启用
- `onboarding.qrStatus: "confirmed"`、`credentialReturned: true`、`lastApplyOk: true`、`restartOk: true` → 扫码与凭证写入早已成功
- `configuration.requiredKeys` 均 `isSet: true` → .env 凭据齐全（不必让用户重发）
- **关键**：`generatedAt: 2026-08-12T11:56:03Z`（19:56 本地），而 gateway.log 显示 22:37、23:25 又重启两次且均 `feishu connected` —— 诊断 JSON 是 19:56 重启前的旧快照，**晚于快照的重启把状态改好了**

## 判定链（当时实测，全部命中"已连通"）

1. `.env` 比对：`FEISHU_APP_ID` 与用户粘贴值 `-eq` 匹配（输出布尔，不回显值）；`FEISHU_APP_SECRET` 长度 32
2. 进程：`hermes-agent-cn-runtime-win32-x64` PID 32108 存活、Responding=True
3. 心跳：`state\gateway.heartbeat` updated_at 距今 13s
4. gateway.log：`[Feishu] Connected in websocket mode (feishu)` + `feishu connected` + `Gateway running with 1 platform(s)`
5. 网络：PID 32108 有 5 条 Established 连接，其中到 `112.50.108.44:443`（飞书 WSS 服务器）

结论：无需重新扫码/重配；唯一待做是"发消息实测"。

## processor-not-found 噪音清单（无害，勿排查）

- `task.task.update_tenant_v1`
- `vc.meeting.all_meeting_ended_v1`
- `application.application.app_version.publish_apply_v6`

出现在 `desktop-gateway-restart.log` / gateway.log 中，均为飞书主动推送的租户级事件，Hermes 未订阅处理器，不影响 im.message.receive_v1 收发。

## 凭据安全处理（用户曾在聊天粘贴 App Secret）

- 不展示、不索要、不还原；回复中一律用脱敏形式（cli_...dcb3 / ou_7...9e2b / 长度 N）
- 先验证 .env 已配置 → 告知无需重新提供
- 提醒：Secret 已暴露在聊天记录，建议飞书开放平台轮换后回接入页重填

## 教训

- 诊断 JSON 的 `issues[].evidence` 里 "disabled" 与 "网关未运行" 常是同一根因两种表现，不是两个独立问题
- 网关日志 + 进程 + 心跳 + 网络连接四件套是"是否真的连通"的权威证据，优于任何状态字段
- 别让用户做无谓操作（重新扫码/重装 lark-cli），先查日志再给结论
