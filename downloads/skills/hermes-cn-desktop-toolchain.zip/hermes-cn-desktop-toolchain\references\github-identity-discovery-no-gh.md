# GitHub 身份与仓库探测（无 gh CLI，Windows PowerShell）

> 适用场景：用户说"下载/克隆我 GitHub 里的 XXX"，但本机没有 gh CLI、没有 GitHub 凭据、甚至不确定用户 GitHub 用户名。**不要盲目猜用户名**，先跑下面的探测流程，再决定问用户什么。

## 第 0 步：检查本机是否已有 GitHub 凭据（30 秒）

```powershell
# 1. git 全局配置里的凭据（credential helper / store 会暴露 host）
git config --global -l
# 2. gh CLI 的 hosts.yml（gh 登录过才有）
Get-Content "$env:USERPROFILE\.config\gh\hosts.yml" -ErrorAction SilentlyContinue
# 3. SSH 公钥（公钥文件名/注释里常带用户名）
Get-ChildItem "$env:USERPROFILE\.ssh" -ErrorAction SilentlyContinue
# 4. 已有 clone 的 remote
Get-ChildItem "D:\pxy" -Directory -Recurse -Depth 2 -Filter ".git" -ErrorAction SilentlyContinue |
  ForEach-Object { git -C $_.FullName remote -v }
```

本机实测（2026-08-13）：只有公司 GitLab `http://120.237.89.124:8929`，无任何 GitHub 凭据 → 走第 1 步探测。

## 第 1 步：探测用户名变体（curl + GitHub REST API）

```powershell
$names = @("pxy","pixiyu","pixy","pi-xy","pxy2024","pxy-pro","pixy-cn")
foreach ($n in $names) {
    $r = curl.exe -s "https://api.github.com/users/$n" | ConvertFrom-Json
    if ($r.login) { Write-Output "$n => login=$($r.login) repos=$($r.public_repos)" }
    else { Write-Output "$n => not found" }
}
```

**⚠️ PowerShell 5.1 坑（踩过）**：`curl.exe -s <url>` 直接管道给 `ConvertFrom-Json | Select-Object ...` 会得到**空对象**（字段全空白），但管道给 `Select-String` 是好的。原因：curl.exe 输出流经 PS 5.1 管道时编码/对象化不干净。**可靠写法：先存文件再解析**：

```powershell
curl.exe -s "https://api.github.com/users/pxy/repos?per_page=100" -o "$env:TEMP\repos.json"
(Get-Content "$env:TEMP\repos.json" -Raw | ConvertFrom-Json) | Select-Object name, description | Format-Table -AutoSize -Wrap
```

同样适用 GitLab：`curl.exe -s "http://<host>/api/v4/projects?search=<name>" -o "$env:TEMP\p.json"` 再 `Get-Content -Raw | ConvertFrom-Json`。

**⚠️ 更强的坑（2026-08-13 实测）：先存文件再 `ConvertFrom-Json` 也不是 100% 可靠**——部分 GitHub API 响应会报 `ConvertFrom-Json : 传入的对象无效，应为":"或"}"`（内容明明是合法 JSON，疑似 BOM/编码问题；同一请求里 `users/<name>` 单对象能解析、`users/<name>/repos` 列表却失败）。**终极可靠写法：用 node 解析**（`Get-Command node` 即得，本机官方版 Hermes 自带 `C:\Users\16543\AppData\Local\hermes\node\node.exe`）：

```powershell
$env:TMPJ = "$env:TEMP\repos.json"
curl.exe -s "https://api.github.com/users/pipykarchu/repos?per_page=100" -o $env:TMPJ
node -e "const fs=require('fs');const d=JSON.parse(fs.readFileSync(process.env.TMPJ,'utf8'));console.log(d.map(x=>x.name+' | '+(x.description||'')).join('\n'))"
```

## 第 2 步：看仓库列表判断是否匹配

```powershell
curl.exe -s "https://api.github.com/users/<USERNAME>/repos?per_page=100" -o "$env:TEMP\repos.json"
(Get-Content "$env:TEMP\repos.json" -Raw | ConvertFrom-Json) |
  Select-Object name, description, private, clone_url | Format-Table -AutoSize -Wrap
```

注意：
- `private=false` 表示公开；私有仓库未认证 API 看不到（列表会缺，或 404）。
- 未认证 API 限流 **60 req/hr**（响应头 `X-RateLimit-Remaining`）；探测变体用户名很快耗尽配额，先做第 0 步，变体探测控制在 ~6 个以内。
- 看 `description` 和仓库名判断是否"视频学习/某应用"，别只凭名字猜；必要时拉 `contents/` 看根目录文件确认（`GET /repos/<owner>/<repo>/contents/` 返回数组，含 name+type）。

## 第 2.5 步：仓库级探测（404 = 私有或不存在，无法区分）

用户给了链接/仓库名后逐个探测。**未认证时私有仓库与不存在的仓库都返回 404，肉眼无法区分**：

```powershell
# 批量测名字变体（GitHub 仓库名大小写不敏感，MV-study == mv-study，不用重复测大小写）
$names = @("MV-study","MV_study","mvstudy","video-study","study")
foreach ($n in $names) {
    $code = curl.exe -s -o NUL -w "%{http_code}" "https://api.github.com/repos/<OWNER>/$n"
    Write-Output "$n => $code"
}
# 命中后拉根目录内容确认是不是目标应用（用 node 解析，见上文坑）
curl.exe -s "https://api.github.com/repos/<OWNER>/<REPO>/contents/" -o "$env:TEMP\c.json"
node -e "const fs=require('fs');const d=JSON.parse(fs.readFileSync(process.env.TEMP+'\\c.json','utf8'));if(Array.isArray(d)){console.log(d.map(x=>x.name+' ('+x.type+')').join('\n'))}else{console.log(d.message)}"
# 网页探测与 API 结果一致（404=私有或不存在）
curl.exe -s -o NUL -w "%{http_code}" -L "https://github.com/<OWNER>/<REPO>"
```

- 全部 404 → **不要反复猜名字**，直接问用户：链接里的用户名/仓库名是否抄错？仓库是否私有？私有仓库的下载选项：用户提供 PAT（`repo` scope）走 `git clone https://<token>@github.com/...`、临时设为 public、或用已登录浏览器下载 zip（本机浏览器无 Chrome 时此路不通，需 `agent-browser install` 或装 Chrome）。
- 确认用户身份的另一条线索：**仓库内容**（如 `pikarchu`=个人IP站、`pxy-skill-index`=技能索引页，与用户履历吻合即实锤）。

## 第 3 步：确认不了就明确问用户

问三件事（一次问清，别来回）：
1. GitHub 用户名或**仓库链接**（最省事）
2. 公开还是私有（私有需要 PAT token，或让用户用已登录浏览器走 web 下载 zip）
3. 下载到哪个目录（如 `D:\pxy\` 下新建文件夹还是现有目录）

## 拿到链接后克隆/下载

```powershell
# 公开仓库直接克隆（git 在 PATH：C:\Users\16543\AppData\Local\hermes\git\）
git clone https://github.com/<user>/<repo>.git D:\pxy\<repo>
# 或仅下载 zip（不用 git）：
curl.exe -L -o "$env:TEMP\<repo>.zip" "https://github.com/<user>/<repo>/archive/refs/heads/<branch>.zip"
Expand-Archive "$env:TEMP\<repo>.zip" -DestinationPath "D:\pxy\" -Force
```

### ⚠️ 私有仓库：git clone 在本机会卡死，用 codeload zip（2026-08-13 实测）

**本机 git clone 私有仓库会无限挂起**（配了 Clash 代理 127.0.0.1:7897、gitconfig 有 sslVerify=false 也一样卡；GitHub API/网页 curl 直连却 ~0.2s 就通）。**不要反复等 git clone，直接走 codeload zip**：

```powershell
$tok = "<PAT>"  # 已存 ~/.git-credentials，格式 https://pipykarchu:<token>@github.com
# codeload 是 GitHub 的 zip 直链，带 basic auth，私有仓库 1-2 秒下完（166KB 实测 1.5s）
curl.exe -s -L -u "pipykarchu:$tok" -o "D:\pxy\MV-study.zip" --max-time 240 `
  "https://codeload.github.com/pipykarchu/MV-study/zip/refs/heads/main"
Expand-Archive "D:\pxy\MV-study.zip" -DestinationPath "D:\pxy\MV-study-extract" -Force
# 解压产物是 <repo>-<branch>/ 子目录，移出来并清理
Move-Item "D:\pxy\MV-study-extract\MV-study-main" "D:\pxy\MV-study"
```

**git clone 卡死后的清理坑（踩过）：**
- 超时后残留 `git` / `git-remote-https` 进程会锁住 `.git` 目录，`Remove-Item` 报"正由另一进程使用"。先 `Stop-Process -Id <pid> -Force`（`Get-Process git` 找 pid）。
- **shell 当前工作目录就是目标目录时无法删除该目录**——先 `cd D:\pxy` 再 `Remove-Item`。
- 后台 `git clone 2>&1 | Out-String` 看不到任何输出且状态一直 running → 判断是否卡死看 `.git` 目录字节数是否增长，别傻等。

## 私有仓库认证与 PAT 存储

- 用户提供 PAT 后先验证：`curl.exe -s -H "Authorization: Bearer $tok" https://api.github.com/user`（返回 `login` 即有效；`Bad credentials` 即无效——注意 PS 5.1 管道解析 BOM 坑，存文件后用 node 解析）。
- **有效 PAT 以 `ghp_` 开头**（classic token，`repo` scope 可读私有仓库）。用户发来的非 `ghp_` 字符串（如 43 字符 base64 二进制）几乎必然不是 GitHub PAT，直接指出并要正确的。
- **凭证持久化**：写入 `C:\Users\16543\.git-credentials` 一行 `https://<user>:<token>@github.com`，git/curl 自动复用（gitconfig 已有 `credential.helper=store`）。用户明确说过 codex/Hermes/reasonix 共用此凭证。
- 私有仓库 zip 下载 URL 用 `codeload.github.com/<owner>/<repo>/zip/refs/heads/<branch>`（`github.com/<owner>/<repo>/archive/...` 会 302 到 codeload，带 -u 认证时直接走 codeload 更稳）。

## npm 12 install-scripts 审批坑（npm install 后 esbuild 被拦）

本机 npm 12.0.2（官方版 Hermes 自带）默认**阻止 postinstall 脚本**：`npm install` 完成但提示 `npm warn install-scripts ... esbuild@0.27.7 (postinstall: node install.js)`。vite 依赖 esbuild 二进制，不批准则启动报错。修复：

```powershell
cd D:\pxy\MV-study
npm install-scripts approve esbuild   # 放行 esbuild 的 postinstall
npm rebuild esbuild                   # 重新执行安装脚本
# 之后 npm run dev:all 才能正常起 vite
```

后台启动 `npm run dev:all` 时输出被 `Out-String` 缓冲、`process log` 看不到内容 → **用端口/健康检查验证**而不是读日志：`Get-NetTCPConnection -State Listen | Where-Object LocalPort -in 5173,3001` + `curl http://127.0.0.1:3001/api/health`。

## 本机已知结论（2026-08-13，用户 16543）

- 用户的真实 GitHub 账号是 **`pipykarchu`**（5 个公开仓库：`pikarchu`=皮玺玉个人IP站(Vite)、`pxy-skill-index`=技能索引页、`skils`=Hermes 技能库、`pets`=宠物应用、`app`≈空）。`pxy`（2 个仓库）是另一个账号，**不是**用户的。
- **`MV-study` = 私有仓库，B站视频AI学习助手**（视频片段→带时间戳逐字稿、说话人区分、学习纲要、Mermaid 脑图、PPT 大纲的 Web 工具；Vue3+Vite+Express，前端 5173 / 后端 3001，B站转写需 yt-dlp+ffmpeg）。2026-08-13 已通过 codeload zip 下载到 `D:\pxy\MV-study` 并成功启动（`npm run dev:all`，浏览器 http://localhost:5173）。**不再需要探测名字变体，直接查本行。**
- PAT 已存 `C:\Users\16543\.git-credentials`（用户明确要求 codex/Hermes/reasonix 共用）。后续遇到"我 github 里的 X"先查本表有没有现成仓库，再复用第 1-2.5 步，别重复盲猜用户名。
- 本机可用工具：git 在 `C:\Users\16543\AppData\Local\hermes\git\`，curl 用 `C:\Windows\System32\curl.exe`，node 用 `Get-Command node`（官方版 Hermes 自带 `C:\Users\16543\AppData\Local\hermes\node\node.exe`），Clash 代理 `127.0.0.1:7897`（git 已配 http/https proxy 指向它）。
