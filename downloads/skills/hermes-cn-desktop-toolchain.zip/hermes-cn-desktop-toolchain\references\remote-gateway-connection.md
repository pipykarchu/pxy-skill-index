# Hermes 桌面版连接远端后端（Remote gateway）

来源：官方文档 web-dashboard 页（https://hermes-agent.nousresearch.com/docs/user-guide/features/web-dashboard#connecting-hermes-desktop-to-a-remote-backend），本机排查 2026-08-12。

## 概念（回答"地址在哪找、令牌是哪里的"）

- 桌面版默认自带本地后端；**Remote gateway = 桌面版连到另一台机器上运行的 `hermes dashboard` 进程**（不是消息 gateway/Telegram/飞书通道，那些是独立进程）。
- **远端地址不是本机配置，是远端机器的 dashboard 地址**：`http://<服务器IP或域名>:<端口>`（例 `http://192.168.1.100:9119`）。找部署方要，或自己部署时 `hermes dashboard --host 0.0.0.0 --port 9119 --no-open` 用的就是它。
- **登录凭证是用户名/密码（basic auth provider），配置在远端机器的 `~/.hermes/.env`**：
  ```
  HERMES_DASHBOARD_BASIC_AUTH_USERNAME=admin
  HERMES_DASHBOARD_BASIC_AUTH_PASSWORD=<强密码>
  HERMES_DASHBOARD_BASIC_AUTH_SECRET=<32+ 随机字节；openssl rand -base64 32>
  ```
- **会话令牌无需手动找**：桌面版登录一次后，服务器自动签发 single-use ticket 用于 `/api/ws` 聊天连接。用户口中"回话令牌"通常就是这层登录凭证，答案是"在远端服务器的 .env 里，找部署方要"。

## 桌面版配置路径

Settings → Gateway → Remote gateway → **Remote URL** 填 `http://IP:端口` → **Sign in** 输入用户名/密码。

## 常见失败点（"backend ready 但聊天不通"）

1. 远端 dashboard 必须绑非回环地址 `--host 0.0.0.0`。只绑 `127.0.0.1` 时远端客户端在 socket 层直接被拒，与凭证无关——最常见的连不上原因。
2. **Host 头必须与绑定地址一致**（防 DNS-rebinding 守卫）。URL 里用的主机名/IP 要和 dashboard 绑定的一致。
3. 非回环绑定必须启用认证，未配置 provider 时 dashboard **启动即失败（fails closed）**。
4. `/api/status` 显示 `auth_required: true` 但没有 `basic` provider → `.env` 的认证变量没被加载，先修远端 `.env`。

## 验证命令（任何机器可跑）

```bash
curl -s http://IP:端口/api/status | jq '.auth_required, .auth_providers'
# 期望：true, ["basic"]
```

- `auth_required: false` → 绑定是回环，改 `--host 0.0.0.0`
- `auth_required: true` 无 basic → `.env` 变量缺失

## 排障日志与关闭码

- desktop.log：桌面版 Settings → Gateway → Open logs
- WebSocket 关闭码：**4403** = `/api/ws` 被请求守卫拒绝（Host/peer 不匹配）；**4401** = WS ticket 未认证
