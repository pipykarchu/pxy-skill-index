---
name: hermes-cn-desktop-toolchain
description: "Bootstrap node/npm/lark-cli and run no-Python data scans (Edge history, SQLite) on Windows machines managed by Hermes CN desktop. Use when node/npm/python/lark-cli appear missing from PATH, when npm install -g fails with 'node is not recognized', when you need to read Edge History or SQLite without Python, or when locating a machine's real toolchain paths. Trigger keywords: 'node not found', 'npm install failed', 'lark-cli missing', 'Edge history scan', 'no python', '工具链引导'."
license: MIT
---

# Hermes CN 桌面版工具链引导 & 无 Python 数据扫描（Windows）

> 在 Hermes CN 桌面版（如 0.19.0-cn.7）管理的 Windows 机器上，系统 PATH 往往**没有** node/npm/python/lark-cli，但 Hermes 自带了完整 node 工具链。本技能记录引导方法，以及没有 Python 时读取 Edge 历史 / SQLite 的替代技巧。

## 触发场景

- 命令报 `'node' is not recognized` / `npm` 找不到 / `lark-cli` 不在 PATH
- 用户说"链接了飞书"但 lark-cli 二进制找不到
- 用户说"链接远端服务器/远程后端"、"地址在哪找"、"回话令牌是哪里的"（Hermes 桌面版 Remote gateway 连接问题）
- 需要扫描 Edge 浏览历史或 SQLite 数据库，但机器没有 python
- 旧脚本引用的路径（如 `C:\Users\皮玺玉\AppData\Roaming\npm\...`）在本机不存在

## 第一步：定位 Hermes 内置 node（总是存在）

Hermes CN 桌面版把 node 捆绑在版本目录下：

```powershell
# 通用定位（版本目录随安装版本变）
Get-ChildItem "D:\hermes" -Filter "node.exe" -Recurse -Depth 4 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName
# 实测本机：D:\hermes\data\versions\0.19.0-cn.7\node\node.exe (v22.12.0)
# 同目录还有 npm.cmd / npx.cmd / corepack.cmd
```

Hermes CLI 也在同版本目录：`hermes-agent-cn-runtime-win32-x64.exe`，支持 `--version`、`tools list`、`mcp list`、`plugins list`。

## 第二步：npm 安装 lark-cli（必须先加 PATH）

**⚠️ 关键顺序：先把 node 目录加进当前会话 PATH，再 npm install。** postinstall 脚本要调 `node`，不在 PATH 会报 `'node' is not recognized as an internal or external command`（npm error code 1）。

```powershell
$nodeDir = "D:\hermes\data\versions\0.19.0-cn.7\node"   # 换成第一步实际路径
$env:Path = "$nodeDir;$env:Path"
npm install -g @larksuite/cli
lark-cli auth status --json
```

注意事项：
- **`npm install -g` 会触发 Hermes 终端安全审批**，超时未获用户确认会被 BLOCK（exit -1）。执行前先征得用户明确同意，不要连续重试同一命令。
- 安装失败留下半成品目录时，修好 PATH 重跑即可。
- **授权痕迹判断**：Edge 历史出现 `localhost:4000/api/auth/feishu/callback` = 本机曾跑过 lark-cli OAuth（4000 是 CLI 本地回调端口），先 `auth status` 而不是重新登录。
- 飞书通道排查顺序：`hermes mcp list` → `hermes tools list` → 都没有飞书集成时，只能装 lark-cli 或直接问用户要飞书链接（最快）。

## 第三步：无 Python 读 Edge 历史 / SQLite

没有 python 时用 PowerShell 字节扫描（Edge 运行时 History 文件被锁，先复制）：

```powershell
# 1. 复制被锁的 History 库
Copy-Item "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\History" "$env:TEMP\edge_hist.db" -Force
# 2. 读字节为 UTF8 文本
$bytes = [System.IO.File]::ReadAllBytes("$env:TEMP\edge_hist.db")
$text = [System.Text.Encoding]::UTF8.GetString($bytes)
# 3. 关键词计数（判断今天访问了什么域/工具）
foreach ($k in @('feishu','meeting','docx','wiki','remote','todesk','gameviewer')) {
    $c = ([regex]::Matches($text, $k, 'IgnoreCase')).Count
    if ($c -gt 0) { Write-Output ("$k : $c") }
}
```

### PowerShell 正则陷阱（踩过）

- **`.NET regex 不支持 `\_` 转义**：`'https?://[a-zA-Z0-9\.\-\_/]'` 报 "Unrecognized escape sequence \_"——直接写 `_` 不加反斜杠。
- **大二进制文件上贪婪 URL 正则会超时**：几 MB 的 History 库用 `https?://...{8,200}` 匹配可能 60s 超时。改用 IndexOf 循环提取，或只做关键词计数。
- 写 `.ps1` 文件执行时，正则字符串用单引号、避免反斜杠转义问题；`Invoke-Expression` 包裹的命令更容易触发转义错误，直接写文件更稳。

## 远程工作日的日报扫描注意（配合 daily-report-mozin 使用）

用户当天主要远程操作（如远程配置同事电脑）时，**本地工作目录 0 个文件变更是正常现象，不是扫描失败**。证据改从这些地方找：

- 桌面快捷方式创建时间（如 `C:\Users\<user>\Desktop\GameViewer - 快捷方式.lnk` = 今天装了远程工具）
- Edge 历史关键词计数（feishu/meeting/remote/gameviewer 等）
- 进程启动时间（`Get-Process | Where-Object { $_.StartTime -ge (Get-Date "yyyy-MM-dd") }`）
- Hermes 日志（`D:\hermes\data\hermes-home\logs\agent.log` 当日时间线）

## 飞书接入诊断：快照 ≠ 实时状态（2026-08-12 实测）

桌面端「接入诊断」JSON 里的 `state: disabled` / "网关未运行" 可能是**过期快照**（快照生成时刻之后网关又重启过）。**先验证实时状态再下结论，别让用户重复扫码/重配**：

```powershell
# 1. 进程存活（runtime 进程存在且 Responding=True）
Get-Process | Where-Object { $_.ProcessName -like '*runtime*' } | Select-Object Id, StartTime, Responding
# 2. 心跳新鲜度（updated_at 距今 <60s = 健康）
Get-Content 'D:\hermes\data\hermes-home\state\gateway.heartbeat'
# 3. gateway.log 最近的连接行（出现 "feishu connected" / "Connected in websocket mode" = 已连通）
Get-Content 'D:\hermes\data\hermes-home\logs\gateway.log' -Tail 30
# 4. WebSocket 长连接是否活着（gateway PID 有到 443 的 Established 连接 = 在线）
Get-NetTCPConnection -State Established | Where-Object { $_.OwningProcess -eq <pid> }
```

要点：
- 飞书适配器用 **WebSocket 长连接模式**（`Connected in websocket mode`），不需要本机监听入站端口；`Get-NetTCPConnection -LocalPort 9119` 无结果不代表失败。
- 日志里 `processor not found, type: task.task.update_tenant_v1 / vc.meeting.all_meeting_ended_v1 / application.application.app_version.publish_apply_v6` 是**无害噪音**：飞书推送的租户级事件，Hermes 未订阅对应处理器，不影响收发消息，不用排查。
- 诊断 JSON 的 `issues[].evidence` 常把 "disabled" 与 "网关未运行" 混为一条——同一根因的两种表现，别当成两个问题。
- 真正确认"接入可用"的唯一标准：**用户给机器人发消息收到回复**（im.message.receive_v1 被处理）。
- 用户粘贴 App ID/Secret 时：先比对 `.env` 是否已配置（读文件比对，**不要回显 secret 值**，可输出 `长度/是否匹配` 布尔结果）；已配置则直接告知"无需重新提供"，并提醒 Secret 已暴露在聊天记录、建议飞书后台轮换。

## "打包的用户配置"为什么不在上下文

用户把技能 ZIP / 配置文件夹拷到任意位置（如 `C:\Users\<user>\用户配置包`），以为就"进上下文了"——**Hermes 不会自动读取任意文件夹**。每轮注入的"上下文"只来自三处：

| 来源 | 位置 | 生效方式 |
|---|---|---|
| 记忆 | `HERMES_HOME\memories\MEMORY.md` | 每轮自动注入 |
| 技能 | `HERMES_HOME\skills\` | 按需加载（装进目录即生效，无需重启） |
| 会话历史 | `HERMES_HOME\sessions\` | 当前对话 |

排查顺序：`Get-ChildItem` 看拷贝目标（常是空目录/没拷对位置）→ 对比 `skills\` 下同名技能 SKILL.md 内容是否与 ZIP 一致 → 一致则告知"已安装生效，随时可用"；若用户要的是**用户画像/偏好**，则写入记忆（memory 工具）而非技能。空目录 `Get-ChildItem` 输出 0 条目 + exit_code 1 是正常现象，不是命令失败。

## 参考

- `references/redskill-manual-install-no-python.md` — 无 Python 时从 RedSkill 商店手动安装技能的完整流程（搜索→获取 zip→解压→跨平台同步到 Hermes 和 Codex）
- `references/remote-gateway-connection.md` — Hermes 桌面版 Remote gateway（连接远端 dashboard）完整说明
- `references/feishu-onboarding-diagnosis-2026-08-12.md` — 飞书接入诊断案例
- `references/hermes-cn-desktop-16543-machine-2026-08-12.md` — 本机（用户 16543）实测路径、工具链真相
- `references/lark-cli-auth-split-flow-tips.md` — lark-cli OAuth 授权实操陷阱：设备流超时处理、二维码生成、Split-Flow 完整操作序列（2026-08-13 实测）
- `references/github-identity-discovery-no-gh.md` — 无 gh CLI 时探测 GitHub 身份/仓库流程 + **私有仓库下载完整方案**（curl 管道 ConvertFrom-Json 空对象/解析失败→用内置 node 解析；未认证 repo 级 API 404=私有或不存在；**git clone 私有仓库本机会卡死→codeload zip 直链下载** `curl -u user:PAT https://codeload.github.com/<o>/<r>/zip/refs/heads/main`；PAT 存 ~/.git-credentials codex/Hermes/reasonix 共用；git clone 卡死后残留进程锁目录的清理；**npm 12 阻止 postinstall→`npm install-scripts approve esbuild`+`npm rebuild esbuild`**；后台进程验证用端口/health 而非读日志；用户真实账号=pipykarchu，MV-study=私有已下载到 D:\pxy\MV-study）
- lark-cli 具体命令与坑：`lark-cli` / `windows-powershell-lark-cli-integration` 技能（手动编写，勿自动修改）
- 日报格式与流程：`daily-report-mozin` 技能（手动编写，勿自动修改）
