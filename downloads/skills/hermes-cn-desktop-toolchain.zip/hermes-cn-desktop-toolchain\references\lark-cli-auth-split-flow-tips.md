# lark-cli OAuth 授权实操陷阱（2026-08-13 实测）

> 补充 `lark-shared` 技能中 Split-Flow 协议之外的实操经验。

## 一、完整 triage 流程（实测 3 轮才成功）

```
首次: `lark-cli auth login --recommend`           → PTY 模式, 120s timeout → 超时
  ↓ 用户说"好了"
第二次: 重新 `--recommend`                          → 生成新链接（旧链接过期）→ 超时
  ↓ 用户说"好了"
第三次: `--recommend --no-wait --json` → 拿到 device_code + verification_url
  → 生成二维码给用户 → 用户扫码
  → `auth login --device-code <code>` → 成功
```

**教训：** 首次尝试不应是 `--recommend`（会阻塞并在超时时作废 device_code）。**永远先走 `--no-wait --json`**，让用户先行授权。

## 二、二维码生成

```powershell
# 注意：URL 是 positional arg，不是 --url flag
lark-cli auth qrcode -o "feishu_auth_qr.png" "https://accounts.feishu.cn/oauth/v1/device/verify?flow_id=xxx&user_code=xxx"
```

但 `--output` 需要相对路径。导出后用 `MEDIA:/absolute/path/file.png` 展示。

## 三、Split-Flow 完整操作序列

### 当前轮（展示给用户）

```powershell
# Step 1: 拿到 device_code + verification_url
lark-cli auth login --recommend --no-wait --json
# → { device_code, verification_url, expires_in: 600 }

# Step 2: 生成二维码
lark-cli auth qrcode -o "<relative-path>.png" "<verification_url>"
```

然后展示 URL + 图片，**结束本轮**让用户去扫码。

### 下一轮（用户说"好了"后）

```powershell
# 从上一轮的 JSON 中拿到 device_code
lark-cli auth login --device-code "<device_code>"
# 这会轮询直到授权完成或过期
```

如果有 `auth status` 的 `verified: true`，也可跳过 `--device-code` 直接继续工作。

## 四、关键：同一轮只展示，不要阻塞执行 device-code

**不要在同一轮展示 URL 后立刻再执行 `--device-code`。** 每次重启 `auth login` 会作废上一轮的 device code。正确的分轮：

- **当前轮**：`--no-wait --json` → 展示 URL + 二维码 → 结束本轮
- **下一轮**（用户说"好了"）：`--device-code <code>` → 完成授权

如果上一轮的 device_code 已过期（10分钟），重新回到第一轮重新获取。

## 五、Powershell 路径注意事项

内置 node 的路径每次要通过 `Get-ChildItem D:\hermes\data\versions -Directory | Select-Object -Last 1` 动态定位，因为版本目录名会变。不要硬编码 `0.19.0-cn.7`。