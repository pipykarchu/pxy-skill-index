---
name: agents-md-generator
version: 1.0.0
description: "为项目生成/定制 AGENTS.md 并安装到 Codex(~/.codex/AGENTS.md)和 Hermes(工作区根)。触发词：AGENTS.md、装进codex、装进Hermes、agent规则、项目规则、省token规则。核心原则：分层——全局版放通用纪律，项目版只放项目特有事实，避免重复加载浪费 token。"
---

# AGENTS.md 生成器（省 token + 少出错）

## 何时用

用户要求：生成 AGENTS.md / 装进 Codex / 装进 Hermes / 给 agent 定规则 / 省 token 规则。

## 核心原则（最重要）

**分层，不重复**：
- Codex 是**全局规则 + 项目规则叠加**（`~/.codex/AGENTS.md` 全局 + 项目根 `AGENTS.md`）。
- Hermes 读**当前工作区根**的 AGENTS.md（无全局叠加概念，但可在常用工作区各放一份）。
- **项目版只放全局没有的内容**：项目事实 + 项目特有坑。通用纪律（上下文限量/操作原则/Windows 坑）放全局版。
- 验证：每个 AGENTS.md 会被**每次会话**加载，越短越省 token。项目版目标 <2KB。

## 步骤

### 1. 拉 agents-md 模板（可选，借鉴规则）

```powershell
curl.exe -sk --connect-timeout 15 "https://raw.githubusercontent.com/Austin1serb/agents-md/main/AGENTS.md"
```
要点：字节上限命令输出（`head -c 4000` → PowerShell 用 `Select-Object -First 40` 或 `$o.Substring(0,[Math]::Min(4000,$o.Length))`）、窄查询、验证匹配风险、最小改动。
注：GitHub API (`api.github.com`) 在用户网络常被拦（SSL 错误 exit 35），用 raw.githubusercontent.com 直连。

### 2. 采集项目事实（不探索，只查关键文件）

- `package.json`：技术栈、scripts（测试命令！）、端口
- 顶层目录结构（排除 node_modules/dist/.git）
- `handoff.md` 或 README 的约定（Git 凭据、启动方式、权限模型）
- 已有 `~/.codex/AGENTS.md` 和项目根 AGENTS.md —— **追加不覆盖**，保留用户原有规则（如生图路由、Gitea 凭据）

### 3. 写文件（三个位置）

| 文件 | 内容 |
|------|------|
| 项目根 `AGENTS.md` | 项目事实 + 项目铁律（双份代码同步/内存库重启/测试命令/坑库链接），<2KB |
| `~/.codex/AGENTS.md` | 追加"全局纪律"段（上下文限量、坑库索引、操作原则、Windows 坑） |
| Hermes 工作区根 | 通用纪律版（不带项目细节，避免污染其他任务） |

### 4. 坑库索引（不内联内容）

- 链接本机跨项目坑库 `坑库.md`（K001+，5要素：现象/根因/规避/项目/日期；位置见项目 handoff 或用户本机约定目录）
- 规则：疑似已知问题先查 K 编号 → 命中直接按规避执行；新坑按 5 要素追加
- 高发坑速查内联 3-4 条即可（K003 长参数被拆→subprocess、K004 exit_code 误报→看输出、K002 中文路径→ASCII workdir、乱码→-Encoding UTF8）

### 5. 验证

- `Get-Content -Encoding UTF8` 读回确认**无乱码**（中文 Windows 必查）
- 检查字节数（项目版 <2KB）
- 注意：PowerShell 管道 exit_code=1 是误报（K004），看输出内容判断

## 陷阱

- `api.github.com` 被网络拦截 → 用 raw.githubusercontent.com
- 不要覆盖已有 `~/.codex/AGENTS.md`（用户有生图路由/Gitea 凭据），用 patch 追加
- 双份代码项目（开发副本+部署副本）必须写"改代码同步两份"铁律
- sql.js 内存库项目必须写"数据层改动后重启验证"
- 模板是 bash 语法，PowerShell 环境必须转写
