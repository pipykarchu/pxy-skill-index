# Skill 安装说明

包：`agents-md-generator`　版本：`1.0.0`

## 安装前检查

1. 将 ZIP、同名 `.zip.sha256` 放在同一目录。
2. Windows PowerShell 运行 `Get-FileHash .\<包名>.zip -Algorithm SHA256`，与 `.zip.sha256` 第一列比较。
3. macOS/Linux 运行 `sha256sum <包名>.zip`，与 `.zip.sha256` 第一列比较。
4. 先解压到临时目录并阅读 `manifest.json`；发现同名 Skill 时停止，不要直接覆盖。

## 平台目录

- Codex：`${CODEX_HOME}/skills`；未设置时使用 `~/.codex/skills`。

复制 `common/skills/<技能名>` 到目标平台 Skill 根目录；复制目标平台下的 `platform/<平台>/skills/pm-workflow-router` 到该平台 Skill 根目录。完成后新开会话或按平台要求重启。

## 包含的 Skill

- `agents-md-generator`，角色：primary
- `project-handoff-core`，角色：handoff
- `pm-workflow-router`，角色：router，平台：codex

成功标志：新会话能发现目标 Skill；随后再按 `VERIFY-自动触发验收.md` 独立验证自动调用。
