# Relay Endpoint Profiles (verified 2026-08-13)

Per-endpoint facts gathered while configuring the official Hermes v0.20.0
desktop install with Chinese new-api relays. All probes run from the official
Hermes venv python (`...\hermes-agent\venv\Scripts\python.exe`) unless noted —
PowerShell `Invoke-RestMethod` and `curl.exe` got TLS connection resets on
these hosts while urllib/openai SDK succeeded.

## 兔子 — apisz.ourzhishi.top (new-api panel)

- Base URL for API: `https://apisz.ourzhishi.top/v1` — the `/v1` suffix is
  REQUIRED. Without it the panel returns its HTML web UI (HTTP 200,
  `text/html`, contains `<meta name="New-Api-Version" ...>`), and Hermes
  reports `EmptyStreamError` / "Provider returned an empty stream with no
  finish_reason".
- Model verified working: `claude-opus-4-6` (supports tools + streaming +
  `json_schema` response_format + `response_format: json_object`).
- Stream responses begin with a `: ping` keep-alive comment line before
  `data:` chunks — openai SDK handles it fine.
- **Flaky**: identical requests vary from ~4s to 240s+ hangs. Non-deterministic
  slowness ≠ config bug; retry before touching config.
- Host resolves to `47.106.212.129` (Aliyun), TLS handshake often reset from
  this machine's direct connections (proxy at `127.0.0.1:7897` exists but didn't
  help TLS either).

## mozin — api.accspark.cn (relay for DeepSeek)

- Base URL: `https://api.accspark.cn/v1`.
- Model name is case-sensitive: `DeepSeek-V4-Flash` (NOT `deepseek-v4-flash`;
  lowercase returns HTTP 404 `MODEL_NOT_FOUND`).
- **Supports `json_schema` response_format** (unlike DeepSeek official) — used
  for Hermes `auxiliary.title_generation`. Fast (~0.6s). Response reports
  `"_detection": {"modelMismatch": true, "reportedModel": "DeepSeek-V4-Flash-INT8"}`.
- Key is 70 chars, `sk_mz_...` prefixed.

## DeepSeek official — api.deepseek.com

- Base URL: `https://api.deepseek.com/v1`.
- **Rejects `json_schema` response_format**: HTTP 400
  `{"error":{"message":"This response_format type is unavailable now","type":"invalid_request_error"}}`.
  Only `json_object` works. → cannot serve Hermes title_generation; fine for
  compression/web_extract (plain text tasks).
- `deepseek-v4-flash` context = 1,000,000 tokens (model_metadata catalog), safe
  as compression model under a 200K-1M main model.

## Exact error strings (grep targets for future sessions)

| Symptom | Meaning | Fix |
|---|---|---|
| `Provider returned an empty stream with no finish_reason (possible upstream error or malformed SSE response)` | base_url missing `/v1`, or relay returned HTML/empty | add `/v1` to base_url |
| `Completions.create() got an unexpected keyword argument 'speed'` | `agent.service_tier: fast` persisted in config.yaml | remove `agent:` block |
| `HTTP 400: This response_format type is unavailable now` | endpoint doesn't accept `json_schema` (DeepSeek official) | route task to relay that accepts it, or accept local fallback |
| `MODEL_NOT_FOUND` / `404` | model id wrong/case-sensitive (mozin) | use exact model name |
| `Config version outdated (v0 → v34)` in doctor | `_config_version` missing/stale | add `_config_version: 34` (0.20.0) |
| `Auxiliary title_generation: using custom (DeepSeek-V4-Flash) at https://api.accspark.cn/v1/` | title task correctly routed to mozin | — (PASS signal) |

## Final working config (official Hermes, 2026-08-13)

```yaml
_config_version: 34
display:
  language: zh
providers:
  custom:apisz-ourzhishi-top:
    name: 兔子
    base_url: https://apisz.ourzhishi.top/v1
    api_mode: chat_completions
    transport: openai_chat
    model: claude-opus-4-6
    models:
      claude-opus-4-6:
        supports_tools: true
    api_key: sk-...
model:
  default: claude-opus-4-6
  provider: custom:apisz-ourzhishi-top
  base_url: https://apisz.ourzhishi.top/v1
  api_mode: chat_completions
  api_key: sk-...
auxiliary:
  compression:
    provider: deepseek
    model: deepseek-v4-flash
  web_extract:
    provider: deepseek
    model: deepseek-v4-flash
  title_generation:
    provider: custom
    model: DeepSeek-V4-Flash
    base_url: https://api.accspark.cn/v1
    api_key: sk_...
```

Backups of each edit were kept in the official config dir as
`config.yaml.bak-<reason>-<yyyyMMdd-HHmmss>` (5 backups total across the
session: rabbit, rabbit2, before-v1fix, aux, title-mozin, servicetier).

## CN desktop note

CN desktop config (`D:\hermes\data\hermes-home\config.yaml`) has the same
providers (`custom:apisz-ourzhishi-top` = 兔子, `custom:api-accspark-cn` =
mozin) but still lacks the `/v1` fix and may carry the `service_tier: fast`
problem — same fixes apply there if the CN desktop shows EmptyStreamError.
