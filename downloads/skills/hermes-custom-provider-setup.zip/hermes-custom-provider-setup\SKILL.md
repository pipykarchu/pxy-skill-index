---
name: hermes-custom-provider-setup
description: "Configure Hermes (official CLI/desktop or CN desktop) with custom OpenAI-compatible relay providers (new-api / one-api style endpoints like apisz.ourzhishi.top 兔子, api.accspark.cn mozin), pick cost-optimal auxiliary models, and fix the classic failure modes (EmptyStreamError, base_url missing /v1, service_tier breaking the endpoint, json_schema response_format 400). Triggers: 配模型/配provider/兔子/中转, EmptyStreamError, response_format type is unavailable, auxiliary 模型, Hermes 辅助模型性价比."
version: 1.0.0
license: MIT
platforms: [windows, macos, linux]
metadata:
  hermes:
    tags: [hermes, provider, relay, new-api, auxiliary, config, china]
---

# Hermes Custom Provider Setup (relay / new-api 中转)

Configuring Hermes with an OpenAI-compatible relay endpoint (new-api / one-api
panel, e.g. `apisz.ourzhishi.top` "兔子", `api.accspark.cn` "mozin") and tuning
auxiliary models for cost. Written from a real 2026-08 session on the official
Hermes v0.20.0 desktop install on Windows.

## Key environment facts (this machine)

- **Official Hermes**: `C:\Users\16543\AppData\Local\hermes` is its HERMES_HOME.
  - exe: `C:\Users\16543\AppData\Local\hermes\hermes-agent\bin\hermes.exe`
  - config: `C:\Users\16543\AppData\Local\hermes\config.yaml`
  - venv python: `C:\Users\16543\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe`
- **CN desktop**: `D:\hermes\data\hermes-home` (separate config, separate runtime).
- `hermes config path` reads `$env:HERMES_HOME` — clear it (`$env:HERMES_HOME=""`) in
  a shell before driving the official exe, or it will read the CN config.
- Config secrets live in `config.yaml` `api_key:` fields (CN desktop) or `.env`
  (official). Keys in config.yaml are redacted in tool output but real on disk.

## Adding a custom relay provider

Config shape (official v0.20.0, `_config_version: 34`):

```yaml
_config_version: 34
providers:
  custom:apisz-ourzhishi-top:
    name: 兔子
    base_url: https://apisz.ourzhishi.top/v1   # ← MUST include /v1 (see pitfall 1)
    api_mode: chat_completions
    transport: openai_chat
    model: claude-opus-4-6
    models:
      claude-opus-4-6:
        supports_tools: true
    api_key: sk-...
model:
  default: claude-opus-4-6
  provider: custom:apisz-ourzhishi-top
  base_url: https://apisz.ourzhishi.top/v1
  api_mode: chat_completions
  api_key: sk-...
```

Then verify: `hermes config` (Model line shows the provider), then
`hermes chat -q "hi" --yolo` must return a real answer.

## Cost-optimal auxiliary model routing

`auxiliary.<task>.provider/model/base_url/api_key` overrides per side-task.
Defaults ("auto") route aux tasks to the MAIN model — expensive if main is a
frontier model. Cheap text tasks on DeepSeek-V4-Flash (1M ctx, ~free) worked
well:

```yaml
auxiliary:
  compression:
    provider: deepseek          # deepseek is a built-in provider id (DEEPSEEK_API_KEY in .env)
    model: deepseek-v4-flash
  web_extract:
    provider: deepseek
    model: deepseek-v4-flash
  title_generation:
    provider: custom            # DeepSeek official rejects json_schema → use mozin relay
    model: DeepSeek-V4-Flash
    base_url: https://api.accspark.cn/v1
    api_key: sk_...
  # vision: leave auto → main model (only provider here with image input)
```

- `auxiliary.compression.model` must have context ≥ main model (DeepSeek-V4-Flash
  is 1M, safe under a 200K/1M main).
- `auxiliary.vision` stays `auto` because DeepSeek has no vision; the auto chain
  falls back to the main model.
- Tasks seen in `hermes config` output: Context Compression, Vision, Web extract;
  title_generation appears in agent.log ("Auxiliary title_generation: using ...").
- Editing config.yaml while a gateway runs: config changes hot-reload for
  compression/context keys; API keys/tools need restart. For CLI tests, each
  invocation is fresh.

## Pitfalls (all hit in the real session)

1. **base_url MUST end in `/v1`.** new-api panels serve the JSON API at
   `/v1/chat/completions`; without `/v1` the same key hits the panel's web UI
   (HTTP 200 `text/html`!) and Hermes reports
   `Provider returned an empty stream with no finish_reason` / EmptyStreamError.
   The API key is NOT the problem — the path is. Probe:
   `curl https://host/v1/chat/completions` (JSON) vs `https://host/chat/completions` (HTML).
2. **`agent.service_tier: fast` breaks relay endpoints.** The desktop `/fast`
   command writes `agent: {service_tier: fast}` into config.yaml; Hermes then
   sends a `speed` kwarg the relay doesn't accept →
   `Completions.create() got an unexpected keyword argument 'speed'` (fails the
   MAIN conversation, not just aux). Remove the `agent:` block for relays.
3. **DeepSeek official API rejects `json_schema` response_format** with HTTP 400
   `This response_format type is unavailable now` (only `json_object` works).
   Hermes title_generation sends `json_schema` → must route title_generation to
   a relay that accepts it (mozin/accspark does, verified). The title then
   falls back to a local rule, so failure is non-fatal but noisy.
4. **Relay endpoints are flaky**: same config succeeds in 8s then hangs 240s on
   the next call. Distinguish transient slowness (retry) from config errors
   (deterministic 400/EmptyStreamError) before changing config.
5. **PowerShell's HTTP stack can't be trusted for probes here** —
   `Invoke-RestMethod`/`curl.exe` got TLS resets while the Hermes venv python
   (urllib/openai SDK) succeeded. Use the venv python for connectivity tests.
6. `_config_version` should match the Hermes version's default (v34 on 0.20.0);
   `hermes doctor` warns "Config version outdated" otherwise (harmless but noisy).

## Debugging technique: capture Hermes' real request

Point the provider `base_url` at a local recording proxy to see exactly what
Hermes sends (path, headers, body) — this is how the missing `/v1` and the
`speed` kwarg were found:

```
scripts/recording_proxy.py   # python http.server on 127.0.0.1:8899, logs POSTs, relays to real host
```

Then set base_url → `http://127.0.0.1:8899` temporarily, run the failing
command, read the printed request, restore the real base_url. See
`references/relay-endpoint-profiles.md` for endpoint-specific findings.

## Verification checklist

1. `hermes config` shows the intended Model/provider and aux overrides.
2. `hermes chat -q "Reply with exactly: X" --yolo` returns X (main path).
3. `logs\agent.log` shows `Auxiliary title_generation: using custom (...)` →
   verify it routed to the intended endpoint and no `Title generation failed`.
4. `hermes doctor` — no config-version complaint after adding `_config_version`.

## Support files

- `references/relay-endpoint-profiles.md` — per-endpoint facts (rabbit/mozin/deepseek), exact error strings, full final config.
- `scripts/recording_proxy.py` — local recording proxy to capture Hermes requests.
