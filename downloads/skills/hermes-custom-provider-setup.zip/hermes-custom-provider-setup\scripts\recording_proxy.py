#!/usr/bin/env python3
"""Recording proxy for capturing what Hermes (or any client) actually sends.

Run on 127.0.0.1:8899, point the Hermes provider `base_url` at
`http://127.0.0.1:8899`, reproduce the failing call, then restore the real
base_url. Prints request path/headers/body and the relayed response (with gzip
decompression + chunked streaming) so you can see e.g. a missing `/v1` prefix
or an unexpected `speed` kwarg.

Usage:
    python recording_proxy.py            # listens on 127.0.0.1:8899
    # optionally change the upstream:
    $env:RECORD_PROXY_UPSTREAM="https://apisz.ourzhishi.top" ; python recording_proxy.py
"""
import gzip
import http.server
import json
import os
import sys
import urllib.request

UPSTREAM = os.environ.get("RECORD_PROXY_UPSTREAM", "https://apisz.ourzhishi.top")
LISTEN_PORT = int(os.environ.get("RECORD_PROXY_PORT", "8899"))


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Length", "2")
        self.end_headers()
        self.wfile.write(b"ok")

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length else b""
        print(f"\n{'='*70}\n>>> POST {self.path}")
        print("HEADERS:", json.dumps(
            {k: v for k, v in self.headers.items()
             if k.lower() in ("authorization", "content-type", "accept", "user-agent")},
            ensure_ascii=False)[:500])
        try:
            parsed = json.loads(body)
            print("BODY keys:", list(parsed.keys()))
            interesting = {k: parsed[k] for k in parsed
                           if k in ("model", "stream", "stream_options",
                                    "response_format", "temperature",
                                    "max_tokens", "speed", "tools")}
            print("BODY:", json.dumps(interesting, ensure_ascii=False)[:1500])
        except Exception:
            print("BODY(raw):", body[:500])

        fwd_headers = {k: v for k, v in self.headers.items()
                       if k.lower() not in ("host", "connection", "content-length",
                                            "accept-encoding", "transfer-encoding")}
        req = urllib.request.Request(UPSTREAM + self.path, data=body,
                                     headers=fwd_headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=180) as resp:
                data = resp.read()
                ctype = resp.headers.get("Content-Type", "")
                cenc = resp.headers.get("Content-Encoding", "")
                print(f"<<< HTTP {resp.status} CT={ctype} CEnc={cenc} len={len(data)}")
                payload = data
                if cenc == "gzip":
                    try:
                        payload = gzip.decompress(data)
                        print("  (decompressed gzip ->", len(payload), "bytes)")
                    except Exception as e:
                        print("  gzip decompress failed:", e)
                if "event-stream" in ctype:
                    print("  STREAM head:", payload[:400].decode("utf-8", "replace"))
                else:
                    print("  BODY:", payload[:400].decode("utf-8", "replace"))
                # Relay back (chunked for streams so the client sees chunks live)
                self.send_response(resp.status)
                self.send_header("Content-Type", ctype)
                self.send_header("Transfer-Encoding", "chunked")
                self.end_headers()
                for chunk in [payload[i:i + 8192] for i in range(0, len(payload), 8192)]:
                    if chunk:
                        self.wfile.write(f"{len(chunk):X}\r\n".encode() + chunk + b"\r\n")
                self.wfile.write(b"0\r\n\r\n")
                self.wfile.flush()
        except urllib.error.HTTPError as e:
            body_err = e.read()
            print(f"<<< HTTP ERROR {e.code}: {body_err[:400].decode('utf-8', 'replace')}")
            self.send_response(e.code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body_err)))
            self.end_headers()
            self.wfile.write(body_err)
            self.wfile.flush()
        except Exception as e:
            print("forward error:", type(e).__name__, e)
            self.send_response(502)
            self.send_header("Content-Length", "2")
            self.end_headers()
            self.wfile.write(b"{}")

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    server = http.server.HTTPServer(("127.0.0.1", LISTEN_PORT), Handler)
    print(f"recording proxy on 127.0.0.1:{LISTEN_PORT} -> {UPSTREAM}", flush=True)
    server.serve_forever()
