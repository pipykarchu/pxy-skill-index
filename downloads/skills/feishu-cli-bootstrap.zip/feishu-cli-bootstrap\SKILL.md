---
name: feishu-cli-bootstrap
description: "lark-cli (飞书 CLI) 在 Hermes 桌面环境下的全新机器引导（安装/绑定/授权）、妙记→日报量化采集、权限与验证。当系统无 node/npm/lark-cli、lark-cli 报 not bound、需要绑定时报错、需要读取飞书妙记/会议纪要补充日报、生成授权二维码、或写含中文的验证脚本时使用。"
version: 1.0.0
license: MIT
tags:
  - feishu
  - lark
  - lark-cli
  - bootstrap
  - minutes
  - daily-report
  - windows
trigger:
  - "lark-cli 安装"
  - "配置飞书"
  - "绑定"
  - "授权"
  - "妙记"
  - "会议纪要"
  - "二维码"
---

# lark-cli 引导、授权与妙记采集（Hermes 桌面环境）

> 在 Hermes CN 桌面版上从零接通飞书：安装 → 绑定 → 授权 → 用妙记补日报量化。
> 2026-08-12 在全新机器上完整走通（Mozin APP 2.0 边界对齐会，86 分钟妙记）。

## 1. 全新机器引导（系统无 node / npm / lark-cli 时）

Hermes 桌面版自带完整 node 运行时，无需系统安装 node：

```powershell
# 内置 node/npm 位置（版本目录号可能变化，用 Get-ChildItem 找最新的）
$nodeDir = "D:\hermes\data\versions\0.19.0-cn.7\node"   # 含 node.exe + npm.cmd + npx.cmd
$env:Path = "$nodeDir;$env:Path"

# 安装 lark-cli（必须 PATH 里有 node，否则 postinstall 报 'node' is not recognized）
cmd /c "`"$nodeDir\npm.cmd`" install -g @larksuite/cli"
# → 装到 $nodeDir\lark-cli.cmd
```

⚠️ `npm install -g` 时 postinstall 报 `'node' is not recognized` = npm.cmd 找不到
node，把 nodeDir 加进 PATH 重试即可，不是网络问题。

## 2. 绑定（bind）与授权（auth login）

```powershell
$env:HERMES_HOME = "D:\hermes\data\hermes-home"   # 绑定必需，不设报 not bound

# 状态检查：报 "hermes context detected but lark-cli is not bound to it" → 未绑定
lark-cli auth status --json

# 绑定（拉个人妙记/日历/任务必须 user-default；bot-only 读不到个人资源）
lark-cli config bind --source hermes --identity user-default
# 输出 {"app_id":"cli_xxx","identity":"user-default","ok":true} 即成功

# 授权（阻塞式，打印 verification_url 等待用户在浏览器完成）
lark-cli auth login --recommend
```

**⚠️ Hermes 安全审批层会拦截 bind / auth login 等写操作命令**（agent 会话内多次
BLOCKED: "Command timed out without user response"）。绕过路径：

1. agent 会话内只执行只读命令（`config bind --help`、`auth status` 没问题）；
2. **写操作（bind、auth login）让用户在自己的终端执行**，命令原样贴给用户：
   ```powershell
   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned -Force   # 解决 .ps1 被禁运行
   $env:Path = "D:\hermes\data\versions\0.19.0-cn.7\node;$env:Path"
   $env:HERMES_HOME = "D:\hermes\data\hermes-home"
   lark-cli config bind --source hermes --identity user-default
   ```
3. 授权链接：verification_url 必须**原样**发给用户在浏览器打开（不要 agent 自己
   browser_navigate 打开，授权必须在用户浏览器完成）。

**二维码生成**（可选，方便手机扫码）：
```powershell
# ⚠️ --output 只接受当前目录内相对路径，绝对路径被拒（unsafe output path）
cd <工作目录>
lark-cli auth qrcode "<verification_url>" --output lark_qr.png
# qrcode 第一个位置参数就是 URL（不是 --url 传参），--output 无参数时也报错
```

## 3. 妙记 → 日报量化（已验证）

```powershell
# 1. 搜索自己的妙记（--participant-ids 用 auth status 里的 open_id）
lark-cli minutes +search --participant-ids <open_id> --start 2026-08-05 --as user
# → items[].token = minute_token；display_info 含标题/开始时间/时长

# 2. 读详情（--minute-tokens 是复数参数名；--summary --todo --chapter 显式声明）
lark-cli minutes +detail --minute-tokens <token> --summary --todo --chapter --as user
# → chapters[].title + summary_content（AI 分章摘要，可直接当证据）
# → summary（全文总结）、todos[]（含 content + is_done + todo_id）
```

**→ 日报映射规则：**
- `chapters[].summary_content` 提取**量化决策**（人数、时长、周期、剔除功能清单）
  → 写进分项「量化/产出」段；
- `todos[]` 中 `@本人` 且 `is_done:false` → 「明日计划」条目，证据写 `妙记待办 <todo_id>`；
- 妙记链接 `https://<租户>.feishu.cn/minutes/<token>` → 分项「证据」；
- 会议时长（display_info「时长: 1 小时 26 分 42 秒」）→ 量化；
- 妙记 AI 总结可引，但「提炼/重述」要基于 chapters/transcript 独立写，不照搬。

**权限坑：** `calendar +agenda` 需要 `calendar:calendar.event:read` scope，新绑定
app 可能缺（报 missing_scope）。**不要卡在日历上**——妙记 +search 已能覆盖
"今天开了什么会"，缺 scope 时跳日历用妙记。

## 4. 验证脚本：中文内容用 node 写，不要 write_file 写 .ps1

`write_file` 写含中文的 .ps1，PowerShell 5.1 按 ANSI 解析直接乱码（反复踩中）。
替代：用 Hermes 内置 node 写 .js 验证脚本（原生 UTF-8）：

```javascript
// Temp\hermes-verify-<name>.js —— 校验日报关键字段 + lark-cli 通道
const fs = require('fs');
const content = fs.readFileSync('D:/pxy/.../日报.md', 'utf8');
// ...检查日期/抄送/妙记链接/阻塞项等关键字符串
```
运行：`cmd /c ""<nodeDir>\node.exe" <script.js>"`，跑完删除脚本。

## 5. 常用只读命令速查（agent 会话内可直接执行）

```powershell
lark-cli auth status --json                     # 身份/scope/token 状态
lark-cli contact +get-user --as user            # 自己的 open_id
lark-cli minutes +search --participant-ids <me> --start YYYY-MM-DD --as user
lark-cli task +get-my-tasks --as user           # 今日任务
lark-cli config bind --help                     # 绑定帮助（只读）
```

## 参考文件

- `references/fresh-machine-bootstrap-and-minutes-to-report-2026-08-12.md` — 本次完整验证记录（含 BLOCKED 审批日志、qrcode 相对路径报错、妙记 JSON 结构）
