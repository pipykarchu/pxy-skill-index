# 2026-08-12 完整验证记录

Hermes CN 桌面版 (`D:\hermes\data\versions\0.19.0-cn.7`) 从零接通飞书的全过程记录。
用途：复现/排查参考，含实际报错原文。

## 环境事实

- 系统 PATH 无 node / npm / lark-cli / python（`where.exe` 全部找不到）
- Hermes 内置 node：`D:\hermes\data\versions\0.19.0-cn.7\node\node.exe`（v22.12.0）+ npm.cmd
- lark-cli 全局安装到 `D:\hermes\data\versions\0.19.0-cn.7\node\lark-cli.cmd`
- HERMES_HOME：`D:\hermes\data\hermes-home`
- 绑定后 app_id：`cli_aadcbfdb323adcb3`，identity：user-default
- 用户：皮玺玉，open_id：`ou_7d05b327389c521f51426312ac5c9e2b`
- 旧脚本引用的 `C:\Users\皮玺玉\AppData\Roaming\npm\...` 是另一台机器的路径，本机无效

## 实际报错原文

### 1. postinstall 找不到 node

```
npm error command C:\WINDOWS\system32\cmd.exe /d /s /c node scripts/install.js
npm error 'node' is not recognized as an internal or external command,
```
→ 修复：`$env:Path = "$nodeDir;$env:Path"` 后重装成功（added 7 packages in 18s）

### 2. 未绑定

```
"type": "config", "subtype": "not_configured",
"message": "hermes context detected but lark-cli is not bound to it",
"hint": "run `lark-cli config bind --help`, then ask the user to confirm intent
and identity preset (bot-only or user-default); only after both are confirmed,
run `lark-cli config bind`"
```

### 3. Hermes 安全审批层 BLOCKED（agent 会话内执行 bind 时）

```
BLOCKED: Command timed out without user response. The user has NOT consented
to this action. Do NOT retry this command...
```
→ 即使 `--help` 通过（只读），实际 bind 写操作反复被拦。
→ 绕过：用户在**自己的终端**执行（配合 Set-ExecutionPolicy + HERMES_HOME）。

### 4. 用户在终端遇到 .ps1 被禁

```
无法加载文件 ...\lark-cli.ps1，因为在此系统上禁止运行脚本
+ CategoryInfo: SecurityError, FullyQualifiedErrorId: UnauthorizedAccess
```
→ `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned -Force` 解决

### 5. qrcode --output 绝对路径被拒

```
"unsafe output path: --output must be a relative path within the current
directory, got \"D:\\...\\lark_qr.png\" (hint: use a relative path like ./filename)"
```
→ `cd <工作目录>` 后用 `--output ./lark_qr.png`
→ 另外注意 qrcode 需要 URL 作为位置参数，裸跑 `auth qrcode --output x.png` 报
  `"accepts 1 arg(s), received 0"`

### 6. calendar 缺 scope

```
"missing required scope(s): calendar:calendar.event:read"
```
→ 新绑定 app 可能缺日历 scope。跳过日历，用妙记 +search 替代（本次成功拿到
  会议信息），不阻塞日报流程。

## 妙记返回结构（本次实际数据）

### +search 返回（items 数组）

```json
{
  "display_info": "Mozin APP 2.0边界对齐会\n关键词: ... 所有者: 皮玺玉 开始时间: 2026.08.12 10:31:20 时长: 1 小时 26 分 42 秒",
  "meta_data": { "app_link": "https://dcna5xbs8p29.feishu.cn/minutes/obcndu76pwh52i182so913me" },
  "token": "obcndu76pwh52i182so913me"
}
```

### +detail 返回（--summary --todo --chapter）

```json
{
  "minute_token": "obcndu76pwh52i182so913me",
  "title": "Mozin APP 2.0边界对齐会",
  "note_id": "7672989150018194711",
  "artifacts": {
    "chapters": [
      { "start_ms": "0", "stop_ms": "214000",
        "summary_content": "本章节...", "title": "AI消费中心相关产品能力连接与业务推进讨论" }
    ],
    "summary": "视频围绕...\n- **APP 2.0整体规划...**",
    "todos": [
      { "content": "功能决策沟通：... @皮玺玉", "is_done": false,
        "todo_id": "1786503947211736265" }
    ]
  }
}
```

→ 本次 24 个章节全部有 AI 摘要，2 条待办（@皮玺玉、is_done:false），全部直接
  映射进日报「明日计划」+「协调帮助」。

## 验证方法（ad-hoc）

- 无 canonical test/lint/build 命令（纯文档 + CLI 采集工作流）
- 用 node 脚本（原生 UTF-8）检查：日报文件存在 + 关键字段（日期/抄送/妙记链接/
  时长/待办/阻塞项）+ lark-cli auth status 有效
- 验证后清理所有临时脚本（lark_*.ps1、check_*.ps1、minute_detail.json、qr png）
