---
name: "hifi-layout-template"
description: "Generates structured Figma layout specifications for common page types including dashboards, lists, forms, detail views, and marketing pages. Invoke when user needs page layout blueprints for HiFi prototype design."
license: MIT
---

# HiFi Layout Template Generator

This skill generates **pixel-precise Figma layout specification documents** for common web and mobile page types. Outputs include responsive breakpoints, grid systems, Auto Layout structure, and component placement maps that designers can directly build in Figma.

## When to Invoke

- When designing a new page and need a proven layout blueprint
- When user asks for dashboard, list view, form, or detail page structure
- When establishing page templates for a design system
- After generating a style guide (hifi-style-guide) — apply those tokens to these layouts

## Input Parameters (Ask User First)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `page_type` | Yes | dashboard | One of: `dashboard`, `list_view`, `form_view`, `detail_view`, `marketing_landing`, `pricing`, `settings`, `empty_state`, `error_state` |
| `platform` | Yes | web | `web`, `mobile`, `both` |
| `sidebar_present` | No | true | For web: include left navigation sidebar? |
| `header_style` | No | standard | `standard`, `compact`, `sticky`, `minimal` |
| `density` | No | comfortable | `compact`, `comfortable`, `spacious` |

---

## Global Layout Foundations

First, define the base grid and responsive system regardless of page type.

### 1. Breakpoint System

| Breakpoint | Min Width | Max Width | Grid Columns | Gutter | Margin |
|-----------|-----------|-----------|--------------|--------|--------|
| Mobile SM | 320px | 479px | 4 | 12px | 16px |
| Mobile LG | 480px | 767px | 4 | 16px | 20px |
| Tablet | 768px | 1023px | 8 | 20px | 28px |
| Desktop | 1024px | 1439px | 12 | 24px | 48px |
| Desktop LG | 1440px+ | — | 12 | 24px | `(100vw - 1344px) / 2` |

### 2. Density Spacing Multiplier

| Density | Vertical Rhythm | Card Padding | Section Gap |
|---------|-----------------|--------------|-------------|
| compact | 4px base (mul × 0.75) | 12px / 16px | 24px |
| comfortable | 4px base (mul × 1.0) | 20px / 24px | 40px |
| spacious | 4px base (mul × 1.5) | 28px / 32px | 64px |

### 3. Standard Frame Sizes for Figma

Create top-level Frames with these exact dimensions:

| Platform | Frame Name | Width | Height (scroll) |
|----------|-----------|-------|-----------------|
| Web | `Desktop / 1440` | 1440px | 900px (content scrolls) |
| Web | `Desktop / 1024` | 1024px | 800px |
| Tablet | `Tablet / 768` | 768px | 1024px |
| Mobile | `Mobile / 390` | 390px | 844px |
| Mobile | `Mobile / 360` | 360px | 800px |

---

## Template 1: Dashboard Layout (`page_type: dashboard`)

### Web Structure (Desktop 1440px)

**Auto Layout Stack Order (top level):**
- `Horizontal Stack` (width: fill, alignment: top)
  - `Sidebar` (width: fixed 260px, min-h: fill)
  - `Main Content` (width: fill, min-h: fill)
    - `Header` (height: 64px, sticky)
    - `Content Wrapper` (width: fill, padding: 32px, spacing: 24px)
      - `Page Title + Action Bar` (height: auto, justify: space-between)
      - `Stats Row` (Auto Layout horizontal, gap: 24px)
        - `Stat Card 1` [span 3 cols]
        - `Stat Card 2` [span 3 cols]
        - `Stat Card 3` [span 3 cols]
        - `Stat Card 4` [span 3 cols]
      - `Charts Row` (Auto Layout horizontal, gap: 24px, wrap)
        - `Main Chart` [span 8 cols, h: 360px]
        - `Side Panel` [span 4 cols, h: 360px]
      - `Table / List Section` [span 12 cols, h: auto]

**Text-based Blueprint (for Figma visual reference):**
```
┌──────┬─────────────────────────────────────────────────────────────┐
│      │  ┌───────────────────────────────────────────────────────┐  │
│  ←   │  │  Logo / Title                [Search] [User] [Avatar] │  │ ← Header (64px)
│  S   │  ├───────────────────────────────────────────────────────┤  │
│  i   │  │                                                         │  │
│  d   │  │  Dashboard Overview                     [+ New Report] │  │ ← Title Bar
│  e   │  ├───────────────────────────────────────────────────────┤  │
│  b   │  │  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐                 │  │
│  a   │  │  │$12.4K│ │+12.5%│ │ 342  │ │ 1,284│ ← Stats Cards   │  │
│  r   │  │  └──────┘ └──────┘ └──────┘ └──────┘                 │  │
│  (   │  ├───────────────────────────────────────────────────────┤  │
│  260 │  │  ┌──────────────────────────────┐ ┌─────────────────┐ │  │
│  p   │  │  │   Revenue Trend (Chart)      │ │ Recent Activity │ │  │
│  x   │  │  │   8 cols × 360px             │ │ 4 cols × 360px  │ │  │
│  )   │  │  └──────────────────────────────┘ └─────────────────┘ │  │
│      │  ├───────────────────────────────────────────────────────┤  │
│      │  │  ┌─────────────────────────────────────────────────┐  │  │
│      │  │  │  Data Table / Transaction List (12 cols)        │  │  │
│      │  │  └─────────────────────────────────────────────────┘  │  │
│      │                                                         │  │
└──────┴─────────────────────────────────────────────────────────────┘
```

### Mobile Structure

- Collapse sidebar to **bottom tab bar** (height: 64px, 5 items max)
- Stats row becomes **vertical stack** (full width, gap: 12px)
- Charts stack vertically (full width each)

---

## Template 2: List View (`page_type: list_view`)

### Core Structure

```
Header (with back button, title, primary action)
├── Filter Bar (sticky below header, height: 56px)
│   ├── Search Input [span 6 cols]
│   ├── Filter Chip Group [span 4 cols]
│   └── View Toggle (grid/list/sort) [span 2 cols, align right]
├── Content Grid (gap: 20px)
│   ├── Card 1
│   ├── Card 2
│   └── ...
└── Pagination (height: 64px, center or right aligned)
```

### Card Sizes (by density)

| Density | Card Min Height | Image Ratio | Text Padding |
|---------|-----------------|-------------|--------------|
| compact | 180px | 16:9 (120px) | 12px |
| comfortable | 240px | 16:9 (160px) | 16px |
| spacious | 300px | 4:3 (200px) | 24px |

### Figma Grid Placement (Desktop 12-col)

- **4-column cards**: 3 per row (each card spans 4 cols, gutter 24px)
- **3-column cards**: 4 per row (each spans 3 cols)
- **2-column cards**: 6 per row (compact list, each spans 2 cols)

### List Variant (not grid)

```
List Item Row (height: 72px, horizontal Auto Layout, padding: 0 16px)
├── [Thumbnail/Avatar] (48×48px, radius: md)
├── Content Stack (flex-grow, padding: 0 16px, vertical gap: 4px)
│   ├── Title Line (Body MD, truncate 1 line)
│   └── Subtitle / Meta (Body SM, Neutral 500, truncate 1 line)
├── Status Badge (align: trailing, padding: 4px 12px, radius: full)
└── [More Icon / Arrow] (24×24px, margin-left: 12px)
```

---

## Template 3: Form View (`page_type: form_view`)

### Form Structure

```
Header: Back | Title | Save Button [sticky right]
├── Breadcrumb (optional, if in nested flow)
├── Page Title + Description
├── Form Content (12-col grid, gap: 24px)
│   ├── Section Heading [span 12 cols, padding-top: 8px]
│   ├── Form Field: Label + Input [span 6 cols] ← 2 per row
│   ├── Form Field: Label + Input [span 6 cols]
│   ├── Form Field: Full Width [span 12 cols]
│   ├── Divider [span 12 cols, height: 1px, margin: 16px 0]
│   └── Section Heading 2 + Fields...
└── Sticky Footer Bar (mobile/long forms)
    ├── Secondary Button: Cancel
    └── Primary Button: Save / Submit
```

### Form Field Specifications

**Desktop Field Layout:**
```
Field Container (width: fill, Auto Layout vertical, gap: 6px)
├── Label (Body SM, Semibold, color: Neutral 700)
│   └── (Optional Red * if required)
├── Input (height: 44px, border: Neutral 200, radius: md, bg: White)
│   ├── Placeholder text: Neutral 400
│   └── Icon prefix/suffix: 44px square (clickable area)
├── Helper / Hint Text (Caption, color: Neutral 500) ← optional
└── Error Message (Caption, color: Error 500) ← only error state
```

**Responsive Rules:**
- Desktop 1440px: fields at span-6 (2 per row), span-12 (full)
- Tablet 768px: all fields span-8 (1 per row, full width in main area)
- Mobile: all fields full width, stacked, padding: 16px

### Figma Component Layout for Forms

Create these reusable Auto Layout containers:
- `Form / 2-Col` (gap: 24px, 2 equal columns)
- `Form / 3-Col` (gap: 24px, 3 equal columns)
- `Form / Section Divider` (width: fill, height: 1px, Neutral 200, margin: 16px vertical)
- `Form / Sticky Actions` (width: fill, padding: 16px 24px, justify: flex-end, bg: White, border-top)

---

## Template 4: Detail View (`page_type: detail_view`)

### Master-Detail Split (Desktop)

```
┌──────────────────────┬──────────────────────────────────────────┐
│  List / Sidebar      │  Detail View                             │
│  (span 4 cols)       │  (span 8 cols)                           │
│                      │                                          │
│  [Item 1] ◄ selected │  ┌───────────────────────────────────┐   │
│  [Item 2]            │  │  Hero Header with Action Bar      │   │
│  [Item 3]            │  ├───────────────────────────────────┤   │
│  [Item 4]            │  │  Tabs / Segmented Control         │   │
│  ...                 │  ├───────────────────────────────────┤   │
│                      │  │                                   │   │
│                      │  │  Tab Content Panels (swappable)   │   │
│                      │  │  - Overview / Info / Metadata     │   │
│                      │  │  - Activity / Timeline            │   │
│                      │  │  - Related Items / Attachments    │   │
│                      │  │                                   │   │
│                      │  └───────────────────────────────────┘   │
└──────────────────────┴──────────────────────────────────────────┘
```

### Detail Hero Header Specs

```
Hero Card (width: fill, padding: 28px, Auto Layout vertical, gap: 20px, elevation: 1)
├── Top Row (horizontal, justify: space-between)
│   ├── Identity Stack (horizontal, gap: 16px)
│   │   ├── Avatar / Thumbnail (64×64px, radius: lg or full)
│   │   └── Title Stack (vertical, gap: 6px)
│   │       ├── Primary Title (Heading LG, 24px)
│   │       ├── Subtitle / Breadcrumb (Body MD, Neutral 500)
│   │       └── Status / Meta Tags (row of badges, gap: 8px)
│   └── Action Buttons Stack (horizontal, gap: 12px)
│       ├── [Secondary] (e.g., Share)
│       ├── [Secondary] (e.g., Edit)
│       └── [Primary] (e.g., Main CTA)
└── Key Stats Row (horizontal, wrap: true, gap: 32px)
    ├── Stat Item: Label (Caption, Neutral 500) + Value (Body MD, Semibold)
    ├── Stat Item: Label + Value
    └── ...
```

### Tab Navigation

```
Tabs Bar (width: fill, border-bottom: 1px Neutral 200)
└── Tab Buttons Row (horizontal, gap: 0)
    ├── Tab Active (padding: 12px 20px, border-bottom: 2px Primary 500, color: Primary 600, font: semibold)
    ├── Tab Inactive (padding: 12px 20px, color: Neutral 500)
    └── Tab Inactive
```

---

## Template 5: Marketing Landing (`page_type: marketing_landing`)

### Standard Section Order (scroll flow)

```
┌─────────────────────────────────────────────────────────────────┐
│  NAVBAR (sticky, height: 72px, elevation 1 on scroll)          │
│  Logo   [Links]   [CTA Button]                                  │
├─────────────────────────────────────────────────────────────────┤
│  HERO SECTION (min-height: 640px, vertical padding: 96px)      │
│  ┌─────────────────────────────────────────────────────┐       │
│  │  Eyebrow / Badge (Overline text + radius full)      │       │
│  │  H1 Headline (Display XL / 2XL, max-width: 700px)   │       │
│  │  Subhead Copy (Body LG, max-width: 600px)           │       │
│  │  [Primary CTA] [Secondary CTA]   (gap: 12px)        │       │
│  │  Trust row: Logos of clients / "Used by 10K+ teams" │       │
│  └─────────────────────────────────────────────────────┘       │
│  (Optional Hero Visual on right: Illustration / Browser Mock)  │
├─────────────────────────────────────────────────────────────────┤
│  LOGO CLOUD (padding: 48px 0, muted bg: Neutral 50)            │
│  "Trusted by companies including"                               │
│  [Logo1] [Logo2] [Logo3] [Logo4] [Logo5] [Logo6]               │
├─────────────────────────────────────────────────────────────────┤
│  FEATURES SECTION (padding: 96px 0)                            │
│  Section Header (centered, max-width: 640px)                    │
│  Feature Grid (3 cards per row, gap: 32px)                     │
│  Each: Icon(48px) + Title(Heading SM) + Desc(Body MD)          │
├─────────────────────────────────────────────────────────────────┤
│  TESTIMONIAL / SOCIAL PROOF (padding: 96px 0, bg: Brand 50)    │
│  Large quote card with avatar, name, company, star rating      │
├─────────────────────────────────────────────────────────────────┤
│  PRICING TIERS (if applicable) OR FEATURE SHOWCASE             │
├─────────────────────────────────────────────────────────────────┤
│  FAQ / ACCORDION (padding: 80px 0)                             │
├─────────────────────────────────────────────────────────────────┤
│  FINAL CTA SECTION (padding: 80px 0, bg: Dark / Brand 900)     │
│  Centered headline + subhead + large CTA button                │
├─────────────────────────────────────────────────────────────────┤
│  FOOTER (padding: 64px 0 32px, bg: Neutral 900, text: Neutral 200)│
│  Columns: Brand+Social, Product, Company, Resources, Legal     │
│  Bottom: Copyright + Privacy/Terms links                       │
└─────────────────────────────────────────────────────────────────┘
```

### Figma Auto Layout Containers for Marketing

Create these reusable frame presets:
- `Section / Container` (max-width: 1280px, margin-left/right: auto, padding: 0 48px)
- `Section / Header` (vertical, gap: 12px, align: center, max-width: 640px, margin: 0 auto 48px)
- `Grid / 3-col Feature` (horizontal, gap: 32px, wrap: true)
- `CTA / Dual Button` (horizontal, gap: 12px, align: center)

---

## Template 6: Settings Page (`page_type: settings`)

### Layout Pattern

```
┌──────────────────────┬──────────────────────────────────────────┐
│ Sidebar Navigation   │ Content Panel                            │
│ (width: 240px fixed) │ (flex: 1, padding: 40px)                 │
│                      │                                          │
│  ▼ Account           │ ┌────────────────────────────────────┐   │
│    • Profile         │ │ Settings Section Title             │   │
│    • Password        │ │ Section description (muted)        │   │
│    • Notifications   │ ├────────────────────────────────────┤   │
│  ▼ Workspace         │ │                                    │   │
│    • General         │ │ ┌─Form Field Group / Card────┐     │   │
│    • Members         │ │ │ [Setting row with toggle]  │     │   │
│    • Billing         │ │ │ [Setting row with input]   │     │   │
│    • Integrations    │ │ │ [Select dropdown row]      │     │   │
│  ▼ System            │ │ └───────────────────────────┘     │   │
│    • Appearance      │ │                                    │   │
│    • Security        │ │ [Save Changes button bar]         │   │
│                      │ └────────────────────────────────────┘   │
└──────────────────────┴──────────────────────────────────────────┘
```

### Setting Row Spec

```
Setting Row (horizontal, justify: space-between, align: center, padding: 20px 0)
├── Setting Label Stack (vertical, gap: 4px, max-width: 440px)
│   ├── Setting Title (Body MD, Semibold)
│   └── Setting Description (Body SM, Neutral 500, line-height: 1.5)
└── Setting Control (width: auto, min-width: 200px, align: right)
    ├── Toggle Switch (width: 44px, height: 24px)
    ├── OR Select Dropdown (width: 240px, height: 40px)
    ├── OR Input Field (width: 240px, height: 40px)
    └── OR Button Group
```

---

## Figma Implementation Checklist

- [ ] Create top-level Frames for all required breakpoints (Section 3)
- [ ] Set up layout grids on each Frame (columns + gutters + margins per breakpoint)
- [ ] Build Auto Layout containers in the exact stack order specified above
- [ ] Apply **constraints** correctly:
  - Sidebar: Left + Top + Bottom (fixed width)
  - Header: Left + Right + Top (fixed height)
  - Content cards: Left + Right (hug or fill)
- [ ] Name every layer explicitly following: `Section / Component / Variant` convention
- [ ] Add proper **Auto Layout padding & gap values** (no manual spacing between items)
- [ ] For responsive variants, use Figma Variables for breakpoint toggling
