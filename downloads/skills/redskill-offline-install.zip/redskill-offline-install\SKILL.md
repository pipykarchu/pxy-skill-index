---
name: redskill-offline-install
description: "Manually install RedSkill (小红书技能商店) skills without the Python CLI — download from edith API, extract ZIP, and install into Hermes and/or Codex. Also covers cross-installing skills between Hermes <-> Codex directories."
version: 1.0.0
license: MIT
author: Hermes Agent
platforms: [windows]
tags: [redskill, skill-install, offline, cross-platform, codex]
---

# RedSkill 离线安装 & 跨平台技能同步

当 RedSkill CLI（Python 工具）不可用时，通过小红书 edith API 直接下载技能包并手动安装到 Hermes 和 Codex。

## 触发场景

- 用户提到 "RedSkill"、"小红书商店"、"装技能"、"install skill"
- 用户给出 identifier（如 89674, codex-canvas）
- 本机没有 Python 环境（RedSkill CLI 无法运行）
- 需要把技能从 Hermes 同步到 Codex，或反之

## RedSkill 生态 API 端点

| 用途 | URL |
|------|-----|
| 搜索技能 | `https://edith.xiaohongshu.com/api/sns/v1/creator/red_skill/search_published_skills?q=<关键词>` |
| 获取技能包 | `https://edith.xiaohongshu.com/api/sns/v1/creator/red_skill/get_skill_bundle?identifier=<identifier>` |
| CLI manifest 检查 | `https://edith.xiaohongshu.com/api/sns/v1/creator/red_skill/get_cli_manifest` |
| 安装文档 | `https://redskill.xiaohongshu.net/install.md` |

## 手动安装流程

### Step 1: 搜索技能（用户没给 identifier 时）

```bash
curl -s "https://edith.xiaohongshu.com/api/sns/v1/creator/red_skill/search_published_skills?q=<关键词>"
```

返回 JSON 中的 `identifier` 字段是安装所需的唯一标识。

### Step 2: 获取技能包下载链接

```bash
curl -s "https://edith.xiaohongshu.com/api/sns/v1/creator/red_skill/get_skill_bundle?identifier=<identifier>"
```

返回示例：
```json
{
  "data": {
    "zip_url": "http://sns-video-v6.xhscdn.com/skill/<hash>.zip?sign=...&t=...",
    "version": "1.0.0",
    "sha256": "..."
  }
}
```

### Step 3: 下载并解压

```bash
# PowerShell
$tmpDir = "$env:TEMP\skill_<identifier>"
New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null
curl.exe -sL -o "$tmpDir\bundle.zip" "<zip_url>"
tar.exe -xf "$tmpDir\bundle.zip" -C "$tmpDir"
Get-ChildItem -Path $tmpDir -Recurse
```

### Step 4: 安装到 Hermes

```bash
Copy-Item -Recurse -Force "$tmpDir\<子技能目录>" "D:\hermes\data\hermes-home\skills\"
```

### Step 5: 同步到 Codex

```bash
Copy-Item -Recurse -Force "$tmpDir\<子技能目录>" "C:\Users\16543\.codex\skills\"
```

### Step 6: 验证

```bash
hermes skills list | Select-String "<技能名关键词>"
Get-ChildItem "C:\Users\16543\.codex\skills" -Directory | Select-String "<技能名>"
```

## 已知 RedSkill 技能

| Identifier | 技能名 | 版本 | 子技能列表 |
|---|---|---|---|
| `89674` | Figma Designer Skills | 1.0.0 | hifi-component-library, hifi-design-review, hifi-layout-template, hifi-style-guide |
| `codex-canvas` | Codex-Canvas 无限画布 | 1.1.0 | canvas, canvas-edit-elements, canvas-edit-text, canvas-expand, canvas-quick-edit, canvas-remove-bg |
| `kirito` | codex-canva（工服海报模板） | 1.0.1 | — |

## Codex-Canvas 插件完整安装

> ⚠️ 技能只是 bootstrap 入口，完整功能需要安装 personal plugin。

### 前置条件

- Git 已安装（`git --version`）
- Node.js 可用（`node --version`）
- 长期保留目录（建议 `C:\Users\<user>\src\codex-canvas\`）

### 安装步骤

```bash
# 1. 克隆到长期目录
mkdir C:\Users\16543\src -Force
git clone https://github.com/Xiangyu-CAS/codex-canvas.git C:\Users\16543\src\codex-canvas
cd C:\Users\16543\src\codex-canvas

# 2. 检出最新稳定 Release
npm run checkout:stable

# 3. 安装依赖
npm ci

# 4. 安装 personal plugin（跳过 OCR 因本机无 Python）
CODEX_CANVAS_SKIP_OCR_INSTALL=1 npm run install:personal

# 5. 注册到 Codex
codex plugin add codex-canvas@personal
```

### 验证

```bash
codex plugin list --json
# 应显示 codex-canvas@personal (v0.3.1) installed=true, enabled=true
```

### 使用

- Codex：新建任务后说 `@Codex-Canvas` 或输入 `/canvas`
- Hermes：加载 `canvas` 技能后使用
- 画布数据存储在 `<workspace>/canvas/` 下
- 支持：图片导入、Quick Edit、Remove BG、Expand、Edit Text、Edit Elements
- 无 Python 时 Edit Text 回退到 Codex 视觉 OCR

## 跨平台技能同步速查

### Codex → Hermes

```bash
$skills = @("skill1", "skill2")
foreach ($s in $skills) {
    if (Test-Path "C:\Users\16543\.codex\skills\$s") {
        Copy-Item -Recurse -Force "C:\Users\16543\.codex\skills\$s" "D:\hermes\data\hermes-home\skills\"
    }
}
```

### Hermes → Codex

```bash
$skills = @("skill1", "skill2")
foreach ($s in $skills) {
    if (Test-Path "D:\hermes\data\hermes-home\skills\$s") {
        Copy-Item -Recurse -Force "D:\hermes\data\hermes-home\skills\$s" "C:\Users\16543\.codex\skills\"
    }
}
```

### 刷新技能列表

- Hermes：`hermes skills list`
- Codex：重启 Codex 任务后自动加载新技能

## 关键陷阱

- **PowerShell 转义**：在 `terminal()` 中传递复杂字符串时避免用双引号嵌套双引号；最好把脚本写成 `.ps1` 文件再执行
- **tar.exe 支持**：Windows 10+ 自带 `tar.exe`，不需要额外安装解压工具
- **edith API 需要 identifier 参数**：用 `get_skill_bundle?identifier=XXX`，不要用 `skill_id=`
- **下载链接带时效性**：`zip_url` 中的 sign 和 t 参数有时效，拿到后尽快下载
- **Codex 插件路径**：`codex plugin add codex-canvas@personal` 依赖个人 marketplace（`~/.agents/plugins/marketplace.json`），安装器会在 `npm run install:personal` 时自动创建
- **RapidOCR 安装失败**：本机无 Python 时正常，Edit Text 自动回退