---
name: redskill-installer
description: "从 RedSkill（小红书技能商店）安装技能到 Hermes。当用户说「装技能」「装skill」「install skill」「RedSkill install」「小红书技能」「89674号技能」时使用。覆盖 API 搜索、下载 zip 包、手动解压安装全流程。本机（Hermes CN 桌面版，无 Python）不用 Python CLI，直接走 edith API。"
version: 1.0.0
license: MIT
author: Hermes Agent
platforms: [windows]
---

# RedSkill 技能安装器（Windows / 无 Python）

小红书 RedSkill 商店的技能安装到 Hermes 的方法。

## 触发场景

- 用户说「装技能」「装skill」「install skill」「我要 xxx 这个技能」
- 用户说「RedSkill install xxx」「小红书技能」「笔记技能」「找技能」
- 用户给了一个技能 ID（纯数字，如 89674）
- 用户说「装89674号技能」

## 注意

本机（Windows 11 / Hermes CN 桌面版）没有 Python 3，所以不能直接使用 `redskill install <id>` 命令。替代方案是直接调用小红书 edith API。

## 步骤

### 1. 搜索技能（用户没给ID时）

先用关键词搜索，找出候选技能和对应的 identifier：

```powershell
curl.exe -s "https://edith.xiaohongshu.com/api/sns/v1/creator/red_skill/search_published_skills?q=<关键词>"
```

返回结构中 `results` 数组包含 identifier、name、description。

### 2. 获取技能包下载地址

已知道 identifier 后，调用获取包信息：

```powershell
$resp = curl.exe -s "https://edith.xiaohongshu.com/api/sns/v1/creator/red_skill/get_skill_bundle?identifier=<技能ID>"
```

响应示例：
```json
{
  "code": 0, "success": true,
  "data": {
    "identifier": "89674",
    "version": "1.0.0",
    "zip_url": "http://sns-video-v6.xhscdn.com/skill/...zip?sign=...",
    "sha256": "..."
  }
}
```

注意 `zip_url` 中的 sign 有时效性，获取后尽快下载。

### 3. 下载并解压

```powershell
# 下载
curl.exe -sL -o "$env:TEMP\skill_<ID>.zip" "<zip_url>"

# 解压（ZIP 格式）
$extractDir = "$env:TEMP\skill_<ID>"
New-Item -ItemType Directory -Force -Path $extractDir | Out-Null
tar.exe -xf "$env:TEMP\skill_<ID>.zip" -C "$extractDir"

# 查看内容结构
Get-ChildItem -Path $extractDir -Recurse | Select-Object FullName, Length
```

### 4. 复制到 Hermes skills 目录

HERMES_HOME 路径：`D:\hermes\data\hermes-home`

```powershell
Copy-Item -Recurse -Force "$env:TEMP\skill_<ID>\<技能目录>" "D:\hermes\data\hermes-home\skills\"
```

### 5. 验证安装

```powershell
hermes skills list | Select-String -Pattern "<技能名关键词>"
```

## 已知陷阱

- **EDITH API 被墙？** 主站 `redskill.xiaohongshu.net` 返回 500，但 `edith.xiaohongshu.com` 可直接访问（国内网络）。如果 API 返回 403 可能需要 cookies 鉴权
- **zip_url 有过期时间**：sign 参数绑定时间戳，获取后必须立即下载
- **sub-skill 包结构**：一个技能 ID 可能包含多个子技能（如 Figma Designer Skills 含 4 个子技能），都是平铺的 SKILL.md 目录，直接整体复制即可
- **Hermes 无需重启**：技能目录直接复制就生效，下次 `/reset` 或新对话自动加载
- **hermes skills install 不可靠**：Hermes 的 skills install 依赖自带的 hub 解析，遇到 hub 不通时会超时。手动安装更可控

## 本机已安装的 RedSkill 技能

| ID | 名称 | 说明 |
|----|------|------|
| 89674 | Figma Designer Skills（包） | 含 hifi-component-library、hifi-design-review、hifi-layout-template、hifi-style-guide 4个子技能 |