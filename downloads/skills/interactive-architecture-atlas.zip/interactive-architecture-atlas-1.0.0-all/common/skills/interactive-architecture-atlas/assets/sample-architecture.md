# 示例产品架构图集

> 本样例用于验证离线渲染、交互编辑和导出能力。

## 页面地图

```mermaid
flowchart LR
  HOME[首页] --> DEVICE[设备]
  HOME --> AI[AI 助手]
  HOME --> MEMORY[记忆]
  HOME --> SCENE[场景]
  DEVICE --> DETAIL[设备详情]
  MEMORY --> MATERIAL[素材管理]
```

## 核心流程

```mermaid
sequenceDiagram
  participant U as 用户
  participant A as 应用
  participant C as 云端
  U->>A: 选择文件
  A->>C: 上传并分析
  C-->>A: 返回标签与状态
  A-->>U: 展示处理结果
```

## 状态说明

| 状态 | 含义 |
|---|---|
| 待处理 | 文件已进入队列 |
| 处理中 | 正在提取内容与标签 |
| 已完成 | 可检索并用于后续任务 |
| 失败 | 保留原因并允许重试 |
