---
name: interactive-architecture-atlas
description: 将含 Mermaid 图的 Markdown 生成为离线交互式架构图集，支持浏览、缩放拖动、编辑和导出；在用户明确要求时可原位上传飞书并回读校验。适用于页面地图、信息架构、业务流程和用例图交付，不用于替代专业多人协同绘图平台。
license: MIT
---

# Interactive Architecture Atlas

把 Markdown 作为唯一真源，生成一个无需联网即可打开的单文件 HTML。图集支持目录与搜索、明暗主题、图表缩放和拖动画布、SVG/高清 PNG 导出、整篇 Markdown 编辑、单图 Mermaid 编辑、流程节点拖动与文字修改。

## 工作方式

1. 确认输入 Markdown 中的 Mermaid 代码块能独立表达结构。内容或业务逻辑不清时先补齐源稿，不要只修饰图形。
2. 从本技能目录运行生成器：

```powershell
node scripts/generate-interactive-atlas.js `
  --input ".\architecture.md" `
  --output ".\architecture.html" `
  --brand "Product Name" `
  --label "业务架构" `
  --version "V1.0"
```

3. 在真实浏览器中打开 HTML，逐项验证图表非空、缩放、拖动、编辑、导出及移动端布局。静态语法检查不能替代浏览器验证。
4. 按 [验收清单](references/acceptance-checklist.md) 记录通过项与未验证项。Mock、静态图或合同测试通过，不等于真实服务、账号或设备验收通过。

环境中已有 Playwright 时，可运行 `node scripts/test-browser.js --html ".\architecture.html"` 执行关键交互验收。

输入也可作为第一个位置参数。`--output`、`--brand`、`--label`、`--version` 可省略，生成器会采用安全默认值。

## 飞书发布

只有用户明确要求上传或覆盖时才使用飞书模式；不传 `--upload` 时生成器不会访问飞书。

```powershell
node scripts/generate-interactive-atlas.js `
  --input ".\architecture.md" `
  --upload `
  --folder-token "<folder-token>"
```

- 无同名文件：首次创建。
- 唯一同名文件：原位覆盖，保留已有链接。
- 多个同名文件：停止，不能猜测目标。
- 已知目标时可加 `--file-token "<existing-file-token>"`；生成器会核对它是否属于目标目录且文件名一致。
- 上传后必须同时通过目录回读、云端源文件下载和 SHA256 一致性校验，不能只看命令退出码。
- 不把 folder token、file token、账号、密钥或项目专属路径写入技能、样例、日志或发布包。

飞书模式需要已安装并认证的 `lark-cli`。本地生成只需要 Node.js 18+。

## 边界

- 浏览器里的节点拖动和文字修改会保存为 Mermaid 注释形式的布局元数据；复杂自由连线仍应直接编辑 Mermaid 源码。
- HTML 中的编辑是本地浏览器能力，不是多人实时协同，不具备版本冲突合并。
- 专业多人白板、任意矢量绘制或复杂图元操作应使用万兴图示、Figma、Excalidraw 等专用工具。
- Mermaid 运行库按其 MIT 许可证分发，归属文件位于 `assets/vendor/MERMAID-LICENSE.txt`。
