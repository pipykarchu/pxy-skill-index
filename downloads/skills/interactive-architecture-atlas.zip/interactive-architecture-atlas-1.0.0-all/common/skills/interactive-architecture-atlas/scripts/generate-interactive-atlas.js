#!/usr/bin/env node
/**
 * Generate an offline interactive architecture atlas from Markdown/Mermaid.
 *
 * Usage:
 *   node generate-interactive-atlas.js --input architecture.md
 *   node generate-interactive-atlas.js --input architecture.md --output architecture.html
 *   node generate-interactive-atlas.js --input architecture.md --upload --folder-token <token>
 *
 * Markdown remains the source of truth. The generated HTML embeds Mermaid and
 * renders without network access. Feishu access is opt-in through --upload.
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const zlib = require('zlib');
const { spawnSync } = require('child_process');

const MERMAID_VENDOR = path.join(__dirname, '..', 'assets', 'vendor', 'mermaid-10.9.1.min.js.gz');

function usage() {
  return [
    '用法：',
    '  node generate-interactive-atlas.js --input <source.md> [--output <atlas.html>]',
    '       [--brand <name>] [--label <type>] [--version <version>]',
    '       [--upload --folder-token <token> [--file-token <token>]]',
    '',
    '说明：不传 --upload 时不会访问飞书。--file-token 只用于明确覆盖已有同名文件。'
  ].join('\n');
}

function parseArgs(argv) {
  const options = { upload: false };
  const valueOptions = new Set(['--input', '--output', '--brand', '--label', '--version', '--folder-token', '--file-token']);
  for (let index = 0; index < argv.length; index++) {
    const arg = argv[index];
    if (arg === '--help' || arg === '-h') options.help = true;
    else if (arg === '--upload') options.upload = true;
    else if (valueOptions.has(arg)) {
      const value = argv[++index];
      if (!value || value.startsWith('--')) throw new Error('参数缺少值：' + arg + '\n\n' + usage());
      options[arg.slice(2).replace(/-([a-z])/g, (_, letter) => letter.toUpperCase())] = value;
    } else if (!arg.startsWith('--') && !options.input) options.input = arg;
    else throw new Error('无法识别参数：' + arg + '\n\n' + usage());
  }
  if (options.help) return options;
  if (!options.input) throw new Error('必须提供 --input <source.md>。\n\n' + usage());
  if (options.upload && !options.folderToken) throw new Error('--upload 必须同时提供 --folder-token。');
  if (options.fileToken && !options.upload) throw new Error('--file-token 只能与 --upload 一起使用。');
  return options;
}

const options = parseArgs(process.argv.slice(2));
if (options.help) {
  console.log(usage());
  process.exit(0);
}
const shouldUpload = options.upload;
const mdPath = path.resolve(options.input);
const htmlPath = path.resolve(options.output || mdPath.replace(/\.md$/i, '.html'));
const documentStem = path.basename(mdPath, path.extname(mdPath));
const documentVersionMatch = documentStem.match(/-V([^-]+)-\d{8}$/i);
const documentVersion = options.version || (documentVersionMatch ? 'V' + documentVersionMatch[1] : 'V1.0');
const architectureLabel = options.label || (documentStem.includes('信息架构') ? '信息架构' : '业务架构');
const brandName = options.brand || 'Architecture Atlas';

function esc(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function inline(value) {
  return esc(value)
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*])\*([^*]+)\*/g, '$1<em>$2</em>')
    .replace(/`([^`]+)`/g, '<code>$1</code>');
}

function slug(value, index) {
  const normalized = String(value)
    .replace(/<[^>]+>/g, '')
    .replace(/[\s/：:]+/g, '-')
    .replace(/[^\w\u4e00-\u9fff-]/g, '')
    .replace(/^-+|-+$/g, '')
    .toLowerCase();
  return (normalized || 'section') + '-' + index;
}

function renderTable(lines) {
  const parseRow = (line) => line
    .replace(/^\s*\|/, '')
    .replace(/\|\s*$/, '')
    .split('|')
    .map((cell) => cell.trim());
  const header = parseRow(lines[0]);
  const rows = lines.slice(2).map(parseRow);
  let html = '<div class="table-scroll"><table><thead><tr>';
  html += header.map((cell) => '<th>' + inline(cell) + '</th>').join('');
  html += '</tr></thead><tbody>';
  html += rows.map((row) => '<tr>' + row.map((cell) => '<td>' + inline(cell) + '</td>').join('') + '</tr>').join('');
  html += '</tbody></table></div>';
  return html;
}

function diagramLegend(source) {
  if (!source.includes('CHAT_CASE') || !source.includes('MEMORY_CASE')) return '';
  return '<div class="diagram-legend" aria-label="用例图模块筛选">' +
    '<button type="button" data-diagram-class="chat"><span class="dot cyan"></span>AI 与任务</button>' +
    '<button type="button" data-diagram-class="device"><span class="dot green"></span>设备</button>' +
    '<button type="button" data-diagram-class="memory"><span class="dot violet"></span>记忆</button>' +
    '<button type="button" data-diagram-class="scene"><span class="dot amber"></span>场景</button>' +
    '<button type="button" data-diagram-class="security"><span class="dot rose"></span>安全与控制</button>' +
    '<button type="button" data-diagram-reset>显示全部</button>' +
    '</div>';
}

function parseMd(md) {
  const lines = String(md).replace(/\r\n/g, '\n').split('\n');
  const out = [];
  const toc = [];
  let sectionOpen = false;
  let headingIndex = 0;
  let diagramIndex = 0;
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    if (/^```mermaid\s*$/i.test(line.trim())) {
      const code = [];
      i++;
      while (i < lines.length && !/^```\s*$/.test(lines[i].trim())) {
        code.push(lines[i]);
        i++;
      }
      i++;
      const source = code.join('\n');
      out.push(
        '<div class="diagram-panel" data-diagram-index="' + diagramIndex + '">' +
        '<div class="diagram-toolbar"><span class="diagram-title">交互图 ' + (diagramIndex + 1) + '</span>' +
        '<div class="diagram-toolbar-controls" role="toolbar" aria-label="图表工具">' +
        '<button type="button" class="zoom-out" title="缩小图表" aria-label="缩小图表">−</button>' +
        '<button type="button" class="zoom-fit" title="适配当前窗口">适配</button>' +
        '<span class="zoom-value" aria-live="polite">100%</span>' +
        '<button type="button" class="zoom-in" title="放大图表" aria-label="放大图表">+</button>' +
        '<button type="button" class="reset-diagram">重置高亮</button>' +
        '<button type="button" class="edit-diagram" title="打开此图编辑器">编辑图</button>' +
        '<button type="button" class="export-svg" title="导出矢量图">SVG</button>' +
        '<button type="button" class="export-png" title="导出高清图片">PNG</button>' +
        '</div></div>' +
        diagramLegend(source) +
        '<pre class="mermaid">' + esc(source) + '</pre>' +
        '</div>'
      );
      diagramIndex++;
      continue;
    }

    if (/^```/.test(line.trim())) {
      const code = [];
      i++;
      while (i < lines.length && !/^```\s*$/.test(lines[i].trim())) {
        code.push(lines[i]);
        i++;
      }
      i++;
      out.push('<pre class="tree">' + esc(code.join('\n')) + '</pre>');
      continue;
    }

    if (/^\|/.test(line.trim())) {
      const table = [];
      while (i < lines.length && /^\|/.test(lines[i].trim())) {
        table.push(lines[i].trim());
        i++;
      }
      out.push(renderTable(table));
      continue;
    }

    const heading = line.match(/^(#{1,6})\s+(.*)$/);
    if (heading) {
      const level = heading[1].length;
      const label = heading[2].trim();
      const id = slug(label, headingIndex++);
      if (level === 1) {
        out.push('<header class="doc-hero"><p class="eyebrow">' + esc(brandName.toUpperCase()) + ' / ' + esc(architectureLabel) + '</p><h1 id="' + id + '">' + inline(label) + '</h1><p class="hero-copy">页面、业务对象、状态与数据流的交互式统一视图</p></header>');
      } else {
        if (level === 2) {
          if (sectionOpen) out.push('</section>');
          out.push('<section class="doc-section" data-search-section><h2 id="' + id + '">' + inline(label) + '</h2>');
          sectionOpen = true;
        } else {
          out.push('<h' + level + ' id="' + id + '">' + inline(label) + '</h' + level + '>');
        }
        if (level <= 3) toc.push({ level, label, id });
      }
      i++;
      continue;
    }

    if (/^---+\s*$/.test(line.trim())) {
      out.push('<hr>');
      i++;
      continue;
    }

    if (/^>\s?/.test(line)) {
      const quote = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) {
        quote.push(lines[i].replace(/^>\s?/, ''));
        i++;
      }
      out.push('<aside class="note">' + quote.map(inline).join('<br>') + '</aside>');
      continue;
    }

    if (/^[-*]\s+/.test(line)) {
      const items = [];
      while (i < lines.length && /^[-*]\s+/.test(lines[i])) {
        items.push(inline(lines[i].replace(/^[-*]\s+/, '')));
        i++;
      }
      out.push('<ul>' + items.map((item) => '<li>' + item + '</li>').join('') + '</ul>');
      continue;
    }

    if (/^\d+\.\s+/.test(line)) {
      const items = [];
      while (i < lines.length && /^\d+\.\s+/.test(lines[i])) {
        items.push(inline(lines[i].replace(/^\d+\.\s+/, '')));
        i++;
      }
      out.push('<ol>' + items.map((item) => '<li>' + item + '</li>').join('') + '</ol>');
      continue;
    }

    if (!line.trim()) {
      i++;
      continue;
    }

    const paragraph = [line.trim()];
    i++;
    while (
      i < lines.length &&
      lines[i].trim() &&
      !/^(#{1,6})\s+/.test(lines[i]) &&
      !/^```/.test(lines[i].trim()) &&
      !/^\|/.test(lines[i].trim()) &&
      !/^[-*]\s+/.test(lines[i]) &&
      !/^\d+\.\s+/.test(lines[i]) &&
      !/^>\s?/.test(lines[i]) &&
      !/^---+\s*$/.test(lines[i].trim())
    ) {
      paragraph.push(lines[i].trim());
      i++;
    }
    out.push('<p>' + inline(paragraph.join(' ')) + '</p>');
  }

  if (sectionOpen) out.push('</section>');
  return { body: out.join('\n'), toc };
}

function renderToc(toc) {
  return toc.map((item) =>
    '<a class="toc-link level-' + item.level + '" href="#' + item.id + '">' + inline(item.label) + '</a>'
  ).join('');
}

function titleOf(md) {
  const match = String(md).match(/^#\s+(.*)$/m);
  return match ? match[1].trim() : brandName + ' ' + architectureLabel + '图集';
}

function buildHtml(mdContent, mermaidRuntime) {
  const parsed = parseMd(mdContent);
  const sourceBase64 = Buffer.from(mdContent, 'utf8').toString('base64');
  const title = titleOf(mdContent);
  const generatedAt = new Date().toISOString().replace('T', ' ').slice(0, 16) + ' UTC';
  const diagramExportPrefix = brandName.replace(/\s+/g, '-') + '-' + architectureLabel + '图-';
  const markdownDownloadName = path.basename(mdPath);

  return `<!DOCTYPE html>
<html lang="zh-CN" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="color-scheme" content="dark light">
<title>${esc(title)}</title>
<style>
:root{
  --bg:#071016;--surface:#0c1821;--surface-2:#11232d;--surface-3:#172d37;
  --line:#29414a;--line-strong:#3f606b;--text:#edf7f8;--muted:#91a8ae;
  --cyan:#22d3ee;--green:#34d399;--violet:#a78bfa;--amber:#fbbf24;--rose:#fb7185;
  --focus:#f8fafc;--shadow:0 18px 50px rgba(0,0,0,.28);--radius:8px;
}
html[data-theme="light"]{
  --bg:#eef4f4;--surface:#ffffff;--surface-2:#f4f8f8;--surface-3:#e8f0f1;
  --line:#c9d7d9;--line-strong:#9eb4b8;--text:#122429;--muted:#5b7075;
  --focus:#061217;--shadow:0 16px 42px rgba(36,55,60,.12);
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--text);font-family:"Microsoft YaHei","PingFang SC","Segoe UI",sans-serif;line-height:1.65;letter-spacing:0}
button,input,textarea{font:inherit;letter-spacing:0}
button{color:inherit}
.app-shell{min-height:100vh;display:grid;grid-template-columns:258px minmax(0,1fr)}
.sidebar{position:sticky;top:0;height:100vh;padding:24px 18px;border-right:1px solid var(--line);background:color-mix(in srgb,var(--surface) 94%,transparent);overflow:auto;z-index:20}
.brand{display:flex;align-items:center;gap:10px;margin:0 6px 22px;font-weight:800;font-size:18px}
.brand-mark{width:11px;height:11px;background:var(--cyan);box-shadow:0 0 18px var(--cyan);border-radius:50%}
.brand small{display:block;color:var(--muted);font-weight:500;font-size:11px}
.toc-label{margin:18px 7px 8px;color:var(--muted);font-size:11px;text-transform:uppercase}
.toc{display:flex;flex-direction:column;gap:3px}
.toc-link{display:block;padding:8px 10px;border-left:2px solid transparent;color:var(--muted);text-decoration:none;font-size:13px;border-radius:0 6px 6px 0}
.toc-link:hover,.toc-link.active{background:var(--surface-2);color:var(--text);border-left-color:var(--cyan)}
.toc-link.level-3{padding-left:22px;font-size:12px}
.workspace{min-width:0}
.toolbar{position:sticky;top:0;z-index:15;display:flex;align-items:center;gap:10px;padding:12px 24px;border-bottom:1px solid var(--line);background:color-mix(in srgb,var(--bg) 90%,transparent);backdrop-filter:blur(14px)}
.toolbar-title{font-size:13px;color:var(--muted);margin-right:auto}
.search{width:min(320px,34vw);height:38px;border:1px solid var(--line);border-radius:6px;background:var(--surface);color:var(--text);padding:0 12px;outline:none}
.search:focus{border-color:var(--cyan);box-shadow:0 0 0 3px color-mix(in srgb,var(--cyan) 18%,transparent)}
.btn{height:38px;border:1px solid var(--line);border-radius:6px;background:var(--surface);padding:0 13px;cursor:pointer;white-space:nowrap}
.btn:hover{border-color:var(--line-strong);background:var(--surface-2)}
.btn.primary{background:var(--cyan);border-color:var(--cyan);color:#062129;font-weight:700}
.menu-btn{display:none;width:38px;padding:0}
.document{width:min(1180px,calc(100% - 48px));margin:0 auto 80px}
.doc-hero{min-height:300px;padding:74px 0 54px;display:flex;flex-direction:column;justify-content:flex-end;border-bottom:1px solid var(--line)}
.eyebrow{color:var(--cyan);font-size:12px;font-weight:800;margin:0 0 16px}
h1{font-size:42px;line-height:1.16;margin:0;max-width:840px}
.hero-copy{font-size:16px;color:var(--muted);margin:16px 0 0}
.doc-section{padding:48px 0 30px;border-bottom:1px solid var(--line)}
h2{font-size:25px;line-height:1.3;margin:0 0 24px;display:flex;align-items:center;gap:12px}
h2::before{content:"";width:5px;height:26px;background:var(--amber);border-radius:2px;flex:none}
h3{font-size:18px;line-height:1.4;margin:32px 0 14px;color:var(--cyan)}
p{font-size:14px;margin:12px 0;color:var(--text)}
ul,ol{padding-left:24px;margin:12px 0;font-size:14px}
li{margin:6px 0}
hr{border:0;border-top:1px solid var(--line);margin:34px 0}
strong{color:var(--focus)}
code{padding:2px 6px;border:1px solid var(--line);border-radius:4px;background:var(--surface-2);font-family:"Cascadia Code",Consolas,monospace;font-size:12px}
.note{margin:16px 0;padding:14px 16px;border-left:3px solid var(--violet);background:var(--surface-2);color:var(--muted);font-size:13px}
.table-scroll{overflow:auto;margin:18px 0;border:1px solid var(--line);border-radius:var(--radius)}
table{width:100%;border-collapse:collapse;background:var(--surface);font-size:13px}
th,td{padding:11px 13px;text-align:left;vertical-align:top;border-bottom:1px solid var(--line);border-right:1px solid var(--line)}
th:last-child,td:last-child{border-right:0}
tr:last-child td{border-bottom:0}
th{background:var(--surface-2);color:var(--amber);font-weight:700;white-space:nowrap}
tbody tr:hover{background:color-mix(in srgb,var(--cyan) 7%,transparent)}
.tree{max-height:720px;overflow:auto;margin:18px 0;padding:18px;border:1px solid var(--line);border-radius:var(--radius);background:var(--surface);color:#bed2d6;font:12px/1.75 "Cascadia Code",Consolas,"Microsoft YaHei",monospace;white-space:pre}
html[data-theme="light"] .tree{color:#304c53}
.diagram-panel{position:relative;margin:20px 0;border:1px solid var(--line);border-radius:var(--radius);background:var(--surface);overflow:hidden;box-shadow:var(--shadow)}
.diagram-toolbar{min-height:48px;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:8px 14px;border-bottom:1px solid var(--line);color:var(--muted);font-size:12px}
.diagram-title{font-weight:700;white-space:nowrap}.diagram-toolbar-controls{display:flex;align-items:center;justify-content:flex-end;gap:6px;flex-wrap:wrap}
.diagram-toolbar button,.diagram-legend button{border:1px solid var(--line);border-radius:5px;background:var(--surface-2);color:var(--text);padding:6px 9px;cursor:pointer;font-size:12px}
.diagram-toolbar button:hover,.diagram-legend button:hover,.diagram-legend button.active{border-color:var(--cyan);box-shadow:0 0 14px color-mix(in srgb,var(--cyan) 25%,transparent)}
.diagram-toolbar button:focus-visible,.diagram-legend button:focus-visible{outline:2px solid var(--cyan);outline-offset:2px}
.zoom-value{min-width:48px;text-align:center;color:var(--text);font-variant-numeric:tabular-nums}
.diagram-legend{display:flex;flex-wrap:wrap;gap:8px;padding:12px 14px 0}
.diagram-legend button{display:inline-flex;align-items:center;gap:7px}
.dot{width:8px;height:8px;border-radius:50%}.cyan{background:var(--cyan)}.green{background:var(--green)}.violet{background:var(--violet)}.amber{background:var(--amber)}.rose{background:var(--rose)}
.mermaid{min-height:120px;max-height:min(78vh,900px);margin:0;padding:20px;overflow:auto;text-align:center;background:transparent;overscroll-behavior:contain}
.mermaid svg{display:block;max-width:none;max-height:none;margin:0 auto;cursor:grab;touch-action:none;user-select:none}
.mermaid svg:active{cursor:grabbing}
.mermaid svg.is-panning{cursor:grabbing}
.diagram-panel .node,.diagram-panel .edgePath,.diagram-panel .edgeLabel,.diagram-panel .cluster{transition:opacity .18s ease,filter .18s ease}
.diagram-panel .node{cursor:pointer}
.diagram-panel.is-focused .node,.diagram-panel.is-focused .edgePath,.diagram-panel.is-focused .edgeLabel{opacity:.12}
.diagram-panel.is-focused .node.is-related,.diagram-panel.is-focused .edgePath.is-related,.diagram-panel.is-focused .edgeLabel.is-related{opacity:1;filter:drop-shadow(0 0 6px var(--focus))}
.diagram-panel .node.is-selected{opacity:1;filter:drop-shadow(0 0 10px var(--cyan)) drop-shadow(0 0 4px white)}
.diagram-panel.module-focused .node,.diagram-panel.module-focused .edgePath,.diagram-panel.module-focused .edgeLabel{opacity:.12}
.diagram-panel.module-focused .node.module-related,.diagram-panel.module-focused .edgePath.module-related{opacity:1;filter:drop-shadow(0 0 6px currentColor)}
.empty-result{display:none;margin:36px 0;padding:18px;border:1px solid var(--rose);color:var(--rose)}
.editor-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.58);opacity:0;pointer-events:none;transition:opacity .2s;z-index:39}
.editor{position:fixed;top:0;right:0;width:min(760px,92vw);height:100vh;display:flex;flex-direction:column;background:var(--surface);border-left:1px solid var(--line);box-shadow:var(--shadow);transform:translateX(100%);transition:transform .22s;z-index:40}
body.editor-open .editor{transform:translateX(0)}body.editor-open .editor-backdrop{opacity:1;pointer-events:auto}
.editor-head,.editor-actions{display:flex;align-items:center;gap:8px;padding:14px;border-bottom:1px solid var(--line)}
.editor-head strong{margin-right:auto}.editor-actions{border-top:1px solid var(--line);border-bottom:0;flex-wrap:wrap}
.editor-note{padding:10px 14px;color:var(--muted);font-size:12px;background:var(--surface-2)}
#source-editor{flex:1;min-height:0;resize:none;border:0;outline:0;background:#061016;color:#d9eef1;padding:18px;font:13px/1.65 "Cascadia Code",Consolas,"Microsoft YaHei",monospace;tab-size:2}
html[data-theme="light"] #source-editor{background:#f7fbfb;color:#17373d}
.diagram-editor{position:fixed;inset:18px;display:grid;grid-template-rows:auto minmax(0,1fr);background:var(--surface);border:1px solid var(--line-strong);border-radius:8px;box-shadow:0 28px 90px rgba(0,0,0,.55);opacity:0;pointer-events:none;transform:translateY(16px) scale(.99);transition:.2s;z-index:55;overflow:hidden}
body.diagram-editor-open .diagram-editor{opacity:1;pointer-events:auto;transform:none}body.diagram-editor-open{overflow:hidden}
.diagram-editor-head{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:12px 14px;border-bottom:1px solid var(--line)}
.diagram-editor-head strong{margin-right:auto}.layout-controls{display:flex;align-items:center;gap:5px;padding-right:8px;border-right:1px solid var(--line)}
.layout-controls .btn{min-width:40px;padding:0 9px}.diagram-editor-body{min-height:0;display:grid;grid-template-columns:minmax(300px,38%) minmax(0,1fr)}
.node-label-input{width:min(210px,42vw);height:38px;border:1px solid var(--line);border-radius:6px;background:var(--surface-2);color:var(--text);padding:0 10px;outline:0}.node-label-input:focus{border-color:var(--cyan)}
#diagram-source-editor{min-width:0;resize:none;border:0;border-right:1px solid var(--line);outline:0;background:#061016;color:#d9eef1;padding:18px;font:13px/1.65 "Cascadia Code",Consolas,"Microsoft YaHei",monospace;tab-size:2}
html[data-theme="light"] #diagram-source-editor{background:#f7fbfb;color:#17373d}
.diagram-preview-wrap{position:relative;min-width:0;min-height:0;display:flex;flex-direction:column;background:var(--bg)}
.diagram-editor-status{min-height:40px;padding:9px 14px;border-bottom:1px solid var(--line);color:var(--muted);font-size:12px}.diagram-editor-status.error{color:var(--rose)}
.diagram-editor-canvas{flex:1;min-height:0;overflow:auto;padding:24px;display:grid;place-items:center}.diagram-editor-canvas svg{display:block;max-width:none;height:auto}
.diagram-editor-canvas .node{cursor:move}.diagram-editor-canvas .node.is-dragging,.diagram-editor-canvas .node.is-selected{filter:drop-shadow(0 0 9px var(--cyan))}.diagram-editor-canvas .node:hover{filter:drop-shadow(0 0 5px var(--cyan))}
.toast{position:fixed;left:50%;bottom:28px;transform:translate(-50%,20px);padding:10px 14px;border:1px solid var(--line);border-radius:6px;background:var(--surface-3);box-shadow:var(--shadow);opacity:0;pointer-events:none;transition:.2s;z-index:60;font-size:13px}
.toast.show{opacity:1;transform:translate(-50%,0)}
.runtime-warning{display:none;margin:16px 0;padding:12px;border:1px solid var(--rose);color:var(--rose)}
.mobile-close{display:none}
@media (max-width:960px){
  .app-shell{grid-template-columns:1fr}.sidebar{position:fixed;left:0;top:0;width:min(300px,86vw);transform:translateX(-100%);transition:transform .2s;box-shadow:var(--shadow)}
  body.sidebar-open .sidebar{transform:translateX(0)}.menu-btn{display:block}.toolbar{padding:10px 14px}.toolbar-title{display:none}.search{width:100%;min-width:0}.document{width:min(100% - 28px,760px)}
  .doc-hero{min-height:240px;padding-top:54px}h1{font-size:32px}.doc-section{padding:38px 0 24px}.mobile-close{display:block}
}
@media (max-width:620px){
  .toolbar{display:grid;grid-template-columns:38px 1fr auto}.toolbar .edit-btn{grid-column:2/4}.theme-btn{width:40px;padding:0}.document{width:calc(100% - 24px)}
  h1{font-size:28px}h2{font-size:21px}.diagram-panel{margin-left:0;margin-right:0}.diagram-toolbar{align-items:flex-start;flex-direction:column}.diagram-toolbar-controls{width:100%;justify-content:flex-start}.mermaid{padding:12px}.editor-actions .btn{flex:1}.diagram-editor{inset:0;border:0;border-radius:0}.diagram-editor-body{grid-template-columns:1fr;grid-template-rows:minmax(220px,42%) minmax(0,1fr)}#diagram-source-editor{border-right:0;border-bottom:1px solid var(--line)}.layout-controls{order:3;width:100%;border-right:0;padding-right:0}
}
</style>
</head>
<body>
<div class="app-shell">
  <aside class="sidebar" id="sidebar">
    <button class="btn mobile-close" id="close-sidebar" type="button">关闭目录</button>
    <div class="brand"><span class="brand-mark"></span><div>${esc(brandName)}<small>${esc(architectureLabel)} / ${esc(documentVersion)}</small></div></div>
    <div class="toc-label">页面目录</div>
    <nav class="toc" id="toc">${renderToc(parsed.toc)}</nav>
  </aside>
  <div class="workspace">
    <div class="toolbar">
      <button class="btn menu-btn" id="open-sidebar" type="button" aria-label="打开目录">☰</button>
      <span class="toolbar-title">${esc(architectureLabel)}统一视图 · ${esc(generatedAt)}</span>
      <input class="search" id="search" type="search" placeholder="搜索页面、状态、对象…" aria-label="搜索文档">
      <button class="btn theme-btn" id="theme-toggle" type="button">明暗</button>
      <button class="btn primary edit-btn" id="open-editor" type="button">编辑源稿</button>
    </div>
    <main class="document" id="document">
      <div class="runtime-warning" id="runtime-warning">图表渲染未启动，下面仍保留 Mermaid 源码。请重新打开页面或检查浏览器脚本权限。</div>
      <article id="doc-content">${parsed.body}</article>
      <div class="empty-result" id="empty-result">没有找到匹配内容。</div>
    </main>
  </div>
</div>

<div class="editor-backdrop" id="editor-backdrop"></div>
<aside class="editor" aria-label="Markdown 源稿编辑器">
  <div class="editor-head"><strong>Markdown 源稿</strong><button class="btn" id="close-editor" type="button">关闭</button></div>
  <div class="editor-note">可直接编辑并应用预览。浏览器支持文件读写时，可选择本地 Markdown 后原位保存；否则使用“下载 Markdown”。云端版本需重新运行生成命令并显式使用 --upload。</div>
  <textarea id="source-editor" spellcheck="false"></textarea>
  <div class="editor-actions">
    <button class="btn" id="pick-source" type="button">选择本地 Markdown</button>
    <button class="btn" id="save-source" type="button">保存到本地源稿</button>
    <button class="btn" id="download-source" type="button">下载 Markdown</button>
    <button class="btn primary" id="apply-preview" type="button">应用预览</button>
  </div>
</aside>
<section class="diagram-editor" id="diagram-editor" aria-label="单图编辑器" aria-hidden="true">
  <div class="diagram-editor-head">
    <strong id="diagram-editor-title">图表编辑器</strong>
    <div class="layout-controls" aria-label="流程图布局">
      <button class="btn" type="button" data-layout="TD" title="从上到下">上下</button>
      <button class="btn" type="button" data-layout="LR" title="从左到右">左右</button>
      <button class="btn" type="button" data-layout="RL" title="从右到左">右左</button>
      <button class="btn" type="button" data-layout="BT" title="从下到上">下上</button>
    </div>
    <input class="node-label-input" id="visual-label-input" type="text" placeholder="点选节点后修改文字" aria-label="节点文字">
    <button class="btn" id="edit-visual-label" type="button">应用文字</button>
    <button class="btn" id="reset-diagram-source" type="button">撤销本次</button>
    <button class="btn" id="reset-visual-layout" type="button">恢复自动布局</button>
    <button class="btn" id="download-diagram-source" type="button">下载源图</button>
    <button class="btn" id="close-diagram-editor" type="button">关闭</button>
    <button class="btn primary" id="apply-diagram-edit" type="button">应用到图集</button>
  </div>
  <div class="diagram-editor-body">
    <textarea id="diagram-source-editor" spellcheck="false" aria-label="Mermaid 图表源稿"></textarea>
    <div class="diagram-preview-wrap">
      <div class="diagram-editor-status" id="diagram-editor-status">实时预览</div>
      <div class="diagram-editor-canvas" id="diagram-editor-canvas"></div>
    </div>
  </div>
</section>
<div class="toast" id="toast" role="status"></div>

<script>${mermaidRuntime}</script>
<script>
(function(){
  'use strict';
  var INITIAL_BASE64='${sourceBase64}';
  var diagramExportPrefix=${JSON.stringify(diagramExportPrefix)};
  var markdownDownloadName=${JSON.stringify(markdownDownloadName)};
  var currentMd=decodeBase64(INITIAL_BASE64);
  var fileHandle=null;
  var mermaidReady=false;
  var activeDiagramIndex=-1;
  var originalDiagramSource='';
  var originalVisualOverride={nodes:{}};
  var activeVisualOverride={nodes:{}};
  var activeVisualNode=null;
  var diagramPreviewTimer=null;
  var diagramColors={chat:'rgb(34, 211, 238)',device:'rgb(52, 211, 153)',memory:'rgb(167, 139, 250)',scene:'rgb(251, 191, 36)',security:'rgb(251, 113, 133)'};

  ${esc.toString()}
  ${inline.toString()}
  ${slug.toString()}
  ${renderTable.toString()}
  ${diagramLegend.toString()}
  ${parseMd.toString()}
  ${renderToc.toString()}

  function decodeBase64(value){
    var bytes=Uint8Array.from(atob(value),function(c){return c.charCodeAt(0);});
    return new TextDecoder('utf-8').decode(bytes);
  }
  function toast(message){
    var node=document.getElementById('toast');node.textContent=message;node.classList.add('show');
    clearTimeout(toast.timer);toast.timer=setTimeout(function(){node.classList.remove('show');},2200);
  }
  function semanticNodeId(node){
    var id=node.id||'';
    var match=id.match(/flowchart-([^-]+)-\d+$/);
    if(match)return match[1];
    return id.replace(/^state-/, '').replace(/-\d+$/, '');
  }
  function edgeText(edge){
    return [edge.id,edge.getAttribute('data-id'),edge.getAttribute('data-edge')].filter(Boolean).join('-');
  }
  function resetPanel(panel){
    panel.classList.remove('is-focused','module-focused');
    panel.querySelectorAll('.is-selected,.is-related,.module-related').forEach(function(node){node.classList.remove('is-selected','is-related','module-related');});
    panel.querySelectorAll('.diagram-legend button').forEach(function(button){button.classList.remove('active');});
  }
  function focusNode(panel,node){
    resetPanel(panel);
    var key=semanticNodeId(node);
    var edges=Array.from(panel.querySelectorAll('.edgePath')).filter(function(edge){
      var parts=edgeText(edge).split(/[_-]/);return parts.indexOf(key)!==-1;
    });
    node.classList.add('is-selected','is-related');
    if(!edges.length)return;
    panel.classList.add('is-focused');
    edges.forEach(function(edge){
      edge.classList.add('is-related');
      var parts=edgeText(edge).split(/[_-]/);
      panel.querySelectorAll('.node').forEach(function(candidate){
        if(parts.indexOf(semanticNodeId(candidate))!==-1)candidate.classList.add('is-related');
      });
    });
  }
  function focusModule(panel,className,button){
    resetPanel(panel);panel.classList.add('module-focused');button.classList.add('active');
    panel.querySelectorAll('.node.'+className).forEach(function(node){node.classList.add('module-related');});
    var target=diagramColors[className];
    panel.querySelectorAll('.edgePath').forEach(function(edge){
      var path=edge.querySelector('path');if(!path)return;
      var stroke=getComputedStyle(path).stroke;
      if(stroke===target)edge.classList.add('module-related');
    });
  }
  function diagramMetrics(svg){
    var values=String(svg.getAttribute('viewBox')||'').trim().split(/[\s,]+/).map(Number);
    var width=values.length===4&&values.every(Number.isFinite)?values[2]:0;
    var height=values.length===4&&values.every(Number.isFinite)?values[3]:0;
    if(!width||!height){
      try{var box=svg.getBBox();width=box.width;height=box.height;}catch(error){}
    }
    width=width||parseFloat(svg.getAttribute('width'))||1000;
    height=height||parseFloat(svg.getAttribute('height'))||600;
    return {width:width,height:height};
  }
  function currentDiagramScale(panel){return Number(panel.dataset.diagramScale)||1;}
  function setDiagramScale(panel,nextScale,resetPosition){
    var svg=panel.querySelector('svg');var host=svg&&svg.closest('.mermaid');if(!svg||!host)return;
    var metrics=diagramMetrics(svg);var scale=Math.max(.1,Math.min(3,Number(nextScale)||1));
    var centerX=(host.scrollLeft+host.clientWidth/2)/Math.max(host.scrollWidth,1);
    var centerY=(host.scrollTop+host.clientHeight/2)/Math.max(host.scrollHeight,1);
    panel.dataset.diagramScale=String(scale);
    svg.style.width=Math.round(metrics.width*scale)+'px';
    svg.style.height=Math.round(metrics.height*scale)+'px';
    var value=panel.querySelector('.zoom-value');if(value)value.textContent=Math.round(scale*100)+'%';
    requestAnimationFrame(function(){
      if(resetPosition){host.scrollLeft=0;host.scrollTop=0;return;}
      host.scrollLeft=Math.max(0,centerX*host.scrollWidth-host.clientWidth/2);
      host.scrollTop=Math.max(0,centerY*host.scrollHeight-host.clientHeight/2);
    });
  }
  function fitDiagram(panel){
    var svg=panel.querySelector('svg');var host=svg&&svg.closest('.mermaid');if(!svg||!host)return;
    var metrics=diagramMetrics(svg);var style=getComputedStyle(host);
    var available=host.clientWidth-(parseFloat(style.paddingLeft)||0)-(parseFloat(style.paddingRight)||0)-2;
    setDiagramScale(panel,Math.min(1,available/metrics.width),true);
  }
  function diagramFileName(panel,extension){
    var number=Number(panel.dataset.diagramIndex||0)+1;
    return diagramExportPrefix+(number<10?'0':'')+number+'.'+extension;
  }
  function downloadBlob(blob,fileName){
    var url=URL.createObjectURL(blob);var link=document.createElement('a');link.href=url;link.download=fileName;
    document.body.appendChild(link);link.click();link.remove();setTimeout(function(){URL.revokeObjectURL(url);},1000);
  }
  function replaceForeignObjectsForPng(original,clone){
    var originals=Array.from(original.querySelectorAll('foreignObject'));var copies=Array.from(clone.querySelectorAll('foreignObject'));
    copies.forEach(function(copy,index){
      var source=originals[index]||copy;var html=source.innerHTML.replace(/<br[^>]*>/gi,String.fromCharCode(10));var holder=document.createElement('div');holder.innerHTML=html;
      var lines=holder.textContent.split(String.fromCharCode(10)).map(function(line){return line.trim();}).filter(Boolean);if(!lines.length)lines=[''];
      var style=getComputedStyle(source.firstElementChild||source);var fontSize=parseFloat(style.fontSize)||14;var lineHeight=fontSize*1.25;
      var x=parseFloat(copy.getAttribute('x'))||0;var y=parseFloat(copy.getAttribute('y'))||0;var width=parseFloat(copy.getAttribute('width'))||100;var height=parseFloat(copy.getAttribute('height'))||fontSize*1.5;
      var text=document.createElementNS('http://www.w3.org/2000/svg','text');text.setAttribute('x',String(x+width/2));text.setAttribute('text-anchor','middle');text.setAttribute('font-family',style.fontFamily||'Microsoft YaHei, sans-serif');text.setAttribute('font-size',String(fontSize));text.setAttribute('font-weight',style.fontWeight||'400');text.setAttribute('fill',style.color||'#edf7f8');
      var firstY=y+height/2-(lines.length-1)*lineHeight/2+fontSize*.35;
      lines.forEach(function(line,lineIndex){var span=document.createElementNS('http://www.w3.org/2000/svg','tspan');span.setAttribute('x',String(x+width/2));span.setAttribute('y',String(firstY+lineIndex*lineHeight));span.textContent=line;text.appendChild(span);});
      copy.replaceWith(text);
    });
  }
  function serializeDiagram(panel,rasterSafe){
    var svg=panel.querySelector('svg');if(!svg)throw new Error('未找到可导出的图表');
    var metrics=diagramMetrics(svg);var clone=svg.cloneNode(true);
    clone.setAttribute('xmlns','http://www.w3.org/2000/svg');
    clone.setAttribute('xmlns:xlink','http://www.w3.org/1999/xlink');
    clone.setAttribute('width',String(Math.ceil(metrics.width)));
    clone.setAttribute('height',String(Math.ceil(metrics.height)));
    clone.style.width='';clone.style.height='';clone.style.maxWidth='none';clone.style.maxHeight='none';
    var background=document.createElementNS('http://www.w3.org/2000/svg','rect');
    background.setAttribute('x','0');background.setAttribute('y','0');background.setAttribute('width','100%');background.setAttribute('height','100%');
    background.setAttribute('fill',getComputedStyle(document.documentElement).getPropertyValue('--surface').trim()||'#0c1821');
    clone.insertBefore(background,clone.firstChild);
    if(rasterSafe)replaceForeignObjectsForPng(svg,clone);
    return {source:'<?xml version="1.0" encoding="UTF-8"?>\\n'+new XMLSerializer().serializeToString(clone),width:metrics.width,height:metrics.height};
  }
  function exportDiagramSvg(panel){
    try{
      var diagram=serializeDiagram(panel);downloadBlob(new Blob([diagram.source],{type:'image/svg+xml;charset=utf-8'}),diagramFileName(panel,'svg'));toast('SVG 已导出');
    }catch(error){console.error(error);toast('SVG 导出失败');}
  }
  function exportDiagramPng(panel){
    var diagram;
    try{diagram=serializeDiagram(panel,true);}catch(error){console.error(error);toast('PNG 导出失败');return;}
    var blob=new Blob([diagram.source],{type:'image/svg+xml;charset=utf-8'});var url=URL.createObjectURL(blob);var image=new Image();
    image.onload=function(){
      try{
        var ratio=Math.min(2,8192/Math.max(diagram.width,diagram.height));
        var canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(diagram.width*ratio));canvas.height=Math.max(1,Math.round(diagram.height*ratio));
        var context=canvas.getContext('2d');context.fillStyle=getComputedStyle(document.documentElement).getPropertyValue('--surface').trim()||'#0c1821';context.fillRect(0,0,canvas.width,canvas.height);
        context.drawImage(image,0,0,canvas.width,canvas.height);
        canvas.toBlob(function(png){
          if(!png){toast('PNG 导出失败，请改用 SVG');return;}
          downloadBlob(png,diagramFileName(panel,'png'));toast('PNG 已导出');
        },'image/png');
      }catch(error){console.error(error);toast('浏览器无法转换此图，请导出 SVG');}
      finally{URL.revokeObjectURL(url);}
    };
    image.onerror=function(){URL.revokeObjectURL(url);toast('浏览器无法转换此图，请导出 SVG');};
    image.src=url;
  }
  function getMermaidBlocks(md){
    var blocks=[];var fence=String.fromCharCode(96,96,96);var newline=String.fromCharCode(13)+'?'+String.fromCharCode(10);var expression=new RegExp(fence+'mermaid[ '+String.fromCharCode(9)+']*'+newline+'([^]*?)'+fence,'gi');var match;
    while((match=expression.exec(md))!==null)blocks.push(match[1].trimEnd());
    return blocks;
  }
  function replaceMermaidBlock(md,index,source){
    var count=0;var fence=String.fromCharCode(96,96,96);var newline=String.fromCharCode(13)+'?'+String.fromCharCode(10);var expression=new RegExp(fence+'mermaid[ '+String.fromCharCode(9)+']*'+newline+'[^]*?'+fence,'gi');
    return md.replace(expression,function(block){
      if(count++!==index)return block;
      return fence+'mermaid'+String.fromCharCode(10)+String(source).trim()+String.fromCharCode(10)+fence;
    });
  }
  function visualOverrideFromSource(source){
    var prefix='%% atlas-layout ';var override={nodes:{}};
    String(source).split(String.fromCharCode(10)).forEach(function(line){
      if(!line.trim().startsWith(prefix))return;
      try{var parsed=JSON.parse(decodeURIComponent(line.trim().slice(prefix.length)));if(parsed&&parsed.nodes)override=parsed;}catch(error){}
    });
    return override;
  }
  function stripVisualOverride(source){
    var prefix='%% atlas-layout ';
    return String(source).split(String.fromCharCode(10)).filter(function(line){return !line.trim().startsWith(prefix);}).join(String.fromCharCode(10)).trimEnd();
  }
  function sourceWithVisualOverride(source,override){
    var clean=stripVisualOverride(source);var hasChanges=override&&override.nodes&&Object.keys(override.nodes).length;
    return hasChanges?clean+String.fromCharCode(10)+'%% atlas-layout '+encodeURIComponent(JSON.stringify(override)):clean;
  }
  function updateEditableConnections(container){
    var svg=container.querySelector('svg');if(!svg)return;var old=svg.querySelector('.atlas-editor-edges');if(old)old.remove();
    var paths=Array.from(svg.querySelectorAll('path.flowchart-link[id^="L-"]'));if(!paths.length)return;
    var nodes={};svg.querySelectorAll('.node[data-id]').forEach(function(node){nodes[node.getAttribute('data-id')]=node;});
    var group=document.createElementNS('http://www.w3.org/2000/svg','g');group.setAttribute('class','atlas-editor-edges');group.setAttribute('pointer-events','none');
    paths.forEach(function(path){
      var sourceToken=Array.from(path.classList).find(function(name){return name.startsWith('LS-');});var targetToken=Array.from(path.classList).find(function(name){return name.startsWith('LE-');});
      var source=sourceToken&&nodes[sourceToken.slice(3)];var target=targetToken&&nodes[targetToken.slice(3)];if(!source||!target||source===target)return;
      path.style.visibility='hidden';var sourceBox=source.getBBox();var targetBox=target.getBBox();var sourceMatrix=source.transform.baseVal.consolidate();var targetMatrix=target.transform.baseVal.consolidate();if(!sourceMatrix||!targetMatrix)return;
      var sx=sourceMatrix.matrix.e,sy=sourceMatrix.matrix.f,tx=targetMatrix.matrix.e,ty=targetMatrix.matrix.f,dx=tx-sx,dy=ty-sy;
      var startFactor=Math.min(Math.abs((sourceBox.width/2)/(dx||.001)),Math.abs((sourceBox.height/2)/(dy||.001)));var endFactor=Math.min(Math.abs((targetBox.width/2)/(dx||.001)),Math.abs((targetBox.height/2)/(dy||.001)));
      var line=document.createElementNS('http://www.w3.org/2000/svg','path');line.setAttribute('d','M '+(sx+dx*startFactor)+' '+(sy+dy*startFactor)+' L '+(tx-dx*endFactor)+' '+(ty-dy*endFactor));line.setAttribute('fill','none');line.setAttribute('stroke',getComputedStyle(path).stroke||'#7f9aa3');line.setAttribute('stroke-width',getComputedStyle(path).strokeWidth||'1.5');
      var marker=path.getAttribute('marker-end');if(marker)line.setAttribute('marker-end',marker);group.appendChild(line);
    });
    var nodesGroup=svg.querySelector('g.nodes');var parent=nodesGroup&&nodesGroup.parentNode;if(parent)parent.insertBefore(group,nodesGroup);else svg.appendChild(group);
  }
  function setVisualNodeText(node,value){
    var label=node.querySelector('.nodeLabel');
    if(label){label.textContent='';String(value).split(String.fromCharCode(10)).forEach(function(line,index){if(index)label.appendChild(document.createElement('br'));label.appendChild(document.createTextNode(line));});return;}
    var text=node.querySelector('text');if(text)text.textContent=value;
  }
  function visualNodeText(node){var label=node.querySelector('.nodeLabel');if(label)return label.innerText||label.textContent||'';var text=node.querySelector('text');return text?text.textContent||'':'';}
  function editVisualNodeLabel(node,event){
    if(!node){toast('请先点选一个节点');return;}if(event){event.preventDefault();event.stopPropagation();}
    var key=node.getAttribute('data-id');var oldValue=visualNodeText(node);var input=document.getElementById('visual-label-input');var value=input.value.trim();if(!value){toast('节点文字不能为空');return;}if(value===oldValue)return;
    activeVisualOverride.nodes[key]=Object.assign({},activeVisualOverride.nodes[key]||{},{label:value});setVisualNodeText(node,value);document.getElementById('diagram-editor-status').textContent='节点文字已修改';
  }
  function applyVisualOverride(container,override){
    if(!override||!override.nodes||!Object.keys(override.nodes).length)return;
    container.querySelectorAll('.node[data-id]').forEach(function(node){var change=override.nodes[node.getAttribute('data-id')];if(!change)return;if(Number.isFinite(change.x)&&Number.isFinite(change.y))node.setAttribute('transform','translate('+change.x+', '+change.y+')');if(typeof change.label==='string')setVisualNodeText(node,change.label);});
    updateEditableConnections(container);
  }
  function enableDirectDiagramEditing(canvas){
    var svg=canvas.querySelector('svg');if(!svg)return;activeVisualNode=null;var canDrag=svg.querySelectorAll('path.flowchart-link[id^="L-"]').length>0;
    if(canvas._atlasDragCleanup)canvas._atlasDragCleanup();var dragging=null;
    function moveDrag(event){if(!dragging)return;event.preventDefault();var point=new DOMPoint(event.clientX,event.clientY).matrixTransform(svg.getScreenCTM().inverse());var view=svg.viewBox.baseVal;var x=Math.max(view.x,Math.min(view.x+view.width,dragging.nodeX+point.x-dragging.startX));var y=Math.max(view.y,Math.min(view.y+view.height,dragging.nodeY+point.y-dragging.startY));dragging.node.setAttribute('transform','translate('+x+', '+y+')');updateEditableConnections(canvas);}
    function finishDrag(){if(!dragging)return;var matrix=dragging.node.transform.baseVal.consolidate();var key=dragging.node.getAttribute('data-id');activeVisualOverride.nodes[key]=Object.assign({},activeVisualOverride.nodes[key]||{},{x:matrix.matrix.e,y:matrix.matrix.f});dragging.node.classList.remove('is-dragging');dragging=null;document.getElementById('diagram-editor-status').textContent='节点位置已调整';}
    window.addEventListener('pointermove',moveDrag,{passive:false});window.addEventListener('pointerup',finishDrag);window.addEventListener('pointercancel',finishDrag);
    canvas._atlasDragCleanup=function(){window.removeEventListener('pointermove',moveDrag);window.removeEventListener('pointerup',finishDrag);window.removeEventListener('pointercancel',finishDrag);};
    canvas.querySelectorAll('.node[data-id]').forEach(function(node){
      function selectNode(){canvas.querySelectorAll('.node.is-selected').forEach(function(selected){selected.classList.remove('is-selected');});activeVisualNode=node;node.classList.add('is-selected');document.getElementById('visual-label-input').value=visualNodeText(node);}
      node.addEventListener('click',function(event){event.stopPropagation();selectNode();});node.addEventListener('dblclick',function(event){event.preventDefault();event.stopPropagation();selectNode();var input=document.getElementById('visual-label-input');input.focus();input.select();});
      if(!canDrag)return;
      node.addEventListener('pointerdown',function(event){selectNode();event.preventDefault();event.stopPropagation();var matrix=node.transform.baseVal.consolidate();if(!matrix)return;var point=new DOMPoint(event.clientX,event.clientY).matrixTransform(svg.getScreenCTM().inverse());dragging={node:node,startX:point.x,startY:point.y,nodeX:matrix.matrix.e,nodeY:matrix.matrix.f};node.classList.add('is-dragging');});
    });
  }
  async function renderDiagramDraft(){
    var source=document.getElementById('diagram-source-editor').value.trim();var canvas=document.getElementById('diagram-editor-canvas');var status=document.getElementById('diagram-editor-status');
    if(!source){canvas.innerHTML='';status.textContent='图表源稿不能为空';status.classList.add('error');return;}
    status.textContent='正在重绘…';status.classList.remove('error');
    try{
      var rendered=await mermaid.render('diagram-edit-'+Date.now(),source);canvas.innerHTML=rendered.svg;
      if(rendered.bindFunctions)rendered.bindFunctions(canvas);
      var svg=canvas.querySelector('svg');if(svg){var metrics=diagramMetrics(svg);var available=Math.max(260,canvas.clientWidth-48);var scale=Math.min(1,available/metrics.width);svg.style.width=Math.round(metrics.width*scale)+'px';svg.style.height=Math.round(metrics.height*scale)+'px';}
      applyVisualOverride(canvas,activeVisualOverride);enableDirectDiagramEditing(canvas);
      status.textContent='预览已更新';status.classList.remove('error');
    }catch(error){console.error(error);status.textContent='语法有误：'+String(error.message||error).split(String.fromCharCode(10))[0];status.classList.add('error');}
  }
  function scheduleDiagramDraft(){clearTimeout(diagramPreviewTimer);diagramPreviewTimer=setTimeout(renderDiagramDraft,350);}
  function openDiagramEditor(panel){
    activeDiagramIndex=Number(panel.dataset.diagramIndex||0);var blocks=getMermaidBlocks(currentMd);var storedSource=blocks[activeDiagramIndex]||'';activeVisualOverride=visualOverrideFromSource(storedSource);originalVisualOverride=JSON.parse(JSON.stringify(activeVisualOverride));originalDiagramSource=stripVisualOverride(storedSource);
    document.getElementById('diagram-editor-title').textContent='图表编辑器 · 交互图 '+(activeDiagramIndex+1);
    document.getElementById('diagram-source-editor').value=originalDiagramSource;
    document.getElementById('diagram-editor').setAttribute('aria-hidden','false');document.body.classList.add('diagram-editor-open');renderDiagramDraft();
  }
  function closeDiagramEditor(){document.body.classList.remove('diagram-editor-open');document.getElementById('diagram-editor').setAttribute('aria-hidden','true');activeDiagramIndex=-1;}
  function changeDiagramLayout(direction){
    var editor=document.getElementById('diagram-source-editor');var source=editor.value;
    if(!/^(flowchart|graph)[ \t]+(TD|TB|BT|RL|LR)(?:[ \t]|$)/im.test(source)){toast('该布局按钮仅用于流程图');return;}
    activeVisualOverride={nodes:{}};editor.value=source.replace(/^(flowchart|graph)[ \t]+(TD|TB|BT|RL|LR)(?:[ \t]|$)/im,'$1 '+direction);scheduleDiagramDraft();
  }
  function downloadDiagramSource(){
    if(activeDiagramIndex<0)return;var blob=new Blob([document.getElementById('diagram-source-editor').value],{type:'text/plain;charset=utf-8'});
    downloadBlob(blob,diagramFileName({dataset:{diagramIndex:String(activeDiagramIndex)}},'mmd'));toast('源图已下载');
  }
  async function applyDiagramEdit(){
    if(activeDiagramIndex<0)return;var index=activeDiagramIndex;var source=document.getElementById('diagram-source-editor').value.trim();if(!source){toast('图表源稿不能为空');return;}source=sourceWithVisualOverride(source,activeVisualOverride);
    currentMd=replaceMermaidBlock(currentMd,index,source);document.getElementById('source-editor').value=currentMd;closeDiagramEditor();await renderDocument(currentMd);
    var panel=document.querySelector('.diagram-panel[data-diagram-index="'+index+'"]');if(panel)panel.scrollIntoView({behavior:'smooth',block:'center'});toast('此图已应用到当前图集');
  }
  function enablePan(svg){
    var down=false,startX=0,startY=0,scrollLeft=0,scrollTop=0,host=svg.closest('.mermaid');
    if(!host)return;
    svg.addEventListener('pointerdown',function(event){if(event.target.closest('.node'))return;down=true;startX=event.clientX;startY=event.clientY;scrollLeft=host.scrollLeft;scrollTop=host.scrollTop;svg.classList.add('is-panning');svg.setPointerCapture(event.pointerId);event.preventDefault();});
    svg.addEventListener('pointermove',function(event){if(!down)return;host.scrollLeft=scrollLeft-(event.clientX-startX);host.scrollTop=scrollTop-(event.clientY-startY);event.preventDefault();});
    function stopPan(){down=false;svg.classList.remove('is-panning');}
    svg.addEventListener('pointerup',stopPan);svg.addEventListener('pointercancel',stopPan);svg.addEventListener('lostpointercapture',stopPan);
  }
  function enhanceDiagrams(){
    document.querySelectorAll('.diagram-panel').forEach(function(panel){
      panel.querySelectorAll('.node').forEach(function(node){node.addEventListener('click',function(event){event.stopPropagation();focusNode(panel,node);});});
      panel.querySelectorAll('[data-diagram-class]').forEach(function(button){button.addEventListener('click',function(){focusModule(panel,button.getAttribute('data-diagram-class'),button);});});
      panel.querySelectorAll('.reset-diagram,[data-diagram-reset]').forEach(function(button){button.addEventListener('click',function(){resetPanel(panel);});});
      panel.querySelector('.zoom-out').addEventListener('click',function(){setDiagramScale(panel,currentDiagramScale(panel)-.2);});
      panel.querySelector('.zoom-fit').addEventListener('click',function(){fitDiagram(panel);});
      panel.querySelector('.zoom-in').addEventListener('click',function(){setDiagramScale(panel,currentDiagramScale(panel)+.2);});
      panel.querySelector('.edit-diagram').addEventListener('click',function(){openDiagramEditor(panel);});
      panel.querySelector('.export-svg').addEventListener('click',function(){exportDiagramSvg(panel);});
      panel.querySelector('.export-png').addEventListener('click',function(){exportDiagramPng(panel);});
      panel.addEventListener('dblclick',function(event){if(!event.target.closest('.node'))resetPanel(panel);});
      var svg=panel.querySelector('svg');if(svg){var source=getMermaidBlocks(currentMd)[Number(panel.dataset.diagramIndex||0)]||'';applyVisualOverride(panel,visualOverrideFromSource(source));enablePan(svg);fitDiagram(panel);}
    });
  }
  async function renderMermaid(){
    if(!window.mermaid){document.getElementById('runtime-warning').style.display='block';return;}
    try{
      mermaid.initialize({startOnLoad:false,theme:document.documentElement.dataset.theme==='light'?'neutral':'dark',securityLevel:'loose',fontFamily:'Microsoft YaHei, PingFang SC, sans-serif',flowchart:{htmlLabels:true,curve:'basis'},themeVariables:{fontSize:'14px',lineColor:'#7f9aa3'}});
      await mermaid.run({nodes:document.querySelectorAll('.mermaid')});
      mermaidReady=true;document.getElementById('runtime-warning').style.display='none';enhanceDiagrams();
    }catch(error){console.error(error);document.getElementById('runtime-warning').style.display='block';}
  }
  async function renderDocument(md){
    var parsed=parseMd(md);document.getElementById('doc-content').innerHTML=parsed.body;document.getElementById('toc').innerHTML=renderToc(parsed.toc);
    bindToc();mermaidReady=false;await renderMermaid();applySearch(document.getElementById('search').value);
  }
  function bindToc(){
    document.querySelectorAll('.toc-link').forEach(function(link){link.addEventListener('click',function(){document.body.classList.remove('sidebar-open');});});
  }
  function applySearch(query){
    var value=String(query||'').trim().toLowerCase();var visible=0;
    document.querySelectorAll('[data-search-section]').forEach(function(section){
      var match=!value||section.textContent.toLowerCase().includes(value);section.hidden=!match;if(match)visible++;
    });
    document.getElementById('empty-result').style.display=visible?'none':'block';
  }
  function downloadMarkdown(){
    var blob=new Blob([document.getElementById('source-editor').value],{type:'text/markdown;charset=utf-8'});
    var url=URL.createObjectURL(blob);var link=document.createElement('a');link.href=url;link.download=markdownDownloadName;link.click();URL.revokeObjectURL(url);toast('Markdown 已下载');
  }
  async function pickSource(){
    if(!window.showOpenFilePicker){toast('当前浏览器不支持直接选择文件，请使用下载 Markdown');return;}
    try{
      var handles=await window.showOpenFilePicker({types:[{description:'Markdown',accept:{'text/markdown':['.md']}}]});
      fileHandle=handles[0];var file=await fileHandle.getFile();var value=await file.text();document.getElementById('source-editor').value=value;toast('已载入 '+file.name);
    }catch(error){if(error.name!=='AbortError')toast('读取文件失败');}
  }
  async function saveSource(){
    if(!fileHandle){await pickSource();if(!fileHandle)return;}
    try{var writable=await fileHandle.createWritable();await writable.write(document.getElementById('source-editor').value);await writable.close();toast('已保存到本地源稿');}
    catch(error){console.error(error);toast('无法原位保存，请下载 Markdown');}
  }
  function openEditor(){document.getElementById('source-editor').value=currentMd;document.body.classList.add('editor-open');}
  function closeEditor(){document.body.classList.remove('editor-open');}
  function bindUi(){
    document.getElementById('search').addEventListener('input',function(event){applySearch(event.target.value);});
    document.getElementById('open-editor').addEventListener('click',openEditor);document.getElementById('close-editor').addEventListener('click',closeEditor);document.getElementById('editor-backdrop').addEventListener('click',closeEditor);
    document.getElementById('pick-source').addEventListener('click',pickSource);document.getElementById('save-source').addEventListener('click',saveSource);document.getElementById('download-source').addEventListener('click',downloadMarkdown);
    document.getElementById('diagram-source-editor').addEventListener('input',scheduleDiagramDraft);
    document.querySelectorAll('[data-layout]').forEach(function(button){button.addEventListener('click',function(){changeDiagramLayout(button.getAttribute('data-layout'));});});
    document.getElementById('edit-visual-label').addEventListener('click',function(){editVisualNodeLabel(activeVisualNode);});
    document.getElementById('visual-label-input').addEventListener('keydown',function(event){if(event.key==='Enter')editVisualNodeLabel(activeVisualNode,event);});
    document.getElementById('reset-diagram-source').addEventListener('click',function(){document.getElementById('diagram-source-editor').value=originalDiagramSource;activeVisualOverride=JSON.parse(JSON.stringify(originalVisualOverride));renderDiagramDraft();});
    document.getElementById('reset-visual-layout').addEventListener('click',function(){activeVisualOverride={nodes:{}};renderDiagramDraft();toast('已恢复自动布局');});
    document.getElementById('download-diagram-source').addEventListener('click',downloadDiagramSource);document.getElementById('close-diagram-editor').addEventListener('click',closeDiagramEditor);document.getElementById('apply-diagram-edit').addEventListener('click',applyDiagramEdit);
    document.getElementById('apply-preview').addEventListener('click',async function(){currentMd=document.getElementById('source-editor').value;closeEditor();await renderDocument(currentMd);toast('预览已更新，记得保存源稿');});
    document.getElementById('theme-toggle').addEventListener('click',async function(){document.documentElement.dataset.theme=document.documentElement.dataset.theme==='dark'?'light':'dark';await renderDocument(currentMd);});
    document.getElementById('open-sidebar').addEventListener('click',function(){document.body.classList.add('sidebar-open');});document.getElementById('close-sidebar').addEventListener('click',function(){document.body.classList.remove('sidebar-open');});
    document.addEventListener('keydown',function(event){if(event.key!=='Escape')return;if(document.body.classList.contains('diagram-editor-open'))closeDiagramEditor();else if(document.body.classList.contains('editor-open'))closeEditor();else document.body.classList.remove('sidebar-open');});
    bindToc();
  }
  bindUi();renderMermaid();
})();
</script>
</body>
</html>`;
}

function findLarkRuntime() {
  const base = path.join(process.env.LOCALAPPDATA || '', 'hermes', 'node');
  const nodeExe = path.join(base, 'node.exe');
  const runner = path.join(base, 'node_modules', '@larksuite', 'cli', 'scripts', 'run.js');
  if (fs.existsSync(nodeExe) && fs.existsSync(runner)) {
    return { command: nodeExe, prefix: [runner], shell: false };
  }
  const command = process.platform === 'win32' ? 'lark-cli.cmd' : 'lark-cli';
  const probe = spawnSync(command, ['--help'], { encoding: 'utf8', windowsHide: true, shell: process.platform === 'win32' });
  if (!probe.error && probe.status === 0) return { command, prefix: [], shell: process.platform === 'win32' };
  throw new Error('未找到 lark-cli。仅本地生成不需要它；飞书上传模式请先安装并完成认证。');
}

function runLark(cliArgs) {
  const runtime = findLarkRuntime();
  const result = spawnSync(runtime.command, runtime.prefix.concat(cliArgs), {
    cwd: path.dirname(htmlPath),
    encoding: 'utf8',
    windowsHide: true,
    shell: runtime.shell,
    maxBuffer: 20 * 1024 * 1024
  });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error((result.stderr || result.stdout || 'lark-cli 执行失败').trim());
  const output = (result.stdout || '').trim();
  try {
    return JSON.parse(output);
  } catch (error) {
    throw new Error('lark-cli 返回内容无法解析：' + output.slice(0, 500));
  }
}

function listFeishuFiles(folderToken) {
  const listing = runLark([
    'drive', 'files', 'list',
    '--folder-token', folderToken,
    '--page-size', '200',
    '--as', 'user',
    '--format', 'json'
  ]);
  return listing && listing.data && Array.isArray(listing.data.files) ? listing.data.files : [];
}

function sha256(filePath) {
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

function uploadAndVerify(filePath) {
  const fileName = path.basename(filePath);
  const folderToken = options.folderToken;
  const requestedToken = options.fileToken;
  const filesBefore = listFeishuFiles(folderToken);
  const matchesBefore = filesBefore.filter((file) => file.type === 'file' && file.name === fileName);
  const existing = requestedToken
    ? filesBefore.find((file) => file.type === 'file' && file.token === requestedToken && file.name === fileName)
    : matchesBefore.length === 1 ? matchesBefore[0] : null;
  if (requestedToken && !existing) throw new Error('指定 file token 与目标文件夹中的同名文件不匹配，已停止上传。');
  if (!requestedToken && matchesBefore.length > 1) throw new Error('飞书文件夹存在多个同名文件，已停止上传：' + fileName);

  const uploadArgs = [
    'drive', '+upload',
    '--folder-token', folderToken,
    '--file', path.resolve(filePath),
    '--name', fileName,
    '--as', 'user',
    '--format', 'json'
  ];
  if (existing) uploadArgs.splice(4, 0, '--file-token', existing.token);
  const upload = runLark(uploadArgs);
  if (!upload.ok) throw new Error('飞书上传未返回 ok=true');

  if (existing) {
    const moved = runLark([
      'drive', '+move',
      '--file-token', existing.token,
      '--type', 'file',
      '--folder-token', folderToken,
      '--as', 'user',
      '--format', 'json'
    ]);
    if (!moved.ok) throw new Error('飞书文件未确认归位到目标文件夹');
  }

  const filesAfter = listFeishuFiles(folderToken);
  const expectedToken = existing && existing.token;
  const matchesAfter = filesAfter.filter((file) => file.type === 'file' && file.name === fileName && (!expectedToken || file.token === expectedToken));
  if (matchesAfter.length !== 1) throw new Error('上传后回读未唯一找到目标文件：' + fileName);

  const remoteFile = matchesAfter[0];
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'interactive-atlas-'));
  const downloadedPath = path.join(tempDir, 'remote-' + fileName);
  try {
    runLark([
      'drive', '+download',
      '--file-token', remoteFile.token,
      '--output', downloadedPath,
      '--overwrite',
      '--as', 'user',
      '--format', 'json'
    ]);
    if (!fs.existsSync(downloadedPath)) throw new Error('飞书下载命令完成，但未找到回读文件。');
    const localSha256 = sha256(filePath);
    const remoteSha256 = sha256(downloadedPath);
    if (localSha256 !== remoteSha256) throw new Error('飞书云端文件 SHA256 与本地文件不一致。');
    return Object.assign({}, remoteFile, {
      upload_mode: existing ? 'overwrite' : 'create',
      sha256: localSha256
    });
  } finally {
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
}

if (!fs.existsSync(mdPath)) throw new Error('找不到 Markdown 源稿：' + mdPath);
if (!fs.existsSync(MERMAID_VENDOR)) throw new Error('找不到 Mermaid 本地运行库：' + MERMAID_VENDOR);

const mdContent = fs.readFileSync(mdPath, 'utf8').replace(/^\uFEFF/, '');
const mermaidRuntime = zlib.gunzipSync(fs.readFileSync(MERMAID_VENDOR)).toString('utf8');
const html = buildHtml(mdContent, mermaidRuntime);
fs.writeFileSync(htmlPath, html, 'utf8');

console.log('生成完成：' + htmlPath);
console.log('源稿：' + mdPath);
console.log('网页大小：' + fs.statSync(htmlPath).size + ' bytes');

if (shouldUpload) {
  const remote = uploadAndVerify(htmlPath);
  console.log('飞书' + (remote.upload_mode === 'create' ? '新建' : '原位覆盖') + '成功：' + remote.name);
  if (remote.url) console.log('飞书链接：' + remote.url);
  console.log('飞书修改时间：' + remote.modified_time);
  console.log('云端回读 SHA256：' + remote.sha256);
}
