#!/usr/bin/env node
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const skillRoot = path.resolve(__dirname, '..');
const generator = path.join(__dirname, 'generate-interactive-atlas.js');
const sample = path.join(skillRoot, 'assets', 'sample-architecture.md');
const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-contract-'));
const output = path.join(tempDir, 'sample.html');

try {
  const result = spawnSync(process.execPath, [
    generator,
    '--input', sample,
    '--output', output,
    '--brand', 'Contract Product',
    '--label', '信息架构',
    '--version', 'V9.9'
  ], { encoding: 'utf8', windowsHide: true });

  assert.strictEqual(result.status, 0, result.stderr || result.stdout);
  assert.ok(fs.existsSync(output), '未生成 HTML');
  const html = fs.readFileSync(output, 'utf8');
  const generatorSource = fs.readFileSync(generator, 'utf8');
  assert.ok(html.length > 3_000_000, 'HTML 未内嵌完整 Mermaid 运行库');
  assert.ok(html.includes('Contract Product'), '品牌参数未生效');
  assert.ok(html.includes('信息架构 / V9.9'), '类型或版本参数未生效');
  assert.ok(html.includes('class="zoom-in"'), '缺少缩放控件');
  assert.ok(html.includes('class="export-svg"'), '缺少 SVG 导出');
  assert.ok(html.includes('class="export-png"'), '缺少 PNG 导出');
  assert.ok(html.includes('id="diagram-source-editor"'), '缺少单图源码编辑器');
  assert.ok(html.includes('atlas-layout'), '缺少可视布局元数据支持');
  assert.ok(!/<script[^>]+src=["']https?:/i.test(html), 'HTML 依赖网络脚本');
  assert.ok(!generatorSource.includes('FEISHU_FOLDER_TOKEN'), '生成器仍有固定飞书目录常量');
  assert.ok(!generatorSource.includes('KNOWN_FEISHU_FILE_TOKENS'), '生成器仍有固定飞书文件映射');

  const missingUploadScope = spawnSync(process.execPath, [generator, '--input', sample, '--upload'], {
    encoding: 'utf8',
    windowsHide: true
  });
  assert.notStrictEqual(missingUploadScope.status, 0, '上传模式未要求 folder token');
  assert.match(missingUploadScope.stderr, /--folder-token/, '上传错误没有说明缺少 folder token');

  console.log('Contract passed: offline atlas generation, interaction controls, parameterization, and upload guard.');
} finally {
  fs.rmSync(tempDir, { recursive: true, force: true });
}
