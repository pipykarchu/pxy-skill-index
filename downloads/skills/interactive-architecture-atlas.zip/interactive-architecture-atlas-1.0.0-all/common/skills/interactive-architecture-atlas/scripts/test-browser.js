#!/usr/bin/env node
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { pathToFileURL } = require('url');

let playwright;
try {
  playwright = require('playwright');
} catch (error) {
  throw new Error('浏览器验收需要 Playwright。请安装 playwright，或在已提供 Playwright 的工作环境中运行。');
}

function option(name) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : null;
}

const htmlPath = path.resolve(option('--html') || '');
const screenshotDir = option('--screenshot-dir') ? path.resolve(option('--screenshot-dir')) : null;
if (!htmlPath || !fs.existsSync(htmlPath)) throw new Error('必须提供存在的 --html <atlas.html>。');
if (screenshotDir) fs.mkdirSync(screenshotDir, { recursive: true });

(async () => {
  const downloadDir = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-download-'));
  const browser = await playwright.chromium.launch({ headless: true });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, acceptDownloads: true });
  const page = await context.newPage();
  page.setDefaultTimeout(10_000);
  const pageErrors = [];
  const networkRequests = [];
  page.on('pageerror', (error) => pageErrors.push(error.message));
  page.on('request', (request) => {
    if (/^https?:/i.test(request.url())) networkRequests.push(request.url());
  });

  try {
    await page.goto(pathToFileURL(htmlPath).href, { waitUntil: 'load' });
    await page.waitForSelector('.diagram-panel .mermaid svg', { timeout: 15_000 });
    console.log('Stage passed: desktop render');
    const diagrams = await page.locator('.diagram-panel .mermaid svg').count();
    assert.ok(diagrams >= 2, 'Mermaid 图表数量不足');

    const visibleSizes = await page.locator('.diagram-panel .mermaid svg').evaluateAll((nodes) =>
      nodes.map((node) => ({ width: node.getBoundingClientRect().width, height: node.getBoundingClientRect().height }))
    );
    assert.ok(visibleSizes.every((size) => size.width > 80 && size.height > 40), '存在空白或尺寸异常的图表');
    assert.strictEqual(await page.locator('#runtime-warning').isVisible(), false, 'Mermaid 运行时警告可见');
    if (screenshotDir) await page.screenshot({ path: path.join(screenshotDir, 'atlas-desktop.png'), fullPage: true });

    const firstPanel = page.locator('.diagram-panel').first();
    await firstPanel.locator('.zoom-in').click();
    assert.ok(parseInt(await firstPanel.locator('.zoom-value').innerText(), 10) > 100, '放大按钮未生效');
    await firstPanel.locator('.node').first().click();
    assert.ok(await firstPanel.locator('.node.is-selected').count() === 1, '节点点击未触发高亮');
    console.log('Stage passed: zoom and highlight');

    const svgDownload = page.waitForEvent('download', { timeout: 15_000 });
    await firstPanel.locator('.export-svg').click();
    const svgFile = await svgDownload;
    const svgPath = path.join(downloadDir, await svgFile.suggestedFilename());
    await svgFile.saveAs(svgPath);
    assert.ok(fs.statSync(svgPath).size > 100, 'SVG 导出为空');
    console.log('Stage passed: SVG export');

    const pngDownload = page.waitForEvent('download', { timeout: 15_000 });
    await firstPanel.locator('.export-png').click();
    const pngFile = await pngDownload;
    const pngPath = path.join(downloadDir, await pngFile.suggestedFilename());
    await pngFile.saveAs(pngPath);
    assert.ok(fs.statSync(pngPath).size > 100, 'PNG 导出为空');
    console.log('Stage passed: PNG export');

    await firstPanel.locator('.edit-diagram').click();
    await page.waitForSelector('body.diagram-editor-open #diagram-editor-canvas svg');
    assert.ok((await page.locator('#diagram-source-editor').inputValue()).includes('flowchart'), '单图编辑器未加载 Mermaid 源码');
    await page.locator('#close-diagram-editor').click();
    await page.waitForTimeout(250);
    console.log('Stage passed: diagram editor');

    await page.setViewportSize({ width: 390, height: 844 });
    await page.reload({ waitUntil: 'load' });
    await page.waitForSelector('.diagram-panel .mermaid svg', { timeout: 15_000 });
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    assert.ok(overflow <= 2, '移动端页面发生横向溢出：' + overflow + 'px');
    await page.locator('#open-sidebar').click();
    await page.waitForTimeout(250);
    assert.ok(await page.locator('#sidebar').isVisible(), '移动端目录未打开');
    await page.locator('#close-sidebar').click();
    await page.waitForTimeout(250);
    console.log('Stage passed: mobile layout');
    if (screenshotDir) await page.screenshot({ path: path.join(screenshotDir, 'atlas-mobile.png'), fullPage: true });

    assert.deepStrictEqual(networkRequests, [], '离线页面发起了网络请求');
    assert.deepStrictEqual(pageErrors, [], '页面脚本报错：' + pageErrors.join('; '));
    console.log('Browser passed: render, zoom, highlight, SVG/PNG export, diagram editor, offline mode, and 390x844 layout.');
  } finally {
    await context.close();
    await browser.close();
    fs.rmSync(downloadDir, { recursive: true, force: true });
  }
})().catch((error) => {
  console.error(error.stack || error.message);
  process.exit(1);
});
