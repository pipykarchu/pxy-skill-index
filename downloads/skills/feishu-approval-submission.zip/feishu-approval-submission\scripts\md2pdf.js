// md2pdf.js — Markdown → PDF on Windows without pandoc/LibreOffice.
// Usage:
//   node md2pdf.js <input.md> <output.pdf>
//   (optional) set EDGE env var to override Edge path
// Prereqs: npm i markdown-it (run once in a scratch dir, or NODE_PATH), Edge installed.
// Uses: markdown-it to render HTML with CJK-friendly styles, then Edge headless --print-to-pdf.
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const MarkdownIt = require('markdown-it');

const md = new MarkdownIt({ html: false, linkify: true, typographer: true });

const css = `
  body { font-family: "Microsoft YaHei", "SimSun", sans-serif; font-size: 12pt; line-height: 1.7; color: #222; margin: 40px 50px; }
  h1 { font-size: 20pt; border-bottom: 2px solid #333; padding-bottom: 8px; }
  h2 { font-size: 16pt; border-bottom: 1px solid #ccc; padding-bottom: 4px; margin-top: 28px; }
  h3 { font-size: 14pt; }
  table { border-collapse: collapse; width: 100%; margin: 12px 0; }
  th, td { border: 1px solid #999; padding: 6px 10px; font-size: 10.5pt; }
  th { background: #f0f0f0; }
  tr { page-break-inside: avoid; }
  code { background: #f5f5f5; padding: 2px 4px; border-radius: 3px; font-size: 10pt; }
  pre { background: #f5f5f5; padding: 10px; border-radius: 4px; overflow-x: auto; }
  blockquote { border-left: 4px solid #ccc; margin-left: 0; padding-left: 14px; color: #555; }
  ul, ol { padding-left: 24px; }
  li { margin: 3px 0; }
  hr { border: none; border-top: 1px solid #ddd; margin: 20px 0; }
  @media print { body { margin: 20px 30px; } }
`;

const EDGE = process.env.EDGE || 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';

if (process.argv.length < 4) {
  console.error('Usage: node md2pdf.js <input.md> <output.pdf>');
  process.exit(1);
}

const inputMd = path.resolve(process.argv[2]);
const outputPdf = path.resolve(process.argv[3]);
const tmpHtml = path.join(process.env.TEMP || '.', 'md2pdf_' + Date.now() + '_' + Math.floor(Math.random() * 10000) + '.html');

const src = fs.readFileSync(inputMd, 'utf8');
const html = `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><style>${css}</style></head><body>${md.render(src)}</body></html>`;
fs.writeFileSync(tmpHtml, html, 'utf8');
const fileUrl = 'file:///' + tmpHtml.replace(/\\/g, '/');

try {
  execFileSync(EDGE, ['--headless', '--disable-gpu', '--no-sandbox', '--print-to-pdf=' + outputPdf, '--no-pdf-header-footer', fileUrl], { timeout: 60000, stdio: 'pipe' });
  const size = fs.statSync(outputPdf).size;
  console.log('OK', outputPdf, size + ' bytes');
} catch (e) {
  console.error('FAIL', outputPdf, e.message);
  process.exitCode = 1;
} finally {
  try { fs.unlinkSync(tmpHtml); } catch (e) {}
}
