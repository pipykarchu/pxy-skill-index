# applink.feishu.cn 短链解析

## 问题

用户分享的 `https://applink.feishu.cn/T98QtfoC5Dx1` 这类短链：
- `curl -I` 返回 404（HEAD 不支持）
- `curl` 返回的是 SPA 落地页 HTML，无目标信息
- 浏览器工具无 Chrome 时无法直接打开

## 解析 API（逆向自 applink_web umi.js）

```bash
curl "https://open.feishu.cn/open-apis/applink/longlink/v1/get?shortLink=%2FT98QtfoC5Dx1&businessTag=applink"
```

- `shortLink` = 短链 pathname（**含开头 `/`**，URL 编码）
- `businessTag=applink` 固定
- 无需鉴权，直接 GET

成功响应：

```json
{"code":0,"data":{"businessTag":"applink","link":"https://applink.feishu.cn/client/mini_program/open?appId=cli_xxx&mode=appCenter&path=pages%2Fapproval-form%2Findex%3Fid%3D7672411260209630448%26scene%3Ddefinition-share&path_pc=...&relaunch=true"},"msg":"success"}
```

## 判读

长链里的关键信息在 `path` 参数（URL 解码后）：

| path 特征 | 含义 |
|---|---|
| `pages/approval-form/index?id=<数字ID>&scene=definition-share` | 审批定义分享；`id` 是审批模板在客户端的数字 ID |
| `pages/create-form/index?id=<数字ID>` | 同一模板的提单页 |
| `scene=definition-share` | 定义分享场景 |

**注意：`id=<数字ID>` 不是 OpenAPI 的 `approval_code`**。拿数字 ID 直接调 `approvals get` 报 `1390002 approval code not found`（v4 接口）或 `60002`（v2 接口）。必须用关键词搜索找到 UUID 格式的 approval_code。

## 下一步：找 approval_code

```bash
lark-cli approval approvals search --data @./search.json --as user
# search.json: {"keyword":"发布"}
```

- 用 `create_link` 中是否含同一 `id=<数字ID>` 确认命中
- `is_external: false` 才是原生审批（可走 instances create）

## 其他来源（非 applink）

用户直接给 `https://xxx.feishu.cn/docx/<token>` / `/wiki/<token>` 等链接时，不需要本方法——直接用 lark-drive `+inspect` 或按 URL 路径取 token。
