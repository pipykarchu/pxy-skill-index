# 审批附件上传：拿到 attachmentV2 / image 的 file code

## 核心事实

- **attachmentV2 / image 控件的 `value` 是审批域的文件 code，不是云盘 file_token**。
  把 drive `+upload` 返回的 file_token 直接填进 form，提交报：
  `1395006 validate form error 控件值不合法或者为空。控件= widgetXXX`
- 必须调审批专用上传接口拿 file_code。
- 官方 lark-approval 的 value-sourcing 说"不负责上传、用户必须提供 file code"——本配方补上获取方式。

## 接口与正确调用

端点：`POST /open-apis/approval/v4/files/upload`（multipart/form-data）

```bash
# body 文件（放 CWD 内，供 @./ 相对路径引用）
# {"file_name":"Mozin-APP-发布执行计划-V1.5.0-20260804.pdf","type":"attachment"}

lark-cli api POST /open-apis/approval/v4/files/upload \
  --data @./body.json \
  --file file=@./xxx.pdf \
  --as bot
```

- **必须 `--as bot`**：user token 报 `99991668 user access token not support`（与旧版 approval API 相同）
- `--data` 的 JSON 字段自动变成 multipart 的 form_fields（dry-run 可见 `form_fields`），`--file` 是二进制文件字段

成功响应（取 `urls_detail[].code`）：

```json
{"ok":true,"identity":"bot","data":{"urls_detail":[{"code":"01AEECFB-6534-4929-9C3A-5F422FAF1BDB","url":"https://...pdf"}]}}
```

## 错误码对照（踩坑实录）

| 传法 | 结果 |
|---|---|
| `file_type:"pdf"`（字段名错） | `1390001 Parameter type is empty` |
| `type:"pdf"`（值错） | `1390001 Parameter type is invalid. valid type has: image, attachment.` |
| `type:"attachment"`（字段+值都对） | ✅ 成功 |
| `--params` 传 file_name/type（当 query 传） | 不生效 / `1390001` |
| `--file` 重复多次传不同字段 | 只保留最后一个 `--file`，前面的被丢弃 |
| 用云盘 file_token 填 attachmentV2 | `1395006 控件值不合法或者为空` |

**结论：字段名是 `type`，合法值只有 `image` 或 `attachment`**（不是文件扩展名！）。

## 组装进 instances create

```json
{
  "id": "widget17863723584190001",
  "type": "attachmentV2",
  "value": ["01AEECFB-6534-4929-9C3A-5F422FAF1BDB"]
}
```

多个附件传数组：`"value": ["code1","code2","code3"]`

## 用户自己在飞书客户端提交的场景

不需要 file_code——用户在客户端里从云盘选文件即可。此时只需：
1. md→PDF（`scripts/md2pdf.js`）
2. `drive +upload --file ./xxx.pdf --folder-token <目标文件夹> --as user`（上传到云盘对应文件夹，如"05-发布与运维"）
3. 给用户路径指引：云空间 → 某文件夹 → 文件名

## 节点审批人（need_approver=true）

`node_list` 中 `need_approver=true` 的节点必须补 `node_approver_list`：
```json
{"key":"<node_id>","value":["<open_id>"]}
```
审批人姓名 → open_id 用 `lark-cli contact +search-user --query <姓名> --as user`。
