---
name: feishu-approval-submission
description: "飞书审批单填报与附件上传全流程：解析 applink 分享短链定位审批定义、搜索 approval_code、读取表单控件结构、把本地材料转 PDF 并上传（审批 file_code 而非云盘 file_token）、组装 instances create payload。用户提供审批分享链接/模板链接，或问'这个审批怎么填/帮我填好/材料齐不齐/提交审批'时使用。补充官方 lark-approval 未覆盖的附件上传与短链解析能力。"
license: MIT
---

# 飞书审批单填报与附件上传

官方 `lark-approval` 技能覆盖定义搜索/读取/实例创建，但**明确不负责附件上传**（value-sourcing 要求用户直接给 file code），且不覆盖 applink 短链解析。本技能补齐这两块 + PowerShell 实操坑。

## 何时使用

- 用户分享 `https://applink.feishu.cn/<key>` 链接问"这是什么/怎么填"
- 需要给审批附件控件（attachmentV2/image）准备 file code
- 需要把本地 md/docx 材料转 PDF 并传到云盘/审批附件
- 要组装 `approval instances create` 的完整 payload（含节点审批人）

## 标准工作流

1. **解析分享链接**（用户只给 applink 短链时）→ [`references/applink-shortlink-resolution.md`](references/applink-shortlink-resolution.md)
   - 短链里 `path=pages/approval-form/index?id=<数字ID>&scene=definition-share` = 审批定义分享
   - 数字 ID **不是** OpenAPI approval_code
2. **找 approval_code**：`lark-cli approval approvals search` 按关键词搜（如"发布"），用返回里的 `approval_code`；用 `create_link` 中是否含同一 `id=<数字ID>` 确认命中
3. **读表单结构**：`lark-cli approval approvals get --approval-code <code> --as user`，重点看 `form`（控件 id/type/option value）和 `node_list`（need_approver=true 的节点必须补审批人）
4. **准备附件**：
   - md→PDF（无 pandoc）→ [`scripts/md2pdf.js`](scripts/md2pdf.js)：markdown-it + Edge headless `--print-to-pdf --no-pdf-header-footer`
   - 用户自己在飞书客户端提交 → PDF 用 `drive +upload` 传到云盘目标文件夹即可
   - 走 API 提单 → 必须用审批上传接口拿 file_code → [`references/approval-attachment-upload.md`](references/approval-attachment-upload.md)
5. **组装并验证**：`instances create --data @./payload.json --as user --dry-run` 先验结构；真实提交前向用户确认表单值与审批人

## 用户偏好（皮玺玉）

- **材料/附件由助手准备并上传到位；提交动作用户自己在飞书客户端点**（"材料帮我上传，我自己点提交"）。除非用户明确说"帮我提交/直接提单"，否则停在 dry-run + 填充指引。
- 发布说明等文案要反映**最新状态**（如"OTA 已修复"），不要照搬文档里过期的"已知限制"。

## 关键陷阱（PowerShell 5.1 + lark-cli）

- **内联 JSON 参数必坏**：`--params '{"a":1}'` / `--data '{...}'` 在 PS 5.1 传给 native exe 时引号被剥，报 `invalid format / invalid JSON format`。解法：把 JSON 写成文件，用 **CWD 内相对路径** `--data @./x.json`（绝对路径被拒：`must be a relative path within the current directory`）。
- **`&` 调用被 Hermes terminal 拦截**（"Foreground command uses '&' backgrounding"）：直接写 exe 全路径执行，或用 `cmd /c "..."` 包装。
- **workdir 参数含中文被拒**：依赖 shell 默认 CWD（本身就是中文路径）即可，别传 workdir。
- **.ps1 验证脚本必须纯 ASCII**：PS 5.1 把无 BOM 的 UTF-8 按 ANSI 解析，脚本里任何中文字面量会让后续行报莫名其妙的 `Unexpected token`。中文路径用相对路径或环境变量注入，不要写进脚本。
- **`--file` 多次传只保留最后一个**：multipart 多字段要用 `--data`(form_fields) + `--file`(文件) 组合，见附件上传 reference。
- **审批文件上传必须 `--as bot`**：user token 报 `99991668 user access token not support`。

## 支持文件

- `references/applink-shortlink-resolution.md` — applink 短链解析 API（逆向所得）+ 判读方法
- `references/approval-attachment-upload.md` — 审批附件 file_code 上传完整配方 + 错误码对照
- `scripts/md2pdf.js` — Windows 无 pandoc 的 md→PDF 转换脚本（markdown-it + Edge headless）
