#!/usr/bin/env node
// Upload a local file to Feishu approval and print the file_code for attachmentV2.
// Usage: node approval-upload.js <pdf-path> [--name <display-name>] [--type attachment|image]
// Prereq: lark-cli on PATH or set LARK_CLI env to the exe path; run from the dir containing <pdf-path> (relative paths only).
// Returns the file_code (urls_detail[0].code) — this is what attachmentV2 value arrays need.
const { execFileSync } = require('child_process');
const path = require('path');

const cli = process.env.LARK_CLI || 'lark-cli';
const fileArg = process.argv[2];
if (!fileArg) { console.error('usage: node approval-upload.js <file> [--name <name>] [--type attachment|image]'); process.exit(2); }

const nameIdx = process.argv.indexOf('--name');
const typeIdx = process.argv.indexOf('--type');
const name = nameIdx > -1 ? process.argv[nameIdx + 1] : path.basename(fileArg);
const type = typeIdx > -1 ? process.argv[typeIdx + 1] : 'attachment';

// lark-cli requires relative paths within CWD — mirror the file name relative to cwd.
const rel = path.relative(process.cwd(), path.resolve(fileArg));
if (rel.startsWith('..') || path.isAbsolute(rel)) {
  console.error('file must be inside current working directory (lark-cli @file/--file only accept relative paths)');
  process.exit(2);
}

const body = { file_name: name, type };
const bodyFile = path.join(process.cwd(), `._approval_upload_${Date.now()}.json`);
require('fs').writeFileSync(bodyFile, JSON.stringify(body), 'utf8');

try {
  const out = execFileSync(cli, [
    'api', 'POST', '/open-apis/approval/v4/files/upload',
    '--data', '@' + path.basename(bodyFile),
    '--file', 'file=' + rel,
    '--as', 'bot',
  ], { encoding: 'utf8', timeout: 60000 });
  const parsed = JSON.parse(out);
  if (!parsed.ok) { console.error('upload failed:', parsed.error || parsed); process.exit(1); }
  const code = parsed.data.urls_detail?.[0]?.code;
  console.log(code || out);
} catch (e) {
  console.error('FAIL:', (e.stdout || '') + (e.stderr || e.message));
  process.exit(1);
} finally {
  try { require('fs').unlinkSync(bodyFile); } catch (e) {}
}
