# applink 短链解析 —— 逆向记录（2026-08-13 验证）

## 背景

用户分享 `https://applink.feishu.cn/T98QtfoC5Dx1`（飞书审批定义分享），需要解析出真实资源。

## 失败路径（不要重复）

- `curl -I` / `curl -s` 访问 applink URL → 返回 SPA HTML（200），无重定向
- 试 `api/short/link?key=`、`api/shortlink?key=`、`short/link?key=` 等候选端点 → 全部返回同一个 SPA HTML（前端路由兜底，不是 API）
- 直接对审批数字 id 调 `approvals get` → `1390002 approval code not found`（数字 id ≠ UUID approval_code）
- 旧版 API `approval/v2/approval/get` → user token 不支持（`user access token not support`）；bot token → `60002 approval code not found`

## 成功路径

### 1. 找前端解析 API

```bash
# 下载落地页，提取 JS chunk 列表
curl -s "https://applink.feishu.cn/T98QtfoC5Dx1" -o applink.html
# 从 HTML 里找到 <script src="//lf-package-cn.feishucdn.com/obj/feishu-static/lark/open/applink_web/umi.<hash>.js">
curl -s "https://lf-package-cn.feishucdn.com/obj/feishu-static/lark/open/applink_web/umi.0255ea30.js" -o umi.js
# 在 umi.js 里搜 "longlink" 找到 API 拼装代码
```

关键代码（umi.js 中 `de()` 函数）：

```js
function de(e) {
  var n = "".concat($("open"), "/open-apis/applink/longlink/v1/get?shortLink=").concat(e, "&businessTag=applink");
  return Pe(n, {method: "GET"});
}
```

`$("open")` 对应 HTML 里 `window.outDomain = {"larkOpen": "https://open.feishu.cn", ...}`。

### 2. 调用解析 API

```bash
curl -s "https://open.feishu.cn/open-apis/applink/longlink/v1/get?shortLink=%2FT98QtfoC5Dx1&businessTag=applink"
```

返回（code=0 成功）：

```json
{
  "code": 0,
  "data": {
    "businessTag": "applink",
    "link": "https://applink.feishu.cn/client/mini_program/open?appId=cli_9cb844403dbb9108&mode=appCenter&path=pages%2Fapproval-form%2Findex%3Fid%3D7672411260209630448%26scene%3Ddefinition-share&path_pc=pc%2Fpages%2Fcreate-form%2Findex%3Fid%3D7672411260209630448%26scene%3Ddefinition-share&relaunch=true"
  },
  "msg": "success"
}
```

### 3. 解读长链接

- `appId=cli_9cb844403dbb9108` → 飞书审批小程序
- `path=pages/approval-form/index?id=7672411260209630448&scene=definition-share` → 审批定义分享，模板 id = 7672411260209630448
- `scene=definition-share` → 分享的是审批定义（模板），不是已提交的实例

### 4. 找对应 approval_code（UUID）

```bash
# 写临时 JSON 到 cwd：{"keyword":"发布"}
# PowerShell 下必须 cmd /c 包装
cmd /c "lark-cli.exe approval approvals search --data @./_tmp_data.json --as user"
```

结果里 `create_link` 包含 `id=7672411260209630448` 的那条就是要找的定义；用它返回的 UUID `approval_code` 再调 `approvals get` 拿完整表单。

## 审批表单结构要点（"版本发布审批"实例）

`approvals get` 返回：
- `approval_name`: 版本发布审批
- `form`（JSON 字符串数组，控件含 id/type/required/option）：
  - `widget17863717659860001` radioV2 发布类型：固件/APP/平台服务/业务后端/Web前端/桌面工具/AI模型/配置数据
  - `widget17863718567950001` radioV2 风险等级：A级/B级/C级
  - `widget17863719425740001` input 版本号
  - `widget17863719618370001` textarea 发布说明
  - `widget17863723584190001` attachmentV2 发布执行计划（必填，value 是 file code 数组）
  - `widget17863720476960001` attachmentV2 附件（必填）
- `node_list`: 节点含 `need_approver=true` 的"项目负责人"节点（发起时需在 `node_approver_list` 补审批人 open_id，approver_chosen_multi=true 可多人）

## 经验教训

- applink 短链的解析入口是 **open.feishu.cn 的 open-apis 路径**，不是 applink.feishu.cn 自身
- 前端 SPA 的 API 拼装逻辑在 webpack chunk 里，搜路径关键词（longlink/shortLink）比猜端点快
- 审批"定义分享"数字 id 与 OpenAPI UUID approval_code 是两套标识，必须经 search 桥接
