---
name: feishu-link-resolution
version: 1.0.0
license: MIT
description: "解析飞书分享链接。applink.feishu.cn 短链（分享审批定义/表单/应用等）用开放平台 longlink API 解析为真实长链接；普通 docx/sheet/wiki 链接按 URL 路径提取 token。用户发来'我在飞书分享了一个...'链接时使用。含 PowerShell 5.1 下调 lark-cli 的 JSON 参数传参技巧与审批材料准备（md→PDF）配套。"
---

# feishu-link-resolution

## 场景

用户发来飞书链接（尤其 `applink.feishu.cn/xxx` 短链），问"这是什么/怎么填/帮我处理"时，第一步是把短链解析成真实资源（文档、审批定义、表单、应用）。

## 核心：applink 短链解析 API

`applink.feishu.cn/<KEY>`（如 `https://applink.feishu.cn/T98QtfoC5Dx1`）是 SPA 落地页，**curl 直接访问返回 HTML 而非重定向**，解析逻辑在前端 JS 里。真正的解析 API（逆向自 applink_web 的 umi.js，2026-08 验证有效）：

```
GET https://open.feishu.cn/open-apis/applink/longlink/v1/get?shortLink=/<KEY>&businessTag=applink
```

返回：

```json
{ "code": 0, "data": { "businessTag": "applink", "link": "https://applink.feishu.cn/client/mini_program/open?appId=cli_xxx&path=pages%2Fapproval-form%2Findex%3Fid%3D7672411260209630448%26scene%3Ddefinition-share&relaunch=true" }, "msg": "success" }
```

**长链接里解码出的参数就是资源标识**：
- `path=...approval-form/index?id=<数字>` + `scene=definition-share` → 审批定义分享，数字 id 是审批模板 ID（见下节）
- `appId=cli_xxx` → 应用 ID
- `scene=xxx` 表明分享类型

### 逆向方法（如果 API 失效）

1. `curl -s "https://applink.feishu.cn/<KEY>"` 保存 HTML，找 `<script src=".../applink_web/umi.<hash>.js">`
2. 下载该 JS，搜索 `longlink` 或 `shortLink`，找到 `de()` 函数里的 API 拼装：`"".concat($("open"), "/open-apis/applink/longlink/v1/get?shortLink=").concat(e, "&businessTag=applink")`
3. `$("open")` = `https://open.feishu.cn`（HTML 里 `window.outDomain` 可确认）

## 审批定义分享链接 → OpenAPI approval_code

**重要陷阱**：applink 解析出的 `id=7672411260209630448`（纯数字）**不是** OpenAPI 的 `approval_code`（UUID 格式，如 `857A2F39-BFD4-49A4-AFE1-2E046EC1F539`）。直接用 `approvals get --approval-code <数字>` 报 `1390002 approval code not found`。

正确流程：
1. 用数字 id 试 `lark-cli approval approvals get --approval-code <数字> --as user` → 预期失败（确认不是 UUID）
2. `lark-cli approval approvals search --data @./<kw>.json --as user` 按关键词搜（如"发布"）
3. 命中后比对 `create_link` 里 `id=<数字>` 与用户分享链接的 id 一致 → 确认是同一个审批定义
4. 用返回的 UUID `approval_code` 调 `approvals get` 拿表单结构（`form` 控件列表、`node_list` 流程节点）

## PowerShell 5.1 下调 lark-cli：JSON 参数必读

在 Hermes CN Desktop（terminal = PowerShell 5.1）里，`lark-cli ... --params '{"key":"val"}'` / `--data '{...}'` 的 JSON **引号会被 PowerShell 吃掉**，报 `invalid format, expected JSON object`。这不是 lark-cli 的问题。

**解法（按优先级）**：
1. **能用 typed flag 就不用 JSON**：如 `--approval-code <code>`、`--folder-token <token>`、`--file ./x.pdf`
2. JSON 场景：用 write_file 写 `_tmp_x.json` 到**当前工作目录**，再 `cmd /c "lark-cli ... --data @./_tmp_x.json --as user"`（`@file` 只接受 cwd 内相对路径，绝对路径报 unsafe file path；`@` 在 PowerShell 是 splatting 语法，必须套 `cmd /c`）
3. 用完删临时 JSON

**输出判断**：node.exe 的进度消息写 stderr，PowerShell 会显示成红色 NativeCommandError，**看 JSON 里 `"ok": true` 才算成功**，不要看 PowerShell 的报错样式。详见技能 `windows-powershell-lark-cli-integration`（同名陷阱的更多案例）。

### 附加陷阱：write_file 写的 .ps1 中文字面量乱码

PowerShell 5.1 对**无 BOM 的 UTF-8 .ps1 按 ANSI(GBK) 解析**，脚本内中文字面量（路径、文件名、expected 列表）全部变 mojibake（如 `鍙戝竷`），导致路径/名称比对失败。规避：
- 脚本正文避免中文字面量——用相对路径（依赖运行时的 CWD）代替中文绝对路径
- 需要比较中文输出时，把 lark-cli 输出重定向到临时文件，再用 `Get-Content -Encoding UTF8` 读回
- 验证脚本（如 `hermes-verify-*.ps1`）写完后先跑一次确认无乱码

## 配套：审批材料准备（md→PDF，Windows 无 pandoc）

审批表单要求上传附件（`attachmentV2` 控件，value 是 file code 数组）时，本地 md 文档可转 PDF 后上传云盘：

1. `npm install markdown-it`（临时目录）
2. markdown-it 渲染 md → 带中文字体 CSS 的 HTML（`font-family: "Microsoft YaHei"`，表格 `tr { page-break-inside: avoid }`）
3. Edge headless 打印（Windows 11 自带）：`msedge.exe --headless --disable-gpu --no-sandbox --print-to-pdf=out.pdf --no-pdf-header-footer file:///...` 
4. 上传：`cmd /c "lark-cli drive +upload --file ./x.pdf --folder-token <token> --as user"`（`--file` 也要相对路径，`--folder-token` 指定目标文件夹）

## ⚠️ attachmentV2 的 file code 怎么拿（2026-08-13 实测踩坑）

**关键结论：drive 上传返回的 `file_token` 不能直接填进 attachmentV2**——`instances create` 会报 `1395006 validate form error 控件值不合法或者为空`。attachmentV2 需要的是**审批专用 file_code**，必须走审批文件上传接口：

```bash
# 1) 写 body JSON（字段名是 type，不是 file_type！）
# {"file_name":"xxx.pdf","type":"attachment"}
# 2) multipart 上传：--data 的 JSON 自动变成 form 字段，--file 是文件本体
cmd /c "lark-cli.exe api POST /open-apis/approval/v4/files/upload --data @./body.json --file file=./xxx.pdf --as bot"
```

**返回 `urls_detail[0].code` 就是 file_code**（如 `01AEECFB-6534-4929-9C3A-5F422FAF1BDB`），填入 attachmentV2 的 value 数组即可。

踩过的坑（按顺序排雷，避免重走）：
- `--as user` → `99991668 user access token not support`，**必须 `--as bot`**
- body 里用 `"file_type":"pdf"` → `1390001 Parameter type is empty`；用 `"file_type":"pdf"` 的其它变体（PDF/大写/.pdf/attachment 值配错字段名）→ 一直报 empty；**字段名必须是 `type`，值为 `attachment`**（报错信息会提示 `valid type has: image, attachment`）
- `--file file_name=./x.json --file file_type=... --file file=./x.pdf` 多次传 `--file` → **只保留最后一个**，其余字段全丢；文本字段必须走 `--data` JSON
- 该接口不在 lark-cli 的 approval 域命令里（`schema approval.files.upload` 报 Unknown resource），必须用 `api` 逃生舱

**提单全链路**（验证通过）：`approvals search`（按关键词，如"发布"）→ 比对 `create_link` 的 `id` 确认定义 → `approvals get` 拿 form 控件 id/type/option 值 → 每个附件逐个 `files/upload` 拿 file_code → 组装 `instances create` 的 `--data`（`form` 是 JSON 字符串；`node_approver_list` 补 `need_approver=true` 节点的审批人 open_id，key 用 `node_id`）→ `--dry-run` 校验结构 → `--yes` 提交。审批人姓名需先用 `contact +search-user --query <名>` 解析 open_id。

**可直接运行的脚本**：`scripts/approval-upload.js`（node）— 传本地文件路径即返回 file_code，自动处理 `--data @body.json` + `--file` 组合与 bot 身份；需要 `LARK_CLI` 环境变量指向 lark-cli.exe 或已在 PATH，且文件须在 CWD 内。

## 参考文件

- `references/applink-api-notes.md` — 本次会话的完整逆向记录与验证过程
