# 飞书数据源 lark-cli 命令速查（v1.0.74+）

所有命令默认加 `--as user`。

## 日程

```bash
lark-cli calendar +agenda --as user
```

## 文档（含大纲深读）

```bash
# 搜索今日编辑的文档/表格（⚠️ 不要加 --mine！该组合有 bug 返回 0 条且漏自己编辑的）
lark-cli drive +search --edited-since 1d --as user --format json
# → 解析 data.results 字段（不是 data.items），兼容 DOCX/BITABLE/SHEET/SLIDES

# 读取文档大纲（不读全文，只读标题结构）
lark-cli docs +fetch --doc <token> --scope outline --as user
```

## 消息搜索

```bash
# 搜索产品相关消息（时间必需 ISO 8601 格式）
lark-cli im +messages-search \
  --query "PRD 评审 方案 需求 原型 交付" \
  --start "2026-07-21T00:00:00+08:00" \
  --end "2026-07-22T00:00:00+08:00" \
  --page-size 10 --as user
```

## 任务

```bash
# 获取我的任务
lark-cli task +get-my-tasks --as user

# 任务详情（用 guid）
lark-cli task tasks get --params '{"task_guid":"<guid>"}' --as user

# 注意：is_completed 字段有 bug 永远返 false
```

## 会议纪要

```bash
# 搜索今日会议（时间必需 ISO 8601）
lark-cli vc +search --start "2026-07-21T00:00:00+08:00" --end "2026-07-22T00:00:00+08:00" --as user

# 拿妙记链接（关键！返回 minute_token + recording_url）
lark-cli vc +recording --meeting-ids <meeting_id> --as user
# → recording_url 形如 https://meetings.feishu.cn/minutes/<token>，可直接作为日报证据链接

# 读妙记全文（含摘要+待办，需 minutes:minutes.basic:read scope）
lark-cli minutes +detail --minute-tokens <token> --as user
```

## 妙记（会议正文）

```bash
# 搜索我的妙记
lark-cli minutes +search --query "产品 评审 方案" --owner-ids me --start "2026-07-21" --end "2026-07-22" --page-size 10 --as user

# 阅读妙记全文（含摘要+待办，注意参数是 --minute-tokens 不是 --minute-id）
lark-cli minutes +detail --minute-tokens <token> --as user
```

## 审批

```bash
# 我的审批任务
lark-cli approval tasks query --params '{"topic":"","status":"pending"}' --as user 2>/dev/null

# 我发起的审批
lark-cli approval instances initiated --as user 2>/dev/null
```

## 身份识别

```bash
lark-cli auth status
```

## 限流

- 命令间 `sleep 0.3s`
