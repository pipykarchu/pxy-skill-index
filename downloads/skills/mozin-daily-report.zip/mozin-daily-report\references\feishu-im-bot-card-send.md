# 飞书 IM 发送：bot 身份 + 卡片消息（2026-08-03 验证）

## 核心结论

| 方式 | 结果 |
|------|------|
| `--as user --markdown` | 发到 `oc_eff5d3d2...`，用户在飞书 APP 看不到 ❌ |
| `--as bot --markdown` | 消息只显示标题，正文被折叠不可见 ❌ |
| `--as bot --text` | 同上，正文不可见 ❌ |
| `--as bot --msg-type interactive --content <card>` | 卡片消息完整展示 ✅ |

## 正确发送代码

```python
import subprocess, os, json

LARK = r"C:\Users\皮玺玉\AppData\Roaming\npm\lark-cli.cmd"
UID = "ou_7d05b327389c521f51426312ac5c9e2b"
env = os.environ.copy()
env["LARK_CLI_WORKSPACE"] = "hermes"

def send_card(title, body, color="blue"):
    card = {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": title},
            "template": color
        },
        "elements": [
            {"tag": "div", "text": {"tag": "lark_md", "content": body}}
        ]
    }
    r = subprocess.run(
        [LARK, "im", "+messages-send", "--as", "bot", "--user-id", UID,
         "--msg-type", "interactive", "--content", json.dumps(card, ensure_ascii=False)],
        capture_output=True, text=True, timeout=30,
        encoding="utf-8", errors="replace", env=env
    )
    return '"ok": true' in (r.stdout or "")
```

## lark_md 支持的格式

- `**粗体**` ✅
- emoji（🟢🟡🔴📊等） ✅
- 换行 ✅
- ~~Markdown 表格~~ ❌
- ~~`---` 分隔线~~ ❌
- 有序列表 `1. xxx` ✅

## chat_id 对照

- `--as user` → `oc_eff5d3d244392bca286604ce366699d0`（用户不可见）
- `--as bot` → `oc_3eab57d10ba96dbfbc6a19818a4d2b02`（"皮玺玉的飞书 CLI" 智能体对话，用户可见）

## D盘权限修复（重装系统后）

重装 Win10 后 D 盘文件所有权属旧 SID，Hermes 写文件 Permission Denied。

管理员 PowerShell 修复：
```powershell
takeown /f "D:\AI\AI产品工作\汇报" /r /d Y
icacls "D:\AI\AI产品工作\汇报" /grant "皮玺玉:(OI)(CI)F" /t
```

**⚠️ icacls 的 grant 参数必须整体加双引号**，否则 PowerShell 5.1 把 `(OI)` 当子表达式解析报错。
