# 飞书卡片消息发送（2026-08-03 完整验证）

## 背景
"皮玺玉的飞书 CLI" 智能体对话中：
- `--markdown` 长内容被折叠成只显示标题的卡片 ❌
- `--text` 纯文本在该对话里也看不到内容 ❌  
- `--as user` 身份发的消息在该对话里完全不可见 ❌
- **唯一可用：`--as bot` + `--msg-type interactive` 卡片消息** ✅

## 完整 Python 发送代码（2026-08-05 更新：必须用 node run.js）

```python
import subprocess, os, json

# ⚠️ 不能用 lark-cli.cmd（中文长内容被 cmd.exe 搞坏）
LARK_JS = r"C:\Users\皮玺玉\AppData\Roaming\npm\node_modules\@larksuite\cli\scripts\run.js"
UID = "ou_7d05b327389c521f51426312ac5c9e2b"
env = os.environ.copy()
env["LARK_CLI_WORKSPACE"] = "hermes"

def send_card(title, body, color="blue"):
    card = {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": title},
            "template": color  # blue/green/orange/red/purple
        },
        "elements": [
            {"tag": "div", "text": {"tag": "lark_md", "content": body}}
        ]
    }
    r = subprocess.run(
        ["node", LARK_JS, "im", "+messages-send", "--as", "bot", "--user-id", UID,
         "--msg-type", "interactive", "--content", json.dumps(card, ensure_ascii=False)],
        capture_output=True, text=True, timeout=30,
        encoding="utf-8", errors="replace", env=env)
    return '"ok": true' in (r.stdout or "")
```

## 卡片 body 格式要点

- 工作总览用**全角空格（　）**对齐列，不用 markdown 表格
- 飞书卡片的 `lark_md` 支持：`**加粗**`、`- 列表`、`---` 分隔线、emoji
- 飞书卡片**不支持** markdown 表格语法

## 成功的 chat_id
- bot→user 私聊: `oc_3eab57d10ba96dbfbc6a19818a4d2b02`（"皮玺玉的飞书 CLI"）
- user→user 私聊: `oc_eff5d3d244392bca286604ce366699d0`（用户看不到）

## 排错路径记录
1. `--as user --markdown` → 消息发送 ok=true 但用户在 CLI 智能体对话里看不到
2. `--as bot --markdown` → 消息被折叠成只显示标题的卡片
3. `--as bot --text` → 消息不显示内容
4. `--as bot --msg-type interactive --content <card_json>` → ✅ 完整显示
