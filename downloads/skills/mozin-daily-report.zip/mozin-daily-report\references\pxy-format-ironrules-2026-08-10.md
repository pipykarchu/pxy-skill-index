# 皮玺玉日报格式铁律（2026-08-10 用户多次纠正固化）

## 总览表格式（不可违反）

用户明确要求用 `🟢x2` 格式，**不用 Markdown 表格**：

```
📊 今日工作总览

产出数　🟢 正常　🟠 待补　🟡 待决　🔴 阻塞

[项目名1]　　🟢x2

[项目名2]　　🟢x1

[项目名3]　　🟢x2

**合计：N 项 | 🟢xN | 🟠xN**
```

- 合计行必须加粗
- 每个项目一行，色标数量紧贴项目名
- 不用 `|` 竖线表格

## 飞书发送目标（不可违反）

**只发 P2P 给自己，不发现群** ❌

```python
LARK_JS = r"C:\Users\皮玺玉\AppData\Roaming\npm\node_modules\@larksuite\cli\scripts\run.js"
UID = "ou_7d05b327389c521f51426312ac5c9e2b"  # 皮玺玉 open_id

subprocess.run(
    ["node", LARK_JS, "im", "+messages-send", "--as", "bot",
     "--user-id", UID, "--markdown", content],
    capture_output=True, text=True, timeout=30,
    encoding="utf-8", errors="replace", env=env
)
```

- 用 `--user-id` P2P 发送，不用 `--chat-id` 群聊
- 用 `--markdown` 纯文本，不用 `--msg-type interactive` 卡片
- 用 `node run.js` 直接调，不用 `lark-cli.cmd`（PowerShell 长内容被拆成位置参数）

## 证据链（不可省略）

每条产出必须有证据：
- 飞书任务链接：`https://applink.feishu.cn/client/todo/detail?guid=xxx`
- 本地文件路径：`D:\AI\AI产品工作\...`

## 电脑扫描采集流程

用户说"扫描我的电脑生成日报"时，并行采集：

1. **本地文件**：`Get-ChildItem D:\AI\AI产品工作 -Recurse` 过滤今日修改
2. **飞书任务**：`lark-cli task +get-my-tasks --as user` 过滤 completed_at=今天
3. **Edge 历史**：复制 SQLite History 文件查询今日记录
4. **handoff.md**：`D:\AI\AI产品工作\牧之音\Mozin 产品研讨中心\handoff.md` 提取"已完成"条目
5. **原型 README**：`pages-v1.2/P0X/README.md` 提取功能变更

## 踩坑记录

| 陷阱 | 原因 | 解决 |
|------|------|------|
| PowerShell `--markdown "$(Get-Content ...)"` 报 `positional arguments not supported` | 长中文内容被空格/特殊字符拆成多个位置参数 | 用 Python subprocess 参数列表传值 |
| `--chat-id` 发到群聊 | 用户要求只发给自己 | 用 `--user-id ou_xxx` P2P |
| 卡片 JSON `--msg-type interactive` | lark-cli v1.0.85 api 参数解析有 bug | 用 `--markdown` 纯文本 |
| 证据缺 Figma 链接 | 未扫描电脑获取 | 用"扫描我的电脑"流程自动采集 |

## 发送验证记录（2026-08-11）

- ✅ `node run.js im +messages-send --as bot --user-id ou_7d05b327389c521f51426312ac5c9e2b --markdown <content>` 发送成功（P2P 发本人，返回 message_id）
- ✅ 直接 `lark-cli im +messages-send --chat-id oc_3eab57d10ba96dbfbc6a19818a4d2b02 --markdown "$(Get-Content ...)" --as bot` 短内容可成功；**长内容（>500字含表格/引号）必败**，必须走 Python subprocess + node run.js
- ✅ 日报内容读 MD 文件原文直发（`Get-Content -Raw -Encoding UTF8`），不精简、不重排

## Gitea 仓库信息（2026-08-11）

- **正式主仓库**：`http://120.237.89.124:8929/rd-center/org-mag-sup/mozin-daily-report`
- 旧内网仓库：`http://192.168.0.102:8929/modaipeng/mozin-daily-report`（pxy 分支）
- push 前需 `git config --global http.sslVerify false` + `http.unsafeRemotes true`
- 首次 push 需要 Gitea 凭据（用户名+密码或 access token），凭据不在 Windows 凭据管理器时向用户索取，禁止写死到仓库文件
