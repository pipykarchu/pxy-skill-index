# lark-cli 升级与授权问题（Windows，2026-07-23 验证）

## 版本升级

### 正确流程
```powershell
# lark-cli update 自动升级可能因 binary verification 超时失败
# 改用手动安装（两步）：
npm install -g @larksuite/cli@1.0.76
npm install -g --allow-scripts=@larksuite/cli @larksuite/cli@1.0.76

# 验证
lark-cli --version  # 应输出 lark-cli version 1.0.76
```

### pitfall
- `lark-cli update` 在 Windows 上可能报 `binary verification timed out after 10s` → 用上面手动方式
- `npm install -g` 第一次会报 `postinstall blocked by allowScripts` → 必须补跑第二条 `--allow-scripts` 命令

---

## 授权 token 持久化问题

### 根本原因
- lark-cli 1.0.69 有 token 刷新 bug，升级到 1.0.76 后 token 可持久存 keychain
- 若每次都要扫码 → 先升级版本再重新授权一次，之后不会再反复要求

### device_code 授权流程注意事项
- `--no-wait --json` 拿到 device_code 后**立刻**让用户扫码
- device_code **10 分钟**有效，超时后需重新生成
- **不要**在同一轮里展示 URL 后立刻执行 `--device-code`（会阻塞且超时）
- 用户确认授权后，单独一步执行：`lark-cli auth login --device-code <code>`

### 一次性补全所有 scope
```bash
lark-cli auth login --scope "minutes:minute:download minutes:minutes.transcript:export search:message report:task:readonly" --no-wait --json
```

---

## needs_refresh 状态处理

**`needs_refresh` 不需要扫码。** 这是最常见的误判陷阱：

```json
"tokenStatus": "needs_refresh",
"message": "User identity: needs refresh (will auto-refresh on next user API call)"
```

- token 仍然有效，下次任何 API 调用会自动刷新
- 有 `offline_access` scope → refresh token 有效期 7 天
- **只有** `token_missing` 或 `missing_scope` 才需要重新授权

## 高权限 scope（需管理员在飞书开放平台审批）

遇到 `"The app is pending approval"` 报错 → 用户扫码无效，必须找管理员在飞书开放平台操作：
- `minutes:minute:download`
- `minutes:minutes.transcript:export`
- `search:message`

不要重试，直接告知用户找管理员审批。

## qrcode --output 路径限制

`lark-cli auth qrcode` 的 `--output` 参数**只接受相对路径**，绝对路径会报错：
```
unsafe output path: --output must be a relative path within the current directory
```
正确做法：先 cd 到目标目录，再用相对路径：
```powershell
cd "D:\AI\AI产品工作\汇报"
lark-cli auth qrcode "<url>" --output qr.png
```

## 所需 scope 清单

| scope | 用途 | 状态 |
|-------|------|------|
| `im:message` | 发送 IM 消息 | ✅ 默认 |
| `im:message.send_as_user` | 以用户身份发消息 | ✅ 默认 |
| `calendar:calendar` | 读日程 | ✅ 默认 |
| `task:task:readonly` | 读任务 | ✅ 默认 |
| `drive:drive:readonly` | 搜索文档 | ✅ 默认 |
| `docx:document:readonly` | 读文档大纲 | ✅ 默认 |
| `minutes:minute:readonly` | 搜索妙记列表 | ✅ 默认 |
| `minutes:minute:download` | 读妙记正文/转录 | ⚠️ 需额外授权 |
| `minutes:minutes.transcript:export` | 导出妙记转录 | ⚠️ 需额外授权 |
| `search:message` | 搜索消息 | ⚠️ 需额外授权 |
| `report:task:readonly` | 读飞书汇报历史 | ⚠️ 需额外授权 |
| `report:task:write` | 写飞书汇报草稿 | ❌ 暂不申请 |
