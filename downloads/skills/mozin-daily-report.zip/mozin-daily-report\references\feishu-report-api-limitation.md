# 飞书汇报 API 限制（2026-08-04 验证）

## 结论
飞书汇报（OA 日报/周报）**无法通过 lark-cli 或自建应用 API 直接提交**。

## 验证过程
1. lark-cli 没有 `report` domain（available: approval, attendance, calendar, contact, drive, im, mail, mindnotes, minutes, okr, sheets, slides, task, vc, wiki）
2. 用 `lark-cli api GET /open-apis/report/v1/rules/query --as user` 返回 `user access token not support`（code 99991668）
3. 飞书汇报 API 需要 tenant_access_token，但提交日报是用户行为，形成死结

## 替代方案
- 以**卡片消息**发到"皮玺玉的飞书 CLI"智能体对话，用户手动复制到飞书汇报三字段
- 卡片内容按飞书汇报三字段结构组织（今日总结 / 明日计划 / 需要协调与帮助）
- 或直接发给莫总/宋总私聊（需要他们的 open_id 或 chat_id）

## 飞书汇报页面 URL 格式
```
https://oa.feishu.cn/report/record/detail?ruleId=<rule_id>
```
Edge 历史中可见用户访问过此页面。
