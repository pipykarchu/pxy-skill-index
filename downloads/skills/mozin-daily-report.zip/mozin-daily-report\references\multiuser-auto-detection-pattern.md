# 多用户自动检测模式 (v2.1, 2026-08-31)

## 背景

在 v4.0 中，用户 ID 被硬编码到脚本中（`ou_7d05b327389c521f51426312ac5c9e2b`）。这对单用户场景有效，但其他用户要么无法使用，要么需要修改脚本。

v4.2 引入了 **自动检测模式**：从当前登录的 `lark-cli` 用户提取身份信息，支持多用户场景而无需配置。

## 核心函数

```python
def get_current_lark_cli_user():
    """
    自动从 lark-cli 获取当前登录用户身份
    
    返回结构:
    {
        "open_id": "ou_xxx...",
        "name": "user_name",
        "workspace": "workspace_name"
    }
    
    如果获取失败返回 None，调用方应优雅降级
    """
    import subprocess
    import json
    
    try:
        result = subprocess.run(
            ["lark-cli", "auth", "status", "--json"],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        if result.returncode != 0:
            print(f"[⚠️ ] lark-cli auth status 返回错误: {result.stderr[:80]}")
            return None
        
        try:
            status_data = json.loads(result.stdout)
            
            # 支持多种字段名（不同 lark-cli 版本可能不同）
            user_id = (status_data.get("user_id") 
                      or status_data.get("open_id") 
                      or status_data.get("id"))
            user_name = (status_data.get("user_name") 
                        or status_data.get("name") 
                        or "unknown")
            workspace = (status_data.get("workspace") 
                        or status_data.get("account") 
                        or "default")
            
            if not user_id:
                print(f"[⚠️ ] 无法从 lark-cli status 获取用户 ID")
                print(f"       响应数据: {status_data}")
                return None
            
            print(f"[✅] 检测到当前 lark-cli 用户: {user_name} ({user_id})")
            
            return {
                "open_id": user_id,
                "name": user_name,
                "workspace": workspace
            }
        except json.JSONDecodeError as e:
            print(f"[⚠️ ] lark-cli status JSON 解析失败: {e}")
            print(f"       原始响应: {result.stdout[:100]}")
            return None
            
    except FileNotFoundError:
        print("[❌] lark-cli 命令未找到，请确保已安装并在 PATH 中")
        return None
    except subprocess.TimeoutExpired:
        print("[❌] lark-cli auth status 执行超时")
        return None
    except Exception as e:
        print(f"[❌] 获取用户身份异常: {e}")
        return None
```

## 使用场景

### 场景 1：飞书消息发送（原始用途）

```python
user_info = get_current_lark_cli_user()
if not user_info:
    return "[⚠️ ] 无法获取 lark-cli 用户身份，跳过飞书发送"

cmd = [
    "lark-cli", "im", "+messages-send",
    "--as", "bot",
    "--msg-type", "interactive",
    "--content", json.dumps(card_json),
    "--to-user", user_info["open_id"]  # ← 动态用户 ID
]
```

### 场景 2：日志标注（审计/追踪）

```python
user_info = get_current_lark_cli_user()
user_label = f"{user_info['name']} ({user_info['open_id']})" if user_info else "unknown"
logger.info(f"Action by {user_label}")
```

### 场景 3：多租户隔离

```python
user_info = get_current_lark_cli_user()
user_workspace = user_info["workspace"] if user_info else "default"
report_path = f"./reports/{user_workspace}/latest_report.md"
```

## 关键设计特性

| 特性 | 实现 | 原因 |
|------|------|------|
| **多字段兼容** | 尝试 `user_id` / `open_id` / `id` | lark-cli 版本间差异 |
| **显式异常处理** | FileNotFoundError / TimeoutExpired / JSONDecodeError | 不同失败模式需要不同处理 |
| **返回结构化数据** | dict 含 open_id/name/workspace | 调用方可以选择使用哪个字段 |
| **优雅降级** | 返回 None 而不是抛异常 | 允许调用方决定是继续还是abort |
| **详细的日志** | 打印检测到的用户和错误信息 | 调试问题时快速定位 |

## 已知限制

- **环境相关**：如果 lark-cli 不在全局 PATH 中，需要使用完整路径
- **认证前提**：假设用户已通过 `lark-cli auth login` 认证；无认证时返回 None
- **超时保护**：10 秒超时；如果 lark-cli 响应慢，可能超时

## 衍生应用

这个模式可以应用到任何需要感知当前用户的工具：

- **飞书 API 调用**：自动填充 `user_id` 参数
- **多用户日报/周报系统**：每个用户得到各自的输出
- **审计日志**：记录哪个用户执行了哪个操作
- **多租户 SaaS 工具**：自动隔离用户工作空间

## 参考

- Lark CLI 版本：v1.0.76 (as of 2026-08-31)
- 相关命令：`lark-cli auth status --json`
- 返回格式：JSON，包含 user_id、user_name、workspace 等字段
