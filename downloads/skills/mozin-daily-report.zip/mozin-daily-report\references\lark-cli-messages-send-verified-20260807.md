# lark-cli im +messages-send 验证记录 (2026-08-07)

## 正确命令

```
lark-cli im +messages-send --chat-id <chat_id> --markdown "<content>"
```

**注意**：不是 `im send`，也不是 `im +send`。子命令全名是 `+messages-send`。

## .cmd 中文长内容必败 → node run.js 绕过

PowerShell 管道或 lark-cli.cmd 直接传中文长内容必定失败（编码/转义问题）。

### 已验证可用的 Node.js 调用方式

```js
const { execFileSync } = require('child_process');
const path = require('path');

const larkDir = path.join(process.env.APPDATA, 'npm', 'node_modules', '@larksuite', 'cli');
const runJs = path.join(larkDir, 'scripts', 'run.js');

const md = `你的 Markdown 内容...`;

const args = ['im', '+messages-send', '--chat-id', 'oc_3eab57d10ba96dbfbc6a19818a4d2b02', '--markdown', md];

const result = execFileSync('node', [runJs, ...args], {
  encoding: 'utf8',
  timeout: 15000,
  env: { ...process.env, LARK_CLI_WORKSPACE: 'hermes' }
});
```

### 关键点
- 文件写到 `C:\Windows\Temp\send_xxxx.js`，然后 `node "C:\Windows\Temp\send_xxxx.js"` 执行
- `LARK_CLI_WORKSPACE: 'hermes'` 确保读到正确 token
- `--markdown` 参数支持飞书 lark_md 格式（粗体、列表、emoji OK；表格渲染差）
- lint 报 MODULE_NOT_FOUND 是 Hermes 用错误路径做 --check，忽略即可，实际执行没问题

## 飞书 IM 总览格式（用户偏好 2026-08-07 确认）

飞书发送时总览用纯文本列表，不用 Markdown 表格：

```
📊 今日工作总览
1. Mozin 1.5 版本过项　　🟢x1
2. Mozin 2.0 功能设计　　🟢x2
3. Mozin 2.0 3D建模　　　🟢x2 🟠x1
合计：6项 | 🟢x5 | 🟠x1
```

## chat_id 速查
- 皮玺玉的飞书 CLI: `oc_3eab57d10ba96dbfbc6a19818a4d2b02`
