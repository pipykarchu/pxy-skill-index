# D盘 ACL 权限修复（重装系统后）

## 症状
重装 Win10 后，D盘文件属于旧 SID，当前用户无写入权限：
```
Set-Content : 对路径"D:\AI\..."的访问被拒绝。
UnauthorizedAccessException
```

文件 Attributes 显示 `Archive`（非 ReadOnly），但 icacls 显示 `CodexSandboxUsers:(M)` 而非当前用户。

## 修复命令（管理员 PowerShell）

```powershell
# 1. 取得所有权（递归）
takeown /f "D:\AI\AI产品工作\汇报" /r /d Y

# 2. 授予完全控制权（注意引号包裹整个参数！）
icacls "D:\AI\AI产品工作\汇报" /grant "皮玺玉:(OI)(CI)F" /t
```

## 关键 pitfall
- **PowerShell 5.1 中 `(OI)(CI)F` 必须用引号包裹整个用户名+权限字符串**
  - ❌ `icacls ... /grant 皮玺玉:(OI)(CI)F /t` → PowerShell 把 `(OI)` 解析为子表达式
  - ✅ `icacls ... /grant "皮玺玉:(OI)(CI)F" /t`
- `takeown` 需要管理员权限，普通 shell 会报 "does not have ownership privileges"
- Hermes Agent 进程以普通用户运行，无法自行 takeown，必须让用户手动执行

## 适用范围
D盘任何在重装前创建的目录都可能有此问题。一次性对 `D:\AI` 整体执行可一劳永逸。
