# 周报分段发送模式（2026-08-04 验证通过）

## 问题

Windows cmd.exe 在 subprocess 传参时解析 JSON 内容中的 `&`、`%`、`|`、`>`、`<`、`^`，导致参数被截断。
单条卡片 content JSON 超过 ~1300 字符时高概率触发截断。

## 解决方案：分段发送 + 特殊字符替换

```python
import subprocess, os, json, time

LARK = r"C:\Users\皮玺玉\AppData\Roaming\npm\lark-cli.cmd"
UID = "ou_7d05b327389c521f51426312ac5c9e2b"
env = os.environ.copy()
env["LARK_CLI_WORKSPACE"] = "hermes"

def send_card(title, body, color="blue"):
    """发送单段卡片，返回 (ok, json_length, error_msg)"""
    # 必须替换的特殊字符
    body = body.replace("&", "、").replace("%", "％")
    card = {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": title},
            "template": color
        },
        "elements": [
            {"tag": "div", "text": {"tag": "lark_md", "content": body}}
        ]
    }
    content_json = json.dumps(card, ensure_ascii=False)
    r = subprocess.run(
        [LARK, "im", "+messages-send", "--as", "bot", "--user-id", UID,
         "--msg-type", "interactive", "--content", content_json],
        capture_output=True, text=True, timeout=30,
        encoding="utf-8", errors="replace", env=env)
    ok = '"ok": true' in (r.stdout or "")
    return ok, len(content_json), r.stderr[:200] if not ok else ""

def send_weekly_report(md_path):
    """读取 MD 文件，按 --- 分段，合并到 ≤1100 字符/段后发送"""
    with open(md_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    sections = content.split("\n---\n")
    
    # 合并相邻段，每段 body ≤ 1100 字符
    parts = []
    current = ""
    for sec in sections:
        if len(current) + len(sec) > 1100:
            if current:
                parts.append(current.strip())
            current = sec
        else:
            current += "\n---\n" + sec if current else sec
    if current.strip():
        parts.append(current.strip())
    
    total = len(parts)
    for i, part in enumerate(parts):
        title = f"周报 · W## · MM-DD~MM-DD ({i+1}/{total})" if total > 1 else "周报 · W## · MM-DD~MM-DD"
        ok, sz, err = send_card(title, part)
        if not ok:
            # 二次切分：在最近的换行处切
            mid = len(part) // 2
            cut = part.rfind("\n", 0, mid + 100)
            if cut < mid - 200:
                cut = mid
            send_card(f"{title}(上)", part[:cut])
            time.sleep(1)
            send_card(f"{title}(下)", part[cut:])
        time.sleep(1)
```

## 关键约束

| 约束 | 值 | 说明 |
|------|----|----|
| 单段 body 上限 | ~1100 字符 | 留余量给 card JSON wrapper |
| 单段 JSON 上限 | ~1300 字符 | 超过此值 Windows cmd.exe 高概率截断 |
| 必须替换的字符 | `&` → `、`, `%` → `％` | cmd.exe 命令分隔符/环境变量引用 |
| 可选替换 | `|` → `｜`, `>` → `＞`, `<` → `＜` | 重定向字符 |
| 发送间隔 | 1 秒 | 避免飞书限流 |
| 分段标记 | `(1/3)` `(2/3)` ... | 让接收者知道总共几段 |

## MD 文件编写规则（为发送兼容）

- 用 `、` 代替 `&`（如 "用户反馈集成、第二轮访谈"）
- 用全角括号 `（）` 代替半角 `()`（飞书渲染一致）
- 不用 markdown 表格（飞书 lark_md 不渲染）
- 用 `---` 作为自然分段点（发送脚本按此切割）
