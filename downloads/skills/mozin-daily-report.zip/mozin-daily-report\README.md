# mozin-daily-report

Mozin 产品部日报 / 周报 / 月报自动化汇报系统（Hermes Agent Skill）。

> **版本**: v4.6 · 2026-08-11
> **维护者**: 皮玺玉（PXY）
> **运行环境**: Hermes Agent + Windows + lark-cli

## 这是什么

一个 Hermes Agent Skill，驱动产品经理的每日汇报闭环：

- **五源并行采集**：飞书（日历/任务/文档/妙记/审批）+ Git 提交 + 本地文件 + Edge 浏览历史 + Hermes 会话记录
- **自动生成日报 / 周报（大小周自动判断）/ 月报**
- **标准化格式**：五色自评（🟢🟠🟡🔴🔵）+ 量化指标 + 证据链 + 下一步
- **本地存档**：`汇报/daily/皮玺玉_YYYYMMDD_日报.md`（命名规范固化）
- **飞书发送**：bot 身份 + interactive 卡片 / markdown 消息，只发用户本人
- **定时触发**：每天 18:30 cron 自动生成草稿；大周周五/小周周六 18:30 周报

## 安装

### 方式 1：Hermes skills 目录（推荐）

```powershell
# 把本仓库内容放到 Hermes 的 skills 目录下
Copy-Item -Recurse . "D:\AI\hermes\Hermes Agent CN Desktop\data\hermes-home\skills\daily-report-mozin"
# 或放入技能站目录
Copy-Item -Recurse . "D:\AI\AI产品工作\技能\skills\04-文档数据与汇报\daily-report-mozin"
```

### 方式 2：zip 打包分发

```powershell
Compress-Archive -Path "daily-report-mozin\*" -DestinationPath "daily-report-mozin-pxy.zip" -Force
# 收件人解压到 ~/.hermes/skills/ 或对应技能目录即可生效
```

## 使用

对 Hermes Agent 说：

| 指令 | 效果 |
|------|------|
| `写日报` | 手动模式，口述内容 → 格式化 → 存档+发送 |
| `写日报 --auto` | 自动模式，五源采集 → 草稿 → 确认后发送 |
| `写周报` | 合并本周已发布日报（飞书汇报 API 为权威数据源） |
| `写月报` | 合并本月日报/周报 |
| `今日进展` | 等同于写日报 |

或等 18:30 cron 自动触发。

## 目录结构

```
mozin-daily-report/
├── SKILL.md                              # Hermes Skill 主定义文件
├── README.md                             # 本文件
├── scripts/
│   ├── daily-report-cron.py              # Cron 定时任务入口（Python）
│   ├── weekly-report-cron.py             # 周报 Cron 脚本（大小周判断）
│   ├── upload_md_to_feishu.py            # 将生成的 MD 上传到飞书云文档
│   └── verify-report-skill.py            # 技能完整性验证
├── templates/
│   ├── daily-report-template.md          # 日报模板
│   ├── mozin-daily-report-template.md    # Mozin 定制版日报模板
│   └── weekly-report-template.md         # 周报模板
└── references/                           # 配置说明 & 踩坑记录（30+ 篇）
    ├── cron-script-execution.md          # Hermes cron 脚本执行原理
    ├── cron-weekly-schedule-unified-18-30.md  # 大小周统一 18:30 调度
    ├── feishu-report-api-query.md        # 飞书汇报 API 调用（周报数据源铁律）
    ├── feishu-im-bot-card-send.md        # bot 身份 + interactive 卡片发送
    ├── feishu-card-format-verified.md    # 卡片格式规范（圈序号+全角空格对齐）
    ├── multiuser-auto-detection-pattern.md   # 多用户自动检测模式
    ├── kiro-execution-patterns-with-pxy.md   # 协作模式参考
    └── ...（完整列表见 SKILL.md）
```

## 依赖

| 依赖 | 版本要求 | 用途 |
|------|---------|------|
| Hermes Agent | 本地运行 | 技能宿主 |
| lark-cli | 1.0.85+ | 飞书数据采集 + IM 发送 |
| Python | 3.10+ | cron 入口 + 上传脚本 |
| node.js | 18+ | lark-cli 运行环境（node run.js 直调） |

## 关键配置

- **飞书发送目标**：`ou_7d05b327389c521f51426312ac5c9e2b`（用户本人 open_id，`--as bot`）
- **发送方式**：`node run.js` 直调（.cmd 长中文内容必败）
- **周报数据源**：飞书汇报 API（`POST /open-apis/report/v1/tasks/query`），rule_id=7611748107898391753
- **Cron**：日报每日 18:30；周报大周周五 18:30 / 小周周六 18:30；月报月末 18:00

## 变更记录

| 版本 | 日期 | 变更 |
|------|------|------|
| v4.6 | 2026-08-11 | 日报格式固化（总览表 🟢xN 格式 + 分项①②③）；飞书只发本人不发现群 |
| v4.5 | 2026-08-07 | lark-cli 升级 1.0.85；node run.js 直调发送 |
| v4.0 | 2026-08-04 | 飞书汇报 API 数据源铁律；周报按项目维度合并 |
| v3.0 | 2026-07-28 | 五源采集 v3.0；Cron 自动化 |
| v2.0 | 2026-07-24 | 大小周判断；周报模板 |
| v1.0 | 2026-07-22 | 初版：日报生成 + 飞书发送 |

## 注意事项

- 飞书卡片不支持 Markdown 表格，工作总览用全角空格对齐
- `--as user` 发送的消息在飞书 APP 不可见，必须 `--as bot`
- lark-cli token 存在 Windows keychain，Cron 需 agent 模式执行
- 周报必须从飞书汇报 API 拉取最终发布的日报，不能凭空编写
