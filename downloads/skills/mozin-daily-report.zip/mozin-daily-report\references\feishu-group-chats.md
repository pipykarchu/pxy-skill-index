# 飞书群聊速查（皮玺玉常用群）

## 已知群 chat_id

| 群名 | chat_id | 用途 |
|------|---------|------|
| Mozin-产品部 | oc_79f8d3a9c6fa73a69f526ccc12bd6f8d | 产品部日常沟通，决策最快在这里更新 |
| Mozin-产研中心 | （从 +chat-list 获取） | 项目进展同步 |
| Mozin_APP | （从 +chat-list 获取） | APP项目群 |
| Mozin-办公群 | （从 +chat-list 获取） | 全员通知 |

## 日报生成前读群聊的命令

```bash
# 产品部群今日消息（chat_id 已知，直接用）
lark-cli im +chat-messages-list \
  --chat-id oc_79f8d3a9c6fa73a69f526ccc12bd6f8d \
  --start "<today>T00:00:00+08:00" \
  --end "<today>T23:59:59+08:00" \
  --page-size 50 --as user 2>&1 | Select-String "content|name"
```

## 群聊优先于任务系统的典型场景

| 任务系统状态 | 群聊实际状态 | 日报应写 |
|------------|------------|---------|
| 🔴 逾期未收到交付物 | 群聊「已发给你了」「收到了」 | 🟢 已收到，等XX测试 |
| 🟡 采购待决策 | 群聊「走流程」「提给宋总」 | 🟡 采购走流程中 |
| 🟠 功能清单阻塞 | 群聊「功能整理完了」 | 🟢 已完结，正在熟悉 |

## ⚠️ 注意

- 系统消息（「XX加入群聊」「XX退出群聊」）不是事件，跳过
- 内部群跨租户不可读（code 230001）时直接跳过，不报错
- 群聊读取需要 `im:message:readonly` scope（当前 token 已包含）
