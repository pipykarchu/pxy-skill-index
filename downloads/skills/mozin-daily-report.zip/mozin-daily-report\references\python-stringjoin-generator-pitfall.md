# Python String-Join Pitfall: Generator Expressions in `"\n".join()` (2026-08-31)

## Problem

Generator expressions passed directly to `str.join()` can fail in complex multi-step logic contexts. The scope and evaluation timing of the generator can cause unexpected behavior or syntax errors.

## Bug: Generator Expression Pitfall

**WRONG** — Generator in `join()` with multi-step logic:
```python
# Attempt to build summary of daily reports
content += "\n".join([
    f"#### {d.strftime('%m-%d')}: report_{d.strftime('%Y%m%d')}.md",
    ""  # Empty string for spacing
] for d, _ in daily_reports)
```

**Problem**: 
- The list comprehension tries to create a list of **strings** and **lists** (the inner `[...]` is interpreted as a literal nested list)
- Syntax is ambiguous: does the `for` belong to the inner `[...]` or the outer `join()`?
- Results in `TypeError` or `ValueError` depending on Python version/context

## Fix: Explicit List Building

**RIGHT** — Build list explicitly, then join:
```python
daily_summary = []
for d, _ in daily_reports:
    daily_summary.append(f"#### {d.strftime('%m-%d')}: report_{d.strftime('%Y%m%d')}.md")
    daily_summary.append("")
content += "\n".join(daily_summary)
```

Or, if you must use a comprehension, make it a clean list comprehension:
```python
daily_summary = [
    line
    for d, _ in daily_reports
    for line in [
        f"#### {d.strftime('%m-%d')}: report_{d.strftime('%Y%m%d')}.md",
        ""
    ]
]
content += "\n".join(daily_summary)
```

## Generalization

**Rule**: When building complex strings with loops, **always separate the loop/build phase from the join phase**.

**Pattern**:
```python
# GOOD: Three explicit phases
1. results = []
2. for item in items:
       results.append(format(item))
3. output = "\n".join(results)

# AVOID: Mixing join and comprehension when logic is complex
output = "\n".join(... complex generator ...)
```

## When Generators ARE Safe

Generators in `join()` work fine when the logic is simple:

```python
# SAFE: Single expression per iteration
files = "\n".join(f.name for f in directory.iterdir())

# SAFE: Filtering only
active_users = ",".join(u.name for u in users if u.active)
```

## Reproduction

```python
from datetime import date, timedelta

daily_reports = [
    (date(2026, 8, 27), "content1"),
    (date(2026, 8, 28), "content2"),
]

# BREAKS
try:
    bad = "\n".join([
        f"#### {d.strftime('%m-%d')}: report",
        ""
    ] for d, _ in daily_reports)
except SyntaxError as e:
    print(f"❌ SyntaxError: {e}")

# WORKS
good_list = []
for d, _ in daily_reports:
    good_list.append(f"#### {d.strftime('%m-%d')}: report")
    good_list.append("")
good = "\n".join(good_list)
print(f"✅ Works: {good[:50]}...")
```

## Lesson

**Explicit > Implicit** — when in doubt, separate concerns:
1. **Build**: loop, append, create intermediate list
2. **Join**: once list is complete, call `"\n".join()`

This is more readable, easier to debug, and less prone to parsing ambiguity.

## Related

- Session: Mozin 周报 system v4.2 (2026-08-31)
- File: `scripts/weekly-report-cron.py` L191-196 (generate_weekly_report function)
- Test: ad-hoc verification script (4/4 checks passed)
