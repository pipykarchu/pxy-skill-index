# 技能包分发与 Gitea push（2026-08-11 验证）

## 场景
用户要求把「日汇报技能包（mozin-daily-report v4.6，含日报/周报/月报）」分发给团队成员（马祖曦、易安、张镭橙），并 push 到 Gitea 正式仓库。

## 技能包内容
- 主技能：`daily-report-mozin`（SKILL.md v4.6，72KB，含日报/周报/月报全流程）
- 54 个文件：SKILL.md + README.md + 30+ references + 3 templates + 5 scripts
- 技能站同步副本：`D:\AI\AI产品工作\技能\skills\04-文档数据与汇报\daily-report-mozin`

## 分发流程（验证通过）

### 1. 查同事 open_id
```bash
lark-cli contact +search-user --query "马祖曦" --as user
lark-cli contact +search-user --query "易安" --as user
lark-cli contact +search-user --query "张镭橙" --as user
```
返回 JSON 含 `open_id`（ou_xxx）、`p2p_chat_id`（oc_xxx）、`department`、`enterprise_email`。

已知 open_id（2026-08-11）：
- 马祖曦：ou_06eb953a09dc20e98d9ac3cbfa1d9dfa
- 易安：ou_e52e487e653c41560ee9adaf13953b69
- 张镭橙：ou_bfa415470e9283f50ef5e09829a76615

### 2. 打包 zip
```powershell
cd "D:\AI\AI产品工作\技能\skills\04-文档数据与汇报"
Compress-Archive -Path "daily-report-mozin\*" -DestinationPath "D:\AI\AI产品工作\汇报\mozin-daily-report-skill-v4.6.zip" -Force
```
命名规范：`<skill-name>-v<版本>.zip`（如 mozin-daily-report-skill-v4.6.zip）。

### 3. 发送（关键陷阱）
- ❌ `--file` 与 `--text` 同用 → 报错：`--image/--file/--video/--audio cannot be used with --text, --markdown, or --content`
- ✅ 必须**分两条消息**：先发文件，再发说明
- ⚠️ `--file` 只接受 cwd 相对路径（绝对路径和 `..` 被拒绝）→ 先 `cd` 到 zip 所在目录
- ⚠️ 必须用 node run.js 直调（lark-cli.cmd 长内容/中文必败）

```python
LARK_JS = r"C:\Users\皮玺玉\AppData\Roaming\npm\node_modules\@larksuite\cli\scripts\run.js"
env = {"LARK_CLI_WORKSPACE": "hermes", **os.environ.copy()}

# 消息1：发文件
subprocess.run(["node", LARK_JS, "im", "+messages-send", "--as", "bot",
                "--user-id", uid, "--file", "mozin-daily-report-skill-v4.6.zip"], ...)
# 消息2：发说明
subprocess.run(["node", LARK_JS, "im", "+messages-send", "--as", "bot",
                "--user-id", uid, "--text", "📦 Mozin 日汇报技能包 v4.6（日报/周报/月报自动生成+飞书发送）\n解压到 Hermes skills 目录即可使用。详见 README.md"], ...)
```

### 4. 验证
- 返回 `"ok": true` + `message_id`（om_xxx）
- 每条消息独立 message_id，两次都成功才算完整分发

## Gitea push 流程

### 正式仓库
`http://120.237.89.124:8929/rd-center/org-mag-sup/mozin-daily-report`（2026-08-11 用户指定）

### 前置配置
```bash
git config --global http.sslVerify false
git config --global http.unsafeRemotes true   # 否则报 "Unencrypted HTTP is not recommended"
```

### 步骤
```powershell
cd "D:\AI\AI产品工作\技能\skills\04-文档数据与汇报\daily-report-mozin"
git init
git config user.name "皮玺玉"; git config user.email "pxy@mozin.io"
# 更新 README.md（版本号/安装/使用/变更记录）
git add -A; git commit -m "feat: mozin-daily-report v4.6 日汇报技能包（日报/周报/月报）"
git remote add origin http://120.237.89.124:8929/rd-center/org-mag-sup/mozin-daily-report.git
git push -u origin master
```

### 凭据（一劳永逸方案 · 2026-08-11 最终验证）
用户明确要求"以后都不想这么麻烦" → 用 `cmdkey` 把 token 存入 **Windows 凭据管理器**，一次设置，以后 clone/push 永久免输入：

```powershell
# 1. 生成 token：Gitea → 设置 → 应用 → 管理访问令牌 → 生成新令牌 → 勾选 write:repository
#    ⚠️ 不要用「新建 OAuth2 应用」页面（那个要填 Redirect URI）——普通 token 不需要
#    ⚠️ token 有有效期（用户这次是 1 年），到期后重新生成再执行一次 cmdkey 即可

# 2. 存入 Windows 凭据管理器（关键！）
cmdkey /generic:git:http://120.237.89.124:8929 /user:pixiyu@mozin.ai /pass:"glpat-XXX"

# 3. 验证存储
cmdkey /list | Select-String "120.237"   # → Target: LegacyGeneric:target=git:http://120.237.89.124:8929

# 4. 之后 git clone/push 完全免认证（credential.helper=manager 自动读取）
```

- ✅ 存储后 `git push` 返回 `* [new branch] master -> master` 即成功
- ⚠️ remote URL 必须是 **HTTP**（`http://120.237.89.124:8929/...`）而不是 SSH：SSH 2222 端口 Connection refused（公网未开放），HTTP 8929 通
- ⚠️ 如果 remote 曾被 set-url 成 ssh://，push 前改回：`git remote set-url origin http://120.237.89.124:8929/rd-center/org-mag-sup/mozin-daily-report.git`
- ⚠️ token 是敏感信息：禁止写入 README/提交文件；cmdkey 存储是安全的本地凭据方案
- ✅ 2026-08-11 已配置：`~/.git-credentials` + `credential.helper=store` 全局生效，Codex/Reasonix/Hermes 均可免认证访问


### Edge 登录数据侦察（2026-08-11 验证）
- Edge `Login Data` SQLite（`%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\Login Data`）可查 Gitea 登录过的**用户名**：
  ```sql
  SELECT origin_url, username_value FROM logins WHERE origin_url LIKE '%120.237%'
  -- → user: pixiyu@mozin.ai（Gitea 账号）
  ```
- ⚠️ 密码列 `password_value` 是 **v20 前缀（Chrome App Bound 加密）**，`CryptUnprotectData`（DPAPI）**解密失败返回 None**——不要再浪费时间尝试 Python 解密，直接向用户索取 token
- 内嵌凭据 URL 方式：`http://<user>:<token>@120.237.89.124:8929/...` 可避免交互式提示

### 历史仓库（参考）
- 旧 Gitea：`http://192.168.0.102:8929/modaipeng/mozin-daily-report` → pxy 分支（莫总仓库）
- 远程别名：`git -c http.proxy= push mozin-boss master:pxy`

## 通用模式
这个流程适用于任何 Hermes 技能包分发：
1. 从技能站目录（`D:\AI\AI产品工作\技能\skills\<分类>\<skill>`）打包
2. 用 contact +search-user 查收件人 open_id
3. node run.js 分两条消息（文件 + 说明）P2P 发送
4. 可选：git init + commit + push 到 Gitea 正式仓库
