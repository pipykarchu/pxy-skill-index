# 周报生成逻辑：大周/小周交替 + 节假日跳过

## 核心规则

**周报生成时间交替：**
```
大周（工作天数≥5天）  → 周五 18:30 生成
小周（工作天数<5天）  → 周六 09:00 生成
国家节假日          → 完全跳过
```

**示例日历（2026年）：**
```
7月第3周（7/13-7/19）— 大周  → 周五 7/17 18:30 生成 ❌（已过）
7月第4周（7/20-7/26）— 小周  → 周六 7/25 09:00 生成 ✅（下周）
8月第1周（7/27-8/2）  — 大周  → 周五 8/1  18:30 生成
8月第2周（8/3-8/9）   — 大周  → 周五 8/8  18:30 生成
8月第3周（8/10-8/16）— 小周  → 周六 8/15 09:00 生成
...
10月国庆（10/1-10/7） — 节假日  → 跳过（改为 10/8 或 10/9）
```

---

## 实现方案

### 方案 A：使用 Python 脚本判断（推荐）

创建智能判断脚本：

```python
# ~/.hermes/scripts/should_generate_weekly_report.py

import datetime
import json
from pathlib import Path

# 国家节假日配置
HOLIDAYS_2026 = [
    (1, 1),      # 元旦
    (2, 7, 2, 13),  # 春节（2/7-2/13）
    (4, 4, 4, 6),   # 清明
    (5, 1, 5, 5),   # 劳动节
    (6, 9, 6, 11),  # 端午
    (9, 15, 9, 17), # 中秋
    (10, 1, 10, 7), # 国庆
]

def is_holiday(date):
    """检查是否为国家节假日"""
    for holiday in HOLIDAYS_2026:
        if len(holiday) == 2:
            if (date.month, date.day) == holiday:
                return True
        else:
            start = datetime.date(2026, holiday[0], holiday[1])
            end = datetime.date(2026, holiday[2], holiday[3])
            if start <= date <= end:
                return True
    return False

def is_big_week():
    """判断本周是大周还是小周"""
    today = datetime.date.today()
    week_start = today - datetime.timedelta(days=today.weekday())
    week_end = week_start + datetime.timedelta(days=6)
    
    # 统计本周有多少个工作日（排除周末和节假日）
    working_days = 0
    for i in range(7):
        date = week_start + datetime.timedelta(days=i)
        if date.weekday() < 5:  # 周一到周五
            if not is_holiday(date):
                working_days += 1
    
    # 大周：≥5 个工作天
    return working_days >= 5

def should_generate_report():
    """判断今天是否应该生成周报"""
    today = datetime.date.today()
    weekday = today.weekday()  # 0=Monday, 4=Friday, 5=Saturday, 6=Sunday
    
    # 检查是否为节假日
    if is_holiday(today):
        print(f"今天是节假日，跳过周报生成")
        return False
    
    big_week = is_big_week()
    
    if big_week and weekday == 4:  # 周五（大周）
        print(f"大周周五，生成周报")
        return True
    elif not big_week and weekday == 5:  # 周六（小周）
        print(f"小周周六，生成周报")
        return True
    else:
        print(f"不是周报生成日期（大周={big_week}, 今天={['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][weekday]}）")
        return False

if __name__ == "__main__":
    if should_generate_report():
        print("YES")
        exit(0)
    else:
        print("NO")
        exit(1)
```

### 使用 Cron + 脚本判断：

```bash
# 创建周报 Cron，使用脚本判断
hermes cron create "0 18 * * 5" \
  "如果是大周周五（工作日≥5），生成周报；否则跳过。" \
  --script should_generate_weekly_report.py \
  --name "📅 周报自动生成-皮玺玉-大周周五" \
  --skill daily-weekly-monthly-reporting \
  --deliver feishu 2>&1

hermes cron create "0 9 * * 6" \
  "如果是小周周六且非节假日，生成周报；否则跳过。" \
  --script should_generate_weekly_report.py \
  --name "📅 周报自动生成-皮玺玉-小周周六" \
  --skill daily-weekly-monthly-reporting \
  --deliver feishu 2>&1
```

---

## 方案 B：使用 Cron 表达式 + 配置文件

如果 Hermes Cron 暂不支持脚本判断，可用配置文件定义具体日期：

**config.yaml:**
```yaml
reporting:
  weekly:
    enabled: true
    big_week_schedule: "30 18 * * 5"  # 周五 18:30
    small_week_schedule: "0 9 * * 6"  # 周六 09:00
    
    # 按年定义大周/小周
    week_pattern_2026:
      - { week: 1, type: "big", date: "2026-01-09", reason: "standard" }
      - { week: 2, type: "small", date: "2026-01-17", reason: "standard" }
      - { week: 3, type: "big", date: "2026-01-23", reason: "standard" }
      # ... 更多周
      - { week: 29, type: "big", date: "2026-07-17", reason: "standard" }  # ← 本周
      - { week: 30, type: "small", date: "2026-07-25", reason: "standard" }
      - { week: 40, type: "skip", date: "2026-10-01", reason: "国庆假期" }
    
    holidays:
      - { date: "2026-01-01", name: "元旦" }
      - { start: "2026-02-07", end: "2026-02-13", name: "春节" }
      - { date: "2026-04-04", end: "2026-04-06", name: "清明" }
      - { date: "2026-05-01", end: "2026-05-05", name: "劳动节" }
      - { date: "2026-06-09", end: "2026-06-11", name: "端午" }
      - { date: "2026-09-15", end: "2026-09-17", name: "中秋" }
      - { start: "2026-10-01", end: "2026-10-07", name: "国庆" }
```

**在 Skill 中读取并判断：**
```bash
$config = Get-Content ~/.hermes/config.yaml | ConvertFrom-Yaml
$thisWeek = Get-Content $config.reporting.weekly.week_pattern_2026 | Where-Object { $_.date -eq (Get-Date).AddDays(-((Get-Date).DayOfWeek)).ToString("yyyy-MM-dd") }

if ($thisWeek.type -eq "big") {
  # 周五 18:30 生成
} elseif ($thisWeek.type -eq "small") {
  # 周六 09:00 生成
} else {
  # 跳过
}
```

---

## 当前推荐方案

**使用方案 A（Python 脚本判断）**，理由：
1. 自动判断大周/小周，无需手工配置
2. 内置国家节假日检查
3. 年份更新只需修改 `HOLIDAYS_2026`
4. 可扩展支持未来年份

---

## 立即实现步骤

### Step 1: 删除旧的周报 Cron
```bash
hermes cron delete b6342a8a3b16  # 删除旧周报任务
```

### Step 2: 创建 Python 判断脚本
将上面的 Python 代码保存到：
`~/.hermes/scripts/should_generate_weekly_report.py`

### Step 3: 创建两个新的 Cron 任务

**大周周五 18:30：**
```bash
hermes cron create "30 18 * * 5" \
  "执行周报生成：先判断是否大周，如果是则生成周报；否则跳过。支持国家节假日自动检测。" \
  --script should_generate_weekly_report.py \
  --name "📅 周报自动生成-皮玺玉-大周周五18:30" \
  --skill daily-weekly-monthly-reporting \
  --deliver feishu
```

**小周周六 09:00：**
```bash
hermes cron create "0 9 * * 6" \
  "执行周报生成：先判断是否小周，如果是则生成周报；否则跳过。支持国家节假日自动检测。" \
  --script should_generate_weekly_report.py \
  --name "📅 周报自动生成-皮玺玉-小周周六09:00" \
  --skill daily-weekly-monthly-reporting \
  --deliver feishu
```

### Step 4: 验证
```bash
hermes cron list | grep "周报"
```

应该看到两个周报任务：
```
  xxx [active]
    Name:      📅 周报自动生成-皮玺玉-大周周五18:30
    Schedule:  30 18 * * 5
    Next run:  2026-07-17T18:30:00+08:00

  yyy [active]
    Name:      📅 周报自动生成-皮玺玉-小周周六09:00
    Schedule:  0 9 * * 6
    Next run:  2026-07-25T09:00:00+08:00
```

---

## 验证测试

**测试判断逻辑：**
```bash
python ~/.hermes/scripts/should_generate_weekly_report.py
# 输出: YES 或 NO（以及原因）
```

**手动触发测试：**
```bash
hermes cron run <job_id>  # 查看是否正确跳过或执行
```

---

## 未来扩展

1. **自动年份更新**：从在线日历 API 获取节假日
2. **假期补班检测**：某些假期前后有补班
3. **自定义调休**：支持公司特定的调休安排
4. **多地区支持**：不同地区节假日不同
