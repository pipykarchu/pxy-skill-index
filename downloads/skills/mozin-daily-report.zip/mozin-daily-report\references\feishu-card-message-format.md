# 飞书卡片消息发送格式（2026-08-03 验证）

## 发送目标
- 对话："皮玺玉的飞书 CLI" 智能体
- chat_id: `oc_3eab57d10ba96dbfbc6a19818a4d2b02`
- 身份：`--as bot`（必须！user 身份发的消息在该对话里看不到）

## 格式对比（实测结论）

| 格式 | 参数 | 结果 |
|------|------|------|
| 卡片 interactive ✅ | `--msg-type interactive --content <card_json>` | 蓝色标题栏+展开正文，完整显示 |
| --markdown ❌ | `--markdown <msg>` | 长内容被折叠成只显示标题的卡片 |
| --text ❌ | `--text <msg>` | 在智能体对话里也看不到内容 |

## 卡片 JSON 结构（Python）

```python
import json

card = {
    "config": {"wide_screen_mode": True},
    "header": {
        "title": {"tag": "plain_text", "content": "产品日报 · 2026-08-03"},
        "template": "blue"  # 可选: blue/green/orange/red/purple
    },
    "elements": [
        {"tag": "div", "text": {"tag": "lark_md", "content": body}}
    ]
}

# 调用
r = subprocess.run(
    [LARK, "im", "+messages-send", "--as", "bot", "--user-id", UID,
     "--msg-type", "interactive", "--content", json.dumps(card, ensure_ascii=False)],
    capture_output=True, text=True, timeout=30,
    encoding="utf-8", errors="replace", env=env)
```

## 卡片内 body 格式规则

1. **内容必须和本地 MD 存档完全一致**（量化、进展、证据、下一步一个不少）
2. 工作总览用**全角空格（　）**对齐列（飞书卡片不渲染 markdown 表格）
3. 工作总览项目前加序号（1. 2. 3. ...）
4. 每条事项标题前加圈序号（①②③...），全局递增：`①🟢 事项标题 ✅`
5. 加粗用 `**text**`（lark_md 支持）
6. `---` 分隔线在卡片里会渲染为横线
7. 列表用 `- ` 前缀（支持）

## 示例 body 片段

```
姓名：皮玺玉 ｜ 工时：8h

📊 今日工作总览
项目　　　　　　产出数　🟢正常　🟠待补　🟡待决　🔴阻塞
1. 公司AI协作　　2　　　2　　　0　　　0　　　0
2. 工具调研　　　1　　　1　　　0　　　0　　　0
合计　　　　　　3　　　3　　　0　　　0　　　0

---

**🔸 公司AI协作推进**
①🟢 上午莫总开会 — 团队介绍与AI协作制度 ✅
- 量化：召集开发+产品认识，推进公司AI协作进度
- 证据：飞书会议记录
- 下一步：各成员落实AI工具配置
```

## 土豆智能体协作

- 名称：土豆（产品搭档）
- 功能：每日自动生成待办摘要（飞书日程+未完成任务+优先级建议）
- 局限：无法通过 lark-cli 直接发消息（chat-search 搜不到）
- 协作：日报发到"皮玺玉的飞书 CLI"后，用户可手动转发给土豆纠正过时信息
- 土豆的待办信息可作为日报输入源之一
