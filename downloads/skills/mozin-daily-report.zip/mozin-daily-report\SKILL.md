---
name: daily-report-mozin
description: "为皮玺玉或当前登录用户生成 Mozin 个人日报、周报和月报。接到日报类请求时先判断核心定位：包含我、我的、个人、我今天做了什么等信号时使用本技能；包含团队、部门、全员、成员、负责人汇总等信号时改用 mozin-daily-report；只有写日报等无法判断范围的说法才询问一次。自动采集飞书汇报、日历、任务、文档、Git、本地文件、Edge 与 Hermes，输出飞书三字段、本地 Markdown 和飞书卡片，支持大小周与 Cron。"
---

# Mozin 日报/周报/月报生成 & 飞书发送（融合版 v4.7 · 2026-08-13）

> 每天的工作散落在飞书任务、Git 提交、本地文件、浏览器历史和 AI 对话里——手写日报重复劳动、漏项漏人、格式来回改。这个技能把碎片化工作自动采集、格式化、存档并推送到飞书，变成可追溯、可积累、零手动的结构化汇报。

## 核心定位判断（最先执行）

先判断用户要汇报的是“我个人”还是“我负责的团队”，再判断日报、周报或月报类型。**任务意图优先于岗位身份**：负责人也可以写个人日报，普通成员不能因为提到团队就自动获得团队数据权限。

| 判断结果 | 明确信号 | 处理 |
|---|---|---|
| 个人汇报 | 我、我的、个人、我今天做了什么、帮我归档、发给我 | 使用 `daily-report-mozin`，只汇总当前用户本人产出 |
| 团队负责人 | 团队、部门、全员、成员、项目组、负责人汇总、组长周报、PMO 汇总 | 路由到 `mozin-daily-report`，按成员核验和汇总产出 |
| 无法判断 | 只有“写日报”“生成周报”等，没有范围信息 | 只问一句：“这次是你的个人汇报，还是团队负责人汇总？” |

执行底线：

- 用户明确说“我的个人日报”时，即使检测到负责人岗位，也保持个人汇报。
- 用户明确要求团队汇总时，先确认其负责人/组长/PMO身份或已有授权；无法确认则不越权采集团队数据。
- 不同时生成个人版和团队版，除非用户明确要求两份。
- 团队模式中逐项标注成员和证据，不把团队成果写成负责人个人成果。

## 功能特性

| 功能 | 说明 |
|------|------|
| 五源自动采集 | 飞书日历/任务 + Git 提交 + 本地文件变更 + Edge 浏览记录 + Hermes 会话历史 |
| 大小周自动判断 | 根据国家节假日识别本周是大周(工作日≥5)还是小周，自动决定周报生成日 |
| 定时生成 | 大周周五 18:30、小周周六 18:30 自动触发（Hermes Cron） |
| 飞书汇报→周报合并 | **首选**从飞书汇报 API 拉取本周已发布日报（今日总结+明日计划+协调），合并生成周报 |
| 飞书卡片发送 | bot 卡片消息格式（`--as bot --msg-type interactive`），全角空格对齐模拟表格 |
| 多用户即插即用 | `lark-cli auth status --json` 自动检测当前用户身份，无需硬编码 ID |
| 本地 Markdown 存档 | 日报→`汇报/daily/`，周报→`汇报/weekly/`，完整 Markdown 表格格式 |
| 时间范围标注 | 文件名和正文均含明确时间范围（MM-DD ~ MM-DD） |

## 信息采集来源

| 来源 | 采集方式 | 获取内容 |
|------|---------|---------| 
| **飞书汇报（首选）** | `lark-cli api POST /open-apis/report/v1/tasks/query --as user` | 已发布日报原文（今日总结+明日计划+协调帮助）|
| 飞书任务 | `lark-cli task +get-my-tasks --as user` | 今日完成/进行中任务 |
| 飞书日历 | `lark-cli calendar +agenda --as user --start ... --end ...` | 今日会议和日程 |
| 飞书妙记 | `lark-cli minutes +search` + `+detail` | 会议纪要摘要 |
| Git 提交 | `git log --since` 扫描工作目录 | 代码/文档变更 |
| 本地文件 | `Get-ChildItem` 按修改时间筛选 | 新增/修改的文档和产物 |
| Edge 浏览记录 | Python sqlite3 读取 History DB | 今日访问的工具/文档页面 |
| Hermes 会话 | 当前 session 自动提取 | AI 辅助完成的任务 |

## 使用方式（可直接复制）

```
写日报
```
→ 手动模式：你口述今天做了什么，系统格式化后存档+发送

```
写日报 --auto
```
→ 自动模式：系统并行扫描 5 个来源，生成草稿让你确认

```
写周报
```
→ 合并本周日报 + 手动补充 → 周报存档+发送

```
今日进展
```
→ 等同于"写日报"

```
本月总结
```
→ 月报模式：合并本月所有日报/周报

## 使用场景

| 场景 | 你说的话 | 系统动作 | 输出 |
|------|---------|---------|------|
| 下班前快速记录 | "写日报" | 等你口述 → 格式化 | 飞书卡片 + 本地 md |
| 全自动不想管 | "写日报 --auto" | 5源并行采集 → 展示草稿 | 确认后发送+存档 |
| 周五生成周报 | "写周报" | 合并本周日报 + 补充 | 飞书卡片 + 本地 md |
| 提前做周报 | "明天休假，今天先做周报" | 截止今天的周报 | 同上 |
| 定时自动触发 | 无需手动 | Cron 18:30 自动执行 | 飞书通知 |

## 已知限制 & 解决方案

| 限制 | 原因 | 解决方案 |
|------|------|--------|
| 飞书卡片不支持 Markdown 表格/分隔线 | 飞书 lark_md 规范限制 | 用全角空格模拟对齐 |
| Edge 浏览记录需 Edge 未运行 | SQLite 数据库锁定 | 复制 History DB 后读取，或使用在线访问记录 |
| `--as user` 消息在 APP 不可见 | 飞书 API 规范 | 改用 `--as bot` 或通过汇报 API 推送 |
| **lark-cli <1.0.85 参数转义失败** | **JSON 解析不稳定** | **见 `references/feishu-api-lark-cli-version-pitfall.md`：升级 lark-cli、用文件参数、或降级本地存档** |
| 说话人分离失败 | 飞书妙记识别能力 | 无法补充——使用飞书妙记手工标注 |
| D 盘重装后写权限丢失 | 权限继承问题 | 见 `references/d-drive-acl-fix.md` — 用 `takeown + icacls` 修复 |

## 公司规范对齐（PMO V2.0）

### 五色自评标准

每条日报产出必须带五色标记：

| 色 | 含义 | 判定标准 |
|----|------|---------|
| 🟢 | 正常推进 | 来源可追溯、逻辑完整、明确可行 |
| 🟡 | 待决策 | 逻辑通顺但依赖他人决策；低风险 |
| 🟠 | 质疑/待补充 | 主张有道理但缺可验证数据；3日内补充 |
| 🔴 | 拒绝/阻塞 | 事实错误、触合规红线、无法执行 |
| 🔵 | 锚定目标 | 与核心目标完全一致——标蓝后其他不构成否决 |

**边界规则**：🔵覆盖一切→🔴优先于🟠🟡→不同产出可不同色。

### 日报铁律

1. **不可空白** — 每人每天必须提交（全员 20:00 前）
2. **日报即看板** — 不写工作日报等于没工作
3. **禁止编造** — 链接必须验证可点开
4. **量化+证据** — 每条产出带数字和飞书链接

### 皮玺玉的日报格式标准（已验证 2026-08-06~07）

**命名规范**：`皮玺玉_YYYYMMDD_日报.md`
- 例：`皮玺玉_20260807_日报.md`  
- 存档位置：`汇报/daily/`
- ⚠️ 避免这些格式：`YYYY-MM-DD-皮玺玉-日报.md` 或 `08-07-皮玺玉-日报.md` 

**文档结构**（按顺序）：
1. 标题：`🗓 产品日报`
2. 元数据：`日期：YYYY-MM-DD ｜ 姓名：皮玺玉 ｜ 工时：Xh` 加 `抄送：莫代鹏、宋家明`
3. **工作总览表** — 统计全天产出分布（必须）
   - **飞书 IM 格式**（用户 2026-08-11 固化）：全角空格对齐 + `🟢xN` 计数，**不用 Markdown 表格**
   - 表头：`产出数　🟢 正常　🟠 待补　🟡 待决　🔴 阻塞`
   - 每项目一行：`原型调试与验收　　🟢x2`（零值不显示）
   - 末行：`**合计：6 项 | 🟢x6 | 🟠x0**`
   - MD 存档文件内可用 6 列 Markdown 表格（项目/产出数/🟢正常/🟠待补/🟡待决/🔴阻塞），但发送飞书时必须转成上面格式
4. **分项详情** — 每项用 `🔸 项目名` 区分
   - 子项格式：`①🟢 分项标题 ✅` → 量化 → 产出 → 证据 → 下一步
   - 编号格式：**必须用圆形序号**①②③（Unicode 24FF+），不要用 1. 2. 3.
   - 色标紧跟分项号，状态一目了然
5. **明日计划** — `📅 明日计划` 后跟任务清单
   - 格式：`- [ ] 任务1` 和 `- [ ] 任务2`（未完成风格）
6. **协调帮助** — `🤝 协调帮助` 后跟编号行（用户 2026-08-13 固化：**禁止 Markdown 表格**，粘贴会失效）
   - 格式：`1.【事项】：负责人<具体需求>时限`（多条时前面加序号 1. 2. 3.，防复制时换行折叠混成一行）
   - 示例：
     ```
     1.【高光剪辑 MCP 对接】：智枢<后台智能体编排内容交接 + MCP 接口对接标准确认>本周
     2.【Ultra 按键唤醒 AI 功能增加】：和成<功能需求提报与方案对齐>本周
     ```
   - 没有协调事项时写「无」，不空白
7. **页尾**：`阻塞项：无`（或具体列出）

**四段式标准**（每条分项必备，不可省略）：
- **量化**：具体数字（人数、时长、数量、百分比等）
- **产出**：交付物名称和形式
- **证据**：飞书链接、文件路径或外部引用（必须可验证）
- **下一步**：明确的后续行动及时间/负责人

**文本格式细节**：
- 用全角分隔符 `｜`（不是 `|`），便于飞书粘贴时保持对齐
- 分项标题后加 `✅` 表示已完成，不加则表示进行中
- 表格行首末都用 `|` 包围（标准 Markdown）
- 色标总是放在编号后面，便于快速扫描色彩分布

**常见错误**（2026-08-07 踩坑）：
- ❌ 省略"量化"或"证据"段——会被视为不可信
- ❌ 用 `1. 2. 3.` 代替 `①②③`——破坏视觉扫描
- ❌ 混用五色标准（如用蓝色、紫色）——统一用 🟢🟠🟡🔴
- ❌ 表格行不对齐——在飞书粘贴时容易失效
- ❌ "下一步"写成模糊的动词（如"继续""优化"）——必须写具体时间和负责人

### 日报模板（公司标准 · 2026-08-11 固化）

```
🗓 产品日报

日期：YYYY-MM-DD ｜ 姓名：皮玺玉 ｜ 工时：8h
抄送：莫代鹏、宋家明

---

📊 今日工作总览

产出数　🟢 正常　🟠 待补　🟡 待决　🔴 阻塞

[项目名]　　🟢xN [🟠xN]

**合计：N 项 | 🟢xN | 🟠xN**

---

🔸 项目名

①🟢 产出标题 ✅
- 量化：具体数字
- 产出：交付物描述
- 证据：飞书链接（须验证通过）或本地路径
- 下一步：后续动作

📅 明日计划

- [ ] 任务1
- [ ] 任务2

🤝 协调帮助

| 事项 | 需要谁 | 具体需求 | 时限 |

阻塞项：无
```

**总览表铁律（用户 2026-08-11 明确纠正，别再犯）：**
- ❌ 不用 Markdown 表格（`| 项目 | 产出数 |` 是错的）
- ✅ 用全角空格（　）对齐 + `🟢xN` 计数格式：
  ```
  产出数　🟢 正常　🟠 待补　🟡 待决　🔴 阻塞

  原型调试与验收　　🟢x2

  跨部门 APP 2.0 对齐　　🟢x1

  **合计：6 项 | 🟢x6 | 🟠x0**
  ```
- 每行只列有值的状态（零值不显示），紧凑易读
- 总览数字最后统计，与实际条目数对齐后再输出

**命名铁律：** `皮玺玉_YYYYMMDD_日报.md`（例：皮玺玉_20260811_日报.md），存 `汇报/daily/`。
禁止其他格式（`08-07-皮玺玉-日报.md`、`2026-08-07-皮玺玉-日报.md` 都是错的）。
生成前先 `Get-ChildItem daily` 检查当日文件是否已存在，避免重复生成两份。

### 周报额外要求

| 维度 | 内容 |
|------|------|
| 本周工时 | 各项目实际投入人天 |
| 本周未按计划完成 | 原因 + 补救方案 |
| 下周计划 | 具体到项目和里程碑 |
| 战略对齐 | 与 OGSM 目标的关联 |

### 数据来源优先级（周报合并）

1. **飞书汇报 API**（首选）— `POST /open-apis/report/v1/tasks/query` 拉取本周已发布日报
2. **本地存档**（备选）— `D:\AI\AI产品工作\汇报\daily\` 下的 md 文件
3. **手动补充** — 用户口述追加

---
## ⚠️ 关键陷阱

### 数据源优先级铁律

**用户说"从飞书汇报的日报为准"** → 飞书汇报 API 是唯一权威数据源。不要用自己编的内容、session 记忆或猜测来生成周报。没有飞书日报数据就问用户，不要杜撰。

### commit_time ≠ 内容日期

补交日报的 `commit_time` 是提交时间（如 8/3 补交 7/29 日报，commit_time 在 8/3）。**按内容文本中的日期（如"补交日报 · 2026-07-29"）匹配本周范围**，不能只按 commit_time 过滤。

正确做法：扩大 commit_time 查询范围（如查本周+后一周），然后按内容中的日期字符串筛选属于目标周的日报。

### 用户日期意图校验

用户说的周报日期可能与当前系统日期矛盾（如系统日期是 8/4 但用户说"生成 8/27-8/31 周报"）。**先检查系统当前日期**，如果目标日期在未来，主动确认用户是否搞混了月份。

---

## 工作流总览

```
触发词（写日报/写周报/今日进展/汇报...）
    ↓
[Step 0] 模式判断：自动采集 or 手动输入？日报 or 周报？
    ↓
[Step 1] 日期确认（强制检查，文件名=内容日期=今天）
    ↓
[Step 2] 数据采集（自动模式：4个SubAgent并行；手动模式：解析用户输入）
    ↓
[Step 3] 五色分类 + 六模块归类 + 证据链验证
    ↓
[Step 4] 生成飞书汇报三字段纯文本（按模板）
    ↓
**Step 5: 本地存档**
4. **存档**：`D:\\AI\\AI产品工作\\汇报\\daily\\皮玺玉_YYYYMMDD_日报.md`
5. **飞书IM**：Python subprocess 调用 `node run.js`（不是 lark-cli.cmd！），`ensure_ascii=False`，卡片 body 直接从 MD 内容生成（不精简）
6. **技能站同步**：修改技能后执行 `cmd /c "同步技能站.cmd"`（D:\AI\AI产品工作\技能\）
    ↓
[Step 6] 飞书IM发送（bot卡片消息）
    ↓
完成
```

---

## ⚠️ lark-cli 实战固化（2026-08-13 验证，新机器/新环境必读）

### 1. 本机没有 lark-cli / node 时用 Hermes 内置 node 安装

旧脚本里的路径 `C:\Users\皮玺玉\AppData\Roaming\npm\...` 是**旧机器**的路径，新机器（用户 16543）不存在。正确做法：

```powershell
# Hermes 内置 node 在 runtime 目录
$nodeDir = "D:\hermes\data\versions\0.19.0-cn.7\node"
$env:Path = "$nodeDir;$env:Path"          # postinstall 需要 node 在 PATH
$npm = "$nodeDir\npm.cmd"
cmd /c "`"$npm`" install -g @larksuite/cli"   # → node\lark-cli.cmd
```

### 2. 绑定 + 授权（一次性）

```powershell
$env:HERMES_HOME = "D:\hermes\data\hermes-home"
lark-cli config bind --source hermes --identity user-default   # 拉个人妙记/日历必须 user-default
lark-cli auth login --recommend                                  # 出授权链接，用户浏览器完成
lark-cli auth status --json                                      # 验证：userName=皮玺玉 + tokenStatus=valid
```

- 授权后用户 open_id：`ou_7d05b327389c521f51426312ac5c9e2b`
- **皮玺玉的飞书 CLI 智能体 chat_id：`oc_3eab57d10ba96dbfbc6a19818a4d2b02`**（查法：`im +chat-list --types p2p,group --page-size 50`，智能体是 p2p 会话，`contact +search-user` 搜不到 bot）

### 3. 发飞书消息：node run.js + spawnSync 传参（禁止 @file / --markdown @file）

`--markdown @file` 不会读文件，会把 `@daily_msg_tmp.md` 当字面文本发出去（2026-08-13 踩坑）。正确姿势：

```javascript
// send_report.js — 参数走 argv，绕开 cmd 中文编码问题
const { spawnSync } = require('child_process');
const fs = require('fs');
const NODE = 'D:/hermes/data/versions/0.19.0-cn.7/node/node.exe';
const RUNJS = 'D:/hermes/data/versions/0.19.0-cn.7/node/node_modules/@larksuite/cli/scripts/run.js';
const env = { ...process.env, LARK_CLI_WORKSPACE: 'hermes', HERMES_HOME: 'D:/hermes/data/hermes-home' };
const report = fs.readFileSync('日报路径.md', 'utf8');
const r = spawnSync(NODE, [RUNJS, 'im', '+messages-send', '--as', 'user',
  '--chat-id', 'oc_3eab57d10ba96dbfbc6a19818a4d2b02', '--markdown', report],
  { encoding: 'utf8', env, timeout: 90000, maxBuffer: 10 * 1024 * 1024 });
```

### 4. 妙记自动采集（边界确认会等会议内容直接进日报）

```bash
# 搜今日妙记（--start 必须 ISO 日期，不能用 "7d"）
lark-cli minutes +search --participant-ids ou_7d05b327389c521f51426312ac5c9e2b --start 2026-08-05 --as user
# 拿 detail（--minute-tokens 逗号分隔，--summary --todo --chapter）
lark-cli minutes +detail --minute-tokens <token> --summary --todo --chapter --as user
```

妙记是日报量化的**权威证据源**：会议时长、章节结论、待办 todo_id 直接引用。

### 5. 中文写入 .ps1 必乱码 → 用 node 脚本代替

`write_file` 写含中文/emoji 的 `.ps1`，PowerShell 5.1 按 ANSI 解析必乱码（路径中文直接炸）。统一改用 node 脚本（原生 UTF-8），或 `[System.IO.File]::WriteAllText(..., UTF8 BOM)`。

### 6. Hermes 工具集里没有飞书工具

`hermes mcp list` 为空、`hermes tools list` 无飞书集成——飞书能力全部走 lark-cli 命令行，不要找 UI 入口。

---

## 日报输入优先级（关键）

**飞书汇报系统生成的草稿 > 用户口述 > 本机扫描**

**用户口述的纠正优先于一切扫描结果：**
- 用户说"不记录"某项 → 立即从日报删除，不存档，不争辩
- 用户说"这是我自己训练的技能" → 属性改为「自训练技能」，不写成平台功能
- 用户纠正描述（如"协作平台是解决乱码，不是文档迁移"）→ 立即 patch，重新输出，不重写整份日报

1. **先问用户：「有飞书生成的草稿吗？」** — 飞书版含量化数据（验收清单129条、逾期天数、协调时限等），本机扫描拿不到
2. 有飞书版 → 以飞书版为主体，用户口述内容追加进对应模块
3. 无飞书版 → 用户口述 + 本机扫描结合生成
4. **两类内容飞书采集不到，必须靠本机扫描补充：**
   - computer-use / 鼠标自动化操作（墨刀等工具的实际操作截图）
   - 本地技能包整理、Hermes skill 安装、Git push 等工具基建工作
5. **总览数字最后统计**，与实际条目数对齐后再输出

---

## 手动生成日报标准流程（用户提供补充内容时）

1. **并行扫描**（不等用户）：
   - 飞书任务：`lark-cli task +get-my-tasks --as user`
   - 本地文件：`Get-ChildItem D:\AI\AI产品工作` 从上次日报 MD 的 `LastWriteTime` 起
   - Edge 历史：Python sqlite3 复制 History 文件后查询（`%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\History`）
   - 飞书妙记：`lark-cli minutes +search` + `+detail --minute-tokens <token>`
2. **结合用户口述**：用户补充的内容权重最高，扫描数据作为证据补充量化
3. **生成草稿展示**：用户确认后，接受修正，一次性存档
4. **存档**：`D:\\AI\\AI产品工作\\汇报\\daily\\皮玺玉_YYYYMMDD_日报.md`
5. **飞书IM**：Python subprocess 调用 `node run.js`（不是 lark-cli.cmd！），`ensure_ascii=False`，卡片 body 直接从 MD 内容生成（不精简）
6. **技能站同步**：修改技能后执行 `cmd /c "同步技能站.cmd"`（D:\AI\AI产品工作\技能\）

**⚠️ D盘写权限问题（重装系统后常见）：**
- 重装系统后 D 盘文件所有权仍属旧 SID，write_file 和 Set-Content 都会 Permission Denied
- 修复：管理员 PowerShell 执行 `takeown /f "D:\AI\AI产品工作\汇报" /r /d Y` 然后 `icacls "D:\AI\AI产品工作\汇报" /grant "皮玺玉:(OI)(CI)F" /t`
- **注意**：icacls grant 参数必须整体加双引号（`"用户:(OI)(CI)F"`），否则 PowerShell 5.1 把括号当子表达式报错
- 如果 Hermes 进程没有管理员权限，先写桌面再让用户手动修权限后重试

**⚠️ 代码陷阱 (Pitfalls)**:

1. **生成器表达式在 join() 中的作用域问题** (2026-08-31 修复)
   - ❌ `"\\n".join([f"#### {d.strftime(...)}" for d, _ in daily_reports])`
     - 问题: 在闭包中直接使用生成器表达式，当 daily_reports 为空或嵌套逻辑复杂时容易出错
   - ✅ 改用显式列表构建:
     ```python
     daily_summary = []
     for d, _ in daily_reports:
         daily_summary.append(f"#### {d.strftime('%m-%d（%A）')}: ...")
     content += "\n".join(daily_summary)
     ```
   - 规则: 涉及复杂格式化逻辑时，优先用显式循环而不是生成器表达式

2. **飞书 IM 发送格式** (2026-08-03 验证)
   - ❌ 其他格式都看不到内容（--as user / --text / --markdown）
   - ✅ 唯一可用: `--as bot --msg-type interactive --content {card_json}`
   - 卡片内容用 `lark_md` 标签；支持粗体/emoji/列表；不支持表格/分隔线

3. **用户 ID 硬编码** (v4.0 问题，v4.2 已解决)
   - ❌ 在脚本中硬编码用户 ID → 多用户场景不可用
   - ✅ 使用 `get_current_lark_cli_user()` 自动检测
   **⚠️ 飞书集成（v4.3, 2026-08-31 完全就绪）：**
   - 📤 **发送到飞书**: markdown 卡片消息（`--msg-type interactive`）
   - 🎯 **发送目标**: 皮玺玉的飞书 CLI 智能体（`oc_3eab57d10ba96dbfbc6a19818a4d2b02`）
   - ✅ **标签支持**: `markdown` 标签（`lark_md` 已验证不支持）
   - 🔄 **自动检测**: lark-cli 用户身份（`lark-cli auth status --json`）
   - 💡 **多用户支持**: 其他用户直接运行，系统自动发给对应用户
   - 📋 **周报发送**: 大周周五 18:30 / 小周周六 18:30 自动触发
   - ⚙️ **Cron 配置**:
     * 大周: ID `67b8cf4f47c0` (周五 18:30)
     * 小周: ID `5c9d5330920e` (周六 18:30)

**⚠️ 周报定期生成（v2.1, 2026-08-31 更新）：**
- **大周周五 18:30** → 自动生成 + 飞书通知（Job ID: `67b8cf4f47c0`）
- **小周周六 18:30** → 自动生成 + 飞书通知（Job ID: `5c9d5330920e`）
- 时间统一为 18:30（与日报同步，简化用户心智）
- 生成脚本：`scripts/weekly-report-cron.py`（大小周判断、日报合并、周报 MD）
- 周报文件名：`皮玺玉_YYYY_W##_周报.md`（含时间范围 MM-DD ~ MM-DD 在标题和正文）
- 发送目标：**自动检测当前 lark-cli 登录用户**（多用户兼容）
  * 使用 `lark-cli auth status --json` 获取当前用户 open_id
  * 脚本中调用 `get_current_lark_cli_user()` 动态获取用户身份，无需硬编码
  * A 用户运行 cron → 周报发给 A；B 用户运行 → 发给 B
- 启动自动执行：`hermes gateway install`

**⚠️ Hermes Cron 脚本执行 Pitfall（2026-08-31 踩坑修复）：**
- ❌ 错误：直接将脚本路径作为 hermes 命令参数 → hermes 误解为子命令名 → `invalid choice` 错误
- ✅ 正确：使用 `--script <name>` 让 Hermes 在 `~/.hermes/scripts/` 自动定位
- ✅ 验证脚本时用 `subprocess.run([python, path])` 而非 `exec()`，避免命名空间污染、便于异常隔离和超时控制
- 见 `references/cron-weekly-schedule-unified-18-30.md` 中「脚本执行模式」section

**⚠️ token 状态规则（反复踩坑已记录）：**
- `needs_refresh` = 正常，下次 API 调用自动刷新，**不需要扫码**
- 只有 `token_missing` 或 `missing_scope` 才需要重新授权
- 授权前先 `lark-cli auth status --json` 检查现有 scope（当前60+个）
- device_code **10分钟**有效，超时需重新生成，不要缓存旧 code

**⚠️ 飞书卡片发送：必须用 node run.js（2026-08-05 定论，不可回退）：**

1. **绝对不能用 `lark-cli.cmd`** — `.cmd` wrapper 经 cmd.exe 处理，中文 `\uXXXX` 转义被误解为路径分隔符，超约200字中文就报 "The system cannot find the path specified"
2. **必须用 `ensure_ascii=False`** — `ensure_ascii=True` 对4字节emoji（🟢🟡📋📊🤝）产生 surrogate pairs `\ud83d\udfe2`，lark-cli JSON parser 拒绝
3. **LARK_JS 路径**：`C:\Users\皮玺玉\AppData\Roaming\npm\node_modules\@larksuite\cli\scripts\run.js`
4. **调用方式**：`["node", LARK_JS, "im", "+messages-send", "--as", "bot", "--user-id", UID, "--msg-type", "interactive", "--content", json.dumps(card, ensure_ascii=False)]`

**⚠️ 内容一致性铁律（用户多次纠正）：**
- 飞书卡片内容必须和本地 MD 文件**完全一致**，不能精简、不能省略字段
- 每条事项必须包含：量化 + 产出 + 证据 + 下一步（至少3项，能写全就写全）
- 用户说"格式不对"时，第一件事是 read_file 对比 MD 原文和发送内容的差异

**⚠️ Cron 脚本执行陷阱（2026-08-03 踩坑记录）：**
- ❌ **错误现象**：创建周报 cron job 时脚本执行失败，错误信息为 `hermes: error: argument command: invalid choice: 'D:\\...\\should_generate_weekly_report.py'`
- ❌ **根本原因**：Hermes cron 系统用 `hermes` CLI 直接解析脚本路径作为子命令参数，而不是用 Python 解释器执行
- ✅ **解决方案**：
  1. 脚本必须预先存在于 `~/.hermes/scripts/` 或 Hermes 的 scripts 目录
  2. 脚本需要 `#!/usr/bin/env python3` shebang（首行）
  3. 脚本应定义 `main()` 函数，用 `sys.exit(0)` 或 `sys.exit(1)` 返回状态码
  4. 创建 cron 时用 `--script <filename>` 指向脚本文件名（不是完整路径），Hermes 会自动在 scripts 目录中查找并用 Python 执行
  5. 见 `references/cron-script-execution.md` 了解完整细节
  6. 周报大小周判断脚本示例见 `references/weekly-report-big-small-week.md`

---

## Step 0: 模式判断

仅在完成上面的“核心定位判断”且结果为个人汇报后执行本节；团队负责人模式直接切换到 `mozin-daily-report`。

**报告类型：**
- 用户说"日报"/"写日报"/"今日进展" → **日报模式**
- 用户说"周报"/"写周报"/"本周周报" → **周报模式**
- 用户说"明天休假，今天先做周报" / "提前做周报" → **周报模式，日期范围截止今天**，不等正常的大小周日期，立即执行

**输入模式：**
- 用户说"写日报 --auto"或"写周报 --auto" → **自动采集模式**（直接拉飞书数据）
- 用户直接描述今天做了什么 → **手动输入模式**（解析用户输入）
- 默认：**预览模式**（生成后展示，用户确认后输出）

---

## Step 1: 日期确认（强制）

```
当前日期 = Get-Date -Format "yyyy-MM-dd"（PowerShell）
文件名格式：皮玺玉_YYYYMMDD_日报.md 或 皮玺玉_YYYY_W##_周报.md
内容第1行日期：YYYY-MM-DD
文件名日期 = 内容日期 = 今天 → 三者必须一致
```

**周报日期范围：** 本周周一 ~ 周五（五天），用 PowerShell 动态计算：
```powershell
$today = Get-Date
$monday = $today.AddDays(-[int]$today.DayOfWeek + 1)   # 周一（DayOfWeek: Sunday=0）
# 注意：PowerShell DayOfWeek Sunday=0, Monday=1 ... Saturday=6
# 若今天是周日(0)，+1会算到明天，需特判：
if ([int]$today.DayOfWeek -eq 0) { $monday = $today.AddDays(-6) }
$friday  = $monday.AddDays(4)
$range   = "$($monday.ToString('MM.dd'))-$($friday.ToString('MM.dd'))"  # 例：07.20-07.24
```
- 文件名中的周号用 `Get-Date -UFormat "%V"` 取 ISO 周号
- ⚠️ 周报覆盖的是完整自然周（周一~周五），不是"从上次日报到今天"
- ⚠️ 实际工作天数要用飞书日历核实（有无请假/调休）再填工时

⚠️ **周一日期必须用命令确认，不能靠推算或记忆：**
```powershell
$today = Get-Date
$monday = $today.AddDays(-(([int]$today.DayOfWeek + 6) % 7))
$monday.ToString("MM.dd")   # 周报起始日
$today.ToString("MM.dd")    # 周报结束日（或当天）
```
- PowerShell 的 `DayOfWeek` 中周日=0、周一=1……周六=6，需用 `(dow+6)%7` 才能得到正确偏移。
- 本周 W30 实际验证：07-20（周一）~ 07-24（周五），不是 07-21 也不是 07-25。
- 连续犯错模式：把周二当周一（差1天）、把休假日当结束日——两种都靠这条命令规避。

---

## Step 2A: 自动采集模式（--auto）

分 **4 个 SubAgent** 并行采集，主流程传入 `<today>` 实际日期。

### SubAgent A：飞书在线数据

> **执行前先动态获取身份**，避免硬编码漂移：
> ```bash
> lark-cli auth status --json
> # 取出 open_id / name，后续命令用变量替换 <me>
> ```

```bash
# 0. 身份确认 + 动态获取姓名
lark-cli auth status --json --as user
# 取 userName 字段用于确认当前用户。岗位只用于权限辅助判断，不能覆盖用户明确的个人汇报意图。
# 查部门：
lark-cli contact +search-user --user-ids "<open_id>" --as user 2>/dev/null

# 1. 日程（周报：覆盖周一~周五完整区间；日报：今天）
# 周报用法——拉本周全部日程，确认实际工作天数和会议：
lark-cli calendar +agenda --start <MONDAY>T00:00:00+08:00 --end <FRIDAY>T23:59:59+08:00 --as user
# 日报用法：
lark-cli calendar +agenda --as user

# 2. 文档（JSON 的有效数据在 data.results；兼容 DOCX/BITABLE/SHEET/SLIDES）
# 不使用 --mine：它与 --edited-since 组合可能返回 0 条。先不限作者采集，再按 result_meta.edit_user_name 过滤归属。
lark-cli drive +search --edited-since 1d --as user --format json
# 负责人需要团队产品相关资料时追加关键词搜索：
lark-cli drive +search --query "产品 方案 需求 架构 设计 PRD AI 规范" --edited-since 1d --as user --format json
# 对每个文档 token 读大纲（不读全文）：
lark-cli docs +fetch --doc <token> --scope outline --as user
# Wiki 空间扫描（培训/技术/产品空间）：
lark-cli wiki +space-list --as user
# lark-cli wiki +node-list --space-id <id> --as user（对产品相关空间执行）

# 3. 飞书消息搜索（关键词过滤，排除系统消息）
lark-cli im +messages-search \
  --query "PRD 评审 方案 需求 原型 交付 验收" \
  --start "<SINCE_DATE>T00:00:00+08:00" \
  --end "<TODAY>T23:59:59+08:00" \
  --page-size 15 --as user
# ⚠️ 系统消息过滤：「XX加入群聊」「XX退出群聊」不是事件，跳过不记录

# 4. 项目群聊消息（先拿群列表，再拉今日消息）
lark-cli im +chat-list --as user
# 对工作相关群（含「产品」「研发」「Mozin」关键字）：
lark-cli im +chat-messages-list \
  --chat-id <id> \
  --start "<SINCE_DATE>T00:00:00+08:00" \
  --end "<TODAY>T23:59:59+08:00" \
  --page-size 20 --as user
# ⚠️ 内部群跨租户不可读（code 230001）→ 跳过不报错，不阻塞整体流程

# 5. 我的任务（注意 is_completed 有 bug 永远返 false，需手动判断）
lark-cli task +get-my-tasks --as user

# 6. 妙记/会议纪要（先搜索再读全文）
lark-cli vc +search \
  --start "<SINCE_DATE>T00:00:00+08:00" \
  --end "<TODAY>T23:59:59+08:00" --as user
lark-cli minutes +search \
  --query "产品 评审 方案 需求 原型" \
  --owner-ids me --start <SINCE_DATE> --end <TODAY> \
  --page-size 10 --as user
# 有结果则读全文（注意参数名是 --minute-tokens 不是 --minute-id）：
lark-cli minutes +detail --minute-tokens <token> --as user

# 7. 审批
lark-cli approval tasks query \
  --params '{"topic":"","status":"pending"}' --as user 2>/dev/null
lark-cli approval instances initiated --as user 2>/dev/null

# 8. 格式校准：生成前拉一条真实日报样本
lark-cli api POST /open-apis/report/v1/tasks/query \
  --data '{"page_size":1}' \
  --params '{"user_id_type":"open_id"}' --as user 2>/dev/null
# → 核对字段结构和写法风格，防止格式漂移
```

### SubAgent B：本地文件扫描

```powershell
# 用 search_files tool（避免 find 命令在 Windows 递归超时）
# 扫描 D:\AI\AI产品工作\ 下今日修改的文件
# 扫描 D:\AI\hermes\runtime\skills\ 下今日修改的 skill
```

### SubAgent C：Git 提交记录

```powershell
# PowerShell 5.1 兼容写法（不用 && 管道）
git -c http.proxy= -C "D:\AI\AI产品工作\牧之音\Mozin-Android-MultiDevice-Prototype" log --since="<today> 00:00" --until="<today> 23:59" --oneline --author="皮玺玉"
```

### GitLab 事件与 MR 降级采集

常规 Git 记录不足以证明推送、评审和合并状态时，按以下顺序补采集；失败不阻塞其他来源：

1. 只从 `GITLAB_TOKEN` 或 `GITLAB_PERSONAL_ACCESS_TOKEN` 环境变量取令牌，不读取 `.git-credentials`、`.netrc` 或配置文件。
2. 调用 `/api/v4/user` 确认当前 GitLab 用户，再查今日 `/events?scope=push`。
3. 查 `/merge_requests?scope=all&state=all`，只认 `author.username` 与当前用户一致的 MR；参与评审/合入必须按实际角色表述。
4. API 不可用时，退回本地 `git log`，并把 GitLab 状态标为“未验证”，不得猜测已推送或已合并。
5. 团队日报和负责人汇总优先调用 `mozin-daily-report/scripts/collect_data.py` 获取统一 JSON。

### 产出归属验证（强制）

- GitLab 提交与 MR：核对 `author`；不是本人创建时写“参与评审/协作”，不得写成“完成”。
- 飞书会议与妙记：核对 `organizer` / owner；参会写“参加”，只有组织者才能写“组织/主持”。
- 飞书任务：核对 `creator`、assignee 和完成状态；创建任务不等于执行完成。
- 飞书文档：从 `data.results[].result_meta.edit_user_name` 判断编辑者，团队产出必须标明作者。
- 无归属字段或证据链接无法验证时，标注“归属待确认”，不要把团队成果冒认为个人成果。

### SubAgent D：Hermes 会话摘要

从今日 Hermes sessions 文件中提取操作摘要。

```python
import os, glob, json, datetime

# Hermes sessions 实际路径（Windows）
HERMES_SESSIONS = r"D:\AI\hermes\runtime\sessions"

# 用 SINCE_DT 时间段过滤（不只是今天，而是从上次日报到现在）
since_dt = get_last_report_time()

summaries = []
# sessions 目录结构：sessions/<id>/messages.json 或 sessions/<id>.json
for pattern in [
    os.path.join(HERMES_SESSIONS, "**", "messages.json"),
    os.path.join(HERMES_SESSIONS, "**", "*.json"),
]:
    for f in glob.glob(pattern, recursive=True):
        try:
            mtime = datetime.datetime.fromtimestamp(os.path.getmtime(f))
            if mtime < since_dt:
                continue
            with open(f, encoding="utf-8", errors="replace") as fp:
                data = json.load(fp)
            # 兼容两种格式：messages 数组 或 {"messages": [...]}
            msgs = data if isinstance(data, list) else data.get("messages", [])
            for m in msgs:
                role = m.get("role", "")
                content = m.get("content", "")
                if role == "user" and isinstance(content, str) and len(content) > 10:
                    summaries.append(content[:120])
        except Exception:
            continue

# 去重 + 取前10条最有信息量的
summaries = list(dict.fromkeys(summaries))[:10]
```

**pitfall：** sessions 目录下子目录名是 UUID，文件名可能是 `messages.json` 或 `<uuid>.json`，需要用 `glob(..., recursive=True)` 兼容两种结构。

---

## Step 2B: 手动输入模式

解析用户输入，映射到六模块 + 五色标准：

**状态符号速查：**
| 符号 | 含义 | 必须写明 |
|:----:|------|---------|
| 🟢 | 正常推进/已完成 | 附来源链接 |
| 🟡 | 待决策/需确认 | 需谁决策、时限 |
| 🟠 | 证据不足/待补充 | 缺什么、何时补 |
| 🔴 | 已阻塞/需修正 | 错在哪、修正计划 |
| 🔵 | 战略对齐 | 对齐的 OKR 或目标 |

---

## Step 3: 分类与验证

**六模块分类：**
- 📦 项目推进（按「项目名 [阶段名｜状态]」分组）
- 📐 流程制度
- 🛠️ 工具基建
- 🔍 研究调研
- 📋 行政事务
- 👥 组织管理

**SOP阶段名（中文）：** 产品梳理 / 业务文档 / 设计原型 / 研发工程 / 质量测试 / 产品验收 / 运维部署 / 运营

**状态词：** 调研中 / 编写中 / 开发中 / 测试中 / 验收中 / 已完成 / 阻塞 / 收尾中

**门禁标注（阶段交接时）：**
```
└ 门禁：规格包→研发 ✅ CEO通过 + PM签核
```

**证据链验证规则：**
- ✅ 每项产出必须附飞书链接（经 `docs +fetch` 验证）或本地路径
- ❌ 禁止放未验证的链接
- ❌ 禁止从会话摘要中抄 token 当证据
- 搜不到/打不开 → 诚实写「本地文件」或「待补充」

**量化规则：**
- 每项产出必须有至少一个量化指标
- 示例：文档683行/32KB、覆盖12个功能点、对比5款竞品
- 禁止编造数据

---

## Step 4A: 日报输出格式（飞书汇报三字段）

> ⚠️ 飞书汇报是表单文本框，禁止 Markdown 表格和多级标题，输出纯文本

**字段一：今日总结**
```
YYYY-MM-DD  皮玺玉 ｜ 8h

📊 总览：X项  🟢X 🟡X 🟠X 🔴X

📦 项目推进

项目名 [阶段名｜状态]
  1. 🟢 产出描述 ｜ 量化
     证据：https://www.feishu.cn/docx/xxx
     下一步：具体动作
  2. 🟡 产出描述 ｜ 量化
     待决策：需XX确认

📐 流程制度
  1. 🟢 产出描述 ｜ 量化
     证据：https://xxx
     下一步：具体动作

👥 组织管理
  1. 🟢 面试/沟通 ｜ 时间

📋 待办
  1. 🔴 逾期事项
```

**字段二：明日计划**
```
1. P0 事项描述
2. P1 事项描述
3. P2 事项描述
```
⚠️ 每条前加序号（1. 2. 3. ...）

**字段三：需要协调与帮助**
```
1. 事项 → 谁：具体需求（时限）
2. 事项 → 谁：具体需求（时限）
```
⚠️ 每条前加序号（1. 2. 3. ...）。无协调事项时写「无」。

## Step 4B: 周报输出格式

**字段一：本周工作（按项目汇总，不按日期罗列）**
```
MM.DD-MM.DD  皮玺玉 ｜ XXh

📊 总览：X项  🟢X 🟠X 🟡X 🔴X

📦 项目推进（按项目分组，每项带序号）

### 项目A [阶段｜状态]
1. ✅ 产出描述（量化）
2. ✅ 产出描述（量化）
3. 🟡 未完成项 — 原因

### 项目B [阶段｜状态]
4. ✅ 产出描述
5. 🔴 阻塞项（已解决/未解决）

...序号全局递增
```

**关键规则：周报按项目维度汇总，不逐日罗列。每条详情带全局递增序号。**

**字段二：下周计划**
```
1. P0 事项描述（4h）
2. P1 事项描述（8h）
```
⚠️ 每条前加序号（1. 2. 3. ...）

**字段三：需要协调和帮助**
```
1. 事项 → 谁：具体需求（时限前）
2. 事项 → 谁：具体需求（时限前）
```
⚠️ 每条前加序号（1. 2. 3. ...）

---

## Step 5: 本地存档

**路径：**
4. **存档**：`D:\\AI\\AI产品工作\\汇报\\daily\\皮玺玉_YYYYMMDD_日报.md`
5. **飞书IM**：Python subprocess 调用 `node run.js`（不是 lark-cli.cmd！），`ensure_ascii=False`，卡片 body 直接从 MD 内容生成（不精简）
6. **技能站同步**：修改技能后执行 `cmd /c "同步技能站.cmd"`（D:\AI\AI产品工作\技能\）

**存档内容：** 三字段完整内容（含字段标题）

---

## Step 6: 飞书IM发送

**目标 user_id：** `ou_7d05b327389c521f51426312ac5c9e2b`（皮玺玉本人）

**⚠️ 身份选择（关键 — 2026-08-03 验证）：**
- `--as user` 发到的 chat（`oc_eff5d3d2...`）用户在飞书 APP 里**看不到** ❌
- `--as bot` 发到的 chat（`oc_3eab57d1...`）对应用户可见的 **"皮玺玉的飞书 CLI"** 智能体对话 ✅
- **结论：日报发送必须用 `--as bot`**

**⚠️ 消息格式选择（关键 — 同日验证）：**
- `--markdown` + `--as bot`：长内容被折叠成只显示标题的卡片，正文不可见 ❌
- `--text` + `--as bot`：同样看不到内容 ❌
- `--msg-type interactive` + `--content <card_json>` + `--as bot`：卡片消息完整展示 ✅

**⚠️ 发送范围铁律（2026-08-11 用户明确纠正）：**
- **默认只发用户本人**（`--user-id ou_7d05b327389c521f51426312ac5c9e2b --as bot` P2P），**绝不默认发现群**
- 用户说"发给XX"（同事/群）时：先查 open_id 再逐一 P2P 发送，除非用户明确要求发到群里
- 用户说"发技能包给XX"：发的是 zip 技能包文件 + 说明文字，不是日报内容

**正确发送方式（Python subprocess + 卡片消息）：**
```python
import subprocess, os, json

LARK = r"C:\Users\皮玺玉\AppData\Roaming\npm\lark-cli.cmd"
UID = "ou_7d05b327389c521f51426312ac5c9e2b"
env = os.environ.copy()
env["LARK_CLI_WORKSPACE"] = "hermes"

def send_daily_card(title, body, color="blue"):
    """发送日报卡片到飞书智能体对话"""
    card = {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": title},
            "template": color  # blue/green/red/orange/purple
        },
        "elements": [
            {"tag": "div", "text": {"tag": "lark_md", "content": body}}
        ]
    }
    r = subprocess.run(
        [LARK, "im", "+messages-send", "--as", "bot", "--user-id", UID,
         "--msg-type", "interactive", "--content", json.dumps(card, ensure_ascii=False)],
        capture_output=True, text=True, timeout=30,
        encoding="utf-8", errors="replace", env=env
    )
    return '"ok": true' in (r.stdout or "")
```

**卡片 body 格式（lark_md 支持）：**
- `**粗体**` ✅、emoji ✅、换行 ✅
- 不支持 Markdown 表格 ❌、不支持 `---` 分隔线 ❌

**IM消息 body 模板（精简，无表格无分隔线）：**
```
姓名：皮玺玉 ｜ 工时：8h

📊 总览：🟢X 🟡X 🟠X 🔴X ｜ 合计X项

**🔸 项目/模块名**
🟢 事项描述 ✅
量化说明

**📋 明日计划**
1. P0 事项
2. P1 事项

**🤝 协调**
事项 → 谁：需求
```

**验证成功：** 返回 `{"ok":true,"data":{"message_id":"om_xxx"}}`

---

## 特殊场景处理

| 场景 | 处理方式 |
|------|---------|
| SubAgent 返回空 | 标注「今日无该源数据」，继续用其他源 |
| 数据源采集失败 | 标注「⚠️ 未拉取到XX数据（原因）」，不阻塞 |
| 今日无产出 | 诚实输出「📭 今日无产品产出」，不造假 |
| 不确定五色 | 宁标 🟡 待确认，不硬标 🟢 |
| 未关联项目 | 归入「🧩 跨项目事项」 |
| 群聊读不到（code 230001） | 内部群跨租户不可读，跳过不报错 |

---

## lark-cli token 在 Cron/subprocess 环境的限制

Windows keychain 存储的 lark-cli user token **无法被 Python subprocess 继承**，即使设置 `LARK_CLI_WORKSPACE=hermes` 也无效（已验证）。

**解决方案：**
- ✅ **hermes cron 不加 `--no-agent`** — Hermes agent 模式有完整 lark-cli token 上下文，飞书 API 正常调用
- ❌ `--no-agent` + Python subprocess → `token_missing` 错误，无论如何设置环境变量

**lark-cli re-login 步骤（token 过期时）：**
```bash
# 1. 发起授权（获取 verification_url + device_code）
lark-cli auth login --scope "im:message im:message.send_as_user" --no-wait --json

# 2. 生成二维码（--output 必须是相对路径，不能用绝对路径）
cd D:\AI\AI产品工作\汇报
lark-cli auth qrcode "<verification_url>" --output feishu_qr.png

# 3. 用户扫码授权后完成登录
lark-cli auth login --device-code "<device_code>"
```

**lark-cli im 发送 markdown 内容注意：**
- PowerShell 里直接传含特殊字符（`·`、`｜`、`**`）的 markdown 会被解析成位置参数 → 报错
- ✅ 用 Python subprocess + 参数列表调用，用 `LARK_CLI_WORKSPACE=hermes` env 确保读到正确 config（但 keychain token 仍需 Hermes 上下文）
- lark-cli 完整路径：`C:\Users\Administrator\AppData\Roaming\npm\lark-cli.cmd`

---

## Pitfalls

| 陷阱 | 说明 |
|------|------|
| ❌ 放未验证飞书链接 | 每项产出的飞书链接必须经 `docs +fetch` 或 `drive +inspect` 验证 |
| ❌ 产出缺量化 | 每项产出必须有量化，禁止编造 |
| ❌ 产出缺证据 | 飞书链接优先，无链接则本地路径 |
| ❌ 输出 Markdown 表格 | 飞书汇报是文本框，表格粘贴后散架 |
| ❌ 输出「粘贴到字段X」等标签 | 直接给三段纯文本，不加说明标签 |
| ❌ 发文件链接/本地超链接 | 皮玺玉不需要本地 file:// 链接 |
| ❌ Windows 用 find 递归 | Windows MSYS 下递归大目录触发 180s 超时，改用纯 Python os.walk |
| ❌ subprocess 扫描文件用 PowerShell Get-ChildItem | 中文文件名乱码，改用纯 Python os.walk + os.path.getmtime |
| ❌ PowerShell 用 && 管道 | PowerShell 5.1 不支持，改用 `;` 分隔或分行 |
| ❌ execute_code 工具在 Cron | Cron job 不支持 execute_code（subprocess 安全限制），改用 terminal |
| ❌ lark-cli --url 参数 | 飞书文档拉取用 `--doc`，不是 `--url` |
| ❌ 日报周报混同 | 日报只有「明日计划」，周报要「下周重点含工时+战略对齐+未完成说明」 |
| ❌ 汇报 API 缺 scope | 需要 `report:task:readonly`，缺时走设备授权流程（见 feishu-report-auth.md） |
| ❌ Cron job 模型漂移 | job 创建后模型变更会导致 job 被跳过，需重新 pin 或重建 job |
| ❌ lark-cli --url 参数 | 飞书文档拉取用 `--doc`，不是 `--url` |
| ❌ Python subprocess 参数列表调 lark-cli | lark-cli 是 npm .cmd 文件，`["lark-cli", ...]` 在 Python subprocess 列表模式中找不到。必须用完整路径 `C:\Users\Administrator\AppData\Roaming\npm\lark-cli.cmd`。用 `where.exe lark-cli` 获取实际路径。 |
| ❌ lark-cli IM 发送用 --text-file | 该参数不存在。用 `--markdown "<内容>"` 或 `--text "<内容>"`。长内容用 subprocess 参数列表传值（非 shell=True 拼接），避免引号嵌套。 |
| ❌ 本地文件扫描用 PowerShell subprocess | Windows subprocess 获取中文文件名会乱码（GBK→UTF-8）。改用纯 Python `os.walk()` + `os.path.getmtime()` 绕过编码问题。 |
| ❌ node_modules 污染本地文件扫描 | `D:\AI` 下 node_modules 有大量文件。扫描时必须在 `dirs[:]` 中过滤：`.git`/`node_modules`/`__pycache__`/`cache`/`image_cache`/`audio_cache`。 |
| ❌ `needs_refresh` 时重新发起授权 | `needs_refresh` 会在下次 API 调用时**自动刷新**，有 `offline_access` scope 的 token 7天有效。**不要因此扫码**，否则用户反复被打扰。只有 `token_missing` 或 `missing_scope` 才走授权流程。 |
| ❌ device_code 超时后继续用旧 code | device_code **10分钟**有效期，过期后 `lark-cli auth login --device-code` 返回 `authorization failed`。必须重新跑 `--no-wait --json` 生成新 code，用户授权后立刻接 `--device-code`，不能拖延。 |
| ❌ 应用待审批的 scope 反复授权 | `minutes:minute:download`、`search:message` 等高权限 scope 需要飞书管理员在开放平台审批才能用，用户扫码不解决问题。遇到 `"The app is pending approval"` 报错，应告知用户找管理员审批，不要继续重试。 |
| ❌ needs_refresh 时重新发起授权 | `needs_refresh` 是正常状态，下次 API 调用自动刷新，**不需要扫码**。只有 `token_missing` 或 `missing_scope` 才需重新授权。反复发起授权 = 用户被迫反复扫码，是操作失误 |
| ❌ 飞书版草稿有了还扫描重写 | 用户贴出飞书汇报系统生成的草稿时，应以飞书版为主体追加补充，不要用扫描版覆盖飞书版。飞书版含量化数据（条目数/逾期天数/协调时限）本机扫描拿不到 |
| ❌ 总览数字追加条目后不更新 | 追加条目后必须同步更新总览的总项数和🟢🟡🟠🔴各色计数，与实际条目数对齐 |
| ❌ 文档搜索使用 `--mine` | `--mine` 与 `--edited-since` 组合可能返回 0 条。使用 `--format json` 读取 `data.results`，再按 `result_meta.edit_user_name` 区分本人和团队产出。 |
| ❌ 不核实产出归属 | GitLab 查 `author`、会议查 `organizer`、任务查 `creator`；无法验证就写“归属待确认”，不能把团队成果算作个人成果。 |
| ❌ 系统消息当事件 | 群聊里「XX加入群聊」是系统消息，不是产出，不要写进日报 |
| ❌ 未扫 Wiki 空间 | 飞书 Wiki 里的产品文档、培训资料、技术文档不会出现在 `drive +search` 里，必须用 `wiki +space-list → wiki +node-list` 单独扫 |
| ❌ 忽略群聊消息中的最新决策 | 群聊是最快速的状态更新渠道。验收资料收到、采购走流程、优先级调整等决策优先出现在群聊，任务系统滞后。日报生成前必须先读产品部群当日消息 |
| ❌ 任务系统状态 ≠ 实际状态 | 飞书任务显示「已逾期」不代表真的阻塞，群聊里可能已经说「收到了」。以群聊最新消息为准 |
| ❌ 不该重复扫码授权 | `needs_refresh` 是正常状态，token 会自动刷新。看到 `needs_refresh` 不要发起新授权，只有 `missing_scope` 或 `token_missing` 才需要重新授权 |
| ❌ Cron no-agent 模式 lark-cli 无 token | lark-cli token 存在 Windows keychain，独立 Python 进程无法读取。必须用 agent 模式（去掉 --no-agent），让 Hermes agent 执行才有完整 lark-cli 上下文。 |
| ❌ python -c 内联多行脚本在 PowerShell 5.1 | `python -c "for i in items: print(...)"` 会触发 `ParseException: TerminatorExpectedAtEndOfString`，PS5.1 先解析引号导致语法错误。正确做法：写临时 `.py` 文件再执行，或用 `Start-Process python -ArgumentList @("-c", "...")` |
| ❌ 日报 SINCE_DT 用文件 LastWriteTime | 如果昨天日报文件今天被更新过（如补录内容），`LastWriteTime` 会偏移导致扫描窗口收缩。应用文件名中的日期派生：`SINCE_DT = datetime(int(filename[3:7]), int(filename[7:9]), int(filename[9:11])) + timedelta(days=1)` 或用文件 `CreationTime` |
| ❌ 本地文件扫描范围过大导致超时 | `Get-ChildItem -Recurse D:\AI` 遍历全盘超时（>30s）。限定扫描路径为 `D:\AI\AI产品工作`，同时排除 `.git`/`node_modules`/`sessions`/`__pycache__`/`cache` |
| ❌ token needs_refresh 时重新发起授权 | `needs_refresh` 状态会在下次 API 调用时**自动刷新**，不需要扫码。有 `offline_access` scope 的 refresh token 有效期7天。只有 token 真正过期或缺少 scope 时才需要重新授权。不要因为 needs_refresh 就发起新的 `auth login`，那会让用户反复扫码。 |
| ❌ 新 scope 触发重复授权 | 申请新 scope 前先用 `lark-cli auth status --json` 检查现有 scope 列表，很多 scope 已经在里面了（当前已有60+个）。确认真的缺少才走授权流程。 |
| ❌ lark-cli `needs_refresh` 误触授权 | `needs_refresh` 会在下次 API 调用自动刷新，有 `offline_access` 则 refresh token 有效期7天。直接继续用即可，**不要重新 `auth login`**，否则用户被迫反复扫码。 |
| ❌ device_code 超时后重用 | device_code 仅10分钟有效。用户确认授权后必须**立刻**执行 `auth login --device-code <code>`；不能同一轮先展示 URL 再阻塞执行——会超时作废。超时了直接重新 `--no-wait --json` 生成新码。 |
| ❌ lark-cli update 自动升级失败 | Windows 下 `lark-cli update` 因 postinstall 被拦截而失败。正确方式：`npm install -g --allow-scripts=@larksuite/cli @larksuite/cli@1.0.76` |
| ❌ 新申请的 scope 需管理员审批 | `minutes:minute:download` 和 `search:message` 是企业级权限，需管理员在飞书开放平台审批，扫码无法解决。 |
| ❌ 飞书汇报写入草稿 API | `report:task:write` scope 默认未授权。正确流程：Cron 生成草稿存本地 → IM 发三段完整内容给用户 → 用户自己复制到飞书汇报提交。 |
| ❌ 日报周报混同 | 日报只有「明日计划」，周报要「下周重点含工时+战略对齐+未完成说明」 |
| ❌ 汇报 API 缺 scope | 需要 `report:task:readonly`，缺时走设备授权流程（见 feishu-report-auth.md） |

---

## 三层汇报体系

```
每日 18:30 ──→ 日报（五源采集 → 三段草稿 → IM发送）
               ↓ 汇总
大周周五/小周周六 18:30 ──→ 周报（7天日报汇总 → 周报模板 → IM发送）
               ↓ 汇总
月末 28-31日 18:00 ──→ 月报（4-5周周报汇总 → 月报模板 → IM发送）
```

**Cron Jobs（当前已部署）：**
| 名称 | Schedule | 说明 |
|------|----------|------|
| 📋 日报草稿生成-皮玺玉 | `30 18 * * *` | 每日，agent模式 |
| 📅 周报-大周周五 | `30 18 * * 5` | 脚本判断大周才生成 |
| 📅 周报-小周周六 | `30 18 * * 6` | 脚本判断小周才生成 |
| 📊 月报 | `0 18 28-31 * *` | 月末 |

**大小周判断脚本：** `~/.hermes/scripts/should_generate_weekly_report.py`
- 本周工作日 ≥5 天 → 大周 → 周五生成
- 本周工作日 <5 天（含节假日）→ 小周 → 周六生成
- 当天是节假日 → 跳过

**2026年节假日：** 元旦(1/1)、春节(2/7-13)、清明(4/4-6)、劳动节(5/1-5)、端午(6/9-11)、中秋(9/15-17)、国庆(10/1-7)

---

## 周报模板（飞书汇报三字段）

**字段一：本周总结**
```
YYYY-W## 皮玺玉 | 工作日Nd | 总产出N项

📊 统计：🟢N 🟡N 🟠N 🔴N

📦 项目推进
[项目名] [阶段｜状态]
  本周完成：X项（列出关键产出）
  未完成：Y项（原因）
  完成度：XX%

🛠️ 工具基建 / 📐 流程制度（视情况）
  ...

📅 会议参与 N次
  🟢 [会议名] — 核心决议3条 | 行动项
```

**字段二：下周计划**
```
P0 任务（4h）
P0 任务（2h）
P1 任务（2h）
P2 任务（1h）
（总量控制在 15-16h 内）
```

**字段三：风险与协调**
```
🟡 风险项 → 负责人：说明，时限
🔴 阻塞项 → 负责人：说明，修正计划
```

---

## 月报模板（飞书汇报三字段）

**字段一：本月总结**
```
YYYY-MM 皮玺玉 | 工作日Nd | 总产出N项

📊 月度统计：🟢N(XX%) 🟡N 🟠N 🔴N

📦 各项目月度产出
[项目名] 月度完成度 XX%
  关键里程碑：...
  未达成：...（原因）
  下月目标：...

🔵 战略对齐检查
  OKR达成：...
  偏差项：...
```

**字段二：下月计划**
```
1. P0 里程碑目标（月度）
2. P1 重点任务
3. P2 常规迭代
```
⚠️ 每条前加序号（1. 2. 3. ...）

**字段三：需要协调**
```
1. 跨部门依赖 → 负责人，时限
2. 资源/权限需求 → 申请方向
```
⚠️ 每条前加序号（1. 2. 3. ...）

---

## 时间段对齐规则

**每次采集的时间范围 = 上次日报 MD 生成时间 → 本次运行时间**

```python
import os, glob, datetime

ARCHIVE_DIR = r"D:\AI\AI产品工作\汇报\daily"

def get_last_report_time():
    """读取上一次日报文件的生成时间，作为本次采集起始点"""
    files = sorted(glob.glob(os.path.join(ARCHIVE_DIR, "皮玺玉_*_日报.md")))
    # 排除今天的文件，取最近一份
    today_short = datetime.date.today().strftime("%Y%m%d")
    prev_files = [f for f in files if today_short not in f]
    if prev_files:
        mtime = os.path.getmtime(prev_files[-1])
        return datetime.datetime.fromtimestamp(mtime)
    # 没有历史文件，默认从今天00:00开始
    return datetime.datetime.combine(datetime.date.today(), datetime.time.min)

# 用于飞书采集的时间参数
SINCE_DT = get_last_report_time()
SINCE_STR = SINCE_DT.strftime("%Y-%m-%dT%H:%M:%S+08:00")  # 飞书 API 格式
SINCE_DATE = SINCE_DT.strftime("%Y-%m-%d")                 # 日期格式
```

**适用场景：**
- Edge 历史查询：`WHERE last_visit_time > SINCE_TS`
- 飞书文档搜索：`--edited-since` 参数改为具体时间戳
- 本地文件扫描：`mtime >= SINCE_DT`（替换原来的 `TODAY_DT`）
- Hermes sessions：按文件 mtime >= SINCE_DT 过滤

---

## 五源采集说明（v3.0）

Cron 脚本 `daily-report-cron.py` 自动采集五个来源：

| 来源 | 内容 | 备注 |
|------|------|------|
| 飞书 | 日程/任务/文档/妙记/审批 | 需 LARK_CLI_WORKSPACE=hermes，keychain token 限制见下 |
| 本地文件 | `D:\AI` 下今日修改的所有文件 | 纯 Python os.walk，无编码问题 |
| Edge 浏览器 | 今日访问记录（标题+URL） | 复制 SQLite History 文件读取 |
| Hermes sessions | 今日会话中 user 消息 | 读 sessions/*.json |
| Git | Mozin 项目 pull 状态 | `git -c http.proxy=` 绕过内网代理 |

**飞书 token 在 Cron 环境的限制：**
- lark-cli token 存在 Windows keychain，Cron 独立 Python 进程无法读取
- 解决方案 A（推荐）：改用 `hermes cron create` 的 agent 模式（去掉 `--no-agent`），让 Hermes agent 执行，agent 有完整 lark-cli 上下文
- 解决方案 B：用 lark-cli 导出 token 到文件，在脚本中注入（需要定期刷新）

**Edge 历史读取方式：**
```python
import sqlite3, shutil, datetime
src = os.path.expandvars(r'%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\History')
tmp = r'C:\Windows\Temp\edge_hist_daily.db'
shutil.copy2(src, tmp)  # Edge 运行时锁定原文件，必须复制
conn = sqlite3.connect(tmp)
epoch = datetime.datetime(1601, 1, 1)  # Edge 时间戳从 1601-01-01 起
today_ts = int((TODAY_DT - epoch).total_seconds() * 1_000_000)
rows = conn.execute('SELECT title, url FROM urls WHERE last_visit_time > ?', (today_ts,))
```

## Cron 定时说明

**日报 job（每天 18:30）流程：**
```
脚本 daily-report-cron.py 执行：
  1. Git sync（Mozin 项目）
  2. 飞书采集：日程 + 任务 + 今日文档 + 妙记
  3. 本地文件扫描
  4. **存档**：`D:\\AI\\AI产品工作\\汇报\\daily\\皮玺玉_YYYYMMDD_日报.md`
  5. **飞书IM**：Python subprocess 调用 `node run.js`（不是 lark-cli.cmd！），`ensure_ascii=False`，卡片 body 直接从 MD 内容生成（不精简）
  6. **技能站同步**：修改技能后执行 `cmd /c "同步技能站.cmd"`（D:\AI\AI产品工作\技能\）
     → 用户看 IM，复制三段内容到飞书汇报，修改后手动提交
```

- **周报：** 大周周五 / 小周周六 18:30 触发（should_generate_weekly_report.py 判断大小周）
- **月报：** 每月 28-31 日 18:00 触发
- Cron 无交互，脚本直接运行（--no-agent 模式），用 lark-cli 完整路径调用
- lark-cli 完整路径：`C:\Users\Administrator\AppData\Roaming\npm\lark-cli.cmd`
- 详见 `scripts/daily-report-cron.py`

---

## 飞书 scope 清单（已验证）

| scope | 用途 | 状态 |
|-------|------|------|
| `im:message` | 发送 IM 消息 | ✅ |
| `im:message.send_as_user` | 以用户身份发消息 | ✅ |
| `calendar:calendar` | 读日程 | ✅ |
| `task:task:readonly` | 读任务 | ✅ |
| `drive:drive:readonly` | 搜索文档 | ✅ |
| `docx:document:readonly` | 读文档大纲 | ✅ |
| `minutes:minute:readonly` | 搜索妙记列表 | ✅ |
| `minutes:minute:download` | 读妙记正文/转录 | ⚠️ 需授权 |
| `minutes:minutes.transcript:export` | 导出妙记转录 | ⚠️ 需授权 |
| `search:message` | 搜索消息 | ⚠️ 需授权 |
| `report:task:readonly` | 读飞书汇报历史 | ⚠️ 需授权 |
| `report:task:write` | 写飞书汇报草稿 | ❌ 暂不申请 |

**一次性补全命令：**
```bash
lark-cli auth login --scope "minutes:minute:download minutes:minutes.transcript:export search:message report:task:readonly" --no-wait --json
```

**妙记命令正确用法（v1.0.69+）：**
```bash
# ❌ 错误：--minute-id
# ✅ 正确：--minute-tokens
lark-cli minutes +detail --minute-tokens <token> --as user
```

---

## 打包分发给团队成员

skill 包路径：`D:\\AI\\hermes\\runtime\\skills\\daily-report-mozin`（技能站同步副本：`D:\\AI\\AI产品工作\\技能\\skills\\04-文档数据与汇报\\daily-report-mozin`）

**三种发送方式：**
1. **zip 打包发飞书**：
   ```powershell
   $src = "D:\\AI\\hermes\\runtime\\skills\\daily-report-mozin"
   Compress-Archive -Path "$src\\*" -DestinationPath "daily-report-mozin-pxy.zip" -Force
   # ⚠️ Compress-Archive 会包含 .git 目录，接收方解压后删掉 .git 即可
   ```
   收件人解压到 `~/.hermes/skills/productivity/daily-report-mozin/` 即可生效

**查同事 open_id（2026-08-11 验证）：**
```bash
lark-cli contact +search-user --query "姓名" --as user
# 返回: open_id (ou_xxx) + p2p_chat_id (oc_xxx) + 部门 + 企业邮箱
# 例：lark-cli contact +search-user --query "易安" --as user
# 例：lark-cli contact +search-user --query "张镭橙" --as user
```

**同事 open_id 速查表（2026-08-11 确认）：**

| 同事 | 部门 | open_id |
|------|------|---------|
| 张镭橙 | Mozin-产研中心 | ou_bfa415470e9283f50ef5e09829a76615 |
| 易安 | Mozin-产研中心 | ou_e52e487e653c41560ee9adaf13953b69 |
| 马祖曦 | Mozin-产研中心 | ou_06eb953a09dc20e98d9ac3cbfa1d9dfa |

> 其他同事先用 `+search-user` 查，查到后回填此表。

**技能包 zip 发给同事（2026-08-11 验证）：**
- ⚠️ `--file` 不能与 `--text`/`--markdown`/`--content` 同用（报 `--image/--file/--video/--audio cannot be used with --text`）——必须**分两条消息**：先发文件，再发说明文字
- ⚠️ `--file` 用 cwd 相对路径（绝对路径被拒绝），先 `cd` 到 zip 所在目录
```python
# 先发文件
["node", LARK_JS, "im", "+messages-send", "--as", "bot",
 "--user-id", UID, "--file", "mozin-daily-report-skill-v4.6.zip"]
# 再发说明
["node", LARK_JS, "im", "+messages-send", "--as", "bot",
 "--user-id", UID, "--text", "📦 Mozin 日汇报技能包 v4.6 ... 解压到 Hermes skills 目录即可使用"]
```
2. **GitHub 链接**：`https://github.com/pipykarchu/work`（直接 clone）
3. **Gitea 正式仓库（当前主仓库）**：`http://120.237.89.124:8929/rd-center/org-mag-sup/mozin-daily-report`（2026-08-11 用户指定）
   - 旧仓库（历史参考）：`http://192.168.0.102:8929/modaipeng/mozin-daily-report` → `pxy` 分支

**打包 push 到 Gitea 流程（2026-08-11 验证）：**
```powershell
cd "D:\\AI\\AI产品工作\\技能\\skills\\04-文档数据与汇报\\daily-report-mozin"
git init
git config user.name "皮玺玉"; git config user.email "pxy@mozin.io"
# 更新 README.md（版本号/安装/使用/变更记录）
git add -A; git commit -m "feat: mozin-daily-report v4.6 日汇报技能包（日报/周报/月报）"
git remote add origin http://120.237.89.124:8929/rd-center/org-mag-sup/mozin-daily-report.git
git push -u origin master
```
- ⚠️ HTTP push 需先：`git config --global http.sslVerify false` + `git config --global http.unsafeRemotes true`
- ⚠️ 首次 push 需要 Gitea 凭据（用户名+密码或 access token，Gitea → 设置 → 应用 → 生成 token 勾选 write:repository）；凭据不在 Windows 凭据管理器时需向用户索取
- ⚠️ 禁止把 token/密钥写入 README 或任何提交文件

**向莫总仓库贡献更新（已配置 remote）：**
```bash
# remote 已添加，直接 push
git -c http.proxy= push mozin-boss master:pxy
# Gitea MR 链接：.../mozin-daily-report/-/merge_requests/new?merge_request[source_branch]=pxy
```

**同步三端（Gitea 新仓库 + GitHub + 莫总仓库）：**
```powershell
# 主仓库（2026-08-11 起）：http://120.237.89.124:8929/rd-center/org-mag-sup/mozin-daily-report
# 凭据已用 cmdkey 存入 Windows 凭据管理器（pixiyu@mozin.ai + token），push 免认证
cd "D:\AI\AI产品工作\技能\skills\04-文档数据与汇报\daily-report-mozin"
git add .; git commit -m "feat: ..."
git push origin master   # HTTP 免认证直接推
git push github master       # 若 rejected 先 pull --no-edit 再 push
git -c http.proxy= push mozin-boss master:pxy
```
⚠️ 主仓库 remote 用 HTTP 不用 SSH（SSH 2222 端口公网不通）；token 有效期 1 年，到期重新 cmdkey 更新。

**Gitea 凭据一次性配置（2026-08-11 用户要求"以后都不想这么麻烦"，已配置完成）：**

1. 用户在 Gitea 生成 access token：设置 → 应用 → 管理访问令牌 → 生成新令牌 → 勾选 `write:repository`（⚠️ 不是"新建 OAuth2 应用"，那个才要 Redirect URI，普通 token 不需要）
2. 存入 Windows 凭据管理器（git 自动读取）：
   ```powershell
   cmdkey /generic:git:http://120.237.89.124:8929 /user:pixiyu@mozin.ai /pass:TOKEN
   ```
3. 写入 `~/.git-credentials`（所有 git 客户端共享，含 Codex/Reasonix）：
   ```powershell
   git config --global credential.helper store
   git config --global http.sslVerify false
   git config --global http.unsafeRemotes true
   # 然后执行一次 git fetch/push 触发 store 自动写入 .git-credentials
   ```
4. 让 Codex/Reasonix 的 agent 也免询问：把"Gitea 凭据已配置，直接 git 操作勿问密码"写进
   - Codex：`C:\Users\皮玺玉\.codex\AGENTS.md`
   - Reasonix：`D:\AI\AI产品工作\牧之音\Mozin 产品研讨中心\1.5版（耳机MVP）\AGENTS.md`
5. token 过期重配：重新生成 token → 重新执行步骤 2 的 cmdkey 即可（30 秒）

⚠️ 禁止把 token/密钥写入 README 或任何提交文件；memory 只存"已配置"事实不存原始 token。

---

## 飞书汇报 scope 检查

```bash
# 检查是否有 report:task:readonly
lark-cli auth status | grep -o report:task:readonly

# 不含时发起设备授权
lark-cli auth login --scope "report:task:readonly" --no-wait --json
# 用户授权后完成
lark-cli auth login --device-code "<device_code>"
```

---

## 飞书汇报 API 拉取日报（周报数据源）

**周报数据必须来自飞书汇报系统最终发布的日报，不能凭空编写。**

API: `POST /open-apis/report/v1/tasks/query`
- 身份: `--as user`
- 参数: `commit_start_time`, `commit_end_time`（Unix 时间戳）, `page_token`（首次传空字符串）, `page_size`（≤20）
- 返回: `items[].form_contents[]` 含 field_name（今日总结/明日计划/需要协调与帮助）和 field_value
- 注意: 补交日报的 commit_time 在补交当天，不在日报标题日期。需用 field_value 内容中的日期匹配目标周。
- 权限: `report:task:readonly`

Python 调用示例:
```python
import subprocess, os, json, datetime
env = os.environ.copy()
env['LARK_CLI_WORKSPACE'] = 'hermes'
LARK = r'C:\Users\皮玺玉\AppData\Roaming\npm\lark-cli.cmd'
body = json.dumps({'commit_start_time': start_ts, 'commit_end_time': end_ts, 'page_token': '', 'page_size': 20})
r = subprocess.run([LARK,'api','POST','/open-apis/report/v1/tasks/query','--as','user','--data',body],
    capture_output=True, text=True, timeout=30, env=env, encoding='utf-8', errors='replace')
data = json.loads(r.stdout)
items = data.get('data',{}).get('items',[])
```

---

## 内容一致性铁律

### 飞书卡片发送核心规则（2026-08-05 定稿）

**必须用 `node run.js` 直调，绝不能用 `lark-cli.cmd`！**

```python
LARK_JS = r"C:\Users\皮玺玉\AppData\Roaming\npm\node_modules\@larksuite\cli\scripts\run.js"
UID = "ou_7d05b327389c521f51426312ac5c9e2b"
env = os.environ.copy()
env["LARK_CLI_WORKSPACE"] = "hermes"

content_str = json.dumps(card, ensure_ascii=False)  # UTF-8原文传参
r = subprocess.run(
    ["node", LARK_JS, "im", "+messages-send", "--as", "bot",
     "--user-id", UID, "--msg-type", "interactive", "--content", content_str],
    capture_output=True, text=True, timeout=30,
    encoding="utf-8", errors="replace", env=env)
```

**为什么 .cmd 必败：**
- lark-cli.cmd 经过 cmd.exe 处理参数
- `ensure_ascii=True` 产生 `\uXXXX`，反斜杠被 cmd.exe 误解为路径分隔符 → "The system cannot find the path specified"
- 4字节 emoji（🟢🟡📋📊🤝）在 ensure_ascii=True 时产生 surrogate pairs → lark-cli JSON parser 拒绝
- `ensure_ascii=False` + .cmd 也被 cmd.exe 的 `%*` 参数展开搞坏 → "not valid JSON"

**用 node run.js 的优势：**
- Python subprocess 直接传参给 Node.js 进程，无中间 cmd.exe 层
- `ensure_ascii=False` UTF-8 直传，emoji 和中文全部正常，无长度限制
- 验证：1300+ 字符中文+emoji 卡片一次发送成功

**⚠️ 陷阱：** .cmd 短内容（<200字 ASCII）碰巧成功——不要被短测试误导！

### 发送命令（v1.0.76+）

**lark-cli 版本命令可用性**（v1.0.76 验证）：
- ✅ `im +messages-send` — 发送消息（正确命令）
- ❌ `im send` — 不存在
- ❌ `report` — 不存在（需 ≥1.0.84）
- 管道输入 `.cmd` 中文长内容必败，必须用 `node run.js` 方式

发送代码模板：
```javascript
// C:\Windows\Temp\send_report.js
const { execFileSync } = require('child_process');
const path = require('path');
const larkDir = path.join(process.env.APPDATA, 'npm', 'node_modules', '@larksuite', 'cli');
const runJs = path.join(larkDir, 'scripts', 'run.js');
const args = ['im', '+messages-send', '--chat-id', 'oc_3eab57d10ba96dbfbc6a19818a4d2b02', '--markdown', mdContent];
execFileSync('node', [runJs, ...args], { encoding: 'utf8', timeout: 15000, env: { ...process.env, LARK_CLI_WORKSPACE: 'hermes' } });
```

### 飞书 IM 总览模块样式

飞书 IM 不渲染 Markdown 表格，总览模块用全角空格对齐的纯文本列表：

```
📊 今日工作总览
　　　　　　　　　　产出数　🟢 正常　🟠 待补　🟡 待决　🔴 阻塞
1. [项目名]　　　　　🟢xN
2. [项目名]　　　　　🟢xN 🟠xN
3. [项目名]　　　　　🟢xN 🟡xN
合计：X项 | 🟢xN | 🟠xN | 🟡xN | 🔴xN
```

每行只列有值的状态（零值不显示），紧凑易读。

MD 存档文件仍可用 Markdown 表格（6列：项目/产出数/🟢正常/🟠待补/🟡待决/🔴阻塞）。

### 卡片格式与本地MD一致性

**"重新生成"的定义**：当用户说"重新生成周报/月报"时，必须同时：
1. **从飞书汇报系统拉取权威日报数据**（report API query，见 references/feishu-report-api-query.md）
2. **重写 MD 文件**（覆盖旧文件，内容完全替换）
3. **重新发送飞书消息**（内容 = MD 文件正文，一字不差）

**数据源优先级（铁律）**：
- ✅ 飞书汇报系统最终发布的日报（report API） — 唯一权威来源
- ❌ 智能体发到飞书 IM 的卡片消息 — 不是最终版
- ❌ 本地 daily/ 目录的 MD 文件 — 不是最终版
- ⚠️ 如果 report API 查不到对应日期的日报，主动告知用户并请求补充

MD 文件和飞书消息永远是同一份内容的两个投递渠道，不存在"只更新一边"的情况。周报、月报都遵守此规则。

---

## 飞书发送格式规则（2026-08-03 验证）

**发送目标："皮玺玉的飞书 CLI" 智能体**
- chat_id: `oc_3eab57d10ba96dbfbc6a19818a4d2b02`
- 发送身份：`--as bot`（必须！user 身份发的消息在该对话里看不到）

**唯一推荐格式：卡片消息（interactive）**

其他格式问题：
- `--markdown`：长内容被折叠成只显示标题的卡片，看不到正文 ❌
- `--text`：在该智能体对话里也看不到内容 ❌

**卡片 JSON 结构：**
```python
card = {
    "config": {"wide_screen_mode": True},
    "header": {"title": {"tag": "plain_text", "content": title}, "template": "blue"},
    "elements": [{"tag": "div", "text": {"tag": "lark_md", "content": body}}]
}
# 调用：--as bot --user-id UID --msg-type interactive --content json.dumps(card)
```

**卡片内日报 body 格式（学习土豆智能体风格）：**
```
姓名：皮玺玉 ｜ 工时：8h

📊 今日工作总览
1. 公司文化学习　　🟢x1
合计：1项 | 🟢x1

> ⚠️ 飞书IM发送时总览必须用纯文本列表+全角空格对齐（不用表格列，飞书IM表格渲染差）。
> 格式：序号. 项目名　　🟢xN 🟠xN
> 末行：合计：N项 | 🟢xN | 🟠xN

---

**🔸 项目名**
🟢 完成事项 ✅
- 量化：具体数字/成果
- 证据：相关证明
- 下一步：计划

**📋 明日计划**
1. P0 关键任务
2. P1 重要任务

**🤝 需要协调与帮助**
1. 事项 → 谁：具体需求（时限）

**⚠️ 风险标记**
- 🟡 风险项 — 影响或改善计划
```

**关键规则：**
1. 飞书卡片内容必须和本地 MD 存档**完全一致**（量化、进展、证据、下一步一个不少）
2. 工作总览用**全角空格（　）**对齐列，不用 markdown 表格（飞书卡片不渲染表格）
3. 工作总览项目前加**序号**（1. 2. 3. ...），方便快速定位
4. 每条事项必须包含：量化/进展/证据/下一步（至少2项）
5. 每条事项标题前也加**圈序号**（①②③...），全局递增编号，格式：`①🟢 事项标题 ✅`

**土豆智能体（产品搭档）：**
- 名称：土豆
- 功能：每日自动生成待办摘要（飞书日程+未完成任务+优先级建议）
- 局限：无法通过 lark-cli 直接发消息（不是普通群聊，chat-search 搜不到）
- 协作方式：日报生成后发到"皮玺玉的飞书 CLI"，用户可手动转发给土豆纠正过时信息
- 土豆的待办信息可作为日报的**输入源之一**：如果用户提到"土豆说的任务"或"今天待办"，参考土豆的待办列表补充日报内容

## 快速参考

- **补交多天日报场景**：用户口述多天内容时，逐天生成独立文件，然后用 Python 脚本循环发送飞书（一次 subprocess 调用/天），标题加 `**补交日报 · YYYY-MM-DD**` 前缀
- 不需要先问用户确认，直接生成→展示→用户说"发"→批量发送

| 用户说 | 动作 |
|--------|------|
| "写日报" / "日报" | 预览模式，生成后确认输出 |
| "写日报 --auto" | 自动采集，直接出结果 |
| "写周报" / "周报" | 周报预览模式 |
| "写周报 --auto" | 自动采集周报 |
| "日报更新了，..." | 手动输入，执行完整 Step 1-6 |
| "明天休假，今天先做周报" | 周报模式，日期范围截止今天，立即执行，不等大小周正常时间 |
| "日报更新了，周报也更新" | **局部 diff 模式**：读最新日报 → diff 上版 → patch 周报 → 重发飞书（标题加「更新版/最终版」） |

---

## 周报迭代更新（日报有变动时）

> 适用场景：周报已发出，当天日报又有新增/修改内容。

**核心原则：局部 patch，不重写整份周报。**

### 步骤

1. **读取最新日报**，与上次生成周报时用的版本对比（重点看：新增条目、已有条目描述是否扩充/拆分）
2. **只 patch 变化部分**，用 `patch(mode='replace')` 精确替换，其他内容不动
3. **总览计数同步更新**（如某条目拆为2条，🟢数+1，总项数+1）
4. **重发飞书时标题加版本标记**，让收件人区分批次：
   - 第1次更新：`周报（更新版）· 2026-W##`
   - 最终确认：`周报（最终版）· 2026-W##`
5. **飞书消息只体现变化的模块**，不重复粘贴未变内容

### 常见 diff 场景

| diff 类型 | 处理方式 |
|-----------|----------|
| 某条目从"1个"变"N个"，描述扩充 | patch 对应行，扩充描述，总览计数不变 |
| 某条目拆成2条 | patch 替换原条目为2条，总览🟢+1、总项数+1 |
| 新增条目 | 在对应项目块末尾追加，总览计数+1 |
| 条目状态变化（🟡→🟢） | patch 对应行颜色和描述 |

## 周报从日报归并的执行路径（2026-07-24 验证）

1. 确认本周日报存档目录：`D:\AI\AI产品工作\汇报\daily\`，列出当周所有 `皮玺玉_2026072*_日报.md`
2. 读取每天日报（4份），提取「今日总结」字段中所有带 🟢🟡🟠🔴 的条目
3. 按项目维度合并（Mozin 2.0 / 1.5 / 协作平台 / 工具基建 / 流程制度 / 行政事务）
4. 同步拉本周 Git log（`git log --oneline --since=<周一>`）补充研发产出
5. 生成飞书三字段格式周报，写入 `皮玺玉_YYYY_W##_周报.md`
6. 用 Python subprocess 调用 lark-cli 发飞书 IM（见 `references/lark-cli-im-send-long-content.md`）
7. 飞书发送成功返回 `"ok": true` + `message_id`，完成闭环

⚠️ 周报 IM 发送遵循**内容一致性铁律**：飞书消息内容 = MD 文件正文（分段发送，每段 ≤1100 字符）。详见 `references/weekly-send-split-pattern.md`。

---

## 📚 参考文件

- `references/kiro-execution-patterns-with-pxy.md` — **必读**: Kiro 与皮玺玉的协作模式（即时验证、清理临时文件、直言问题，2026-08-31）
- `templates/mozin-daily-report-template.md` — 日报模板（快速复用）
- `templates/mozin-weekly-report-template.md` — 周报模板（新增）
- `references/feishu-im-format.md` — 飞书IM消息格式规范
- `references/date-sync-pitfall.md` — 日期一致性检查陷阱
- `references/feishu-sources.md` — lark-cli 命令速查（来自莫总 skill）
- `references/feishu-report-auth.md` — 飞书汇报API授权流程（来自莫总 skill）
- `references/doc1-spec.md` — 产品部日报周报规范摘要（五色+量化）
- `references/doc2-sop.md` — 交付全流程SOP阶段映射（来自莫总 skill）
- `references/edge-history-collection.md` — Edge 浏览器历史 SQLite 采集方法（时间戳格式、复制锁定、过滤建议）
- `references/lark-cli-windows-subprocess.md` — lark-cli 在 Windows Python subprocess 中的正确调用方式（完整路径、参数列表、--markdown 传长内容）
- `references/lark-cli-upgrade-and-auth.md` — lark-cli 升级流程（手动方法）、device_code 授权 10 分钟限时、scope 完整清单（2026-07-23 验证）
- `references/lark-cli-im-send-long-content.md` — Python subprocess 发送长 markdown 内容，避免 shell 特殊字符被解析为位置参数
- `references/lark-cli-messages-send-node.md` — **必读**：lark-cli 1.0.76+ 正确命令是 `im +messages-send`（非 `im send`），支持 `--markdown` 参数，必须通过 `node run.js` 调用避免 .cmd 中文截断（2026-08-07 验证）
- `references/lark-cli-im-send-long-content.md` — **必读**：node run.js 绕过 .cmd 中文长度限制；lark-cli 1.0.76+ 正确命令是 `im +messages-send --markdown`（不是 `im send`），2026-08-07验证可用
- `references/feishu-card-format-verified.md` — **必读**：卡片消息格式规范（圈序号①②③+全角空格对齐+lark_md支持范围，2026-08-03验证）
- `references/feishu-card-send-validated.md` — 完整 Python 发送代码 + 排错路径全记录（4种方式对比）
- `references/d-drive-acl-fix.md` — D盘重装后ACL修复（takeown+icacls，含PS5.1引号pitfall）
- `references/d-drive-acl-and-git-recovery.md` — D盘ACL修复 + Git .git目录丢失恢复（shallow clone移植法）
- `references/feishu-card-message-format.md` — 卡片消息完整格式规范（card JSON结构+body格式+土豆协作，2026-08-03验证）
- `references/feishu-group-chats.md` — 产品部群 chat_id 速查 + 群聊优先于任务系统的典型场景
- `references/cron-weekly-schedule-unified-18-30.md` — **必读**：大小周判断、统一 18:30 时间、cron 配置模式、脚本执行陷阱防护（2026-08-31 验证）
- `references/cron-script-execution.md` — **必读**：Hermes cron 脚本执行原理 + 陷阱防护 + 验证步骤（2026-08-03 踩坑记录，解决 `invalid choice` 错误）
- `references/multiuser-auto-detection-pattern.md` — **必读**：多用户自动检测通用模式（v2.1）、`get_current_lark_cli_user()` 函数完整代码、异常处理、衍生应用（2026-08-31 新增，可在任何需要感知当前用户的工具中复用）
- `references/python-stringjoin-generator-pitfall.md` — Python `"\n".join()` 中的生成器表达式陷阱、再现脚本、显式构建-连接分离模式（2026-08-31 新增，避免常见的字符串构建错误）
- `references/feishu-report-api-query.md` — **必读**：飞书汇报 API（POST /open-apis/report/v1/tasks/query）完整调用方式、皮玺玉 rule_id/字段映射、Python 代码、数据源优先级铁律（2026-08-04 验证）
- `references/weekly-send-split-pattern.md` — **必读**：周报分段发送完整 Python 代码（≤1100字符/段 + 特殊字符替换 + 二次切分降级，2026-08-04 验证通过）
- `references/lark-cli-subprocess-pitfalls-2026-08-07.md` — **必读**：subprocess + lark-cli api 调用的 PATH 解析陷阱、JSON 参数转义问题、工作流程 fallback 模式（发送失败时用本地存档+手动飞书，2026-08-07 踩坑记录）
- `references/feishu-api-lark-cli-version-pitfall.md` — **必读**：lark-cli v1.0.76 参数转义陷阱 + 升级方案 + 文件参数稳定传递 + 降级到本地存档流程（2026-08-07 踩坑记录，避免多轮 API 调试）
- `references/lark-cli-api-send-pitfalls-20260807.md` — **必读**：日报发送失败的 4 种根本原因（npm PATH、JSON 转义、UTF-8 编码、参数格式）+ 3 个 Fallback 方案（汇报 API + @file | 本地存档+手动 | Node.js SDK）+ 调试技巧（2026-08-07 新增，解决多轮发送失败）
- `references/pxy-format-ironrules-2026-08-10.md` — **必读**：皮玺玉日报格式铁律（🟢xN 总览格式、P2P 发自己不发群、node run.js 发送方式、证据链必须、电脑扫描5源采集流程，2026-08-10 用户多次纠正固化）
- `references/skill-distribution-and-gitea-push-2026-08-11.md` — **必读**：技能包 zip 分发给同事（contact +search-user 查 open_id、--file 不能与 --text 同用需分两条消息、node run.js 直调）与 Gitea push 全流程（http.unsafeRemotes 配置、凭据获取）
