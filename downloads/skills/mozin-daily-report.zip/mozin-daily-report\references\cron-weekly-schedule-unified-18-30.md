# 周报 Cron 定期配置（统一时间 18:30）

> 2026-08-31 验证：大周周五 + 小周周六 均改为 18:30，与日报同步，简化用户心智

---

## 大小周判断逻辑

**定义**:
- **大周**: 本周工作日（周一～周五，不含节假日）≥ 5 天
- **小周**: 本周工作日 < 5 天
- **节假日**: 2026 年国家法定假期自动检测，自动跳过

**示例（2026 年）**:
```
8月第1周（8/3-8/9）   ← 大周（5 个工作日）→ 周五 8/8 不生成（今天是周日）
8月第2周（8/10-8/16）  ← 大周 → 周五 8/15 生成 ✓
10月第1周（10/1-10/7） ← 小周（节假日 10/1-10/7）→ 周六 10/9 或 10/10 生成
```

---

## 统一时间方案（改进版，2026-08-31）

### 之前的问题

```bash
# ❌ 旧配置（不同步）
大周周五 18:30  → 周报
小周周六 09:00  → 周报
```

**问题**: 
- 用户需要记住两个时间点
- 与日报 18:30 不一致，容易混淆
- 周六 09:00 时间过早，用户很难及时处理

### 改进后的方案

```bash
# ✅ 新配置（统一 18:30）
大周周五 18:30  → 周报 + 飞书通知
小周周六 18:30  → 周报 + 飞书通知
```

**优势**:
- ✅ 与日报时间一致（都是 18:30）
- ✅ 用户心智模型清晰（每天都是 18:30 时间检查）
- ✅ 飞书通知统一时段，避免信息碎片化
- ✅ 周六下午 18:30 时间合理（周末工作回顾）

---

## Cron 配置命令（2026-08-31 验证）

### 大周周五 18:30

```bash
hermes cron create "30 18 * * 5" \
  "📋 周报生成-大周周五 18:30" \
  --model claude-haiku-4-5-20251001 \
  --provider custom:api-aicodewith-com \
  --skill daily-report-mozin \
  --script weekly-report-cron.py \
  --deliver feishu \
  --workdir "D:\AI\AI产品工作\汇报"
```

**Job ID** (示例): `67b8cf4f47c0`

### 小周周六 18:30

```bash
hermes cron create "30 18 * * 6" \
  "📋 周报生成-小周周六 18:30" \
  --model claude-haiku-4-5-20251001 \
  --provider custom:api-aicodewith-com \
  --skill daily-report-mozin \
  --script weekly-report-cron.py \
  --deliver feishu \
  --workdir "D:\AI\AI产品工作\汇报"
```

**Job ID** (示例): `5c9d5330920e`

---

## 脚本执行模式（重要 Pitfall）

### ❌ 错误做法

```bash
# 直接传脚本名给 hermes 命令
hermes should_generate_weekly_report.py  # ← hermes 试图把脚本路径当作子命令解析
# 结果: argument command: invalid choice: '...\should_generate_weekly_report.py'
```

### ✅ 正确做法

**方式 A: 让 Hermes cron 系统自动定位脚本**
```bash
--script weekly-report-cron.py  # Hermes 自动在 ~/.hermes/scripts/ 查找
```

**方式 B: 独立 Python 执行验证（推荐用于测试）**
```python
import subprocess
result = subprocess.run(
    [sys.executable, str(SCRIPT_PATH)],  # 完整路径 + python 解释器
    capture_output=True,
    text=True,
    timeout=5
)
```

**为什么 B 胜过 exec()？**
- ✅ 隔离命名空间（不污染当前进程）
- ✅ 真实执行环境（环境变量、stdin/stdout 独立）
- ✅ 超时控制与异常隔离
- ✅ 便于调试（能捕捉 stderr）

---

## 时间范围格式（周报文件）

**文件名**:
```
皮玺玉_YYYY_W##_周报.md
例: 皮玺玉_2026_W35_周报.md
```

**文件内容（第 1-4 行）**:
```markdown
# 周报 · W35 · 2026-08-27 ~ 2026-08-31

**汇报人**: 皮玺玉  
**时间周期**: 2026-08-27 ~ 2026-08-31（第35周）  
**提交日期**: 2026-08-31
```

**关键**:
- ✅ 标题中含时间范围（MM-DD ~ MM-DD）
- ✅ 第二行含完整 ISO 周期 + 周编号
- ✅ 便于飞书卡片消息显示

---

## 国家节假日 2026（完整列表）

```python
HOLIDAYS_2026 = {
    "single": [
        (1, 1),      # 元旦
        (4, 4),      # 清明
        (6, 9),      # 端午
        (9, 15),     # 中秋
    ],
    "range": [
        ((2, 7), (2, 13)),   # 春节
        ((4, 4), (4, 6)),    # 清明（包括清明本身）
        ((5, 1), (5, 5)),    # 劳动节
        ((6, 9), (6, 11)),   # 端午
        ((9, 15), (9, 17)),  # 中秋
        ((10, 1), (10, 7)),  # 国庆
    ]
}
```

---

## 验证与测试

### 脚本功能验证

```bash
# 在任何日期运行脚本，查看是否应该生成周报
python D:\AI\hermes\Hermes Agent CN Desktop\data\hermes-home\scripts\weekly-report-cron.py

# 输出例（如果今天是大周周五）
# ✅ 大周周五，生成周报
# exit code: 0

# 输出例（如果今天不是周报生成日期）
# ⏭️  今天不是周报生成日期 (大周Tue，需要周五)
# exit code: 1
```

### Cron 作业验证

```bash
# 列出所有周报 cron 任务
hermes cron list | grep "周报生成"

# 预期输出
# Name: 📋 周报生成-大周周五 18:30
# Schedule: 30 18 * * 5
# Next run: 2026-08-08T18:30:00+08:00
#
# Name: 📋 周报生成-小周周六 18:30
# Schedule: 30 18 * * 6
# Next run: 2026-08-09T18:30:00+08:00
```

### 启动自动执行

```bash
hermes gateway install
# Hermes cron 系统现在会在大周周五 18:30 和小周周六 18:30 自动触发
```

---

## 常见问题

| 问题 | 答案 |
|------|------|
| 周六 18:30 太晚了怎么办？ | 可改为周六 09:00，但需保持与日报时间一致的原则考虑 |
| 假期前一天（如 9 月 30 日）会生成吗？ | 否，该周工作日不足 5 天，自动识别为小周，延后到周六 10/10 |
| 能同时发给多个人吗？ | 可在飞书卡片消息中指定多个 user_id，或发到群聊 |
| 如何手动触发一次？ | `hermes cron run <job_id>` 或直接执行 Python 脚本 |

---

## 参考

- 脚本实现: `scripts/weekly-report-cron.py`
- 大小周判断脚本: `scripts/should_generate_weekly_report.py`
- 飞书消息格式: `references/feishu-im-bot-card-send.md`
