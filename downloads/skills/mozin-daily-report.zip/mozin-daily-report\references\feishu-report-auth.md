# 飞书汇报 API — 授权与调用

## 所需 Scope

`report:task:readonly` — 查询汇报任务记录

## 授权流程

1. 检查当前 scope 是否已包含：
   ```powershell
   lark-cli auth status
   # 找输出中是否有 report:task:readonly
   ```

2. 如不含，发起设备授权（生成授权链接）：
   ```bash
   lark-cli auth login --scope "report:task:readonly" --no-wait --json
   ```
   返回 `verification_url` + `device_code`。

3. 用户打开链接授权后，完成授权：
   ```bash
   lark-cli auth login --device-code "<device_code>"
   ```

> ⚠️ 授权需要在飞书开放平台中将 `report:task:readonly` 权限添加到应用后再操作。
> ⚠️ `lark-cli auth login` 是阻塞命令，用 `--no-wait --json` 分离展示步骤和完成步骤。

## 查询日报/周报记录

```bash
lark-cli api POST /open-apis/report/v1/tasks/query \
  --data '{"commit_start_time":<timestamp>,"commit_end_time":<timestamp>,"page_size":10,"page_token":"","rule_id":""}' \
  --params '{"user_id_type":"open_id"}' --as user
```

## 常见错误

| 错误 | 原因 | 解决 |
|------|------|------|
| `missing_scope report:task:readonly` | scope 未添加到应用 | 飞书开发者后台→权限管理→添加→发布 |
| `user access token not support` | API 只接受 user/bot token | 按文档切换 `--as user` 或 `--as bot` |
| `data: {}` (空结果) | 时间戳错误或该时间无记录 | 用 Python 精确计算时间戳 |
