# 飞书汇报 API 周报数据拉取（2026-08-06 验证）

## API 端点

```
POST /open-apis/report/v1/tasks/query
权限: report:task:readonly
授权: lark-cli auth login --scope "report:task:readonly"
```

## 请求参数

```json
{
  "commit_start_time": "<unix_timestamp>",
  "commit_end_time": "<unix_timestamp>",
  "page_token": "",
  "page_size": 20
}
```

## Windows lark-cli 调用方式

lark-cli api 在 Windows 上传 JSON 必须用 node 脚本（.cmd 中文长内容必败）：

```javascript
const { execSync } = require('child_process');
const data = JSON.stringify({commit_start_time, commit_end_time, page_token:'', page_size:20});
const escaped = data.replace(/"/g, '\\"');
const cmd = `lark-cli api POST /open-apis/report/v1/tasks/query --data "${escaped}" --as user`;
const out = execSync(cmd, {encoding:'utf8'});
```

## 返回结构

```
items[].form_contents[].field_name = "今日总结" | "明日计划" | "需要协调与帮助"
items[].form_contents[].field_value = 日报正文
items[].commit_time = 提交时间戳（补交≠内容日期！）
items[].rule_id = "7611748107898391753" (工作日报规则)
```

## 周报合并关键逻辑

- 补交日报的 commit_time 是补交日而非内容日 → 必须按 field_value 中的日期文本匹配
- 查询范围要扩大覆盖补交（如查 7/27-31 的日报，时间范围设 7/25 - 8/4）
- 按内容日期排序后合并，再按项目维度汇总去重

## rule_id

工作日报规则 ID: 7611748107898391753（用于精确筛选，避免拉到其他汇报类型）
