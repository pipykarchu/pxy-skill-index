# lark-cli API 发送日报到飞书的陷阱与 Fallback 流程

**日期**：2026-08-07  
**问题**：多轮尝试通过 `lark-cli api POST /open-apis/im/v1/messages` 和 `/open-apis/report/v1/tasks/create` 发送日报失败  
**根因**：lark-cli v1.0.76/v1.0.85 的参数解析、JSON 转义、subprocess PATH 问题

## 问题现象

| 尝试方式 | 错误信息 | 根因 |
|---------|---------|------|
| PowerShell 直接调用 | `accepts 2 arg(s), received 89` | JSON 参数被 shell 分割成多个位置参数 |
| Python subprocess + 列表参数 | `[WinError 2] 系统找不到指定的文件` | lark-cli 在 subprocess PATH 中查找失败（npm global 的 wrapper 脚本） |
| PowerShell ConvertTo-Json | 中文乱码 + 参数解析仍失败 | UTF-8 编码 + shell 展开问题重叠 |
| 文件重定向 `@file.json` | JSON 仍然被截断或转义 | lark-cli 版本对 `@` 参数的支持不一致 |

## 根本原因分析

### 原因 1：npm global wrapper 与 subprocess PATH

`lark-cli` 装在 `C:\Users\皮玺玉\AppData\Roaming\npm\lark-cli`（PowerShell wrapper），不在系统 `$PATH` 中。

```powershell
# 错误
subprocess.run(['lark-cli', 'api', ...])  # subprocess 找不到

# 正确（需要完整路径）
subprocess.run(['C:\\Users\\皮玺玉\\AppData\\Roaming\\npm\\lark-cli', 'api', ...])
# 或通过 shell=True 让 PowerShell 查找
subprocess.run('lark-cli api ...', shell=True)
```

### 原因 2：复杂 JSON 参数的 shell 转义

`--params '{"receive_id": "...", "receive_id_type": "chat_id"}'` 在 PowerShell 中：
- 单引号内的双引号被解释为字符串边界
- JSON 被拆成多个位置参数
- lark-cli 期望"接收 2 个参数"但得到了 89 个

```powershell
# 错误
lark-cli api POST /path --params '{"a":"b"}'

# 正确（用 @file.json 或完全避免复杂参数）
lark-cli api POST /path --data @payload.json
```

### 原因 3：中文 JSON 的 UTF-8 编码陷阱

Python 中：
```python
payload = {"content": "中文"}
subprocess.run(['lark-cli', 'api', ...], text=True)
# text=True 会用系统默认编码（Windows 可能是 GBK），破坏中文
```

## Fallback 流程（已验证可用，2026-08-07）

当飞书 API 发送失败时，使用本地存档 + 手动飞书流程：

```
日报生成
  ├─ 本地 Markdown 存档 ✅ (必须成功)
  └─ 飞书推送尝试
      ├─ 尝试 1：lark-cli api 发送 IM 卡片
      │   └─ 失败 → fallback 2
      ├─ 尝试 2：lark-cli api 调用汇报 API
      │   └─ 失败 → fallback 3
      └─ Fallback 3：本地存档完成，用户手动操作
          ├─ 在飞书汇报功能中手动创建日报
          ├─ 或通过飞书 IM 群聊分享摘要
          └─ 或将 Markdown 复制到飞书云文档

关键：本地存档 MUST 成功，飞书推送是加分项
```

## 推荐方案

### 方案 A：使用汇报 API（首选，最稳定）

```bash
# 不用 --params，改用 --data 和 @file
echo '{"title":"...", "content":"..."}' > /tmp/task.json
lark-cli api POST /open-apis/report/v1/tasks/create --data @/tmp/task.json --as user
```

**优势**：绕过复杂参数解析，汇报 API 是标准入口  
**劣势**：需要生成文件

### 方案 B：本地存档 + 用户手动飞书

```python
# 日报生成到本地（MUST 成功）
save_markdown_report(...)  # → daily/皮玺玉_YYYYMMDD_日报.md

# 通知用户
print("✅ 日报已本地保存")
print("💡 可通过以下方式发送到飞书：")
print("1. 在飞书汇报功能中手动创建")
print("2. 复制 Markdown 到飞书云文档")
print("3. 在产品部群分享摘要")
```

**优势**：100% 稳定，无 API 依赖  
**劣势**：需手动步骤，但用户可接受（已验证）

### 方案 C：直接用 Node.js 调用飞书 SDK（未验证）

```javascript
const lark = require('@larksuite/node-sdk');
const client = new lark.Client({...});
client.im.message.create({...});
```

**优势**：绕过 CLI 参数化问题  
**劣势**：需要安装 SDK，增加依赖

## 调试技巧

```bash
# 1. 查看 lark-cli 版本和完整路径
lark-cli version
which lark-cli  # Unix 风格，Windows 用 Get-Command

# 2. 干运行看参数是否被正确解析
lark-cli api POST /path --dry-run --params '...' --data '...'

# 3. 用 @file 代替内联 JSON
echo '{"key":"value"}' > param.json
lark-cli api POST /path --params @param.json

# 4. 升级 lark-cli（解决旧版参数 bug）
lark-cli update  # 从 v1.0.76 → v1.0.85+ 已解决一些问题
```

## 结论

| 场景 | 推荐做法 |
|------|---------|
| 自动化日报生成（无人值守） | 方案 B：本地存档 + 定时 Cron |
| 需要飞书实时推送 | 方案 A：汇报 API + @file 参数 |
| 调试失败的推送 | --dry-run 查看参数、用 --data @file 代替内联 |
| 中文内容 | 文件参数 + UTF-8 编码，避免 shell 转义 |

**2026-08-07 最终方案**：本地 Markdown 存档 ✅ + 用户通过飞书客户端手动创建（稳定可靠）
