#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
周报自动生成 Cron 脚本 v2.0
大周周五 18:30 / 小周周六 18:30 触发
功能：合并本周日报 → 生成周报 MD → 发飞书智能体消息

使用场景：
  - Hermes 定时任务自动触发（cron）
  - 手动触发：`python weekly-report-cron.py`
"""

import datetime
import os
import glob
import json
from pathlib import Path

# ──────────────────────────────────────────────────────────
# 配置
# ──────────────────────────────────────────────────────────

TODAY = datetime.date.today()
TODAY_STR = TODAY.strftime("%Y-%m-%d")
ARCHIVE_BASE = Path(r"D:\AI\AI产品工作\汇报")
DAILY_DIR = ARCHIVE_BASE / "daily"
WEEKLY_DIR = ARCHIVE_BASE / "weekly"

# 周数计算（ISO 周编号）
WEEK_NUM = TODAY.isocalendar()[1]
YEAR = TODAY.year
WEEK_STR = f"{YEAR}_W{WEEK_NUM:02d}"

# 文件路径
WEEKLY_FILE = WEEKLY_DIR / f"皮玺玉_{WEEK_STR}_周报.md"


def is_big_week(date=None):
    """
    判断是否为大周（工作日 >= 5 天）
    """
    if date is None:
        date = TODAY
    
    # 2026 年国家节假日定义
    HOLIDAYS_2026 = {
        "single": [
            (1, 1), (4, 4), (6, 9), (9, 15),
        ],
        "range": [
            ((2, 7), (2, 13)), ((4, 4), (4, 6)), ((5, 1), (5, 5)),
            ((6, 9), (6, 11)), ((9, 15), (9, 17)), ((10, 1), (10, 7)),
        ]
    }
    
    def is_holiday(d):
        if (d.month, d.day) in HOLIDAYS_2026["single"]:
            return True
        for (sm, sd), (em, ed) in HOLIDAYS_2026["range"]:
            start = datetime.date(d.year, sm, sd)
            end = datetime.date(d.year, em, ed)
            if start <= d <= end:
                return True
        return False
    
    # 周一为周的开始
    week_start = date - datetime.timedelta(days=date.weekday())
    working_days = 0
    for i in range(5):  # 周一到周五
        check_date = week_start + datetime.timedelta(days=i)
        if not is_holiday(check_date):
            working_days += 1
    
    return working_days >= 5


def collect_daily_reports():
    """
    收集本周所有日报文件
    返回列表：[(日期, 文件内容), ...]
    """
    os.makedirs(DAILY_DIR, exist_ok=True)
    
    # 获取本周的周一日期
    week_start = TODAY - datetime.timedelta(days=TODAY.weekday())
    
    reports = []
    for i in range(7):  # 周一到周日
        check_date = week_start + datetime.timedelta(days=i)
        date_str = check_date.strftime("%Y%m%d")
        daily_file = DAILY_DIR / f"皮玺玉_{date_str}_日报.md"
        
        if daily_file.exists():
            try:
                content = daily_file.read_text(encoding="utf-8")
                reports.append((check_date, content))
            except Exception as e:
                print(f"  [错误] 读取 {daily_file.name}: {e}")
    
    return reports


def generate_weekly_report():
    """
    生成周报 (来自本周日报的合并)
    """
    DAILY_DIR.mkdir(parents=True, exist_ok=True)
    WEEKLY_DIR.mkdir(parents=True, exist_ok=True)
    
    # 获取周期时间范围
    week_start = TODAY - datetime.timedelta(days=TODAY.weekday())
    week_end = week_start + datetime.timedelta(days=6)
    
    period_str = f"{week_start.strftime('%Y-%m-%d')} ~ {week_end.strftime('%Y-%m-%d')}"
    
    # 收集本周日报
    daily_reports = collect_daily_reports()
    
    # 生成周报模板
    content = f"""# 周报 · {WEEK_STR} · {period_str}

**汇报人**: 皮玺玉  
**时间周期**: {period_str}（第 {WEEK_NUM} 周）  
**提交日期**: {TODAY_STR}

---

## 📊 一、本周工作总结

### 项目概览

（根据本周日报自动汇总，需手工补充）

### 工作量统计

- **总工作项**: X 项
- 🟢 已完成: X 项
- 🟡 进行中: X 项
- 🟠 阻塞: X 项
- 🔴 延期: X 项

---

## 🚀 二、核心产出

**本周重点成果**（从日报提取）

---

## 📅 三、下周计划

| 优先级 | 任务 | 预估工时 | 负责人 |
|--------|------|---------|--------|
| **P0** | 任务 1 | Xh | 皮玺玉 |
| **P1** | 任务 2 | Xh | 皮玺玉 |

---

## ⚠️ 四、需要协调和帮助

无

---

## 🎯 五、战略对齐

**OKR 进度**: （待填写）

**本周战略价值**: （待填写）

---

## 📝 六、风险与反思

| 风险 | 影响 | 缓解措施 | 责任人 |
|------|------|--------|--------|
|无|无|无|皮玺玉|

---

**签字**: 皮玺玉  
**日期**: {TODAY_STR}  
**下周跟进**: {(TODAY + datetime.timedelta(days=7)).strftime('%Y-%m-%d')}

---

### 本周日报记录

"""
    
    # 附加本周日报内容摘要
    if daily_reports:
        daily_summary = []
        for d, _ in daily_reports:
            daily_summary.append(f"#### {d.strftime('%m-%d（%A）')}: 皮玺玉_{d.strftime('%Y%m%d')}_日报.md")
            daily_summary.append("")
        content += "\n".join(daily_summary)
    
    # 写入文件
    WEEKLY_FILE.parent.mkdir(parents=True, exist_ok=True)
    WEEKLY_FILE.write_text(content, encoding="utf-8")
    
    return str(WEEKLY_FILE)


def get_current_lark_cli_user():
    """
    获取当前 lark-cli 登录的用户身份（自动检测，支持多用户）
    
    返回: {
        "open_id": "ou_xxx",
        "name": "username",
        "workspace": "workspace_name"
    }
    
    如果获取失败返回 None
    """
    import subprocess
    
    try:
        # 查询 lark-cli 当前认证状态
        result = subprocess.run(
            ["lark-cli", "auth", "status", "--json"],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        if result.returncode != 0:
            print(f"  [⚠️ ] lark-cli auth status 返回错误: {result.stderr[:80]}")
            return None
        
        try:
            status_data = json.loads(result.stdout)
            
            # 提取用户信息（支持不同字段名）
            user_id = status_data.get("user_id") or status_data.get("open_id") or status_data.get("id")
            user_name = status_data.get("user_name") or status_data.get("name") or "unknown"
            workspace = status_data.get("workspace") or status_data.get("account") or "default"
            
            if not user_id:
                print(f"  [⚠️ ] 无法从 lark-cli status 获取用户 ID")
                print(f"       响应数据: {status_data}")
                return None
            
            print(f"  ✅ 检测到当前 lark-cli 用户: {user_name} ({user_id})")
            
            return {
                "open_id": user_id,
                "name": user_name,
                "workspace": workspace
            }
        except json.JSONDecodeError as e:
            print(f"  [⚠️ ] lark-cli status JSON 解析失败: {e}")
            print(f"       原始响应: {result.stdout[:100]}")
            return None
            
    except FileNotFoundError:
        print("[❌ ] lark-cli 命令未找到，请确保已安装并在 PATH 中")
        return None
    except subprocess.TimeoutExpired:
        print("[❌ ] lark-cli auth status 执行超时")
        return None
    except Exception as e:
        print(f"[❌ ] 获取用户身份异常: {e}")
        return None


def send_to_feishu_agent():
    """
    发送周报到飞书（使用 IM bot 卡片消息）
    
    自动检测当前 lark-cli 登录用户，支持多用户场景
    """
    import subprocess
    
    # 自动检测当前用户
    user_info = get_current_lark_cli_user()
    if not user_info:
        return "[⚠️ ] 无法获取 lark-cli 用户身份，跳过飞书发送"
    
    user_open_id = user_info["open_id"]
    user_name = user_info["name"]
    
    summary = f"""📊 周报生成完成
    
**周次**: {WEEK_STR}
**周期**: {(TODAY - datetime.timedelta(days=TODAY.weekday())).strftime('%m-%d')} ~ {(TODAY + datetime.timedelta(days=6-TODAY.weekday())).strftime('%m-%d')}
**大/小周**: {'大周' if is_big_week() else '小周'}
**用户**: {user_name}

📁 文件: 皮玺玉_{WEEK_STR}_周报.md
📍 位置: {WEEKLY_DIR}

☑️ 手工审核内容后在飞书汇报页提交"""

    # 构建飞书 bot 卡片消息
    card_json = {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"content": "📋 周报", "tag": "plain_text"},
            "template": "blue"
        },
        "elements": [
            {
                "tag": "markdown",
                "content": summary
            }
        ]
    }
    
    try:
        # 使用 lark-cli 发送（使用当前登录用户的身份）
        cmd = [
            "lark-cli", "im", "+messages-send",
            "--as", "bot",
            "--msg-type", "interactive",
            "--content", json.dumps(card_json),
            "--to-user", user_open_id  # 使用自动检测的用户 ID
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=15
        )
        
        if result.returncode == 0:
            print(f"  ✅ 周报已发送到飞书 (用户: {user_name})")
            return "✅ 消息已发送"
        else:
            error_msg = result.stderr[:100] if result.stderr else result.stdout[:100]
            print(f"  [❌ ] 飞书消息发送失败: {error_msg}")
            return f"[❌ ] 发送失败: {error_msg}"
            
    except Exception as e:
        print(f"  [❌ ] 无法发送飞书消息: {e}")
        return f"[❌ ] 异常: {e}"


def main():
    """主程序"""
    print(f"[{TODAY_STR}] 周报生成 v2.0")
    
    # 检查是否应该生成周报
    big_week = is_big_week()
    weekday = TODAY.weekday()
    
    should_gen = (big_week and weekday == 4) or (not big_week and weekday == 5)
    
    if not should_gen:
        day_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        week_type = "大周" if big_week else "小周"
        print(f"  ⏭️  跳过：今天非周报生成日期 ({week_type}{day_names[weekday]})")
        return 1
    
    print(f"  ✅ 生成周报 ({WEEK_STR})")
    
    # 生成周报
    print("Step 1: 收集本周日报")
    daily_reports = collect_daily_reports()
    print(f"  找到 {len(daily_reports)} 份日报")
    
    print("Step 2: 生成周报 MD 文件")
    weekly_file = generate_weekly_report()
    print(f"  ✅ {weekly_file}")
    
    print("Step 3: 发送飞书通知")
    feishu_result = send_to_feishu_agent()
    print(f"  {feishu_result[:80]}")
    
    print("完成。")
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
