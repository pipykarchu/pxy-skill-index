# lark-cli 版本兼容性与飞书 API 参数转义陷阱

**最后验证**: 2026-08-07 · lark-cli 从 v1.0.76 升级到 v1.0.85  
**症状**: lark-cli v1.0.76 API 调用返回 `accepts 2 arg(s), received 89` 错误或 `--params invalid format`

## 问题场景

当通过 `lark-cli api POST /open-apis/im/v1/messages` 发送飞书卡片消息时：

```powershell
# ❌ v1.0.76 失败
lark-cli api POST /open-apis/im/v1/messages \
  --params '{"receive_id": "oc_xxx", "receive_id_type": "chat_id"}' \
  --data '{"msg_type": "interactive", "content": "..."}' \
  --as bot

# 错误1: accepts 2 arg(s), received 89
# 错误2: --params invalid format, expected JSON object
```

## 根因

- **lark-cli ≤1.0.76**: 对 `--params` 和 `--data` 的 JSON 解析不稳定，复杂参数容易被误解析为位置参数
- **PowerShell 转义**: 嵌套引号、美元符号、反斜杠经常被 PowerShell 当作特殊字符而非纯文本
- **中文编码**: JSON 中含中文时，某些转义路径会产生乱码

## 解决方案

### 方案 A：升级 lark-cli（推荐）

```bash
lark-cli update
# 从 1.0.76 → 1.0.85（或更新）

# 升级后命令格式依然需要谨慎，但参数解析更可靠
```

**升级效果**: v1.0.85 对 JSON 参数的容错更好，但仍需避免过度复杂的嵌套。

### 方案 B：通过文件传递参数（最稳定）

```powershell
# 1. 将 payload 写入文件（确保 UTF-8 NoBOM）
$payload = @{
    receive_id_type = "chat_id"
    msg_type = "interactive"
    content = (ConvertTo-Json $card -Compress -AsArray)
} | ConvertTo-Json

$payload | Out-File -Encoding UTF8NoBOM "payload.json"

# 2. 使用 @file 语法
lark-cli api POST /open-apis/im/v1/messages \
  --params "{`"receive_id`": `"oc_xxx`"}" \
  --data "@payload.json" \
  --as bot
```

**优点**:
- 避免 PowerShell 转义问题
- 中文完整保留
- 可复用 payload 文件

### 方案 C：分段发送 + 本地存档

当 API 调用遇冷，转向异步流程：

```python
# 1. 本地生成日报 Markdown（可靠）
with open("daily_report.md", "w", encoding="utf-8") as f:
    f.write(formatted_report)

# 2. 手动或定时上传到飞书汇报系统（稳定）
# 3. 在下周周报时一并合并推送

# 判断条件：当 lark-cli api 连续失败 2 次以上，降级为本地存档模式
```

## 推荐工作流（2026-08-07 后）

1. **日报生成** → 本地 Markdown（快速 + 可靠）
2. **API 尝试** → lark-cli v1.0.85+ 通过文件参数发送
3. **失败降级** → 本地存档 + 手动上传或等待周报合并
4. **周报推送** → 通过飞书汇报 API 批量发送（比卡片消息更稳定）

## 命令清单

```bash
# 检查版本
lark-cli auth status --json | jq .version

# 升级
lark-cli update

# 通过文件参数安全发送
lark-cli api POST /open-apis/im/v1/messages \
  --params @params.json \
  --data @payload.json \
  --as bot

# params.json
{
  "receive_id": "oc_xxx",
  "receive_id_type": "chat_id"
}

# payload.json
{
  "msg_type": "interactive",
  "content": "{\"config\": {...}}"
}
```

## 何时应用此指南

- 日报卡片消息发送失败
- lark-cli api 返回参数格式错误
- PowerShell 中文编码问题
- 批量发送卡片且不能容忍单条失败

**相关技能参考**：`references/weekly-send-split-pattern.md`（周报分段 + API 容错）
