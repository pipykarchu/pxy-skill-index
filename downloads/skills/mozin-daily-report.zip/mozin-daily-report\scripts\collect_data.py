#!/usr/bin/env python3
"""
数据采集整合工具（独立运行脚本，主流程用 agent 流程替代）
lark-cli v1.0.74+ 兼容（lark-cli 是 Node 脚本，跨平台）
跨平台：Windows / macOS / Linux 通用
用法: python3 collect_data.py
"""
import subprocess, json, os, sys, re
from datetime import datetime, timezone
import requests

HOME = os.path.expanduser("~")
TODAY = datetime.now().strftime("%Y-%m-%d")
GITLAB_URL = os.environ.get("GITLAB_URL", "http://120.237.89.124:8929")

def run(cmd, timeout=30):
    """执行 shell 命令。Windows 下 shell=True 自动处理 cmd 前缀。"""
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip(), r.stderr.strip(), r.returncode
    except Exception as e:
        return "", str(e), 1

def parse_lark(raw):
    try:
        idx = raw.index("{")
        return json.loads(raw[idx:])
    except:
        return None

def parse_drive_search(raw):
    """解析 drive +search 结果：数据在 data.results（不是 data.items！）。
    兼容所有文档类型：DOCX/BITABLE/SHEET/SLIDES/MINDNOTE 等。
    返回 [{type, title, url, update_time, edit_user}]"""
    try:
        d = parse_lark(raw)
        if not d or not d.get("ok"):
            return []
        results = d.get("data", {}).get("results", []) or []
        out = []
        for it in results:
            meta = it.get("result_meta", {}) or {}
            out.append({
                "type": meta.get("doc_types", "?"),
                "title": (it.get("title_highlighted") or "").replace("<em>", "").replace("</em>", ""),
                "url": meta.get("url", ""),
                "update_time": meta.get("update_time_iso", ""),
                "edit_user": meta.get("edit_user_name", ""),
            })
        return out
    except Exception:
        return []

def find_git_repos(base_dirs, max_depth=3):
    """动态扫描目录树下所有含 .git 的仓库（os.walk，跨平台）。"""
    repos = []
    for base in base_dirs:
        if not os.path.isdir(base):
            continue
        base = os.path.abspath(base)
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [d for d in dirnames if d not in
                           (".git", "node_modules", "vendor", "target", "venv", ".venv", "__pycache__", ".DS_Store")]
            depth = dirpath[len(base):].count(os.sep)
            if depth > max_depth:
                dirnames[:] = []
                continue
            if ".git" in dirnames:
                repos.append(dirpath)
                dirnames.remove(".git")
    return repos

def find_modified_files(dirs, max_per_dir=30):
    """扫描目录下 24 小时内修改的文件（os.walk + mtime，跨平台替代 find -mtime）。"""
    cutoff = datetime.now().timestamp() - 86400
    results = []
    for d in dirs:
        if not os.path.isdir(d):
            continue
        count = 0
        for dirpath, dirnames, filenames in os.walk(d):
            dirnames[:] = [x for x in dirnames if x not in
                           (".git", "node_modules", "vendor", "target", "venv", ".venv", "__pycache__", ".DS_Store")]
            if count >= max_per_dir:
                break
            for f in filenames:
                if f.endswith((".pyc", ".DS_Store")):
                    continue
                fp = os.path.join(dirpath, f)
                try:
                    if os.path.getmtime(fp) >= cutoff:
                        results.append(fp.replace(HOME, "~"))
                        count += 1
                        if count >= max_per_dir:
                            break
                except OSError:
                    continue
    return results

# ── GitLab 采集 ──────────────────────────────────────────────

def detect_gitlab_token():
    """自动检测 GitLab token：环境变量 GITLAB_TOKEN > ~/.git-credentials > ~/.netrc"""
    tok = os.environ.get("GITLAB_TOKEN") or os.environ.get("GITLAB_PERSONAL_ACCESS_TOKEN")
    if tok:
        return tok.strip()
    # ~/.git-credentials 里找 120.237.89.124 的 token
    cred_path = os.path.join(HOME, ".git-credentials")
    if os.path.isfile(cred_path):
        for line in open(cred_path, encoding="utf-8", errors="ignore"):
            if "120.237.89.124" in line or "glpat-" in line:
                m = re.search(r"glpat-[A-Za-z0-9._-]+", line)
                if m:
                    return m.group(0)
    return None

def gitlab_api_get(token, path):
    """GitLab API GET，返回 (json 或 None, 错误信息)
    注意：必须禁用 trust_env 绕过系统代理——内网 GitLab IP 走代理会超时。"""
    url = f"{GITLAB_URL}/api/v4{path}"
    try:
        session = requests.Session()
        session.trust_env = False  # 不走系统代理（内网 IP 走代理必超时）
        resp = session.get(url, headers={"PRIVATE-TOKEN": token}, timeout=15)
        if resp.status_code == 200:
            return resp.json(), None
        return None, f"HTTP {resp.status_code}"
    except Exception as e:
        return None, str(e)

def collect_gitlab(token):
    """拉今日 GitLab 活动：我的提交事件 + 我创建的/参与合入的 MR"""
    # 注意：GitLab events API 用 created_after 参数（after 有边界 bug），时区用 +08:00（北京时间）
    today_iso = f"{TODAY}T00:00:00%2B08:00"
    result = {"configured": True, "events": [], "merge_requests": []}

    # 先拿当前用户
    me, me_err = gitlab_api_get(token, "/user")
    username = me.get("username", "") if me else ""
    if me_err:
        result["error"] = f"user: {me_err}"

    # 1. 今日我的 push 事件（events API）
    events, err = gitlab_api_get(token, f"/events?created_after={today_iso}&scope=push&per_page=50")
    if err:
        result["error"] = f"events: {err}"
    elif isinstance(events, list):
        for e in events:
            proj_id = e.get("project_id") or e.get("target_id") or ""
            target = e.get("target_title") or (e.get("push_data") or {}).get("ref", "")
            result["events"].append({"project": f"id:{proj_id}", "ref": target, "action": e.get("action_name", "")})

    # 2. 我创建的 MR（含合并的）
    mrs, err = gitlab_api_get(token, "/merge_requests?scope=all&state=all&per_page=100")
    if err:
        result.setdefault("errors", []).append(f"merge_requests: {err}")
    elif isinstance(mrs, list) and username:
        for mr in mrs:
            if mr.get("author", {}).get("username") == username:
                result["merge_requests"].append({
                    "title": mr.get("title", ""),
                    "state": mr.get("state", ""),
                    "project": f"id:{mr.get('project_id', '')}",
                    "url": mr.get("web_url", ""),
                })
    return result

# ── 主流程 ───────────────────────────────────────────────────

def collect():
    data = {"date": TODAY, "sources": {}}

    # 身份
    out, _, _ = run("lark-cli auth status")
    data["sources"]["identity"] = out[:300]

    # 日程
    out, _, _ = run("lark-cli calendar +agenda --as user")
    data["sources"]["agenda"] = out[:500]

    # 文档 + 多维表格（⚠️ 不能用 --mine：lark-cli 的 --edited-since + --mine 组合有 bug 返回 0 条，
    # 且 --mine 会漏掉自己今日编辑的文档。用 --edited-since 1d 不限作者，再在解析时按 edit_user 过滤）
    out, _, _ = run("lark-cli drive +search --edited-since 1d --as user --format json 2>/dev/null")
    docs = parse_drive_search(out)
    data["sources"]["docs"] = docs

    # 任务
    out, _, _ = run("lark-cli task +get-my-tasks --as user")
    data["sources"]["tasks"] = out[:1000]

    # 会议
    start_iso = f"{TODAY}T00:00:00+08:00"
    end_iso = f"{TODAY}T23:59:59+08:00"
    out, _, _ = run(f'lark-cli vc +search --start "{start_iso}" --end "{end_iso}" --as user')
    data["sources"]["meetings"] = out[:500]

    # 妙记
    out, _, _ = run(f'lark-cli minutes +search --owner-ids me --start "{TODAY}" --end "{TODAY}" --as user 2>/dev/null')
    data["sources"]["minutes"] = out[:500]

    # GitLab（自动检测 token，未配置则标记，不阻塞其他源）
    token = detect_gitlab_token()
    if token:
        data["sources"]["gitlab"] = collect_gitlab(token)
    else:
        data["sources"]["gitlab"] = {
            "configured": False,
            "hint": "未检测到 GitLab token。请设置环境变量 GITLAB_TOKEN，或在 ~/.git-credentials 配置后重跑。"
        }

    # Git 提交（动态扫描）
    repos = find_git_repos([os.path.join(HOME, "Documents"), os.path.join(HOME, ".hermes", "skills")])
    git_data = []
    for r in repos:
        o, _, _ = run(f'cd "{r}" && git log --since="{TODAY} 00:00" --format="%h %s" --oneline 2>/dev/null | head -20')
        if o.strip():
            git_data.append({"repo": r.replace(HOME, "~"), "log": o.strip()})
    data["sources"]["git"] = git_data

    # 本地文件变更（跨平台 os.walk）— 扫整个 Documents + Desktop + 当前目录，
    # 不限于产品文档：所有当天修改的文件都可能体现工作产出（含导出的表格/截图/PDF 等）
    local_dirs = [
        os.path.join(HOME, "Documents"),
    ]
    # 桌面目录（跨平台：macOS=Desktop, Windows=桌面, Linux=Desktop；用 os.path.join 探测）
    desktop = os.path.join(HOME, "Desktop")
    if os.path.isdir(desktop):
        local_dirs.append(desktop)
    cwd = os.getcwd()
    if cwd not in local_dirs:
        local_dirs.append(cwd)
    data["sources"]["local_files"] = find_modified_files(local_dirs)

    print(json.dumps(data, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    collect()
