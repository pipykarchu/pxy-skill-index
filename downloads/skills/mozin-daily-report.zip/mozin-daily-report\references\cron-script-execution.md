# Hermes Cron 脚本执行细节（2026-08-03 验证）

## 问题现象

创建周报 cron job 时，配置 `--script should_generate_weekly_report.py` 导致执行失败：

```
hermes: error: argument command: invalid choice: 'D:\\AI\\hermes\\...\\should_generate_weekly_report.py'
(choose from 'chat', 'model', ..., 'cron', ...)
```

**错误原因**：Hermes cron 系统试图把脚本路径当作 `hermes` CLI 的子命令来解析。

---

## 解决方案

### 前置条件

1. **脚本位置**：必须放在 `~/.hermes/scripts/` 目录下
   ```bash
   ~/.hermes/scripts/should_generate_weekly_report.py
   ```

2. **脚本开头**：需要 shebang（虽然 Windows 不强制，但提高兼容性）
   ```python
   #!/usr/bin/env python3
   # -*- coding: utf-8 -*-
   ```

3. **脚本结构**：
   - 定义核心逻辑函数（如 `is_big_week()`, `should_generate_report()`）
   - 定义 `main()` 入口函数
   - 在 `main()` 中调用 `sys.exit(0)` 或 `sys.exit(1)` 返回状态码
   - 末尾含 `if __name__ == "__main__": main()`

### 正确的 Cron 配置

```bash
hermes cron create "30 18 * * 5" \
  "📋 周报生成（大周周五）" \
  --script should_generate_weekly_report.py \
  --skill daily-report-mozin \
  --model claude-haiku-4-5-20251001 \
  --provider custom:api-aicodewith-com \
  --deliver feishu
```

**关键点**：
- `--script <filename>` — 只填文件名，不要填完整路径
- Hermes 会自动在 `~/.hermes/scripts/` 查找
- Hermes 会用 Python 解释器执行脚本（而非 `hermes` CLI）

---

## 脚本模板

### 最小可工作示例

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
周报生成判断脚本 — 返回是否应该生成周报
"""

import datetime
import sys

def should_generate_report(date=None):
    """判断是否应该生成周报（示例逻辑）"""
    if date is None:
        date = datetime.date.today()
    
    weekday = date.weekday()  # 0=Monday, 4=Friday, 5=Saturday
    
    # 大周周五 or 小周周六
    if weekday == 4:  # Friday (simplified)
        return True
    return False

def main():
    """主程序"""
    should_gen = should_generate_report()
    sys.exit(0 if should_gen else 1)  # 0 = 执行 skill, 1 = 跳过

if __name__ == "__main__":
    main()
```

### 返回码约定

| 返回码 | 含义 | Cron 行为 |
|--------|------|---------|
| `0` | 符合条件，继续执行 | 执行绑定的 skill / prompt |
| `1` | 不符合条件，跳过 | 记录 skip，不触发 skill |
| 其他 | 异常 | 记录为执行错误 |

---

## 验证步骤

### 1. 验证脚本语法

```bash
python -m py_compile ~/.hermes/scripts/should_generate_weekly_report.py
# 无输出 = 语法正确
```

### 2. 验证脚本可执行

```bash
python ~/.hermes/scripts/should_generate_weekly_report.py
# 输出诊断信息 + exit code
echo $?  # 查看返回码
```

### 3. 查看 Cron job 日志

```bash
hermes cron list | grep "周报"
# 查看 last_status 和 last_error 字段
```

---

## 常见陷阱

| 陷阱 | 症状 | 修复 |
|------|------|------|
| 脚本路径用绝对路径 | `invalid choice` 错误 | 只填文件名，放到 `~/.hermes/scripts/` |
| 脚本没有 shebang | 可能在某些系统上失败 | 添加 `#!/usr/bin/env python3` |
| `main()` 不调用 `sys.exit()` | Cron 无法判断成功/失败 | 显式 `sys.exit(0)` 或 `sys.exit(1)` |
| 脚本有语法错误 | `Skipped to prevent unintended spend` 或执行错误 | 用 `py_compile` 检查 |
| 脚本输出过多 | Cron 日志被污染 | 在必要时重定向 stdout/stderr |

---

## 周报特定逻辑

对于**大小周自动判断**，见 `references/weekly-report-big-small-week.md`。

该文档包含完整的判断脚本示例（国家节假日检测、大周/小周识别、生成条件判断）。

---

## 相关参考

- `references/weekly-report-big-small-week.md` — 周报大小周判断脚本
- `references/cron-weekly-biweek-setup.md` — 周报 cron 配置完整指南
