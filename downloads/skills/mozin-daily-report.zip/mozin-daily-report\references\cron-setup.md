# Cron 定时任务配置

## 1. 日报自动生成（每日 18:30）

```bash
hermes cron create "📋 日报自动生成-皮玺玉" \
  --schedule "30 18 * * *" \
  --role "leaf" \
  --goal "加载 daily-weekly-monthly-reporting skill → 执行本地文件扫描 + 飞书任务读取 + 会议妙记汇总 → 生成日报 Markdown → 保存至 D:\AI\AI产品工作\汇报\daily\ → 通过 IM 发送给自己 (ou_7d05b327389c521f51426312ac5c9e2b) → 更新 报告统计.json 数据库" \
  --deliver "feishu" \
  --on-error "notify" \
  --timeout 300 \
  --context "用户名: 皮玺玉, 工作目录: D:\AI\AI产品工作, 汇报抄送: 莫代鹏/宋家明"
```

**验证：**
```bash
hermes cron list | grep "日报自动生成"
```

---

## 2. 周报自动生成（每周一 09:00）

```bash
hermes cron create "📅 周报自动生成-皮玺玉" \
  --schedule "0 9 * * 1" \
  --role "leaf" \
  --goal "加载 daily-weekly-monthly-reporting skill → 读取过去7天 报告统计.json → 汇总周数据（总产出/完成率/风险数） → 生成周报 Markdown → 保存至 weekly/YYYY_W##_周报.md → 发送任务看板提醒到飞书 IM" \
  --deliver "feishu" \
  --on-error "notify" \
  --timeout 600
```

---

## 3. 月报自动生成（每月月末 18:00）

```bash
hermes cron create "📊 月报自动生成-皮玺玉" \
  --schedule "0 18 28-31 * *" \
  --role "leaf" \
  --goal "加载 daily-weekly-monthly-reporting skill → 读取过去4-5周周报数据 → 汇总月KPI（产出总数/完成率/ROI） → 生成月报 Markdown → 保存至 monthly/YYYY_M##_月报.md → 同步到知识库 → 发送月总结到飞书群聊" \
  --deliver "feishu" \
  --on-error "notify" \
  --timeout 900
```

**注意：** 月末需要处理28-31号的灵活调度

---

## 4. 手动触发

如需临时运行日报生成：

```bash
# 直接执行脚本
powershell -ExecutionPolicy Bypass -File "D:\hermes-home\skills\productivity\daily-weekly-monthly-reporting\scripts\daily-report-generator.ps1"

# 或通过 Hermes CLI
hermes skill load daily-weekly-monthly-reporting --run
```

---

## 5. 禁用/删除 Cron

```bash
# 查看所有任务
hermes cron list

# 删除特定任务
hermes cron delete "日报自动生成-皮玺玉"

# 临时禁用
hermes cron disable "日报自动生成-皮玺玉"

# 重新启用
hermes cron enable "日报自动生成-皮玺玉"
```

---

## 6. 权限检查清单

- [ ] `lark-cli` 已安装且 `--as user` 已授权
- [ ] 用户 open_id：`ou_7d05b327389c521f51426312ac5c9e2b`
- [ ] 飞书任务权限：`tasklist:tasklist.task:read`
- [ ] 飞书消息权限：`im:message:create_by_bot`
- [ ] 飞书会议权限：`minutes:minutes:read`
- [ ] 本地目录写权限：`D:\AI\AI产品工作\汇报\` 目录可写
- [ ] 飞书日历权限：`calendar:calendar.event:read`（可选，待补充）

**检查用户权限：**
```bash
lark-cli auth scopes | grep -E "tasklist|im:message|minutes|calendar"
```

---

## 7. 故障排查

### 问题：Cron 任务未执行
**原因：** Hermes 进程未运行或任务已禁用
```bash
hermes cron list  # 检查任务状态
hermes cron enable "日报自动生成-皮玺玉"  # 重新启用
```

### 问题：lark-cli 权限不足
**原因：** 权限未申请或已过期
```bash
lark-cli auth login --scope "tasklist:tasklist.task:read" --scope "im:message:create_by_bot"
```

### 问题：文件路径错误
**原因：** PowerShell 中文路径编码问题
**修复：** 使用英文工作目录或转义路径
```powershell
$WorkDir = "D:\AI"  # 避免中文路径
```

---

## 8. 监控和日志

**Cron 任务日志：**
```bash
hermes cron list --verbose  # 查看最近执行状态
hermes cron log "日报自动生成-皮玺玉"  # 查看执行日志
```

**本地日报文件验证：**
```bash
Get-ChildItem "D:\AI\AI产品工作\汇报\daily\" -File | Sort-Object LastWriteTime -Descending | Select-Object -First 5
```

**飞书消息验证：**
在飞书中搜索 "日报已生成"，确认消息正常发送
