# lark-cli Subprocess & API Push Pitfalls (2026-08-07)

## Problem Summary

When scripting `lark-cli api` calls from Python (`subprocess.run()`) or PowerShell to push daily reports to Feishu, multiple failure modes occur:

| Failure | Root Cause | Fix |
|---------|-----------|-----|
| `WinError 2: 系统找不到指定的文件` | `subprocess` cannot resolve `lark-cli` in PATH | Use absolute path: `/c/Users/<user>/AppData/Roaming/npm/lark-cli` or shell=True |
| `"accepts 2 arg(s), received 22"` | lark-cli v1.0.85+ API parser splits `--data '{json}'` on spaces | Pass JSON via file: `--data @payload.json` or use shell expansion |
| PowerShell `& "path"` backgrounding error | `&` operator interpreted as background when not in proper context | Use `Invoke-Expression` or direct executable call |
| JSON encoding in shell | Nested quotes, Chinese characters, and emoji corrupt the payload | Write to file first, then reference via `@file.json` |

---

## Working Patterns

### Pattern 1: Local Archive + Manual Feishu (Reliable, Current)
```python
# Generate and save Markdown
report = format_daily_report()
save_markdown_report(report)

print(f"✅ Local archive: daily/{date}-皮玺玉-日报.md")
print("💡 Next step: Manually paste into Feishu 汇报 or IM")
```
- **Pros**: Zero dependencies, always succeeds, user can review before sending
- **Cons**: Manual step required
- **When to use**: Default fallback; used 2026-08-07

### Pattern 2: Direct lark-cli via Absolute Path + File Input
```python
import subprocess
import json

# Write payload to file (avoids shell expansion issues)
payload_file = r"D:\path\to\payload.json"
with open(payload_file, "w", encoding="utf-8") as f:
    json.dump({"msg_type": "interactive", "content": card_json}, f, ensure_ascii=False)

# Use absolute path, no subprocess PATH resolution
cmd = [
    r"C:\Users\皮玺玉\AppData\Roaming\npm\lark-cli",
    "api", "POST", "/open-apis/im/v1/messages",
    "--params", json.dumps({"receive_id": chat_id}),
    "--data", f"@{payload_file}",
    "--as", "bot"
]
result = subprocess.run(cmd, capture_output=True, text=True)
```
- **Pros**: Full control, works with lark-cli v1.0.85+
- **Cons**: Absolute path breaks across machines; requires absolute path discovery
- **Blocker (2026-08-07)**: Parser still returned "accepts 2 arg(s), received 22" — parameter count mismatch suggests internal lark-cli regression

### Pattern 3: Shell=True with Escaping (Last Resort)
```python
# PowerShell with proper string quoting
ps_cmd = '''
$body = @{...} | ConvertTo-Json -Compress
lark-cli api POST /path --data $body --as user
'''
result = subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], ...)
```
- **Pros**: Avoids PATH issues
- **Cons**: Shell-injection risks; Chinese characters may encode wrong
- **Status**: Untested; complex JSON likely still fails

---

## Current Workaround (2026-08-07)

**Given repeated lark-cli failures, the reliable flow is:**

1. Generate Markdown report locally → save to `daily/YYYY-MM-DD-皮玺玉-日报.md`
2. Print summary to console (user verifies content)
3. Document that manual Feishu push is required OR queue for async Feishu push via cron job

```python
print("✅ Markdown 已保存")
print("📂 路径：daily/2026-08-07-皮玺玉-日报.md")
print("\n💡 发送到飞书方式：")
print("   1. 手动：飞书 APP → 工作 → 汇报 → 创建日报（粘贴内容）")
print("   2. 或：稍后用 cron job + 升级 lark-cli 后重试")
```

---

## lark-cli Version Notes

| Version | Status | API Behavior |
|---------|--------|------|
| 1.0.76 | Old | `lark-cli im send-message` — subcommand exists but deprecated |
| 1.0.85+ | Current | `lark-cli api POST /open-apis/...` — preferred, but parameter parser fragile |

**Neither version reliably handles complex JSON from `--data` flag in shell.**

Recommendation: Use **file input** (`@file.json`) exclusively for API calls with structured payloads.

---

## Next Steps for Future Sessions

1. **Before attempting lark-cli push:**
   - Check if lark-cli is in PATH: `which lark-cli`
   - If not, use absolute path: `/c/Users/皮玺玉/AppData/Roaming/npm/lark-cli`

2. **For Feishu汇报 API specifically:**
   - Test with simpler payload (plain text title + content, no emoji initially)
   - If `--data @file.json` fails, fall back to local archive + manual Feishu creation

3. **For scaling (多用户):**
   - Store user-specific lark-cli paths in config to avoid hardcoding
   - Validate PATH resolution at skill load time, not at push time

---

## Related Skills & Docs

- `daily-report-mozin/SKILL.md` — main skill
- `references/multiuser-auto-detection-pattern.md` — user identity detection (compatible with this fix)
- `references/feishu-report-api-query.md` —汇报 API details (success pattern when query works; push pattern TBD)
