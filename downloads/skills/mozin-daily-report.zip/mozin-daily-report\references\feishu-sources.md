# 飞书数据源 lark-cli 命令速查（v1.0.74+）

所有命令默认加 `--as user`。

## 日程

```bash
lark-cli calendar +agenda --as user
```

## 文档（含大纲深读）

```bash
# 搜索今日编辑的文档
lark-cli drive +search --edited-since 1d --mine --as user

# 读取文档大纲（不读全文，只读标题结构）
lark-cli docs +fetch --doc <token> --scope outline --as user
```

## 消息搜索

```bash
lark-cli im +messages-search \
  --query "PRD 评审 方案 需求 原型 交付" \
  --start "YYYY-MM-DDT00:00:00+08:00" \
  --end "YYYY-MM-DDT23:59:59+08:00" \
  --page-size 10 --as user
```

## 任务

```bash
# 获取我的任务（注意 is_completed 字段有 bug 永远返 false）
lark-cli task +get-my-tasks --as user

# 任务详情
lark-cli task tasks get --params '{"task_guid":"<guid>"}' --as user
```

## 会议纪要

```bash
lark-cli vc +search --start "YYYY-MM-DDT00:00:00+08:00" --end "YYYY-MM-DDT23:59:59+08:00" --as user
```

## 妙记（会议正文）

```bash
lark-cli minutes +search --query "产品 评审 方案" --owner-ids me --start "YYYY-MM-DD" --end "YYYY-MM-DD" --page-size 10 --as user
lark-cli minutes +detail --minute-tokens <token> --as user
# 注意：参数是 --minute-tokens，不是 --minute-id（v1.0.69+ 已改名）
```

## 审批

```bash
lark-cli approval tasks query --params '{"topic":"","status":"pending"}' --as user 2>/dev/null
lark-cli approval instances initiated --as user 2>/dev/null
```

## 飞书汇报（需要 report:task:readonly scope）

```bash
# 查询汇报记录（Unix 时间戳）
lark-cli api POST /open-apis/report/v1/tasks/query \
  --data '{"commit_start_time":<ts>,"commit_end_time":<ts>,"page_size":10,"page_token":"","rule_id":""}' \
  --params '{"user_id_type":"open_id"}' --as user

# 获取汇报规则列表
lark-cli api GET /open-apis/report/v1/rules/query \
  --params '{"rule_name":"","include_deleted":0}' --as bot
```

## 身份识别

```bash
lark-cli auth status
```

## 注意

- 飞书文档拉取用 `--doc`，不是 `--url`
- 命令间建议 sleep 0.3s 避免限流
- Windows PowerShell 5.1：管道用 `;` 不用 `&&`
