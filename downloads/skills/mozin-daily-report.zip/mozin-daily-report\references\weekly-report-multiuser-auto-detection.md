# 周报多用户自动检测机制 (v2.1)

## 问题背景

**之前**: 脚本硬编码了皮玺玉的 open_id (`ou_7d05b327389c521f51426312ac5c9e2b`)
- ❌ 其他用户无法使用（需手工修改源码）
- ❌ 多用户环境中无法按用户身份发送

**现在**: 自动检测当前 lark-cli 登录用户
- ✅ 任何登录用户都能使用，无需修改脚本
- ✅ 多用户场景：A 用户运行 → 发给 A；B 用户运行 → 发给 B
- ✅ Cron 环境兼容（每个用户的 cron 任务独立执行）

---

## 实现细节

### 核心函数：`get_current_lark_cli_user()`

**位置**: `scripts/weekly-report-cron.py` L205

**职责**:
1. 执行 `lark-cli auth status --json`
2. 解析 JSON 响应
3. 提取用户身份（支持多个字段名变体）
4. 返回结构化的用户信息

**返回值**:
```python
{
    "open_id": "ou_xxx",          # 飞书用户 ID
    "name": "username",            # 用户名
    "workspace": "workspace_name"  # CLI workspace
}
```

**失败返回**: `None`

---

## 异常处理

函数涵盖以下异常场景：

| 异常类型 | 触发条件 | 处理方式 |
|---------|---------|---------|
| `FileNotFoundError` | lark-cli 未安装或不在 PATH | 打印警告，返回 None |
| `JSONDecodeError` | 响应不是有效 JSON | 打印原始响应，返回 None |
| `TimeoutExpired` | lark-cli 命令超时（>10s） | 打印超时警告，返回 None |
| `subprocess.CalledProcessError` | 命令返回非零状态 | 打印错误消息，返回 None |
| 通用 `Exception` | 其他异常 | 捕获并打印，返回 None |

---

## 字段名兼容性

由于飞书 CLI 版本或不同环境的差异，JSON 响应可能包含不同的字段名。函数支持：

```python
user_id = status_data.get("user_id") or \
          status_data.get("open_id") or \
          status_data.get("id")
```

**支持的字段**:
- `user_id` （优先）
- `open_id`
- `id`

**用户名**:
- `user_name` （优先）
- `name`
- 默认值 `"unknown"`

**Workspace**:
- `workspace` （优先）
- `account`
- 默认值 `"default"`

---

## 集成点：`send_to_feishu_agent()`

**改进**（相对于 v2.0）:

```python
# v2.0 (硬编码)
"--to-user", "ou_7d05b327389c521f51426312ac5c9e2b"  # ❌ 固定用户

# v2.1 (动态)
user_info = get_current_lark_cli_user()              # ✅ 自动检测
if not user_info:
    return "[⚠️ ] 无法获取用户身份..."              # ✅ 优雅降级
user_open_id = user_info["open_id"]
"--to-user", user_open_id                            # ✅ 动态赋值
```

---

## 使用场景

### 场景 1：单用户主机
```
皮玺玉登录 → cron 运行
  ↓ 检测到: 皮玺玉 (ou_7d05b327...)
  ↓ 发送到: 皮玺玉
✅ 成功
```

### 场景 2：多用户共享主机
```
用户 A 登录 → A 的 cron 运行
  ↓ 检测到: 用户 A (ou_aaa...)
  ↓ 发送到: 用户 A

用户 B 登录 → B 的 cron 运行
  ↓ 检测到: 用户 B (ou_bbb...)
  ↓ 发送到: 用户 B

✅ 互不干扰
```

### 场景 3：多 Workspace 环境
```
用户 A (workspace=hermes) → 自动检测
  ↓ 使用 A 的 CLI 上下文
  ↓ 发送给 A

用户 B (workspace=custom) → 自动检测
  ↓ 使用 B 的 CLI 上下文
  ↓ 发送给 B

✅ 各自独立
```

---

## Cron 环境中的行为

Hermes Cron 系统在每个定时任务执行时：

1. 在 Hermes agent 上下文中运行脚本
2. 脚本调用 `get_current_lark_cli_user()`
3. 函数执行 `lark-cli auth status --json`
4. Hermes agent 有完整的 lark-cli token 上下文（keychain 可访问）
5. 用户信息被正确检测和传递

**关键点**: 不要在 `--no-agent` 模式下运行周报脚本（会导致 lark-cli token 无法访问）

---

## 向后兼容性

- ✅ 现有 Cron 任务无需修改
- ✅ 现有飞书消息格式保持不变
- ✅ 只是增强了用户检测，不破坏现有功能
- ✅ 如果检测失败，脚本优雅降级（不发送消息，记录警告）

---

## 验证（2026-08-31）

通过 ad-hoc 验证脚本确认：
- ✅ 脚本语法正确
- ✅ 所有必需函数已实现
- ✅ 调用链完整
- ✅ 异常处理完善
- ✅ 多用户逻辑正确

---

## 扩展点

### 可选：支持 `--to-user` 参数
```bash
# 指定接收者（而非自动检测）
python weekly-report-cron.py --to-user "ou_xxx"
```

### 可选：群组发送
```python
# 不仅发给个人，也发给团队群
--to-chat "oc_xxx"  # 群组 ID
```

### 可选：多接收者
```python
# 发给多个用户或群组
recipients = [user_open_id, "群组_id", "另一用户_id"]
```
