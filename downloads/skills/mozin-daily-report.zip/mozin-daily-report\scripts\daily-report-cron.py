#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日报自动生成 Cron 脚本 v3.0
每天 18:30 触发，五源采集：
  1. Git 同步
  2. 飞书数据（日程/任务/文档/妙记/审批）
  3. D:\AI 本地文件变动
  4. Edge 浏览器今日访问记录
  5. Hermes 今日会话摘要
生成三段草稿 → 存档 → 飞书 IM 通知
"""

import subprocess, datetime, os, json, time, sqlite3, shutil, glob

# ── 配置 ─────────────────────────────────────────────────
TODAY       = datetime.date.today().strftime("%Y-%m-%d")
TODAY_SHORT = datetime.date.today().strftime("%Y%m%d")
TODAY_DT    = datetime.datetime.combine(datetime.date.today(), datetime.time.min)
ARCHIVE_DIR = r"D:\AI\AI产品工作\汇报\daily"
ARCHIVE_FILE= os.path.join(ARCHIVE_DIR, f"皮玺玉_{TODAY_SHORT}_日报.md")


def get_last_report_time():
    """读取上一次日报文件的生成时间，作为本次采集起始点"""
    files = sorted(glob.glob(os.path.join(ARCHIVE_DIR, "皮玺玉_*_日报.md")))
    prev_files = [f for f in files if TODAY_SHORT not in f]
    if prev_files:
        mtime = os.path.getmtime(prev_files[-1])
        return datetime.datetime.fromtimestamp(mtime)
    return TODAY_DT  # 无历史文件，从今天00:00开始


SINCE_DT   = get_last_report_time()
SINCE_ISO  = SINCE_DT.strftime("%Y-%m-%dT%H:%M:%S+08:00")
SINCE_DATE = SINCE_DT.strftime("%Y-%m-%d")
FEISHU_UID   = "ou_7d05b327389c521f51426312ac5c9e2b"
LARK         = r"C:\Users\Administrator\AppData\Roaming\npm\lark-cli.cmd"
GIT_REPOS    = [r"D:\AI\AI产品工作\牧之音\Mozin-Android-MultiDevice-Prototype"]
HERMES_SESSIONS = r"D:\AI\hermes\runtime\sessions"
EDGE_HISTORY = os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\History")
LOCAL_SCAN_BASE = r"D:\AI"
LOCAL_SCAN_SKIP = {".git", "__pycache__", "node_modules", "cache", "image_cache", "audio_cache"}


def run(cmd, timeout=25):
    env = os.environ.copy()
    env["LARK_CLI_WORKSPACE"] = "hermes"  # 指定 lark-cli workspace，确保读到正确 token
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True,
                           text=True, timeout=timeout, encoding="utf-8", errors="replace",
                           env=env)
        return r.stdout.strip()
    except Exception:
        return ""


# ── Step 1: Git 同步 ─────────────────────────────────────
def git_sync():
    results = []
    for repo in GIT_REPOS:
        if not os.path.isdir(repo):
            results.append(f"[跳过] {os.path.basename(repo)} 路径不存在")
            continue
        out = run(f'git -c http.proxy= -C "{repo}" pull --ff-only 2>&1', timeout=30)
        results.append(f"[{os.path.basename(repo)}] {(out or 'Already up to date')[:80]}")
    return results


# ── Step 2: 飞书数据采集 ─────────────────────────────────
def collect_feishu():
    items = []

    def parse(raw, label):
        if not raw or len(raw) < 10 or "error" in raw[:60].lower():
            return
        try:
            data = json.loads(raw)
            inner = (data.get("data", {}).get("items")
                     or data.get("data", {}).get("files")
                     or data.get("data", {}).get("events")
                     or [])
            lines = []
            for i in inner[:6]:
                text = (i.get("summary") or i.get("name") or i.get("title") or "").strip()
                if text:
                    lines.append(text)
        except Exception:
            lines = [l.strip() for l in raw.splitlines() if l.strip()][:5]
        if lines:
            items.append((label, lines))

    cmds = [
        ("lark-cli calendar +agenda --as user", "飞书日程"),
        ("lark-cli task +get-my-tasks --as user", "飞书任务"),
        (f"lark-cli drive +search --edited-since 1d --mine --as user", "今日文档"),
        (f'lark-cli minutes +search --query "产品 评审 方案 需求 原型" --owner-ids me --start {SINCE_DATE} --end {TODAY} --page-size 10 --as user', "会议妙记"),
        (f'lark-cli im +messages-search --query "PRD 评审 方案 需求 原型 交付 验收" --start "{SINCE_ISO}" --end "{TODAY}T23:59:59+08:00" --page-size 15 --as user', "消息搜索"),
        ("lark-cli approval instances initiated --as user", "发起审批"),
    ]
    for cmd, label in cmds:
        parse(run(cmd, timeout=15), label)
        time.sleep(0.3)

    return items


# ── Step 3: 本地文件扫描（D:\AI 全量）──────────────────────
def collect_local():
    """扫描 D:\AI 下，从上次日报生成时间起的修改文件"""
    found = []
    try:
        for root, dirs, files in os.walk(LOCAL_SCAN_BASE):
            dirs[:] = [d for d in dirs if d not in LOCAL_SCAN_SKIP]
            for fname in files:
                fpath = os.path.join(root, fname)
                try:
                    mtime = datetime.datetime.fromtimestamp(os.path.getmtime(fpath))
                    if mtime >= SINCE_DT:
                        rel = os.path.relpath(fpath, LOCAL_SCAN_BASE)
                        found.append(rel)
                        if len(found) >= 15:
                            return found
                except Exception:
                    continue
    except Exception:
        pass
    return found


# ── Step 4: Edge 浏览器今日访问记录 ──────────────────────
def collect_edge():
    if not os.path.exists(EDGE_HISTORY):
        return []
    tmp = r"C:\Windows\Temp\edge_hist_daily.db"
    try:
        shutil.copy2(EDGE_HISTORY, tmp)
        conn = sqlite3.connect(tmp)
        epoch = datetime.datetime(1601, 1, 1)
        since_ts = int((SINCE_DT - epoch).total_seconds() * 1_000_000)
        rows = conn.execute(
            "SELECT title, url FROM urls WHERE last_visit_time > ? "
            "ORDER BY last_visit_time DESC LIMIT 30",
            (since_ts,)
        ).fetchall()
        conn.close()
        # 过滤掉无意义条目，只保留有标题的
        seen, result = set(), []
        for title, url in rows:
            title = title.strip()
            if not title or title in seen:
                continue
            # 跳过空白页/内部重定向
            if url.startswith("edge://") or url.startswith("about:"):
                continue
            seen.add(title)
            result.append(f"{title[:50]} ({url[:60]})")
        return result[:15]
    except Exception:
        return []


# ── Step 5: Hermes 今日会话摘要 ──────────────────────────
def collect_hermes_sessions():
    results = []
    # 兼容两种结构：sessions/<uuid>/messages.json 和 sessions/<uuid>.json
    patterns = [
        os.path.join(HERMES_SESSIONS, "**", "messages.json"),
        os.path.join(HERMES_SESSIONS, "**", "*.json"),
    ]
    seen_files = set()
    try:
        for pattern in patterns:
            for f in glob.glob(pattern, recursive=True):
                if f in seen_files:
                    continue
                seen_files.add(f)
                try:
                    mtime = datetime.datetime.fromtimestamp(os.path.getmtime(f))
                    if mtime < SINCE_DT:
                        continue
                    with open(f, encoding="utf-8", errors="replace") as fp:
                        data = json.load(fp)
                    msgs = data if isinstance(data, list) else data.get("messages", [])
                    for m in msgs:
                        if not isinstance(m, dict):
                            continue
                        if m.get("role") == "user":
                            content = m.get("content", "")
                            if isinstance(content, str) and len(content) > 10:
                                results.append(content[:120])
                            elif isinstance(content, list):
                                for c in content:
                                    if isinstance(c, dict) and c.get("type") == "text":
                                        t = c.get("text", "")[:120]
                                        if len(t) > 10:
                                            results.append(t)
                    if len(results) >= 10:
                        break
                except Exception:
                    continue
    except Exception:
        pass
    # 去重保序
    seen = set()
    deduped = []
    for r in results:
        if r not in seen:
            seen.add(r)
            deduped.append(r)
    return deduped[:10]


# ── Step 6: 构建三段草稿 ─────────────────────────────────
def build_sections(feishu_items, local_files, edge_items, hermes_items):
    L1 = [f"{TODAY}  皮玺玉 | 8h", "",
          "📊 总览：待确认  🟢? 🟡? 🟠? 🔴?", ""]

    # 飞书数据 → 项目推进
    if feishu_items:
        L1 += ["📦 项目推进", ""]
        for label, rows in feishu_items:
            L1.append(f"[{label}]")
            for i, row in enumerate(rows, 1):
                L1 += [f"  {i}. 🟡 {row} | 待确认",
                       "     证据：待补充",
                       "     下一步：待填写"]
            L1.append("")

    # Hermes 操作 → 工具基建
    if hermes_items:
        L1 += ["🛠️ 工具基建（Hermes操作）"]
        for i, h in enumerate(hermes_items[:5], 1):
            L1.append(f"  {i}. 🟢 {h} | 已完成")
        L1.append("")

    # 本地文件变动
    if local_files:
        L1 += ["📁 本地文件变动（D:\\AI）"]
        for i, f in enumerate(local_files[:8], 1):
            L1.append(f"  {i}. 🟢 {f} | 已修改")
        L1.append("")

    # Edge 浏览记录 → 研究调研
    if edge_items:
        L1 += ["🔍 研究调研（浏览记录）"]
        for i, e in enumerate(edge_items[:5], 1):
            L1.append(f"  {i}. 🔵 {e}")
        L1.append("")

    if not any([feishu_items, local_files, edge_items, hermes_items]):
        L1 += ["（暂无自动采集数据，请手动填写）", ""]

    s1 = "\n".join(L1)
    s2 = "P0 （待填写）\nP1 （待填写）\nP2 （待填写）"
    s3 = "无"
    return s1, s2, s3


# ── Step 7: 存档 ─────────────────────────────────────────
def save_draft(s1, s2, s3):
    os.makedirs(ARCHIVE_DIR, exist_ok=True)
    content = "\n".join([
        f"# 日报草稿 · {TODAY}",
        "> ⚠️ 自动生成草稿（五源采集），请核对修改后在飞书汇报提交", "",
        "---", "", "## 字段一：今日总结", "", s1, "",
        "---", "", "## 字段二：明日计划", "", s2, "",
        "---", "", "## 字段三：需要协调与帮助", "", s3, ""
    ])
    with open(ARCHIVE_FILE, "w", encoding="utf-8") as f:
        f.write(content)


# ── Step 8: 飞书 IM 通知 ─────────────────────────────────
def send_notify(s1, s2, s3, git_results, counts):
    git_txt = " | ".join(git_results[:2]) if git_results else "无变更"
    body = "\n".join([
        f"**📋 日报草稿已生成 · {TODAY}**",
        "",
        f"五源采集：飞书{counts[0]}条 | 本地{counts[1]}个文件 | 浏览{counts[2]}条 | Hermes{counts[3]}条",
        "",
        "**今日总结**",
        s1[:600],
        "",
        "**明日计划**",
        s2,
        "",
        "**需要协调与帮助**",
        s3,
        "",
        "---",
        f"Git: {git_txt}",
        f"草稿: {ARCHIVE_FILE}",
        "在 Hermes 说「写日报」可查看完整草稿修改后提交飞书汇报",
    ])
    env = os.environ.copy()
    env["LARK_CLI_WORKSPACE"] = "hermes"
    try:
        r = subprocess.run(
            [LARK, "im", "+messages-send",
             "--as", "user",
             "--user-id", FEISHU_UID,
             "--markdown", body],
            capture_output=True, text=True,
            timeout=20, encoding="utf-8", errors="replace",
            env=env
        )
        return r.stdout.strip() or r.stderr.strip()
    except Exception as e:
        return f"[ERROR] {e}"


# ── main ─────────────────────────────────────────────────
def main():
    print(f"[{TODAY}] 日报生成 v3.0 开始...")

    print("Step 1: Git 同步")
    git_results = git_sync()
    for r in git_results:
        print(f"  {r}")

    print("Step 2: 飞书数据采集")
    feishu_items = collect_feishu()
    feishu_count = sum(len(v) for _, v in feishu_items)
    print(f"  {len(feishu_items)} 类 / {feishu_count} 条")

    print("Step 3: 本地文件扫描 (D:\\AI)")
    local_files = collect_local()
    print(f"  {len(local_files)} 个修改文件")

    print("Step 4: Edge 浏览记录")
    edge_items = collect_edge()
    print(f"  {len(edge_items)} 条")

    print("Step 5: Hermes 会话摘要")
    hermes_items = collect_hermes_sessions()
    print(f"  {len(hermes_items)} 条")

    print("Step 6: 构建三段草稿")
    s1, s2, s3 = build_sections(feishu_items, local_files, edge_items, hermes_items)

    print("Step 7: 存档")
    save_draft(s1, s2, s3)
    print(f"  {ARCHIVE_FILE}")

    print("Step 8: 飞书 IM 通知")
    counts = (feishu_count, len(local_files), len(edge_items), len(hermes_items))
    result = send_notify(s1, s2, s3, git_results, counts)
    print(f"  {result[:120] if result else '无响应'}")

    print("完成。")


if __name__ == "__main__":
    main()
