# D盘 ACL 权限修复 + Git .git 恢复（重装系统后）

## D盘文件写入权限问题

### 症状
- `write_file` 报 `Permission denied: .hermes-tmp.xxxxx`
- `Set-Content` 报 `UnauthorizedAccessException`
- `icacls` 显示文件属于旧 SID，当前用户只有继承的 `(M)` 权限

### 根因
重装系统后旧用户 SID 持有文件所有权，新用户即使同名也是不同 SID。

### 修复（必须管理员 PowerShell）
```powershell
takeown /f "D:\AI\AI产品工作" /r /d Y
icacls "D:\AI\AI产品工作" /grant "皮玺玉:(OI)(CI)F" /t
```

### ⚠️ PowerShell icacls 坑
参数中的 `(OI)(CI)F` 必须**整体用引号包裹**：
```powershell
# ❌ 报错：OI 不能识别为 cmdlet（括号被当成子表达式）
icacls "D:\path" /grant 皮玺玉:(OI)(CI)F /t

# ✅ 正确
icacls "D:\path" /grant "皮玺玉:(OI)(CI)F" /t
```

### 验证
```powershell
Set-Content -Path "D:\AI\AI产品工作\汇报\daily\test.txt" -Value "ok"
Remove-Item "D:\AI\AI产品工作\汇报\daily\test.txt"
```

---

## Git .git 目录丢失恢复

### 症状
- `git status` 报 `fatal: not a git repository`
- 文件都在，只是 `.git` 消失（可能在磁盘坏道区域）

### 快速恢复（shallow clone + 移植）
```powershell
# 1. Shallow clone 到临时目录
git clone https://github.com/user/repo.git "原目录_tmp" --branch main --depth 1

# 2. 把 .git 移回原位
Move-Item "原目录_tmp\.git" "原目录\.git" -Force
Remove-Item "原目录_tmp" -Recurse -Force

# 3. 重设 git config（重装系统后丢失）
git -C "原目录" config user.email "user@noreply.github.com"
git -C "原目录" config user.name "username"

# 4. 验证
git -C "原目录" log --oneline -1
```

### 注意
- 如果仓库很大，加 `--depth 1 --single-branch` 减少下载量
- 移植后工作区文件可能显示为 modified（因为 shallow 只有最新 commit），用 `git checkout .` 或直接 add+commit 新状态
