# 飞书汇报 API — 查询已提交日报（2026-08-04 验证）

## 接口

```
POST /open-apis/report/v1/tasks/query
```

## 参数

| 名称 | 类型 | 必填 | 说明 |
|------|------|------|------|
| commit_start_time | int | 是 | Unix 时间戳（秒） |
| commit_end_time | int | 是 | Unix 时间戳（秒） |
| page_token | string | 是 | 首次传空字符串 "" |
| page_size | int | 是 | 1-20 |
| rule_id | string | 否 | 汇报规则 ID |
| user_id | string | 否 | open_id（指定查某人） |

## 皮玺玉的汇报规则

- rule_id: `7611748107898391753`
- rule_name: `工作日报`
- 字段: 今日总结(7611748107898440905)、明日计划(7611748107898457289)、需要协调与帮助(7611748107898473673)
- 汇报对象: 宋家明、莫代鹏、皮玺玉

## Python 调用代码

```python
import subprocess, os, json, datetime

env = os.environ.copy()
env['LARK_CLI_WORKSPACE'] = 'hermes'
LARK = r'C:\Users\皮玺玉\AppData\Roaming\npm\lark-cli.cmd'

def query_reports(start_date, end_date):
    """查询飞书汇报系统中指定日期范围的日报
    start_date, end_date: datetime.date 对象
    """
    start_ts = int(datetime.datetime.combine(start_date, datetime.time.min).timestamp())
    end_ts = int(datetime.datetime.combine(end_date, datetime.time(23,59,59)).timestamp())
    body = json.dumps({
        'commit_start_time': start_ts,
        'commit_end_time': end_ts,
        'page_token': '',
        'page_size': 20,
        'user_id': 'ou_7d05b327389c521f51426312ac5c9e2b'
    })
    r = subprocess.run(
        [LARK, 'api', 'POST', '/open-apis/report/v1/tasks/query',
         '--as', 'user', '--data', body],
        capture_output=True, text=True, timeout=30,
        encoding='utf-8', errors='replace', env=env)
    data = json.loads(r.stdout)
    return data.get('data', {}).get('items', [])
```

## 注意事项

1. **user token 调用时不分页**，直接返回所有结果
2. 不需要额外权限申请（已验证 user token 可用）
3. `commit_time` 是实际提交时间（可能补交，日期看 field_value 内容里的标注）
4. 返回的 `form_contents` 即为用户最终发布的日报全文

## 周报数据源规则（铁律）

**周报必须以飞书汇报系统中最终发布的日报内容为准归纳。**
- 智能体发送到飞书 IM 的卡片消息不是最终版
- 本地 daily/ 目录的 MD 文件也不是最终版
- 只有通过 report API 查到的 form_contents 才是权威数据源
