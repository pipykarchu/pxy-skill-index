# 从飞书汇报 API 生成精炼周报（2026-08-06 验证）

## 核心流程

1. **扩大时间范围拉取**：补交日报的 commit_time 在补交当天而非内容日期，所以查询范围要从目标周前2天到后7天
2. **按内容日期匹配**：在 field_value 文本中搜索目标日期（如 `07-27`、`2026-07-27`）
3. **按项目维度合并**（非按天罗列）：提取所有天的项目名→去重→每个项目汇总关键成果+状态
4. **精炼输出结构**：总览表→分项目详情→风险/协调汇总→下周计划

## Node.js 调用模式（Windows lark-cli）

```javascript
const { execSync } = require('child_process');
const start = Math.floor(new Date('2026-07-25T00:00:00+08:00').getTime()/1000);
const end = Math.floor(new Date('2026-08-04T23:59:59+08:00').getTime()/1000);
const data = JSON.stringify({commit_start_time:start, commit_end_time:end, page_token:'', page_size:20});
// Windows cmd 不支持单引号，必须转义双引号
const escaped = data.replace(/"/g, '\\"');
const cmd = `lark-cli api POST /open-apis/report/v1/tasks/query --data "${escaped}" --as user`;
const out = execSync(cmd, {encoding:'utf8', timeout:15000});
const result = JSON.parse(out);
```

## 补交日报匹配逻辑

```javascript
const weekDates = ['2026-07-27','2026-07-28','2026-07-29','2026-07-30','2026-07-31'];
const matched = items.filter(item => {
  const summary = item.form_contents.find(f => f.field_name === '今日总结');
  if (!summary) return false;
  return weekDates.some(d => summary.field_value.includes(d) || summary.field_value.includes(d.replace('2026-','')));
});
```

## 精炼周报输出格式

```markdown
# 皮玺玉 周报 YYYY-MM-DD ~ YYYY-MM-DD
> 部门 ｜ 工时 ｜ 产出统计

## 📊 本周总览（按项目）
| 项目 | 关键成果 | 状态 |

## 📦 分项目详情（每个项目独立 section）

## ⚠️ 本周风险与协调
| 事项 | 协调人 | 状态 |

## 📋 下周计划
| 优先级 | 事项 | 预计工时 |
```

## 关键陷阱

- commit_time ≠ 内容日期：7/29-31 补交的日报 commit_time 在 8/3
- rule_id 固定为 `7611748107898391753`（工作日报规则）
- page_token 首次必须传空字符串（不是不传）
- 权限 `report:task:readonly` 需单独授权
