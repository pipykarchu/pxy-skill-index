# 飞书卡片消息格式（2026-08-03 验证）

## 唯一可用格式：interactive 卡片

其他格式在"皮玺玉的飞书 CLI"智能体对话中的表现：
- `--markdown`：长内容被折叠成只显示标题的卡片，正文不可见 ❌
- `--text`：在该智能体对话里也看不到内容 ❌
- `--as user`：user 身份发的消息在该对话里完全不显示 ❌

## 正确调用方式（2026-08-05 更新：必须用 node run.js）

```python
import subprocess, os, json

# ⚠️ 绝不能用 lark-cli.cmd（中文长内容必败）
LARK_JS = r"C:\Users\皮玺玉\AppData\Roaming\npm\node_modules\@larksuite\cli\scripts\run.js"
UID = "ou_7d05b327389c521f51426312ac5c9e2b"
env = os.environ.copy()
env["LARK_CLI_WORKSPACE"] = "hermes"

card = {
    "config": {"wide_screen_mode": True},
    "header": {
        "title": {"tag": "plain_text", "content": "🗓 产品日报 · 2026-08-05"},
        "template": "blue"
    },
    "elements": [
        {"tag": "div", "text": {"tag": "lark_md", "content": body}}
    ]
}

r = subprocess.run(
    ["node", LARK_JS, "im", "+messages-send", "--as", "bot", "--user-id", UID,
     "--msg-type", "interactive", "--content", json.dumps(card, ensure_ascii=False)],
    capture_output=True, text=True, timeout=30,
    encoding="utf-8", errors="replace", env=env
)
```

## 关键参数

| 参数 | 值 | 说明 |
|------|---|------|
| `--as` | `bot` | 必须！user身份发的消息看不到 |
| `--msg-type` | `interactive` | 卡片消息类型 |
| `--content` | card JSON | 不是 `{"card": card}`，直接是 card 本身 |
| `--user-id` | UID | 发送给用户的 open_id |

## chat_id 对照

| 身份 | chat_id | 说明 |
|------|---------|------|
| bot → 用户 | `oc_3eab57d10ba96dbfbc6a19818a4d2b02` | "皮玺玉的飞书 CLI" 对话，消息可见 ✅ |
| user → 用户 | `oc_eff5d3d244...` | 不同的 chat，消息在智能体对话里不可见 ❌ |

## body 格式规范（lark_md 内容）

1. 工作总览用全角空格对齐，项目前加阿拉伯序号（1. 2. 3.）
2. 每条事项标题前加圈序号（①②③），全局递增
3. 格式：`①🟢 事项标题 ✅`
4. 每条事项下必须有：量化/进展/证据/下一步（至少2项）
5. 内容必须和本地 MD 存档完全一致，不做精简

## lark_md 支持的格式

- `**加粗**` ✅
- `- 列表` ✅
- `---` 分隔线 ✅
- emoji ✅
- 表格 ❌（用全角空格对齐代替）
