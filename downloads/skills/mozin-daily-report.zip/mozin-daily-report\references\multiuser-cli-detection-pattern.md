# Multi-User CLI Detection Pattern (v2.1 · 2026-08-31)

## Problem
CLI tools (e.g. `lark-cli`) are often per-user authenticated. Hardcoding user IDs (`ou_7d05b327...`) breaks when different users run the same script. Solution: **detect current user dynamically from CLI state**.

## Pattern: `get_current_lark_cli_user()`

### Core Implementation
```python
def get_current_lark_cli_user():
    """Detect the currently-authenticated lark-cli user."""
    result = subprocess.run(
        ["lark-cli", "auth", "status", "--json"],
        capture_output=True, text=True, timeout=10
    )
    
    if result.returncode != 0:
        return None  # Not authenticated or command missing
    
    status_data = json.loads(result.stdout)
    
    # Support multiple field names (API variance across versions)
    user_id = status_data.get("user_id") or status_data.get("open_id") or status_data.get("id")
    user_name = status_data.get("user_name") or status_data.get("name") or "unknown"
    workspace = status_data.get("workspace") or status_data.get("account") or "default"
    
    return {
        "open_id": user_id,
        "name": user_name,
        "workspace": workspace
    }
```

### Usage: Dynamic ID Injection

**Before** (hardcoded):
```python
cmd = [..., "--to-user", "ou_7d05b327..."]  # Only works for one user
```

**After** (dynamic):
```python
user_info = get_current_lark_cli_user()
if user_info:
    cmd = [..., "--user-id", user_info["open_id"]]  # Works for any user
```

### Error Handling Checklist

- [ ] **FileNotFoundError** — `lark-cli` not in PATH or not installed
  - Mitigation: Fall back to local-only mode (skip Feishu send, continue with archive)
- [ ] **JSONDecodeError** — Response format changed or unexpected
  - Mitigation: Log raw response, retry once, then degrade
- [ ] **TimeoutExpired** — Command hung (network issue, slow auth server)
  - Mitigation: Set reasonable timeout (10s), then skip Feishu send
- [ ] **KeyError on field names** — Field names vary across CLI versions
  - Mitigation: Use `.get()` with fallback chain; never assume field exists

### Field Name Variance (Observed)

| CLI Version | User ID Field | Name Field | Workspace Field |
|-------------|---------------|------------|-----------------|
| v1.0.76+ | `user_id` | `user_name` | `workspace` |
| Older | `open_id` | `name` | `account` |
| Future | (unknown) | (unknown) | (unknown) |

**Solution**: Always check multiple names in priority order:
```python
user_id = data.get("user_id") or data.get("open_id") or data.get("id")
```

## Generalization

This pattern applies to **any CLI-authenticated tool**:
- `github` CLI (`gh auth status`)
- `aws` CLI (`aws sts get-identity`)
- `gcloud` (`gcloud auth list`)
- `kubectl` (`kubectl config current-context`)

## Benefits

✅ Zero hardcoding — works for any user without modification  
✅ Immediate scalability — new users add themselves to `lark-cli`, scripts work  
✅ Auditability — user ID embedded in message metadata  
✅ Graceful degradation — missing auth doesn't crash, downgrades to local-only  

## Pitfalls

❌ **Don't cache `get_current_lark_cli_user()` across runs** — auth can change between invocations  
❌ **Don't assume field names** — always use `.get()` with fallback chain  
❌ **Don't ignore timeouts** — set explicit `timeout=` on subprocess.run  
❌ **Don't swallow exceptions silently** — print or log errors for debugging

## Related

- `daily-report-mozin` Skill: core implementation in `scripts/weekly-report-cron.py` (v2.1)
- Session context: 2026-08-31, multi-user weekly-report upgrade
