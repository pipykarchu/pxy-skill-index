# lark-cli Windows Subprocess 调用模式

## 问题

lark-cli 是通过 npm 安装的 `.cmd` 文件，在 Python `subprocess` 的参数列表形式（`["lark-cli", ...]`）中找不到，报 `[WinError 2] 系统找不到指定的文件`。

## 正确做法

### 1. 获取完整路径

```powershell
where.exe lark-cli
# 输出：C:\Users\Administrator\AppData\Roaming\npm\lark-cli.cmd
```

### 2. Python 中使用完整路径 + 参数列表

```python
import subprocess

LARK = r"C:\Users\Administrator\AppData\Roaming\npm\lark-cli.cmd"

# 参数列表形式（推荐，避免引号嵌套）
r = subprocess.run(
    [LARK, "im", "+messages-send",
     "--as", "user",
     "--user-id", "ou_xxx",
     "--markdown", "消息内容（可含换行）"],
    capture_output=True, text=True,
    timeout=20, encoding="utf-8", errors="replace"
)
print(r.stdout)
```

### 3. 验证成功

```json
{
  "ok": true,
  "identity": "user",
  "data": {
    "chat_id": "oc_xxx",
    "message_id": "om_xxx"
  }
}
```

## Token 限制（重要）

**Windows keychain token 无法被 Python subprocess 继承。**
即使设置 `LARK_CLI_WORKSPACE=hermes` 环境变量，subprocess 中调用 lark-cli 仍会报 `token_missing`。

这是 Windows keychain 安全隔离机制，不是配置问题。

**唯一可行方案：在 Hermes agent 上下文中调用 lark-cli（不用 subprocess）**，即 cron job 不加 `--no-agent`。

## 注意

- `--text-file` 参数不存在，长内容直接通过参数列表传 `--markdown`
- `shell=True` + 字符串拼接会有引号嵌套问题，优先用参数列表
- lark-cli 路径在 Administrator 账户下固定为 `C:\\Users\\Administrator\\AppData\\Roaming\\npm\\lark-cli.cmd`
- PowerShell 直接传含 `·`、`｜`、`**` 的 markdown 字符串给命令会被解析成位置参数报错，必须用 Python subprocess 参数列表传递
