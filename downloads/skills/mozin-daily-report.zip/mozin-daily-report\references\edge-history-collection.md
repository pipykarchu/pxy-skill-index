# Edge 浏览器历史采集（Python + SQLite）

## 原理

Edge 历史记录存储在 SQLite 数据库，路径固定：
```
%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\History
```

Edge 运行时会锁定该文件，必须先 `shutil.copy2()` 复制到临时路径再读取。

时间戳格式：**微秒数，从 1601-01-01 00:00:00 UTC 开始计算**（Windows FILETIME 格式）。

## 完整采集代码

```python
import sqlite3, shutil, os, datetime

def collect_edge_history(limit=20):
    src = os.path.expandvars(r'%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\History')
    tmp = r'C:\Windows\Temp\edge_hist_daily.db'
    if not os.path.exists(src):
        return []
    try:
        shutil.copy2(src, tmp)  # 必须复制，Edge 运行时锁定原文件
        conn = sqlite3.connect(tmp)

        # 计算今天 00:00 的 Edge 时间戳
        TODAY_DT = datetime.datetime.combine(datetime.date.today(), datetime.time.min)
        EPOCH = datetime.datetime(1601, 1, 1)
        today_ts = int((TODAY_DT - EPOCH).total_seconds() * 1_000_000)

        rows = conn.execute(
            "SELECT title, url FROM urls WHERE last_visit_time > ? "
            "ORDER BY last_visit_time DESC LIMIT ?",
            (today_ts, limit)
        ).fetchall()
        conn.close()

        # 去重 + 过滤无意义条目
        seen, result = set(), []
        for title, url in rows:
            title = title.strip()
            if not title or title in seen:
                continue
            if url.startswith("edge://") or url.startswith("about:"):
                continue
            seen.add(title)
            result.append({"title": title, "url": url})
        return result
    except Exception:
        return []
```

## 注意事项

- Edge 必须已在运行，否则 History 文件可能是空的（新启动 Edge 才会写入）
- 如果 Edge 未运行，`shutil.copy2` 仍能成功，但数据可能不是最新
- 临时文件路径 `C:\Windows\Temp\` 在 Cron 环境中可写
- 日期比较必须用 EPOCH = 1601-01-01，不是 Unix epoch (1970-01-01)

## 用于日报的过滤建议

从浏览记录中提取工作相关内容，过滤掉：
- `edge://` 内部页
- `about:blank`
- 广告/安装感谢页（`utm_source=`, `thank-you-for-installing`）
- 重复标题

保留：
- 飞书文档（`feishu.cn/docx/`）
- GitLab/GitHub（`github.com`, `118.196.129.116`）
- 本地运行的服务（`localhost:`）
- 飞书开放平台（`open.feishu.cn`）
