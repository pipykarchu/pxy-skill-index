# mozin-daily-report 对比与分工

> 来源：http://120.237.89.124:8929/rd-center/org-mag-sup/mozin-daily-report（v1.3.10，2026-08-07 下载）
> 安装路径：`D:\AI\AI产品工作\技能\skills\04-文档数据与汇报\mozin-daily-report\`

## 最终分工

| 场景 | 默认技能 | 原因 |
|---|---|---|
| 皮玺玉个人日报、周报、月报 | `daily-report-mozin` | 多源采集、本地归档、飞书发送、大小周和 Cron 更完整 |
| 团队日报、负责人/组长/PMO 汇总 | `mozin-daily-report` | 负责人模式和团队产出扫描更明确 |
| GitLab 事件、提交、MR 专项采集 | `mozin-daily-report` | GitLab API 双通道采集和作者校验更完整 |
| 飞书汇报 API 合并、补交、定时发送 | `daily-report-mozin` | 已有稳定的个人工作流与 Windows 经验 |

两个技能并存，不互相覆盖。

## mozin-daily-report v1.3.10 独有或更强能力

- 个人模式和负责人模式分流；负责人、组长、PMO 可额外扫描团队产出。
- 今日 GitLab push 事件和合并请求双通道采集。
- GitLab 查 `author`，会议查 `organizer`，任务查 `creator`，避免把团队产出算作个人产出。
- 飞书搜索按 `data.results` 解析，兼容 DOCX、BITABLE、SHEET、SLIDES。
- 六模块分类、项目阶段门禁、五色状态和飞书汇报三字段格式。
- 跨平台采集脚本和日报/周报模板。

## daily-report-mozin 独有或更强能力

| 能力 | 说明 |
|---|---|
| Windows/PowerShell 适配 | 有编码、命令、权限和 subprocess 的实测经验 |
| 日报/周报/月报全覆盖 | 包含月报、补交和多日汇总场景 |
| 飞书汇报 API | 能从权威汇报记录合并周报 |
| 本地归档与 Cron | 自动归档，支持大小周定时 |
| 飞书卡片发送 | 本地 Markdown 与飞书卡片内容一致 |
| 多源补全 | Edge、Hermes 会话、飞书群聊和 Wiki |

## 本次已融合

1. 修正飞书文档搜索：去掉不可靠的 `--mine` 组合，统一使用 `--format json` 和 `data.results`。
2. 加入 GitLab 事件/MR 降级采集流程。
3. 加入 `author`、`organizer`、`creator` 归属验证规则。
4. 保留两个技能各自优势，通过描述明确触发边界。
5. 新技能脚本只从环境变量读取 GitLab 令牌，不读取本机凭据文件。

## 共同执行底线

- 不把未经验证的飞书链接当证据。
- 每项产出提供数字或可检查的结果。
- 飞书汇报文本框不输出 Markdown 表格。
- 日报与周报使用各自模板，不混用。
- 缺 `report:task:readonly` 时明确提示，不伪造 API 结果。
- 不从 `.git-credentials` 自动提取令牌，只接受环境变量注入。
- 不把“参加/收到”写成“主持/完成”，必须核对归属字段。
