#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ad-hoc Verification Template for Report Generation & Multi-User Features
Copy this template and adapt it for new skill versions or environments.

Usage:
  python verify-report-skill.py
  
Expected output: 4/4 checks pass
"""

import sys
import subprocess
from pathlib import Path

SCRIPT_TO_TEST = Path(r"REPLACE_WITH_SCRIPT_PATH")  # e.g. weekly-report-cron.py

def test_syntax():
    """Check Python syntax is valid."""
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(SCRIPT_TO_TEST)],
        capture_output=True, timeout=5
    )
    return result.returncode == 0

def test_imports():
    """Check script can be imported without errors."""
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("m", SCRIPT_TO_TEST)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        # Check for critical functions
        return all(hasattr(m, f) for f in [
            "is_big_week",
            "collect_daily_reports",
            "generate_weekly_report",
            "get_current_lark_cli_user",  # Multi-user detection
        ])
    except Exception as e:
        print(f"  Import failed: {e}")
        return False

def test_multiuser_detection():
    """Check multi-user detection function exists and has proper structure."""
    content = SCRIPT_TO_TEST.read_text()
    checks = [
        ("def get_current_lark_cli_user", "Function definition"),
        ("lark-cli auth status", "CLI invocation"),
        ("json.loads", "JSON parsing"),
        ("user_info.get", "Field extraction with fallback"),
    ]
    return all(check in content for check, _ in checks)

def test_execution():
    """Try to execute core functions."""
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("m", SCRIPT_TO_TEST)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        
        # Test big-week detection
        from datetime import date
        result = m.is_big_week(date(2026, 8, 5))
        return isinstance(result, bool)
    except Exception as e:
        print(f"  Execution failed: {e}")
        return False

def main():
    print("=" * 70)
    print("🔍 Report Skill Verification Template")
    print("=" * 70)
    
    if not SCRIPT_TO_TEST.exists():
        print(f"❌ Script not found: {SCRIPT_TO_TEST}")
        return 1
    
    tests = [
        ("Syntax Check", test_syntax),
        ("Import & Functions", test_imports),
        ("Multi-User Detection", test_multiuser_detection),
        ("Execution Test", test_execution),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            passed = test_func()
            status = "✅" if passed else "❌"
            print(f"{status} {name}")
            results.append(passed)
        except Exception as e:
            print(f"❌ {name}: {e}")
            results.append(False)
    
    print("=" * 70)
    passed_count = sum(results)
    total = len(results)
    print(f"Result: {passed_count}/{total} checks passed")
    
    return 0 if passed_count == total else 1

if __name__ == "__main__":
    sys.exit(main())
