#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量上传MD文件到飞书文件夹
使用 lark-cli docs +create
"""

import os
import sys
import subprocess
import json
from pathlib import Path
from datetime import datetime
import time

def main():
    # ======== 配置参数（可自定义） ========
    source_dir = r"D:\AI\AI产品工作\牧之音\Mozin 产品研讨中心\2.0版（全设备）\Mozin_2.0_交付规格包_V1.0"
    parent_token = "JqkKf9ewXlsBP1dQErJcDF8gnfw"
    # ====================================
    
    print("=" * 50)
    print("📤 飞书MD文档批量导入工具")
    print("=" * 50)
    
    source_path = Path(source_dir)
    if not source_path.exists():
        print(f"❌ 源目录不存在: {source_dir}")
        return 1
    
    # 获取所有MD文件
    md_files = sorted(source_path.glob("**/*.md"))
    print(f"\n📋 找到 {len(md_files)} 个MD文件")
    
    if not md_files:
        print("⚠️  未找到MD文件")
        return 0
    
    success = 0
    failed = 0
    created = []
    errors = []
    
    print("\n🚀 开始上传...\n")
    
    for idx, md_file in enumerate(md_files, 1):
        file_name = md_file.stem
        rel_path = md_file.relative_to(source_path)
        file_size = md_file.stat().st_size
        size_str = f"{file_size / 1024 / 1024:.1f}MB" if file_size > 1024*1024 else f"{file_size / 1024:.1f}KB"
        
        print(f"[{idx}/{len(md_files)}] 📄 {rel_path} ({size_str})")
        
        # 读取文件内容
        try:
            with open(md_file, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            print(f"    ❌ 读取文件失败: {e}")
            failed += 1
            errors.append({"file": str(rel_path), "error": f"读取失败: {e}"})
            continue
        
        print("    ↳ 创建云文档...", end=" ", flush=True)
        
        try:
            # 调用lark-cli创建文档
            cmd = [
                "lark-cli", "docs", "+create",
                "--title", file_name,
                "--parent-token", parent_token,
                "--content", content,
                "--doc-format", "markdown"
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode != 0:
                print(f"❌")
                error_msg = result.stderr[:150] if result.stderr else "未知错误"
                print(f"    错误: {error_msg}")
                failed += 1
                errors.append({"file": str(rel_path), "error": error_msg})
                continue
            
            # 解析JSON响应
            try:
                response = json.loads(result.stdout)
                if response.get("ok") and response.get("data", {}).get("document"):
                    doc_id = response["data"]["document"]["document_id"]
                    doc_url = response["data"]["document"]["url"]
                    
                    print("✓")
                    print(f"    📍 文档ID: {doc_id}")
                    print(f"    🔗 链接: {doc_url}\n")
                    
                    success += 1
                    created.append({
                        "name": file_name,
                        "path": str(rel_path),
                        "id": doc_id,
                        "url": doc_url
                    })
                else:
                    print(f"❌")
                    error_msg = response.get('error', {}).get('message', '未知错误')
                    print(f"    创建失败: {error_msg}")
                    failed += 1
                    errors.append({"file": str(rel_path), "error": error_msg})
            except json.JSONDecodeError as e:
                print(f"❌")
                print(f"    JSON解析错误: {e}")
                failed += 1
                errors.append({"file": str(rel_path), "error": f"JSON解析错误: {e}"})
        
        except subprocess.TimeoutExpired:
            print("❌")
            print("    超时（30秒）")
            failed += 1
            errors.append({"file": str(rel_path), "error": "命令超时"})
        except Exception as e:
            print(f"❌")
            print(f"    错误: {e}")
            failed += 1
            errors.append({"file": str(rel_path), "error": str(e)})
        
        # 限流
        if idx < len(md_files):
            time.sleep(0.8)
    
    # 输出总结
    print("")
    print("=" * 50)
    print("✅ 上传完成")
    print("=" * 50)
    print(f"✓ 成功: {success}/{len(md_files)}")
    print(f"✗ 失败: {failed}/{len(md_files)}")
    print("")
    
    if created:
        print(f"📋 已上传的文档 ({len(created)}个):")
        print("")
        for doc in created:
            print(f"  ✓ {doc['name']}")
            print(f"     路径: {doc['path']}")
            print(f"     文档ID: {doc['id']}")
            print(f"     链接: {doc['url']}")
            print("")
    
    if errors:
        print(f"⚠️  失败的文件 ({len(errors)}个):")
        print("")
        for err in errors:
            print(f"  ❌ {err['file']}")
            print(f"     错误: {err['error']}")
            print("")
    
    print("=" * 50)
    
    return 0 if failed == 0 else 1

if __name__ == "__main__":
    sys.exit(main())
