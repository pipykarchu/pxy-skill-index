#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mozin 日报发送脚本（皮玺玉版本 v2.0 — 2026-08-10 修正）
功能：读取本地 Markdown 日报 → 通过 node run.js P2P 发给皮玺玉自己
关键修正：
  1. 用 --user-id P2P 发自己，不发现群
  2. 用 --markdown 纯文本，不用卡片 JSON
  3. 用 Python subprocess 调 node run.js，不用 PowerShell（长内容会被拆成位置参数）
"""

import json
import subprocess
import sys
import os
from datetime import datetime
from pathlib import Path

# 皮玺玉的固定配置
LARK_JS = r"C:\Users\皮玺玉\AppData\Roaming\npm\node_modules\@larksuite\cli\scripts\run.js"
UID = "ou_7d05b327389c521f51426312ac5c9e2b"  # 皮玺玉 open_id

def read_daily_report(date_str=None):
    """读取今天或指定日期的日报文件"""
    if not date_str:
        date_str = datetime.now().strftime("%Y%m%d")

    daily_dir = Path("daily")
    filename = f"皮玺玉_{date_str}_日报.md"
    filepath = daily_dir / filename

    if not filepath.exists():
        print(f"❌ 日报文件不存在：{filepath}")
        return None

    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    print(f"✅ 已读取日报：{filename}（{len(content)} 字符）")
    return content

def send_to_feishu(content):
    """通过 node run.js P2P 发给皮玺玉自己"""
    env = os.environ.copy()
    env["LARK_CLI_WORKSPACE"] = "hermes"

    print(f"\n📤 P2P 发送到皮玺玉飞书（user_id: {UID}）...")

    r = subprocess.run(
        ["node", LARK_JS, "im", "+messages-send", "--as", "bot",
         "--user-id", UID, "--markdown", content],
        capture_output=True, text=True, timeout=30,
        encoding="utf-8", errors="replace", env=env
    )

    if r.stdout:
        try:
            resp = json.loads(r.stdout)
            if resp.get("ok"):
                msg_id = resp.get("data", {}).get("message_id", "N/A")
                print(f"✅ 发送成功！消息 ID：{msg_id}")
                return True
            else:
                print(f"⚠️ API 返回错误：{resp.get('error', {})}")
        except json.JSONDecodeError:
            print(f"响应：{r.stdout[:300]}")

    if r.stderr:
        print(f"STDERR: {r.stderr[:300]}")

    return False

def main():
    print("=" * 60)
    print("🗓  Mozin 日报发送 - 皮玺玉 v2.0")
    print("=" * 60)

    content = read_daily_report()
    if not content:
        print("\n💡 用法：python send_daily_to_feishu.py [YYYYMMDD]")
        sys.exit(1)

    success = send_to_feishu(content)

    print("\n" + "=" * 60)
    if success:
        print("✅ 日报已发送到皮玺玉飞书")
    else:
        print("⚠️ 发送失败，请检查 lark-cli 认证状态")
    print("=" * 60)

    return 0 if success else 1

if __name__ == "__main__":
    os.chdir(r"D:\AI\AI产品工作\汇报")
    sys.exit(main())
