# AGENTS.md — 产研中心日报/周报生成指令

> 本文件是 Codex / Claude Code / OpenCode 等通用 AI 编程助手的入口。
> Hermes 用户请使用 `SKILL.md`（功能更完整：SubAgent 并行采集 + 会话记录源）。

## 触发条件

用户说：`写日报` / `写周报` / `生成日报` / `生成周报` / `今日日报` / `本周周报`

## 前置依赖（全员必装，一次性）

日报自动生成依赖两个外部系统：**飞书**（lark-cli）和 **GitLab**（MR/提交数据）。两者都必须配置好，缺一个就采不全数据。

### A. lark-cli（飞书数据源，必装）

lark-cli 是 Node.js 脚本，跨平台（Windows/macOS/Linux 通用）。所有飞书数据采集（日程/文档/任务/会议/妙记/审批/日报）都依赖它。

**1. 安装 Node.js**（如未安装）：从 https://nodejs.org 下载 LTS 版。

**2. 安装 lark-cli**（npm 包名 `@larksuite/cli`）：
```bash
npm install -g @larksuite/cli
lark-cli --version   # 确认安装成功（如 1.0.82）
```

**3. 登录授权**（首次必做，一次性）：
```bash
lark-cli auth login
```
- 弹出授权链接，用飞书 App 扫码或打开链接确认
- 完成后验证：`lark-cli auth status` 应显示你的姓名和 scope

**4. 授权日报查询 scope**（生成周报时读取本周已提交日报需要）：
```bash
# 检查是否已有 report:task:readonly
lark-cli auth status | grep -o report:task:readonly

# 没有则发起设备授权，生成授权链接：
lark-cli auth login --scope "report:task:readonly" --no-wait --json
# 返回 verification_url + device_code，用户打开链接授权后：
lark-cli auth login --device-code "<device_code>"
```
> ⚠️ 需要在飞书开放平台将 `report:task:readonly` 权限添加到应用后再操作。
> 详情见 `references/feishu-report-auth.md`。

### B. GitLab 访问（代码数据源，必装）

日报中「今日 Git 提交 / MR」来自公司 GitLab：`http://120.237.89.124:8929`。两种访问方式任选其一：

**方式 1：GitLab MCP（Hermes 用户推荐）**
```bash
hermes mcp add gitlab --env GITLAB_URL=http://120.237.89.124:8929 GITLAB_PERSONAL_ACCESS_TOKEN=<你的token> --command npx --args -y @modelcontextprotocol/server-gitlab
```
配置后 Hermes 可直接调用 GitLab 的 9 个工具（search_repositories / get_file_contents / create_issue / create_merge_request 等）。

**方式 2：GitLab API（Codex / 其他 agent 通用）**
```bash
# 生成自己的 Personal Access Token（GitLab 右上角头像 → Preferences → Access Tokens）
# scope 至少勾选：read_api、read_repository
export GITLAB_URL="http://120.237.89.124:8929"
export GITLAB_TOKEN="glpat-你的token"

# 拉今日我的提交（按项目，注意用 created_after 参数 + 北京时间，after 有边界 bug）
curl -s -H "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "$GITLAB_URL/api/v4/events?created_after=<today>T00:00:00%2B08:00&scope=push" | jq '.[] | {project: .project.path_with_namespace, action: .action_name, target: .target_title}'

# 拉我参与/创建的 MR（state=opened/merged）
curl -s -H "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "$GITLAB_URL/api/v4/merge_requests?scope=all&state=all&per_page=50" | jq '.[] | select(.author.username=="<你的用户名>") | {title, state, merged_at}'
```

> 💡 也可以 clone 项目到本地后用 `git log` / `git status` 直接看，但 MR 创建/合并记录必须走 GitLab API 或 MCP。

**5. 验证采集**：
```bash
python3 scripts/collect_data.py   # 或直接 lark-cli calendar +agenda --as user 看能否拉到数据
```

**常见问题**：
- `command not found: lark-cli` → npm 全局 bin 目录没进 PATH，或安装失败
- `lark-cli` 卡在登录 → 确认飞书 App 能打开授权链接
- 报 `missing_scope report:task:readonly` → 按步骤 4 补授权
- GitLab API 返回 401 → token 过期或 scope 不足，重新生成
- GitLab 事件拉不到今天的 → 确认用了 `created_after` 参数（不是 `after`）且时区是 `+08:00`
- 群聊读不到（code 230001）→ 内部项目群跨租户不可读，跳过该源不报错，不阻塞流程
- 产出没有飞书链接 → 本地文件路径也是有效证据，如实写路径，不要编造链接

## 开始前：强制确认日期

**先执行 `date '+%Y-%m-%d'` 确认今天日期**，不要从会话标题推断。凌晨 0:00-6:00 用户说「今天」时，询问是前一天还是当天。

## 工作流

### Step 1: 身份识别

```bash
# 从 lark-cli auth status 获取飞书用户姓名（lark-cli 是 Node 脚本，跨平台）
lark-cli auth status 2>&1 | grep -o '"userName":"[^"]*"' | cut -d'"' -f4
# 备用：git config user.name
```

**身份类型判断**（影响数据采集范围，面向产研中心全员）：
```bash
# 查用户飞书部门/岗位
lark-cli contact +search-user --user-ids "<open_id>" --as user 2>/dev/null || echo '{"data":{"users":[{"department":""}]}}'
```
- 判定为 **负责人模式**（额外拉团队产出）：部门含「总经理办公室」「总经办」「管理层」「负责人」「总监」「CEO」「中心负责人」，或岗位含「组长」「PMO」「主管」
- 判定为 **个人模式**（只看自己）：其余所有成员（PM/工程师/测试/运维/设计师）
- 无法判定 → 默认 **个人模式**（安全兜底，不越权采集他人数据）
- ⚠️ 判定依据是「角色是否带团队管理职责」，不是部门

### Step 2: 数据采集（五源）

用 lark-cli（Node 脚本，Windows/macOS/Linux 通用）并行拉取：

| 源 | 命令 |
|---|---|
| 日程 | `lark-cli calendar +agenda --as user` |
| 今日文档/表格 | `lark-cli drive +search --edited-since 1d --as user --format json`（⚠️ 不要用 `--mine`，该组合有 bug 返回 0 条且漏自己编辑的；解析 `data.results` 字段；含多维表格 BITABLE） |
| 任务 | `lark-cli task +get-my-tasks --as user` |
| 会议纪要 | `lark-cli vc +search --start <today>T00:00:00+08:00 --end <today>T23:59:59+08:00 --as user`（结果含 AppLink）→ **妙记链接用 `lark-cli vc +recording --meeting-ids <id>`**（返回 recording_url，可直接作为证据） |
| 妙记 | `lark-cli minutes +search --query "产品 评审 方案" --owner-ids me --start <today> --end <today> --as user`（需 `minutes:minutes.basic:read` scope） |
| **GitLab 提交/MR** | 方式 1（Hermes）：GitLab MCP 工具查我的 MR/提交；方式 2（通用）：`curl` GitLab API `/events?created_after=<today>T00:00:00%2B08:00&scope=push` + `/merge_requests`（见「前置依赖 B」，⚠️ 必须用 created_after + 北京时区，after 有边界 bug） |
| 本地 Git | 扫本地含 `.git` 的目录：`git log --since="<today> 00:00" --format="%h %s"` |
| 本地文件 | 扫 `~/Documents` + `~/Desktop` + 当前目录 24h 内修改的所有文件（排除 .git/node_modules/vendor/target/venv/.DS_Store/*.pyc），不限于产品文档——表格/截图/PDF 都可能是产出 |
| 会话/AI 工具记录 | Hermes 用户：`session_search`；Codex/Claude Code/OpenCode 用户：查各自会话历史文件（~/.codex/sessions/、~/.claude/projects/、~/.local/share/opencode/）；兜底：今日新建文件+Git 提交 |

**负责人/组长额外**：拉团队成员的飞书汇报日报（`/open-apis/report/v1/tasks/query`）+ 不限作者的项目文档搜索 + GitLab 全组 MR（`/merge_requests?scope=all&state=merged&author_username=<成员>`）。

**无终端权限的 AI 工具**：不支持自动采集。产研中心统一使用 Hermes / Codex / Claude Code / OpenCode 等具备终端能力的工具。

### Step 2.5: GitLab 未配置时的降级处理（重要）

**采集前先检测 GitLab 是否可用**：

| 检测方式 | 判断条件 |
|---------|---------|
| 环境变量 | `GITLAB_URL` 和 `GITLAB_TOKEN` 是否已设置且指向 `120.237.89.124:8929` |
| MCP 工具 | Hermes 用户：`mcp_gitlab_*` 工具是否在工具列表（`hermes mcp list`） |
| 凭证文件 | `~/.git-credentials` 或 `~/.netrc` 是否含 `120.237.89.124` 的 token |
| API 冒烟 | `curl -s -o /dev/null -w "%{http_code}" -H "PRIVATE-TOKEN: $TOKEN" http://120.237.89.124:8929/api/v4/user` 返回 200 |

**未配置时（任何一项不满足），按以下流程处理：**

1. **提示用户**（不阻塞、不报错）：
   ```
   ⚠️ 未检测到 GitLab 访问配置（GITLAB_TOKEN 未设置或指向旧服务器）。
   日报将暂时缺少「GitLab 提交/MR」数据源。
   如需补全，请：
   ① 在 GitLab(http://120.237.89.124:8929) 右上角头像 → Preferences → Access Tokens 生成 Personal Access Token（scope: read_api, read_repository）
   ② 设置环境变量：export GITLAB_TOKEN=glpat-xxx
   ③ 或配置 Hermes GitLab MCP（见「前置依赖 B」）
   ```
2. **继续生成** — 用其余源（飞书/本地 Git/本地文件/会话记录）正常生成日报，不中断
3. **GitLab 源标注** — 日报中涉及代码/MR 的部分标注「待补充：GitLab 未配置」，不编造 MR 数据

**已配置但访问失败**（401/token 过期/旧地址）：同样提示用户检查 token 有效期，GitLab 源标「待补充」，其余照常。

> ⚠️ 禁止：因 GitLab 未配置而拒绝生成日报，或编造 MR/提交数据。日报宁可缺一个源，不可造假。

### Step 3: 合并去重 + 链接验证

- 同一产出在飞书/本地/Git 出现多次 → 只保留一次
- **飞书链接必须验证**：`lark-cli docs +fetch --doc "<token>" --scope outline --as user` 返回 ok:true 才能放
- 没有飞书链接时，本地路径也是有效证据

### Step 4: 填充模板

使用 `templates/daily.md`（日报）或 `templates/weekly.md`（周报）。

**五色自评（审查标识标准 V2.0）**：

| 色 | 含义 | 判定标准 | 闭环规则 |
|:--:|------|---------|---------|
| 🔴 | 拒绝/阻塞 | 事实错误、逻辑矛盾、无法执行、触及合规红线 | 直接打回修正 |
| 🟠 | 质疑/待补充 | 主张有道理但缺可验证数据；推论跳跃 | 3 个工作日内补充来源 |
| 🟡 | 待决策 | 逻辑通顺但依赖他人决策；低风险 | 指定验证责任人 + 截止日期 |
| 🟢 | 正常推进 | 来源可追溯、逻辑完整、明确可行 | 直接进入执行 |
| 🔵 | 锚定目标 | 与核心目标完全一致；战略方向正确 | 最高优先级——标蓝后其他颜色不构成否决 |

边界规则：🔵 覆盖一切 → 🔴 优先于 🟠🟡 → 不同分句可不同色。

**量化铁律**：每条产出带数字（行数/功能数/页面数），禁止编造。
**证据铁律**：每条产出附验证通过的飞书链接或本地路径。

### Step 4.5: 证据链接验证（关键步骤）

**每项产出的飞书链接必须经过实际验证才能放入日报：**
```bash
# 验证文档链接（用 docs +fetch 读大纲验证）
lark-cli docs +fetch --doc "https://dcna5xbs8p29.feishu.cn/docx/<token>" --scope outline --as user
# 验证文件夹链接
lark-cli drive +inspect --url "https://www.feishu.cn/drive/folder/<token>" --as user
```

**硬规则**：
- ✅ **证据必须是完整可点击 URL**，禁止只贴 token 或写「同上」「见上」等指代
- ✅ **每条产出标注归属**：GitLab 用 author 字段、会议用 organizer 字段验证是否本人产出；他人组织的会议如实写「参加」，不得默认为己功
- ✅ 只放验证通过的飞书链接（`docs +fetch` 或 `drive +inspect` 返回 `ok: true`）
- ✅ 本地文件用相对路径（如 `公司管理/公司培训/01-入职培训SOP.md`）
- ❌ 禁止放未经验证的链接。搜不到/打不开，诚实写「本地文件」或「待补充」
- ❌ 禁止从会话摘要或文件列表中抄一个 token 过来当证据
- ❌ 禁止写「同上」「同上仓库」「见上」这类无法点击的指代

**找不到飞书链接时**：用 `session_search` 查用户今天发过的文档 URL、或 `drive +search` 按标题搜，两者都没有才用本地路径。

### Step 4.8: 特殊场景处理

| 场景 | 处理 |
|------|------|
| **某数据源拉取失败** | 标注「⚠️ 未拉取到 XX 数据（原因：...）」，不阻塞整体流程 |
| **今日无产出** | 诚实输出「📭 今日无产品产出」，不做假数据 |
| **不确定五色** | 宁可标 🟡 待确认，不硬标 🟢 |
| **未关联项目** | 归入「🧩 跨项目事项」分组 |
| **GitLab 未配置** | 见 Step 2.5：提示申请 token → 源标「待补充：GitLab 未配置」 |

### Step 5: 输出（纯文本，禁止 Markdown 表格）

```
🗓 产研日报 日期 ｜ 姓名 ｜ 工时 ｜ 抄送

📊 今日工作总览（项目 ｜ 产出数 ｜ 🔴🟠🟡🟢 分布）

🔸 项目名 [阶段名｜状态]

🟢 产出标题
- 量化：具体数字
- 证据：飞书链接（须验证通过）

📋 明日计划

1. P0 事项描述
2. P1 事项描述

🤝 需要协调与帮助

1. 事项 ｜ 需要谁 ｜ 具体需求 ｜ 时限
```

**⚠️ 明日计划/需要协调每条独立一行 + 编号**（`1. 2. 3.`）——飞书文本框复制换行可能折叠，编号防 P0/P1/P2 混成一团。

**周报差异**：加 `🕐 本周工时（各项目人天）`、`⚠️ 未按计划完成（原因+补救）`、`🔵 战略对齐（OGSM）`、下周计划到项目/里程碑。

## 硬规则

1. **不可空白** — 每人每天必须提交，20:00 前
2. **日报即看板** — 不写工作日报等于没工作
3. **禁止编造** — 产出和链接都必须真实，链接必须验证通过
4. **量化+证据** — 每条产出带数字和链接
5. **纯文本输出** — 飞书汇报是文本框，Markdown 表格/多级标题粘贴会散架
6. **不输出装饰标签** — 不要「⚠️ 粘贴到字段X」等说明

## 提交

- 飞书「汇报」功能提交，20:00 前
- 抄送：按各岗位规范
- 各线组长每日检查，PMO线组长每周抽查（连续 3 天空白上报中心负责人）

## 文件清单

| 文件 | 用途 |
|------|------|
| `AGENTS.md` | 本文件 — Codex/Claude Code/OpenCode 入口 |
| `SKILL.md` | Hermes 用户入口（SubAgent 并行采集，功能最全） |
| `templates/daily.md` / `weekly.md` | 输出模板 |
| `references/doc1_spec.md` | 规范原文摘要（五色 V2.0） |
| `references/feishu_sources.md` | lark-cli 命令速查 |
| `scripts/collect_data.py` | 数据采集脚本（Python 3，跨平台） |
