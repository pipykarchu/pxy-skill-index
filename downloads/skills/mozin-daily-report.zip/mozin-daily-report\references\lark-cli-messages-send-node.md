# lark-cli im +messages-send via Node.js (2026-08-07 验证)

## 核心发现

lark-cli 1.0.76 中：
- ❌ `lark-cli im send` — 不存在
- ❌ `lark-cli report` — 不存在  
- ✅ `lark-cli im +messages-send` — 正确命令

## 支持的参数

```
--chat-id string    (required, 与 --user-id 互斥) 群聊 ID (oc_xxx)
--user-id string    (required, 与 --chat-id 互斥) 用户 open_id (ou_xxx)
--markdown string   markdown 文本（自动包装为 post 格式，图片 URL 自动解析）
--content string    message content JSON
--msg-type string   消息类型（默认 text）
```

## 发送方式（必须用 node run.js）

.cmd 包装器遇到中文长内容必败（参数截断/编码错误）。唯一可靠方式：

```javascript
const { execFileSync } = require('child_process');
const path = require('path');

const larkDir = path.join(process.env.APPDATA || '', 'npm', 'node_modules', '@larksuite', 'cli');
const runJs = path.join(larkDir, 'scripts', 'run.js');

const md = `你的 markdown 内容`;

const args = ['im', '+messages-send', '--chat-id', 'oc_3eab57d10ba96dbfbc6a19818a4d2b02', '--markdown', md];

const result = execFileSync('node', [runJs, ...args], {
  encoding: 'utf8',
  timeout: 15000,
  env: { ...process.env, LARK_CLI_WORKSPACE: 'hermes' }
});
console.log(result);
```

## 关键注意

1. `LARK_CLI_WORKSPACE: 'hermes'` 必须设置，确保读到正确 token
2. `--markdown` 比 `--content` 更方便——无需手动构建 JSON
3. 发送到个人聊天用 `--chat-id oc_3eab57d10ba96dbfbc6a19818a4d2b02`（皮玺玉的飞书 CLI）
4. 成功返回 JSON 含 `"ok": true` + `message_id`
5. 文件保存为 `.js`，通过 `node "C:\Windows\Temp\xxx.js"` 执行（write_file 的 lint 路径解析有 bug 但实际执行无问题）
