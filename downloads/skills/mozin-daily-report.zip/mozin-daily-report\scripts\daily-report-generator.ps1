# 日报自动生成脚本 — 每日 18:30 执行
# 依赖: lark-cli, Hermes Agent, PowerShell 5.1+

param(
    [string]$PersonName = "皮玺玉",
    [string]$WorkDir = "D:\AI\AI产品工作",
    [string]$ReportDir = "$WorkDir\汇报"
)

# ============ 1. 数据收集 ============

Write-Host "📊 [1/5] 开始数据收集..." -ForegroundColor Cyan

# 1.1 扫描本地文件变更（过去24小时）
$files = Get-ChildItem $WorkDir -Recurse -File |
  Where-Object { $_.LastWriteTime -gt [DateTime]::Now.AddDays(-1) } |
  Select-Object Name, Length, LastWriteTime |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 30

Write-Host "   找到 $($files.Count) 个文件变更" -ForegroundColor Green

# 1.2 获取飞书任务
Write-Host "   获取飞书任务..." -ForegroundColor Gray
$tasks = & lark-cli task +get-my-tasks --as user 2>&1 | ConvertFrom-Json
$taskCount = if ($tasks.data.items) { $tasks.data.items.Count } else { 0 }
Write-Host "   找到 $taskCount 条任务" -ForegroundColor Green

# 1.3 获取飞书会议妙记（可选，如果有妙记token）
Write-Host "   获取飞书会议记录..." -ForegroundColor Gray
$meetings = @()  # 可扩展为实际读取

# ============ 2. 日报生成 ============

Write-Host "✍️  [2/5] 生成日报内容..." -ForegroundColor Cyan

$today = Get-Date -Format "yyyy-MM-dd"
$todayShort = Get-Date -Format "yyyyMMdd"
$reportPath = "$ReportDir\daily\$($PersonName)_${todayShort}_日报.md"

# 确保目录存在
if (-not (Test-Path "$ReportDir\daily")) {
    New-Item -ItemType Directory -Path "$ReportDir\daily" -Force | Out-Null
}

# 日报模板（简化版）
$reportContent = @"
🗓 产品日报

日期：$today ｜ 姓名：$PersonName ｜ 工时：8h
抄送：莫代鹏、宋家明

---

📊 今日工作总览

| 项目 | 产出数 | 🟢 正常 | 🟠 待补 | 🟡 待决 | 🔴 阻塞 |
|------|--------|--------|--------|--------|--------|
| 项目1 | N | x | y | z | w |
| 合计 | $($files.Count + $taskCount) | | | | |

---

🔸 本地文件变更

最近24小时共 $($files.Count) 个文件修改：
$($files | ForEach-Object { "• $($_.Name) — $($_.LastWriteTime)" } | Select-Object -First 10 | Out-String)

🔸 飞书任务

今日任务数：$taskCount
$($tasks.data.items | Select-Object -First 5 | ForEach-Object { "• $($_.title) — $($_.status)" } | Out-String)

---

📋 明日计划

P0: [关键任务]
P1: [重要任务]
P2: [常规任务]

---

⚠️ 风险标记
- 🟠 [待补充事项]

_🤖 由 Hermes Agent 自动生成 | $today 18:30_
_📄 文件：$reportPath_
"@

# 3. 保存到本地
Write-Host "💾 [3/5] 保存日报文件..." -ForegroundColor Cyan
$reportContent | Out-File -FilePath $reportPath -Encoding UTF8
Write-Host "   ✅ 已保存：$reportPath" -ForegroundColor Green

# 4. 发送飞书 IM
Write-Host "📤 [4/5] 发送飞书消息..." -ForegroundColor Cyan
$slackMsg = @"
**📋 日报已生成**
📅 日期：$today
👤 姓名：$PersonName
📊 产出：$($files.Count + $taskCount) 项

**关键工作：**
• 本地文件修改：$($files.Count) 个
• 飞书任务完成：$taskCount 条

📄 完整日报：file:///$reportPath

_自动生成时间：$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')_
"@

try {
    $sendResult = & lark-cli im +messages-send `
      --as user `
      --user-id "ou_7d05b327389c521f51426312ac5c9e2b" `
      --markdown $slackMsg 2>&1

    if ($sendResult | Select-String "ok.*true") {
        Write-Host "   ✅ IM 消息已发送" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️  IM 发送可能失败，请检查权限" -ForegroundColor Yellow
    }
} catch {
    Write-Host "   ❌ IM 发送错误：$_" -ForegroundColor Red
}

# 5. 数据库记录
Write-Host "📊 [5/5] 记录统计数据..." -ForegroundColor Cyan
$statsPath = "$ReportDir\报告统计.json"

$stat = @{
    date = $today
    person = $PersonName
    outputs = $files.Count + $taskCount
    file_path = $reportPath
    created_at = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
}

$stats = @()
if (Test-Path $statsPath) {
    $stats = Get-Content $statsPath | ConvertFrom-Json
}
$stats += $stat
$stats | ConvertTo-Json | Out-File -FilePath $statsPath -Encoding UTF8

Write-Host "   ✅ 统计数据已记录" -ForegroundColor Green

# ============ 完成 ============
Write-Host ""
Write-Host "✨ 日报生成完成！" -ForegroundColor Green
Write-Host "📄 文件：$reportPath" -ForegroundColor Cyan
