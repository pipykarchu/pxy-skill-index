# 飞书 IM 发送长内容（Python subprocess，Windows）

## 核心问题
lark-cli `--markdown` 参数在 PowerShell 里直接传长文本时，特殊字符（`·`、`**`、换行）会被 shell 解析成位置参数，导致：
```
positional arguments are not supported (got ["·" "2026-07-22**"])
```

## 正确做法：Python subprocess 参数列表（2026-08-03 更新）

**重要：--markdown 和 --text 在"皮玺玉的飞书 CLI"智能体对话里都看不到内容。唯一可用格式是卡片消息。见 `references/feishu-card-message-format.md`。**

以下代码仅适用于普通群聊或需要 markdown 的场景：
```python
import subprocess, os

LARK = r"C:\Users\皮玺玉\AppData\Roaming\npm\lark-cli.cmd"
UID  = "ou_7d05b327389c521f51426312ac5c9e2b"

msg = """**日报 · 2026-07-22**
...多行内容..."""

env = os.environ.copy()
env["LARK_CLI_WORKSPACE"] = "hermes"  # 指定 workspace，确保读到 keychain token

r = subprocess.run(
    [LARK, "im", "+messages-send", "--as", "bot", "--user-id", UID, "--markdown", msg],
    capture_output=True, text=True, timeout=20,
    encoding="utf-8", errors="replace", env=env
)
print(r.stdout or r.stderr)
```

## 卡片消息发送关键（2026-08-05 最终验证）

**必须用 `node run.js` 直接调用，绕过 lark-cli.cmd！**

`.cmd` wrapper 经过 cmd.exe 处理，`\uXXXX` 转义序列中的反斜杠被误解为路径分隔符，
导致中文内容超过约 200 字就报 "The system cannot find the path specified"。

**正确方式：**
```python
LARK_JS = r"C:\Users\皮玺玉\AppData\Roaming\npm\node_modules\@larksuite\cli\scripts\run.js"
content_str = json.dumps(card, ensure_ascii=False)  # UTF-8 原文传参
r = subprocess.run(
    ["node", LARK_JS, "im", "+messages-send", "--as", "bot", "--user-id", UID,
     "--msg-type", "interactive", "--content", content_str],
    capture_output=True, text=True, timeout=30,
    encoding="utf-8", errors="replace", env=env)
```

**错误方式（短内容碰巧成功，长内容必败）：**
```python
# ❌ lark-cli.cmd + ensure_ascii=True → cmd.exe 把 \uXXXX 当路径
LARK = r"C:\Users\皮玺玉\AppData\Roaming\npm\lark-cli.cmd"
content_str = json.dumps(card, ensure_ascii=True)
```

## 关键点
- 用**参数列表**（list）而非字符串拼接，避免 shell 解析特殊字符
- 必须设置 `LARK_CLI_WORKSPACE=hermes`，否则 subprocess 读不到 keychain token
- lark-cli 完整路径：`C:\Users\皮玺玉\AppData\Roaming\npm\lark-cli.cmd`
- **身份必须用 `--as bot`**，`--as user` 发的消息在智能体对话里不可见
- 日报发送：必须用卡片消息（`--msg-type interactive --content <card_json>`），见 feishu-card-message-format.md

## PowerShell 直接调用的 pitfall
```powershell
# ❌ 这样会失败，特殊字符被 shell 解析
lark-cli im "+messages-send" --markdown "**日报 · 2026**"

# ✅ 用 Python 脚本代替（subprocess 参数列表模式）
```
