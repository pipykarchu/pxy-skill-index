---
name: "hifi-design-review"
description: "Conducts structured Figma design quality reviews by generating comprehensive checklists covering spacing consistency, color accuracy, typography compliance, accessibility, and component best practices. Invoke when auditing HiFi designs or before design handoff."
license: MIT
---

# HiFi Design Review Auditor

This skill performs **structured, systematic design quality reviews** of Figma high-fidelity designs. It generates comprehensive audit checklists and issue-reporting templates that designers or reviewers can walk through to ensure designs meet professional standards before handoff.

## When to Invoke

- Before final design sign-off or handoff to engineering
- When auditing a design file for visual inconsistency
- After completing a major design iteration to catch regressions
- When onboarding a new designer to an existing design system
- When user mentions "QA the design", "review the screens", "audit", or "check for issues"

## Input Parameters (Ask User First)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `review_scope` | Yes | full_design | One of: `component_only`, `single_screen`, `user_flow`, `full_design`, `design_system` |
| `platform` | Yes | web | `web`, `mobile`, `both` |
| `severity_weight` | No | balanced | `strict` (block minor issues), `balanced`, `lenient` (flag only critical) |
| `include_accessibility` | No | true | Include WCAG 2.1 AA accessibility checks? |
| `design_system_ref` | No | default | Name of the style guide / design system being followed — for token matching (use output from hifi-style-guide if available) |

---

## Review Output Format

For every audit, generate a document in this exact format:

```
# Design Review Report

## Metadata
| Field | Value |
|-------|-------|
| Review Date | YYYY-MM-DD |
| Reviewer | (name) |
| Scope | [review_scope] |
| Platform | [platform] |
| Design System | [design_system_ref] |
| Severity Mode | [severity_weight] |

## Summary
- **Total Issues Found:** X
- **Critical (Must Fix):** X   [red]
- **Major (Should Fix):** X   [orange]
- **Minor (Nice to Have):** X  [yellow]
- **Passed Checks:** X / Y
- **Overall Rating:** ⭐⭐⭐☆☆ / 5

## Issue Severity Legend
| Level | Definition |
|-------|-----------|
| 🔴 CRITICAL | Blocks handoff: broken accessibility, wrong data, broken states, inconsistency across flows |
| 🟠 MAJOR | Significant visual or UX issue: inconsistent spacing, wrong tokens, broken alignment |
| 🟡 MINOR | Polish / nit-level: 1-2px off, minor color variance, tiny text mismatch |
| 💡 SUGGESTION | Optional improvement, not a bug (alternative approach, UX consideration) |
| ✅ PASS | Verified correct |
```

Then run through ALL checklist categories below, marking items Pass / Fail / Not Applicable, and attaching issue details for any Fails.

---

## Audit Category 1: Spacing & Layout Consistency

**Goal:** Verify ALL spacing follows the 4px grid and matches the design system tokens.

| # | Check Item | Severity if Fail | Pass / Fail | Notes / Issue |
|---|-----------|------------------|-------------|---------------|
| 1.1 | Every padding and gap value is a multiple of 4px (0, 4, 8, 12, 16, 20, 24, 32, 40, 48, 64...) | 🟠 MAJOR | | List any odd values: e.g., 5px, 7px, 13px, 18px padding |
| 1.2 | Same component type has IDENTICAL padding across all instances (e.g., every Button MD is height 44px, padding 18px × 0) | 🟠 MAJOR | | e.g., "Primary button in header = 46px tall, but in modal = 44px" |
| 1.3 | Consistent vertical rhythm in content stacks (body text ↔ heading ↔ section gap ratios follow spec) | 🟡 MINOR | | |
| 1.4 | Grid alignment: all columns align to the defined breakpoint grid (no elements bleed outside grid margins) | 🟠 MAJOR | | Note screen width and misaligned elements |
| 1.5 | Spacing between related items < spacing between unrelated groups (Gestalt proximity principle) | 💡 SUGGESTION | | e.g., label-to-input gap (6px) < gap between fields (16px) |
| 1.6 | Touch targets ≥ 44×44px on mobile, clickable icons ≥ 32×32px on web | 🔴 CRITICAL | | List undersized targets with actual dimensions |
| 1.7 | Auto Layout is enabled on ALL components (no manual positioning inside component frames) | 🟠 MAJOR | | e.g., "Card component has 3 manually positioned text layers" |

**Example Issue Log Entry:**
```
📋 Issue #3: Inconsistent button padding
🔍 Location: Modal / Footer / Cancel Button
📐 Current: padding-left: 14px, padding-right: 14px
✅ Expected: Button MD → padding X = 18px per spec
🟠 Severity: MAJOR
```

---

## Audit Category 2: Color System Compliance

**Goal:** Every color pixel references an approved design token — NO custom hex or RGB values.

| # | Check Item | Severity if Fail | Pass / Fail | Notes / Issue |
|---|-----------|------------------|-------------|---------------|
| 2.1 | All fills use the approved Color Variables / Styles only (no custom hex, no detached styles) | 🟠 MAJOR | | Count: X custom color instances found |
| 2.2 | Text/background contrast ratio ≥ 4.5:1 for body text (AA), ≥ 3:1 for large text (18pt+) | 🔴 CRITICAL | | List failures with actual contrast ratio (use WebAIM Contrast Checker values) |
| 2.3 | Disabled state opacity = 40-50% consistently across ALL disabled components (not 30% here, 60% there) | 🟡 MINOR | | |
| 2.4 | Semantic color usage correct: Green = success, Yellow = warning, Red = error, Blue = info (no mixing) | 🟠 MAJOR | | e.g., "Delete button uses yellow instead of red" |
| 2.5 | Hover state = exactly one shade darker/lighter than default (not arbitrary color shift) | 🟡 MINOR | | e.g., "Primary 600 default → Primary 700 hover" is correct |
| 2.6 | Focus ring (outline) visible on ALL interactive elements when focused | 🔴 CRITICAL | | List elements missing focus indicator |
| 2.7 | Dark mode variants: backgrounds use dark tokens (not just black inverted), text contrast passes | 🟠 MAJOR | | If dark mode included |
| 2.8 | No full #000000 black text on pure #FFFFFF white (use Neutral/800 or /900 for softer contrast) | 💡 SUGGESTION | | Harsh pure black-on-white strains eyes |

**Contrast Ratio Calculation Reference:**
```
Text Size              AA Level     AAA Level
Normal text (<18px)    ≥ 4.5:1      ≥ 7:1
Large text (≥18px)     ≥ 3:1        ≥ 4.5:1
UI components (icons)  ≥ 3:1        ≥ 4.5:1
```

---

## Audit Category 3: Typography System Compliance

**Goal:** Every text layer uses the approved Text Style tokens exactly.

| # | Check Item | Severity if Fail | Pass / Fail | Notes / Issue |
|---|-----------|------------------|-------------|---------------|
| 3.1 | Every text layer uses an approved Text Style (no modified / detached instances) | 🟠 MAJOR | | Count: X detached text layers found |
| 3.2 | Font-family matches exactly the approved stack (no unexpected fallback fonts visible) | 🟡 MINOR | | |
| 3.3 | Font weights: Heading = 600-700 (Semibold to Bold), Body = 400 (Regular), Caption = 400-500 | 🟡 MINOR | | e.g., "Paragraph text uses weight 500 — should be 400 regular" |
| 3.4 | Line-height ratios per scale: Display = tight (1.1-1.2), Heading = medium (1.3-1.4), Body = relaxed (1.5-1.6) | 🟡 MINOR | | e.g., "Body text has line-height 1.3 — too tight" |
| 3.5 | Text truncation rules correct: Body max 2-3 lines, Titles max 1-2 lines, Caption 1 line | 🟡 MINOR | | Note instances of overflowing/clipping text |
| 3.6 | Heading hierarchy correct per semantic level: H1 > H2 > H3 > H4 in size, weight, spacing | 🟠 MAJOR | | e.g., "Card subtitle larger than card title — inverted hierarchy" |
| 3.7 | Letter-spacing: Display = slightly negative (-0.01 to -0.02em), Overline = positive (+0.08em), Body = 0 | 💡 SUGGESTION | | |
| 3.8 | No orphan/widow words (single word on last line of paragraph) on key marketing text | 💡 SUGGESTION | | |

---

## Audit Category 4: Component Correctness

**Goal:** Every component instance matches the master Component Set spec (no one-off overrides that should be variants).

| # | Check Item | Severity if Fail | Pass / Fail | Notes / Issue |
|---|-----------|------------------|-------------|---------------|
| 4.1 | All instances reference the central Component Set (no detached instances / "orphan" frames) | 🟠 MAJOR | | Count: X detached components |
| 4.2 | Component states exist for: Default, Hover, Pressed, Focus, Disabled, Loading (all interactive components) | 🔴 CRITICAL | | List which states are missing per component type |
| 4.3 | Component variants use property-swapping approach (not "duplicate frame and tweak manually") | 🟠 MAJOR | | e.g., "3 separate primary button frames instead of 1 Component Set with Size property" |
| 4.4 | Property names match the design system convention exactly (State, Size, Variant, IconLeft, etc.) | 🟡 MINOR | | e.g., "Component uses 'Type' instead of 'Variant'" |
| 4.5 | Loading state: Label is hidden (opacity 0%) AND spinner is centered, no label showing through | 🟡 MINOR | | |
| 4.6 | Error state: Field has red border AND helper text visible (not just red border alone) | 🟠 MAJOR | | Count fields with only visual error but no message |
| 4.7 | Icon sizes inside components scale correctly: SM component → 16px icon, MD → 18px, LG → 20px | 🟡 MINOR | | e.g., "MD Button has 16px icon — should be 18px" |
| 4.8 | All Auto Layout components resize correctly: Stretch test to 30% narrower and 150% wider, no broken layout | 🟠 MAJOR | | Test: Buttons full-width, Cards in narrow columns, Modals at min-width |
| 4.9 | Layer names are semantic and descriptive (no "Frame 123", "Rectangle 456", "Group 789") | 🟡 MINOR | | Count: X generically-named layers found (threshold: > 5 per screen) |

---

## Audit Category 5: Accessibility (if include_accessibility = true)

Reference: WCAG 2.1 Level AA

| # | Check Item | Severity if Fail | Pass / Fail | Notes / Issue |
|---|-----------|------------------|-------------|---------------|
| 5.1 | Keyboard navigable: Logical tab order (use Figma Prototype "Tabbing order" or visual inspection left→right, top→bottom) | 🔴 CRITICAL | | Note any out-of-order flows |
| 5.2 | All non-text content (icons, images) has equivalent alt text or aria label described in design notes | 🟠 MAJOR | | List decorative-only icons vs informational icons |
| 5.3 | Color is NOT the sole means of conveying information (e.g., error = red border + icon + text, not just red) | 🔴 CRITICAL | | e.g., "Form fields use only red border with no error icon/text" |
| 5.4 | States distinguishable without color: Focus = outline, Hover = elevation/scale/underline (not just color shift) | 🟠 MAJOR | | |
| 5.5 | Minimum tap target: 44×44px mobile, 32×32px web (re-check per Category 1.6, but confirm accessible spacing around targets) | 🔴 CRITICAL | | |
| 5.6 | Motion: Animated transitions ≤ 500ms, and "reduce motion" alternative exists or motion is purely decorative | 💡 SUGGESTION | | |
| 5.7 | Form inputs have visible labels visible at all times (no floating labels that disappear on input) | 🟠 MAJOR | | |
| 5.8 | Error states provide suggestions for correction (e.g., "Password must be 8+ chars") not just "Invalid input" | 🟠 MAJOR | | |

---

## Audit Category 6: Responsive & Breakpoints

| # | Check Item | Severity if Fail | Pass / Fail | Notes / Issue |
|---|-----------|------------------|-------------|---------------|
| 6.1 | Designs provided for all required breakpoints: Mobile 390px, Tablet 768px, Desktop 1440px minimum | 🔴 CRITICAL | | Note which breakpoints are missing |
| 6.2 | Content properly reflows: No horizontal scrolling on mobile, text wraps, columns collapse to stack correctly | 🟠 MAJOR | | e.g., "4-col dashboard grid still 4-col at 768px — should be 2-col or 1-col" |
| 6.3 | Navigation pattern adapts: Sidebar → bottom tab / hamburger on mobile, Topbar items collapse appropriately | 🟠 MAJOR | | |
| 6.4 | Typography scales down on mobile (Display XL on desktop ≠ Display XL on mobile — use mobile sizes) | 🟡 MINOR | | List mismatched type sizes |
| 6.5 | Modal widths capped: Mobile full-screen (max-width 100% - 16px margin), desktop max 880px | 🟡 MINOR | | |
| 6.6 | Tables on mobile: Either horizontal scroll, stacked cards, or condensed columns (not shrunk tiny columns) | 🟠 MAJOR | | e.g., "6-col data table on 390px width — each column ~60px, unreadable" |

---

## Audit Category 7: UX Flow & Logic (if scope = user_flow or full_design)

| # | Check Item | Severity if Fail | Pass / Fail | Notes / Issue |
|---|-----------|------------------|-------------|---------------|
| 7.1 | Every entry point has a clear exit / back path (no dead-end screens) | 🔴 CRITICAL | | List dead ends |
| 7.2 | Primary CTA is visually dominant (one clear action per screen, not multiple equal-weight CTAs fighting) | 🟠 MAJOR | | |
| 7.3 | Loading state: Skeleton or spinner shown for ALL async operations (no blank screen during load) | 🟠 MAJOR | | List screens missing loading state |
| 7.4 | Empty states: Every list/collection view has an empty state with illustration + primary action | 🟠 MAJOR | | List empty screens missing treatment |
| 7.5 | Error states: Network error, permission denied, 404 — each has recovery action or contact support | 🔴 CRITICAL | | |
| 7.6 | Confirmation before destructive actions (Delete, Leave site, Cancel form): Modal or at least undo/toast | 🔴 CRITICAL | | |
| 7.7 | Form long flows have: Save Draft button, progress indicator, and autosave indication | 💡 SUGGESTION | | |
| 7.8 | Critical data is persistent: User name, nav, breadcrumbs visible as user navigates (no disorientation) | 🟡 MINOR | | |

---

## Audit Category 8: Handoff & Documentation Quality

| # | Check Item | Severity if Fail | Pass / Fail | Notes / Issue |
|---|-----------|------------------|-------------|---------------|
| 8.1 | Figma file structure is clean: Pages named correctly, Frames named with screen IDs | 🟡 MINOR | | |
| 8.2 | Every screen has an annotated description for devs (what is this screen? when does it appear?) | 💡 SUGGESTION | | |
| 8.3 | Component descriptions filled in Figma's "Description" field (what it does, when to use each variant) | 🟡 MINOR | | Count components with empty descriptions |
| 8.4 | Interactive prototype connected: All main flows clickable with correct transitions | 🟠 MAJOR | | Note % of prototype links complete |
| 8.5 | Dev mode clean: No hidden layers cluttering the panel, exportable assets marked for export | 💡 SUGGESTION | | |
| 8.6 | Assets correctly named: `icon/action/delete.svg`, `img/hero-banner.png` — not `Frame 78 copy 2.png` | 🟠 MAJOR | | Count misnamed exportable assets |

---

## Issue Reporting Template

For every FAIL or SUGGESTION found, document it using this structured block. Replace bracketed content.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Issue #[NUMBER]: [SHORT DESCRIPTIVE TITLE]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📂 Category:      [Category 1-8]
🔴🟠🟡 Severity:  [CRITICAL / MAJOR / MINOR / SUGGESTION]
📍 Location:      [Figma Page > Frame Name > Component Name]
                  (Add Figma node URL or frame coordinates if available)
📐 Current State: [What the design currently has — include pixel values,
                  hex codes, actual screenshots verbally described]
✅ Expected State: [What the spec / checklist requires — reference the
                  exact design token, e.g., "Button MD height should be 44px
                  per Component Library spec §Category 1"]
🎯 Fix Steps:     [1. Click X, 2. Change Y, 3. Set property Z to value A]
🎨 Screenshot:    [Describe visual diff: e.g., "Left button has 14px padding,
                  right button (correct) has 18px — 4px discrepancy visible"]
📎 Attachments:   [Link to component reference, dev mode screenshot, or
                  relevant design system page]
```

---

## Final Report Summary

After completing all checklists above, append this summary section:

```
## Action Plan by Priority

### 🔴 Fix Immediately (Block Handoff) — 3 issues
1. [Critical Issue 1 title] → Assigned to: [name], ETA: [date]
2. [Critical Issue 2 title] → Assigned to: [name], ETA: [date]
3. [Critical Issue 3 title] → Assigned to: [name], ETA: [date]

### 🟠 Fix Before Sign-off — 5 issues
1. [Major Issue 1]
2. [Major Issue 2]
...

### 🟡 Polish / Fix When Possible — 8 issues
...

### 💡 Suggestions (Backlog) — 4 items
...

---

## Approver Sign-off

| Role | Name | Date | Signature / Initials |
|------|------|------|---------------------|
| Designer (Owner) | | | |
| Design Lead (Review) | | | |
| Product Manager (UX) | | | |
| Engineering Rep (Handoff) | | | |

☐ All CRITICAL issues resolved
☐ All MAJOR issues resolved
☐ Review follow-up scheduled for [date] to validate fixes
☐ Final sign-off granted → Ready for development handoff

---
```

## Usage Instructions for Designer / Reviewer

1. **Go screen by screen**: Open one Figma frame at a time, go through each checklist category, mark P/F/N/A
2. **Measure everything**: Use Figma Inspector to read exact padding, font sizes, and colors — NO eyeballing
3. **Compare to master**: Open the Component Set master definition side-by-side with instances and compare properties
4. **Check contrast manually**: Use the Figma "Color Contrast" plugin or WebAIM checker on text/background pairs
5. **Document every fail**: Use the Issue Template block above for every non-Pass item
6. **Re-audit after fixes**: Once issues are fixed, re-run this review on the affected screens — do NOT assume fixes are correct without verifying
