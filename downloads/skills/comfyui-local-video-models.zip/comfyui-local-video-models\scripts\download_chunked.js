// 大文件多线程分块下载器 (Node 22+, hf-mirror 优先)
// 用法: node download_chunked.js
// 修改 MODELS 数组即可复用于任何大文件下载
// 关键设计(踩坑后的教训):
//  1. worker pool 控制并发 —— 千万别 Promise.allSettled(chunks.map(...)) 一次性发全部请求
//  2. 同步合并(openSync/writeSync), 合并成功后才删分块 —— 异步 write+立即 unlink 会被 kill 丢数据
//  3. 分块断点续传: 已存在且大小正确则跳过
const fs = require('fs');
const path = require('path');

const BASE = 'https://hf-mirror.com/<org>/<repo>/resolve/main'; // 改成目标仓库
const OUT_ROOT = path.join('D:', 'pxy', 'ComfyUI_windows_portable', 'ComfyUI', 'models');
const THREADS = 8;
const CHUNK = 64 * 1024 * 1024; // 64MB

const MODELS = [
  // [相对路径, 估算大小字节]  (估算值仅用于日志; 实际大小从 HEAD 获取)
  ['diffusion_models/example.safetensors', 20000000000],
];

async function headSize(relPath) {
  try {
    const res = await fetch(`${BASE}/${relPath}`, { method: 'HEAD', redirect: 'follow' });
    return parseInt(res.headers.get('content-length') || '0', 10);
  } catch (e) {
    return 0;
  }
}

async function downloadChunk(relPath, dest, start, end, idx) {
  const chunkFile = `${dest}.part${idx}`;
  // 续传: 分块已存在且大小正确则跳过
  if (fs.existsSync(chunkFile) && fs.statSync(chunkFile).size === (end - start + 1)) {
    return true;
  }
  const tmp = `${chunkFile}.tmp`;
  for (let attempt = 1; attempt <= 8; attempt++) {
    try {
      const res = await fetch(`${BASE}/${relPath}`, {
        headers: { Range: `bytes=${start}-${end}`, 'User-Agent': 'Mozilla/5.0' },
        redirect: 'follow',
      });
      if (!res.ok && res.status !== 206) throw new Error(`HTTP ${res.status}`);
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length !== (end - start + 1)) throw new Error(`长度不符 ${buf.length}`);
      fs.writeFileSync(tmp, buf);
      fs.renameSync(tmp, chunkFile);
      return true;
    } catch (e) {
      if (attempt === 8) { console.log(`  chunk${idx} 最终失败: ${e.message}`); return false; }
      console.log(`  chunk${idx} 第${attempt}次失败: ${e.message}`);
      await new Promise(r => setTimeout(r, 3000));
    }
  }
  return false;
}

async function downloadFile(relPath, estSize) {
  const dest = path.join(OUT_ROOT, ...relPath.split('/'));
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  if (fs.existsSync(dest)) {
    const sz = fs.statSync(dest).size;
    const size = await headSize(relPath);
    if (sz === size) { console.log(`[跳过] ${relPath} 已完整 (${(sz / 1e9).toFixed(2)}GB)`); return true; }
    console.log(`[重建] ${relPath} 不完整(${(sz / 1e9).toFixed(2)}GB)，删除重下`);
    fs.unlinkSync(dest);
  }
  console.log(`[下载] ${relPath} (估算 ${(estSize / 1e9).toFixed(1)}GB)`);
  const size = await headSize(relPath);
  if (size <= 0) { console.log(`[错误] 无法获取 ${relPath} 大小`); return false; }
  console.log(`  实际大小: ${(size / 1e9).toFixed(2)}GB`);

  const chunks = [];
  let start = 0, idx = 0;
  while (start < size) {
    const end = Math.min(start + CHUNK - 1, size - 1);
    chunks.push([start, end, idx]);
    start = end + 1;
    idx++;
  }
  console.log(`  共 ${chunks.length} 个分块，${THREADS} 线程`);

  const t0 = Date.now();
  // 并发限制: worker pool 游标模式 —— 不要用 Promise.allSettled(chunks.map(...))
  const results = new Array(chunks.length);
  let cursor = 0;
  async function worker() {
    while (cursor < chunks.length) {
      const job = cursor++;
      const [s, e, i] = chunks[job];
      results[job] = await downloadChunk(relPath, dest, s, e, i);
    }
  }
  await Promise.all(Array.from({ length: THREADS }, () => worker()));
  const failed = results.filter(r => r !== true).length;
  if (failed > 0) {
    console.log(`  ${relPath} 有 ${failed} 个分块失败`);
    return false;
  }

  // 同步合并(写入全部完成前不删分块)
  const ordered = chunks.slice().sort((a, b) => a[2] - b[2]);
  let written = 0;
  try {
    const fd = fs.openSync(dest, 'w');
    for (const [s, e, i] of ordered) {
      const cf = `${dest}.part${i}`;
      const buf = fs.readFileSync(cf);
      fs.writeSync(fd, buf);
      written += buf.length;
    }
    fs.closeSync(fd);
  } catch (e) {
    console.log(`  [合并失败] ${relPath}: ${e.message}`);
    return false;
  }
  // 合并成功后才删分块
  for (const [s, e, i] of ordered) {
    fs.unlinkSync(`${dest}.part${i}`);
  }
  const elapsed = (Date.now() - t0) / 1000;
  console.log(`[完成] ${relPath} ${(written / 1e9).toFixed(2)}GB 用时${elapsed.toFixed(0)}s 平均${(written / elapsed / 1e6).toFixed(1)}MB/s`);
  return true;
}

(async () => {
  let ok = true;
  for (const [p, est] of MODELS) {
    try {
      if (!(await downloadFile(p, est))) ok = false;
    } catch (e) {
      console.log(`[错误] ${p}: ${e.message}`);
      ok = false;
    }
  }
  console.log(ok ? 'ALL_DONE' : 'HAS_FAILURES');
})();
