# 抖音短链解析（byted_acrawler 反爬绕过）

用户发来抖音分享链接（如 `https://v.douyin.com/xxxx/`）时要能取出视频内容（标题、作者、合集、章节要点）。

## 失败路径（不要浪费时间）

- `web_extract`：本机 web.extract_backend 是 DuckDuckGo search-only，直接报错
- `curl` 直连/代理拿 `v.douyin.com`：只到 `www.douyin.com/video/<id>` 后返回 404 或 byted_acrawler 反爬壳页（整页就是一个 JS 混淆脚本 + `window.location.reload()`，无 RENDER_DATA）
- 浏览器直连：超时（os error 10060），因为不走代理

## 可行路径

1. **curl 追踪重定向拿视频 ID**（先确认是什么视频，0.3s）：
   ```powershell
   curl.exe -sIL -A "Mozilla/5.0 ... Chrome/126.0.0.0 Safari/537.36" "https://v.douyin.com/xxxx/" -o NUL -w "final_url=%{url_effective}"
   # → https://www.douyin.com/video/<数字ID>?previous_page=app_code_link
   ```

2. **安装 agent-browser（若 Chrome 缺失）**：
   - CN 桌面版无 agent-browser，官方版有：
     `C:\Users\16543\AppData\Local\hermes\hermes-agent\node_modules\agent-browser\bin\agent-browser-win32-x64.exe`
   - 安装 Chrome：`... agent-browser-win32-x64.exe install`（约 193MB，装到 `C:\Users\16543\.agent-browser\browsers\`）

3. **走 Clash 代理开页面**（设置环境变量后 agent-browser CLI 会跟随）：
   ```powershell
   $env:HTTPS_PROXY = "http://127.0.0.1:7897"; $env:HTTP_PROXY = "http://127.0.0.1:7897"
   cmd /c "`"<agent-browser.exe>`" open `"https://www.douyin.com/video/<ID>`" --json"
   # 注意: 必须用 cmd /c 包装, PowerShell 的 & 调用符会被误判为后台
   ```

4. **snapshot 读内容**：
   ```powershell
   cmd /c "`"<agent-browser.exe>`" snapshot --json"
   # 返回 refs + snapshot 可访问性树, 含标题/作者/合集/章节要点/评论
   ```
   示例输出（2026-08 实测）：标题"第2集 | 迎接你们的王！MiniMaxH3王炸更新免费开源！"，作者"罐头聊AI（没有助理）"，合集"AI漫剧短剧AIGC教学"，章节要点带时间戳段落——这就是"根据这个视频内容安装配置"类请求的信息源。

## 代理要点

- 本机 Clash 代理 `127.0.0.1:7897`；设置 `$env:HTTPS_PROXY`/`$env:HTTP_PROXY` 后 agent-browser CLI 生效
- 抖音页面加载完成后 CLI open 命令可能一直不退出（服务常驻），拿完 snapshot 后无需等 open 退出；后续 snapshot 命令单独跑即可
