---
name: comfyui-local-video-models
version: 1.0.0
license: MIT
description: "Use when deploying open-weight local AI video generation models (MiniMax H3, Wan, Hunyuan, LTX Video etc.) via ComfyUI portable on Windows — model download from hf-mirror, correct model directory layout, native ComfyUI node chains vs Cloud API nodes, hand-built API-format prompt submission, and verification. Triggers on: 本地部署视频模型, MiniMax H3, 安装ComfyUI模型, 根据抖音教程安装, hf-mirror 下载, 图生视频/文生视频本地跑."
---

# ComfyUI 本地开源视频模型部署与调用

在 Windows 上用 ComfyUI portable 部署开源视频生成模型（MiniMax H3、Wan、Hunyuan、LTX 等）并跑通文生视频/图生视频。以 MiniMax H3 为实测案例（RTX 4070 Laptop 8GB 跑通）。

## 何时使用

- 用户给一个抖音/教程链接，要你"按这个装"本地 AI 视频模型
- 用户要本地跑开源视频模型（免费、可控、无平台额度）
- 需要从 hf-mirror/HuggingFace 下载几十 GB 的大模型文件
- 漫剧生产阶段 7 的视频生成（见 `manju-production-workflow`）

## 核心流程

### 1. 解析教程链接（抖音）

抖音短链 → 视频页需要真实浏览器 + JS 执行（curl 只会拿到 byted_acrawler 反爬壳）。详见 `references/douyin-link-resolution.md`。

### 2. 确认硬件与磁盘

```powershell
nvidia-smi          # GPU 型号 + 显存
Get-PSDrive D       # 磁盘剩余空间（模型总大小通常 30-60GB）
```

### 3. 安装 ComfyUI portable

- 从 GitHub releases 下载 `ComfyUI_windows_portable_nvidia.7z`（约 2GB，走 Clash 代理 127.0.0.1:7897 可达 20MB/s；直连可能卡死）
- Windows 自带 `tar.exe`（bsdtar）可直接解压 7z：`tar -xf xxx.7z -C D:\pxy`
- 解压后 portable 目录含 `python_embeded\python.exe`（真实 Python，本机 PATH 里没有 python 时用它）
- 启动：`.\python_embeded\python.exe -s ComfyUI\main.py --windows-standalone-build --listen 127.0.0.1 --port 8188`

### 4. 下载模型（hf-mirror 多线程分块下载）

- **HF 直连国内不通（超时）；hf-mirror.com 免代理直连可行**；走代理 2.6MB/s 慢，8 线程可达 10-45MB/s
- 模型文件列表从官方文档（docs.comfy.org）或 HuggingFace API 获取：
  `curl "https://huggingface.co/api/models/<org>/<repo>/tree/main?recursive=true&expand=true"` 拿每个文件实际大小
- **用 `scripts/download_chunked.js`（Node.js，本机无 Python 时用 `D:\hermes\data\versions\0.19.0-cn.7\node\node.exe` 运行）**
- 模型目录布局（重要，ComfyUI 按目录认模型）：
  - `models/diffusion_models/` ← 扩散模型（如 minimax_h3_fl2va_pruned_int8_convrot.safetensors）
  - `models/text_encoders/` ← 文本编码器（如 qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors）
  - `models/vae/` ← 视频 VAE + 音频 VAE

### 5. 提交推理（API 格式 prompt）

- UI 模板（`python_embeded\Lib\site-packages\comfyui_workflow_templates_json\templates\*.json`）是 editor 格式（nodes/links/UUID 节点引用），**不能直接 POST**
- 用 `GET /object_info/<NodeType>` 查节点 schema，手工构造 API 格式 prompt（每个节点 `class_type` + `inputs`，连线 `[src_id, src_slot]`）
- **提交用 Python urllib 脚本，不要用 PowerShell curl -d**（PowerShell 会把 JSON 引号转义破坏；curl `--data-binary @file` 的 @ 也被 PowerShell 干扰）。参考 `scripts/submit_prompt.py`
- 轮询：`GET /queue` 看运行中；`GET /history/<prompt_id>` 看完成状态和输出文件
- 输出在 `ComfyUI\output\` 下

### 6. 验证

- `GET /system_stats`：确认 GPU/VRAM/PyTorch 版本
- 日志出现 `Model Initialization complete` + 进度条 = 采样开始
- `GET /history/<id>` 的 `outputs` 里有 mp4 = 成功
- 检查输出文件头 `ftyp isom` 确认是有效 MP4

## MiniMax H3 关键事实（实测 2026-08，RTX 4070 8GB）

- 官方文档：docs.comfy.org/tutorials/video/minimax/minimax-h3（ComfyUI 0.30.0+，本机 0.33.1）
- 模型组合（T2V/I2V 共 ~41GB）：fl2va pruned int8 扩散模型 19.5GB + qwen3vl_32b nvfp4_awq 文本编码器 14.6GB + video VAE fp16 4.9GB + audio VAE fp32 0.56GB（R2V 另需 ref2va 扩散模型）
- **陷阱：模板里的 `MinimaxHailuo03TextToVideoNode` 是 Comfy Cloud API 节点（需登录付费）**，本地推理必须用原生节点：
  - `UNETLoader`(unet_name) + `CLIPLoader`(clip_name, type=minimax) + `VAELoader`×2
  - `MiniMaxH3ImageToVideo`(clip, vae, prompt, width, height, length) → positive + LATENT（T2V/I2V 共用，可选 first_frame/last_frame）
  - 采样链：`RandomNoise` → `BasicGuider` → `KSamplerSelect` → `BasicScheduler` → `SamplerCustomAdvanced`
  - 解码：`VAEDecode`(video vae) + `VAEDecodeAudio`(audio vae) → `CreateVideo`(fps) → `SaveVideo`
- length 参数：帧数，24fps 下对齐 17k+5 网格（124≈5s，73≈3s）
- **8GB 显存实测可跑**：动态 VRAM offload，20 步采样约 4.5 分钟（~14s/步），768×768 3 秒视频正常出片。视频教程要求最低 12GB 是保守说法
- 完整可跑 prompt 示例见 `references/minimax-h3-t2v-prompt.md`

## 关键坑

1. **Node 大文件下载器两个致命 bug**（都踩过）：
   - `Promise.allSettled(chunks.map(download))` 会一次性并发全部请求（THREADS 变量失效）→ 内存爆到 5GB+、连接池卡死、进度停住。必须用 worker pool（cursor 游标 + N 个 worker）
   - 合并分块时异步 `out.write()` + 立即 `unlink` 分块 → 进程被 kill 时已删分块但 dest 不完整，数据全丢。必须同步 `openSync/writeSync/closeSync` 合并，**合并成功后才删分块**
2. **PowerShell 传 JSON 给 curl**：`-d $body` 引号被破坏 → JSONDecodeError；用 Python 脚本提交最稳
3. **模型文件必须放对目录**（diffusion_models vs text_encoders vs vae），放错 ComfyUI 不识别
4. **视频推理耗时长**：首次要加载 20GB 模型 + 15GB 文本编码器，几分钟起步；后台跑 + 轮询 queue/history
5. **node.exe 位置**：CN 桌面版在 `D:\hermes\data\versions\<ver>\node\node.exe`（注意是 node 子目录，不是根目录）
6. ComfyUI 日志用 watch_patterns 监听 `To see the GUI go to` 即可知启动完成；`Error`/`Traceback` 也值得监听
7. **watch_patterns 监听 "Error" 会被无害噪音频繁误报**（2026-08 实测一次部署被误报 4 次）：
   - `triton backend: {'available': False}` — 只是可选加速后端未装，不是错误
   - `NativeCommandError` / `FullyQualifiedErrorId : NativeCommandError` — python 进度条和 `[INFO]` 日志走 stderr，PowerShell 把 stderr 输出包装成"错误记录"，纯终端层假象
   - `[ERROR] Error handling request from 127.0.0.1` — 常是历史请求留下的 traceback（如之前一次失败的 JSON 提交），看具体 JSONDecodeError 判断，服务本身可能健康
   - 判断标准：`GET /system_stats` 200 + 队列能跑 = 服务正常，日志噪音无视
8. **ComfyUI 便携版自带的 `python_embeded\python.exe` 是本机唯一可靠 Python**：装模型、提交 prompt、验证脚本都调它（本机 PATH 里只有 Microsoft Store 的 python 存根，会报 "Python was not found"）

## 云服务器迁移/远端部署预检（重要）

用户可能想把本地部署迁到云服务器（"这台电脑先保留，云服务器正常就不用留了"）。**先 SSH 检查硬件，不要盲目传 40GB 模型**：

- 云 IP 可能是内网/CGNAT 段（100.x.x.x）：先 `ping` + `Test-NetConnection -ComputerName <ip> -Port 22` 确认可达
- Windows 无 sshpass/plink → 用 ComfyUI 自带 python_embeded 装 paramiko：`python -m pip install paramiko`，脚本 `client.connect(host, port=22, username, password, timeout=20)` + `exec_command` 批量跑检查命令
- 必查清单：
  - `nvidia-smi`；若无则 `lspci | grep -i vga` — 出现 `Cirrus Logic GD 5446` 等虚拟显卡 = 纯 CPU 虚机，**直接判定跑不了视频生成**
  - `free -g`（MiniMax H3 加载需 20GB+ 内存）
  - `df -h /`（模型 40GB+，需 >100GB 磁盘）
- 判定失败（无 GPU / <16GB 内存 / <100GB 磁盘）→ 告知用户此服务器无法承载，**不要传文件**；给替代方案（租 GPU 云主机 4090/A10/L4 12G+ 显存按小时计费，或本机继续用）
- 实测（2026-08）：一台 Ubuntu 26.04 云服务器（6 核 CPU、7GB 内存、48GB 磁盘、无 NVIDIA GPU）判定为不可承载，模型未迁移

## 部署收尾：一键启动 + 桌面快捷方式（用户偏好）

装完并验证推理后，用户会问"平常怎么打开"。标准收尾：

- `ComfyUI_start.bat`：先检测端口占用（`netstat -ano | findstr ":8188" | findstr LISTENING`）——已在运行就直接 `start http://127.0.0.1:8188` 退出，未运行才启动服务器（避免重复实例冲突）
- 桌面快捷方式：PowerShell `WScript.Shell` COM 创建 `.lnk`（TargetPath=bat，WorkingDirectory=D:\pxy，IconLocation 用前端包的 `comfy-icon-192.png`，因 web\favicon.ico 不存在）
- **向用户明确：本地推理不花 token、不需要 API key**（开放权重模型全本地）。但模板库有陷阱——`MinimaxHailuo03TextToVideoNode` 等名字带 "Hailuo" 的节点是 Comfy Cloud 付费 API 节点；认准原生 `MiniMaxH3*` 模板（T2V/I2V/R2V）才是本地免费

## 参考文件

- `scripts/download_chunked.js` — 可复用 Node 多线程分块下载器（hf-mirror，断点续传，worker pool）
- `scripts/submit_prompt.py` — Python 提交 API prompt 到本地 ComfyUI
- `references/douyin-link-resolution.md` — 抖音短链解析（反爬绕过）
- `references/minimax-h3-t2v-prompt.md` — 实测可跑的 MiniMax H3 文生视频 API prompt
