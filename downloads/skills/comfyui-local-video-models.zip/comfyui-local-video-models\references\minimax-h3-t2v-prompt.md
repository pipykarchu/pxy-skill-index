# MiniMax H3 文生视频 API Prompt（实测可跑，RTX 4070 8GB）

2026-08 在 ComfyUI 0.33.1 portable + RTX 4070 Laptop 8GB 实测跑通。20 步采样约 4.5 分钟，输出 768×768 3 秒视频 + 原生音频。

## 节点链（全部是原生本地节点，勿用 MinimaxHailuo03TextToVideoNode——那是 Comfy Cloud 付费 API 节点）

| id | class_type | 关键 inputs |
|---|---|---|
| 1 | UNETLoader | unet_name=minimax_h3_fl2va_pruned_int8_convrot.safetensors, weight_dtype=default |
| 2 | CLIPLoader | clip_name=qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors, type=minimax |
| 3 | VAELoader | vae_name=minimax_h3_video_vae_fp16.safetensors |
| 4 | VAELoader | vae_name=minimax_h3_audio_vae_fp32.safetensors |
| 5 | MiniMaxH3ImageToVideo | clip=[2,0], vae=[3,0], prompt, width, height, length → 输出0=positive(CONDITIONING), 输出1=LATENT |
| 6 | RandomNoise | noise_seed |
| 7 | BasicGuider | model=[1,0], conditioning=[5,0] |
| 8 | KSamplerSelect | sampler_name=euler |
| 9 | BasicScheduler | model=[1,0], scheduler=simple, steps=20, denoise=1.0 |
| 10 | SamplerCustomAdvanced | noise=[6,0], guider=[7,0], sampler=[8,0], sigmas=[9,0], latent_image=[5,1] |
| 11 | VAEDecode | samples=[10,0], vae=[3,0] (video VAE) |
| 12 | VAEDecodeAudio | samples=[10,0], vae=[4,0] (audio VAE) |
| 13 | CreateVideo | images=[11,0], audio=[12,0], fps=24 |
| 14 | SaveVideo | video=[13,0], filename_prefix=video/MiniMax_H3_test, format=auto, codec=auto |

## length 参数（帧数）

- 24fps 下对齐 17k+5 网格：124≈5s（训练范围 ~124-362），73≈3s
- 分辨率：原生画布短边 768px，上限 768×1344，取 32 的倍数（768×768 实测 OK）

## 提交与轮询

```bash
# 提交（用 Python 脚本, PowerShell curl -d 会破坏 JSON）
python submit_prompt.py h3_t2v_prompt.json
# → {"prompt_id": "09cdeb36-..."}

# 轮询
curl http://127.0.0.1:8188/queue          # queue_running 非空=在跑
curl http://127.0.0.1:8188/history/<id>   # 有 outputs=完成; .outputs.<node>.videos[0].filename
# 输出文件: ComfyUI\output\video\MiniMax_H3_test_00001_.mp4
```

## 日志观察点（服务器后台进程）

- `Found quantization metadata version 1` → int8 模型正常
- `Requested to load MiniMaxH3` → 扩散模型开始加载（20GB）
- `Model Initialization complete` + 进度条 `0/20` → 采样开始
- 8GB 显存下每步约 13-15s，全程 ~4.5 分钟 + VAE 解码 ~2 分钟

## 提示词要点（T2VA 模式）

- 同一提示词块内描述镜头 + 相机运动 + 音频（对白/音效/音乐），如 "Cinematic drone shot of ... Camera slowly pushes forward. Audio: soft ambient wind and distant birdsong."
- I2V：给 MiniMaxH3ImageToVideo 接 first_frame / last_frame（IMAGE 输入）
- R2V 需单独下载 ref2va 扩散模型（另 19.5GB）
