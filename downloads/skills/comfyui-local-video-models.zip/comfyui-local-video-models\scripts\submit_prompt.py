# -*- coding: utf-8 -*-
"""提交 API 格式 prompt 到本地 ComfyUI 并返回 prompt_id。
用法: python submit_prompt.py <workflow_api.json> [client_id]
注意: PowerShell 里 curl -d 传 JSON 会被引号转义破坏, 一律用本脚本提交。
"""
import json, sys, urllib.request

API = "http://127.0.0.1:8188/prompt"

def submit(prompt_file, client_id="hermes"):
    with open(prompt_file, "r", encoding="utf-8") as f:
        prompt = json.load(f)
    data = json.dumps({"prompt": prompt, "client_id": client_id}).encode("utf-8")
    req = urllib.request.Request(API, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            resp = json.loads(r.read().decode("utf-8"))
            print("提交结果:", json.dumps(resp, ensure_ascii=False))
            return resp
    except Exception as e:
        print("提交失败:", e)
        try:
            print(e.read().decode("utf-8") if hasattr(e, "read") else "")
        except Exception:
            pass
        return None

if __name__ == "__main__":
    pf = sys.argv[1] if len(sys.argv) > 1 else r"D:\pxy\h3_t2v_prompt.json"
    submit(pf)
