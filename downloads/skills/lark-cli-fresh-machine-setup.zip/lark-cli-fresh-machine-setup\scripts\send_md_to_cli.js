// 发送本地 Markdown 日报到「皮玺玉的飞书 CLI」智能体(2026-08-13 验证)
// 用法:node send_md_to_cli.js <md文件路径> [chat_id]
// 要求:node 用 Hermes 内置 node(D:\hermes\data\versions\<ver>\node\node.exe)
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const NODE = process.env.HERMES_NODE || 'D:/hermes/data/versions/0.19.0-cn.7/node/node.exe';
const RUNJS = process.env.LARK_RUN_JS || 'D:/hermes/data/versions/0.19.0-cn.7/node/node_modules/@larksuite/cli/scripts/run.js';
const CHAT = process.argv[3] || 'oc_3eab57d10ba96dbfbc6a19818a4d2b02'; // 皮玺玉的飞书 CLI
const file = process.argv[2];
if (!file) { console.error('usage: node send_md_to_cli.js <md path> [chat_id]'); process.exit(1); }
if (!fs.existsSync(NODE) || !fs.existsSync(RUNJS)) {
  // 尝试自动定位内置 node:扫描 D:\hermes\data\versions 下最新版
  const fsd = require('fs');
  const base = 'D:/hermes/data/versions';
  const vers = fsd.existsSync(base) ? fsd.readdirSync(base).filter(v => /^\d/.test(v)).sort().reverse() : [];
  if (vers.length) {
    const nodeDir = path.join(base, vers[0], 'node');
    console.error('auto nodeDir: ' + nodeDir);
    if (fsd.existsSync(path.join(nodeDir, 'node.exe'))) {
      process.env.HERMES_NODE = path.join(nodeDir, 'node.exe');
      const r2 = spawnSync(path.join(nodeDir, 'node.exe'), [__filename, file, CHAT], { encoding: 'utf8', env: process.env, timeout: 120000, stdio: 'inherit' });
      process.exit(r2.status ?? 1);
    }
  }
  console.error('node/run.js not found; set HERMES_NODE and LARK_RUN_JS env vars');
  process.exit(1);
}

const content = fs.readFileSync(file, 'utf8');
const env = { ...process.env, LARK_CLI_WORKSPACE: 'hermes', HERMES_HOME: process.env.HERMES_HOME || 'D:/hermes/data/hermes-home' };

console.error('sending ' + content.length + ' chars to chat ' + CHAT);
const r = spawnSync(NODE, [RUNJS, 'im', '+messages-send', '--as', 'user', '--chat-id', CHAT, '--markdown', content],
  { encoding: 'utf8', env, timeout: 90000, maxBuffer: 10 * 1024 * 1024 });

if (r.status !== 0) {
  console.error('exit: ' + r.status);
  console.error('stderr: ' + String(r.stderr || '').slice(0, 1000));
}
console.log(String(r.stdout || ''));
if (r.stdout && r.stdout.includes('"ok": true')) {
  console.error('SEND_OK');
} else {
  console.error('SEND_FAILED');
  process.exit(1);
}
