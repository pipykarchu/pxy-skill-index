---
name: lark-cli-fresh-machine-setup
description: "在新机器/新 Hermes 环境从零启用 lark-cli(飞书 CLI):用 Hermes 内置 node 安装、config bind 绑定、OAuth 授权、发送长中文日报到飞书 CLI 智能体。当 lark-cli 不在 PATH、auth status 报 not_configured、或需要把日报/长中文内容发到飞书 bot 智能体时使用。"
metadata:
  triggers:
    - "lark-cli 没装"
    - "not_configured"
    - "config bind"
    - "发给我的cli智能体"
    - "发飞书"
    - "auth login"
license: MIT
---

# lark-cli 新机器启用 & 发送到 CLI 智能体(Windows + Hermes CN)

> 场景:换新电脑/新 Hermes 环境后,`lark-cli` 不在 PATH、`auth status` 报 `not_configured`,或需要把日报等长中文内容发给「皮玺玉的飞书 CLI」智能体。
> 完整验证于 2026-08-13(Windows 11, Hermes CN 0.19.0-cn.7, 用户 16543)。

## 0. 前置判断(先做,避免白折腾)

```powershell
# lark-cli 在 PATH 吗?
where.exe lark-cli
# Hermes 内置 node 在哪?桌面版自带,版本号目录会变
Get-ChildItem "D:\hermes\data\versions" -Directory   # 找最新版本目录
# auth 状态(报 not_configured 说明需要 bind)
lark-cli auth status --json
```

- 系统 PATH 无 node/python 是常态(CN 桌面版自带 runtime),**不是故障**。
- 旧脚本里的路径(如 `C:\Users\皮玺玉\AppData\Roaming\npm\...`)是另一台机器的,别信。

## 1. 用 Hermes 内置 node 安装 lark-cli

关键:**npm postinstall 需要 `node` 在 PATH**,所以先把内置 node 目录注入 PATH 再装:

```powershell
$nodeDir = "D:\hermes\data\versions\0.19.0-cn.7\node"   # 版本号按实际
$env:Path = "$nodeDir;$env:Path"
npm install -g @larksuite/cli
# 验证
lark-cli --version   # 或 where.exe lark-cli 看 lark-cli.cmd 出现
```

## 2. config bind(把飞书应用绑定到 Hermes 上下文)

`auth status` 报 `"hermes context detected but lark-cli is not bound to it"` 时执行。

**⚠️ bind 是 write 操作,Hermes 安全审批会拦截(即使聊天里用户已确认)。** 三种路径:
1. 让用户在自己终端手动跑(最稳):
   ```powershell
   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned -Force   # PS 禁 .ps1 时先放行
   $env:Path = "D:\hermes\data\versions\0.19.0-cn.7\node;$env:Path"
   $env:HERMES_HOME = "D:\hermes\data\hermes-home"
   lark-cli config bind --source hermes --identity user-default
   ```
2. 或 agent 终端跑但需用户批准审批弹窗。
3. 不要反复重试同一命令——每次都触发审批超时,白等。

- `--identity user-default` 才能访问个人资源(妙记/日历/云文档);`bot-only` 拉不到个人数据。
- bind 需要用户确认(会覆盖既有绑定、锁定身份策略),必须先问。

## 3. OAuth 授权登录

```powershell
lark-cli auth login --recommend
```
- 输出 verification_url 后**阻塞等待**用户授权(~10 分钟)。
- **两步法更稳**:`--no-wait --json` 拿 device_code + verification_url → 生成二维码给用户扫 → 用户完成后 `lark-cli auth login --device-code <code>` 续轮询。
- 二维码:`lark-cli auth qrcode "<url>" --output ./qr.png`(**--output 必须相对路径**,绝对路径被拒;先 cd 到目标目录)。
- **不要同一轮展示 URL 后立刻阻塞执行 --device-code,也不要短 timeout 反复重试**——每次重启会作废上一轮 device code。
- 验证:`lark-cli auth status --json` 应见 `"tokenStatus": "valid"` + open_id。

## 4. 发送长中文日报到飞书 CLI 智能体

### 先找智能体的 chat_id(bot 不在 contact 搜索结果里)

```powershell
# bots 对 +search-user 不可见,必须列 p2p 会话
lark-cli im +chat-list --types p2p,group --as user --page-size 50
# 找「皮玺玉的飞书 CLI」→ chat_id oc_3eab57d10ba96dbfbc6a19818a4d2b02
```

### ⚠️ 核心陷阱:`--markdown @file` 不会读文件内容!

`lark-cli im +messages-send --markdown @daily.md` 会把字面文本 `@daily.md` 发出去(已验证踩坑)。`@file` 语法只对 `--data` 类参数有效。**markdown 内容必须作为参数值传入。**

### 正确姿势:node spawnSync 直调 run.js(绕开 cmd/PowerShell 编码)

中文/emoji/长内容走 `node run.js`,不要走 `.cmd`(cmd.exe 会搞坏 UTF-8 和 emoji):

```javascript
const { spawnSync } = require('child_process');
const fs = require('fs');
const NODE = 'D:/hermes/data/versions/0.19.0-cn.7/node/node.exe';
const RUNJS = 'D:/hermes/data/versions/0.19.0-cn.7/node/node_modules/@larksuite/cli/scripts/run.js';
const CHAT = 'oc_3eab57d10ba96dbfbc6a19818a4d2b02'; // 皮玺玉的飞书 CLI
const env = { ...process.env, LARK_CLI_WORKSPACE: 'hermes', HERMES_HOME: 'D:/hermes/data/hermes-home' };
const report = fs.readFileSync('D:/pxy/AI产品工作/汇报/daily/皮玺玉_20260812_日报.md', 'utf8');
const r = spawnSync(NODE, [RUNJS, 'im', '+messages-send', '--as', 'user',
  '--chat-id', CHAT, '--markdown', report],
  { encoding: 'utf8', env, timeout: 90000, maxBuffer: 10 * 1024 * 1024 });
console.log(r.stdout); // {"ok":true,...,"message_id":"om_..."}
```

- 脚本文件放 ASCII 路径(如 `C:\Users\<user>\AppData\Local\Temp\`),因为 `write_file` 写含中文的 `.ps1` 会乱码(PowerShell 5.1 按 ANSI 解析)。
- 发完用 `im +chat-messages-list --chat-id <id> --as user --page-size 5` 验证 `message_id` 存在且 content 含日报标题(消息类型应为 `post`)。

## 5. 验证与清理

- 发送成功返回 `"ok": true` + `message_id`;`im +chat-messages-list` 可回查消息内容。
- 结束前清理临时脚本(node/js),只留交付物。

## 可复用脚本

- `scripts/send_md_to_cli.js` — 发送本地 MD 文件到 CLI 智能体(自动定位内置 node,传 md 路径即可):
  ```
  node send_md_to_cli.js "D:/pxy/AI产品工作/汇报/daily/皮玺玉_20260812_日报.md"
  ```
  用法:`node <skill_dir>/scripts/send_md_to_cli.js <md路径> [chat_id]`;stderr 输出 `SEND_OK`/`SEND_FAILED`。

## 已知环境事实(2026-08-13,可能漂移)

- Hermes CN 桌面版内置 node v22:`D:\hermes\data\versions\0.19.0-cn.7\node\`
- HERMES_HOME:`D:\hermes\data\hermes-home`
- 皮玺玉 open_id:`ou_7d05b327389c521f51426312ac5c9e2b`
- 皮玺玉的飞书 CLI 智能体 chat_id:`oc_3eab57d10ba96dbfbc6a19818a4d2b02`
- lark-cli.cmd 路径:`<nodeDir>\lark-cli.cmd`;run.js 路径:`<nodeDir>\node_modules\@larksuite\cli\scripts\run.js`

## 相关

- 日报格式/内容规范 → `daily-report-mozin`(手动维护,勿改)
- lark-cli 命令速查 → `lark-cli`(手动维护,勿改)
- 本技能只覆盖「新环境启用 + 发送通道」,与上述两个技能互补。

## 二次复用验证(2026-08-13 当晚)

- `--markdown <内容>` 传参方式已再次用于常规日报(8/13)发送,`msg_type=post` 可回查,稳定。
- 发送后验证链:`im +chat-messages-list --chat-id <id> --as user --page-size 5` → 按 `message_id` 找目标消息 → `content` 以 `🗓 产品日报` 开头即成功;不要只看 `"ok": true`。
- 日报内容迭代(如改协调帮助格式)后要**重发**,旧消息留在对话里不撤回,以最新 message_id 为准。
