#!/usr/bin/env node
/**
 * 飞书任务批量创建脚本模板
 * 
 * 用法：
 * 1. 准备 tasks.json（任务数组，格式见下方 SCHEMA）
 * 2. node batch-create-tasks.js tasks.json
 * 
 * 依赖：lark-cli 已安装且已 auth login
 * 平台：Windows PowerShell 5.1 / Node.js 18+
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// ─── 配置 ───
const LARK_CLI = 'lark-cli';  // 如有 Device Guard 拦截，改为 '%USERPROFILE%\lark-cli-copy.exe'
const AS_USER = '--as user';

// ─── 任务JSON Schema ───
const SCHEMA = `
[
  {
    "type": "milestone",           // "milestone"=里程碑父任务, "deliverable"=交付物子任务
    "summary": "8.26 需求定稿+搓图", // 标题（日期+重点，不套Mozin前缀）
    "description": "【交付】D层全量+E层设计系统【量化】9份文档【验收】CEO初审通过",
    "tasklist_guid": "<需求管理清单GUID>",
    "section_guid": "<里程碑分组GUID>",
    "start_ts": 1756166400000,     // 开始时间戳（毫秒）
    "due_ts": 1756252800000,       // 截止时间戳（毫秒）
    "assignee_id": "ou_xxx",       // 负责人 open_id（可选）
    "parent_guid": "",             // 交付物子任务填父里程碑GUID
    "deliverable_section_guid": "" // 交付物移到交付与验收分组的GUID（可选）
  }
]
`;

// ─── 主函数 ───
async function main() {
  const jsonFile = process.argv[2];
  if (!jsonFile) {
    console.error('用法: node batch-create-tasks.js <tasks.json>');
    console.error('Schema:\n', SCHEMA);
    process.exit(1);
  }

  // 读取任务JSON（剥离BOM）
  let raw = fs.readFileSync(jsonFile, 'utf8');
  raw = raw.replace(/^\uFEFF/, '');
  const tasks = JSON.parse(raw);

  console.log(`📋 共 ${tasks.length} 个任务待创建\n`);

  const results = [];

  for (let i = 0; i < tasks.length; i++) {
    const t = tasks[i];
    console.log(`[${i + 1}/${tasks.length}] 创建: ${t.summary}`);

    try {
      if (t.type === 'milestone') {
        // 创建里程碑父任务（用 @file 传JSON）
        const taskJson = {
          summary: t.summary,
          description: t.description || '',
          tasklists: [{
            tasklist_guid: t.tasklist_guid,
            section_guid: t.section_guid
          }],
          start: { timestamp: t.start_ts, is_all_day: true },
          due: { timestamp: t.due_ts, is_all_day: true }
        };
        if (t.assignee_id) {
          taskJson.members = [{ id: t.assignee_id, role: 'assignee' }];
        }

        const tmpFile = path.join(__dirname, `_tmp_task_${i}.json`);
        fs.writeFileSync(tmpFile, JSON.stringify(taskJson), 'utf8');

        const output = execSync(
          `${LARK_CLI} task tasks create --data "@${tmpFile}" ${AS_USER}`,
          { encoding: 'utf8', timeout: 30000 }
        );
        
        // 解析返回的 task guid
        const match = output.match(/"guid"\s*:\s*"([^"]+)"/);
        const guid = match ? match[1] : '';
        
        results.push({ index: i, summary: t.summary, guid, status: 'created' });
        console.log(`  ✅ 创建成功 GUID: ${guid}`);
        
        fs.unlinkSync(tmpFile);

      } else if (t.type === 'deliverable') {
        // 创建交付物子任务
        const output = execSync(
          `${LARK_CLI} task +create --summary "${t.summary}" --tasklist-id "${t.tasklist_guid}" ${AS_USER}`,
          { encoding: 'utf8', timeout: 30000 }
        );
        
        const match = output.match(/"guid"\s*:\s*"([^"]+)"/);
        const guid = match ? match[1] : '';

        if (guid && t.parent_guid) {
          // 挂到里程碑父任务
          execSync(
            `${LARK_CLI} task +set-ancestor --task-id "${guid}" --ancestor-id "${t.parent_guid}" ${AS_USER}`,
            { encoding: 'utf8', timeout: 30000 }
          );
          console.log(`  ✅ 已挂到父任务`);
        }

        if (guid && t.deliverable_section_guid) {
          // 移到交付与验收分组
          execSync(
            `${LARK_CLI} task +tasklist-task-add --tasklist-id "${t.tasklist_guid}" --task-id "${guid}" --section-guid "${t.deliverable_section_guid}" ${AS_USER}`,
            { encoding: 'utf8', timeout: 30000 }
          );
          console.log(`  ✅ 已移到交付分组`);
        }

        results.push({ index: i, summary: t.summary, guid, parent: t.parent_guid, status: 'created' });
      }

      // 避免飞书API限流
      await sleep(500);

    } catch (err) {
      console.error(`  ❌ 失败: ${err.message.split('\n')[0]}`);
      results.push({ index: i, summary: t.summary, status: 'failed', error: err.message });
    }
  }

  // 输出结果摘要
  console.log('\n═══════════════════════════════');
  console.log(`✅ 成功: ${results.filter(r => r.status === 'created').length}`);
  console.log(`❌ 失败: ${results.filter(r => r.status === 'failed').length}`);
  console.log('═══════════════════════════════\n');

  // 保存结果
  const resultFile = jsonFile.replace('.json', '_result.json');
  fs.writeFileSync(resultFile, JSON.stringify(results, null, 2), 'utf8');
  console.log(`📄 结果已保存: ${resultFile}`);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

main().catch(err => {
  console.error('致命错误:', err);
  process.exit(1);
});
