---
name: feishu-diagram-board-online-edit
description: 用于把含 Mermaid 的 Markdown 架构文档生成可编辑、可框选评论、可本地预览并能原位发布到飞书的交互式 HTML 图集；也用于修复保存总显示取消、评论发布不了或飞书预览丢图。Use when generating or repairing this Feishu architecture-board workflow.
license: MIT
metadata:
  version: 1.0.1
  author: PXY Skill Library
  platforms: [windows]
  hermes:
    tags: [architecture, mermaid, dashboard, comments, feishu, online-editing, publishing]
    related_skills: [architecture-diagram, dashboard-builder, feishu-selective-upload, multi-agent-task-harness]
---

# 飞书架构图集在线编辑与评论

把 Markdown 作为唯一源稿，生成一个离线可看的 HTML 架构图集。图集支持目录、搜索、Mermaid 静态 SVG、单图编辑、Markdown 在线预览、框选文字评论，以及通过本机保存桥原位更新飞书文件。

## 适用范围

- 从 Markdown + Mermaid 生成可交互图集看板。
- 修复“保存修改显示已取消”“评论只存在本机”“飞书链接被换掉”等问题。
- 把编辑后的源稿和评论发布到同一个飞书 file token。
- 给 Codex、Hermes 或项目 `AGENTS.md` 提供可复用入口。

这不是真正的多人协同文档服务。在线保存依赖编辑者电脑上的本机桥；桥未启动时，飞书里的 HTML 只能查看和本地预览，不能写回。

## 必要输入

1. Markdown 源稿，Mermaid 代码块使用 ` ```mermaid `。
2. `board.config.json`，从 [templates/board.config.example.json](templates/board.config.example.json) 复制后填写。
3. 飞书目标文件的 `file token`；仅在新建或按文件名查找时需要 `folder token`。
4. 已登录用户态的 Hermes `lark-cli` 运行时。
5. Microsoft Edge，用于把 Mermaid 预渲染成静态 SVG。

保存密码优先通过环境变量 `BOARD_SAVE_PASSWORD` 注入。不要把真实密码、access token 或其他凭据提交到技能库。

## 工作流

1. 读取源稿、当前 HTML、评论 JSON 和配置，确认目标 file token，避免覆盖错文件。
2. 执行环境检查。完成标准：Markdown、Mermaid 运行库、Edge、lark-cli、file token、folder token 都通过。

```powershell
node scripts/check-env.js --config .\board.config.json
```

3. 生成本地看板。完成标准：输出 HTML 存在，脚本报告 SVG 数量，浏览器禁用网络时图仍能显示。

```powershell
node scripts/gen-diagram-html.js --config .\board.config.json
```

4. 启动本机保存桥。完成标准：`/health` 返回 `ok=true`，`/preview` 能打开生成的 HTML。

```powershell
$env:BOARD_SAVE_PASSWORD = Read-Host '保存密码'
node scripts/online-save-bridge.js --config .\board.config.json
```

也可以运行 [scripts/启动在线保存桥.ps1](scripts/启动在线保存桥.ps1)，并通过 `-Config` 传入配置文件路径。

5. 浏览器验收：

- “保存修改”弹出页面内密码框，不使用 `window.prompt()`。
- 错误密码明确失败，源稿和线上文件不变化。
- 应用预览后输入正确密码，提示“已保存到飞书在线版”。
- 框选正文文字后出现“评论选中内容”；发布后选文高亮，刷新仍存在。
- 上传失败时源稿或评论 JSON 自动回滚，不显示假成功。

6. 飞书回读。已有 `file token` 时直接原位覆盖并下载同一 token，比对本地与回读文件 SHA256；新建或仅按文件名定位时再使用 `folder token`。

## 关键约束

- Markdown 是唯一源稿；HTML 是生成物，不手工长期维护。
- 正文与评论发布必须串行，避免并发覆盖。
- 保存正文失败时恢复旧 Markdown；发布评论失败时恢复旧评论 JSON。
- 原位覆盖必须使用固定 file token，不能因为文件移动了文件夹就新建同名文件代替。
- 静态 HTML 中不嵌入保存密码。密码只从弹窗发送到 `127.0.0.1` 保存桥验证。
- 评论由章节或段落锚点、选文、评论内容组成；重新生成后仍能对齐并高亮。
- 静态 SVG 渲染成功只证明图集可读，不证明真实账号、AI、设备、支付或云服务已经接入。

## Codex 与 Hermes 入口

- Codex：直接说“用 feishu-diagram-board-online-edit 生成/修复在线架构图集”。
- Hermes：`/skill feishu-diagram-board-online-edit`，或启动时使用 `hermes -s feishu-diagram-board-online-edit`。
- 多智能体任务：先加载 `multi-agent-task-harness`，再让本技能负责图集生成、保存桥和验收边界。

## 故障处理

详细接口、状态码、回滚和安全边界见 [references/online-publishing-contract.md](references/online-publishing-contract.md)。

- 一点保存就“已取消”：检查 HTML 是否仍有 `window.prompt()`；重新生成并上传最新 HTML。
- 保存提示桥未启动：先访问 `http://127.0.0.1:<port>/health`，再检查端口、配置和防火墙。
- 评论发布后刷新丢失：确认请求走 `/comment`，评论 JSON 已更新，并且上传后回读成功。
- 上传成功但飞书没变：核对 file token，不要只看进程 exit code；必须检查飞书列表回读结果。
- 图在飞书里不见：确认生成日志包含静态 SVG 数量，HTML 内存在 `<svg`，再重新原位覆盖。

## 验收清单

- [ ] `node --check` 通过四个脚本。
- [ ] `check-env.js` 通过。
- [ ] 本地生成与静态 SVG 预渲染通过。
- [ ] `/health`、`/preview`、`/comments` 可访问。
- [ ] 保存弹窗、正确/错误密码、取消行为正确。
- [ ] 框选、发布、选文高亮、刷新保留正确。
- [ ] 正文与评论失败路径均完成回滚测试。
- [ ] 飞书 file token、文件名、修改时间和文件大小完成结构化回读。
- [ ] Codex 可发现，Hermes `/skill` 可加载，GitHub Pages 下载包已回读。
