---
name: feishu-diagram-board-online-edit
version: 1.0.0
title: 飞书图集看板在线编辑与密码保存工作流
description: "从 Markdown 源稿生成交互式业务架构图集看板（内嵌 Mermaid + 评论选文 + 高亮 + 暗色主题），上传飞书云空间后支持在线编辑源稿、页面内密码弹窗验证、通过本机在线保存桥原位回写到飞书在线版。触发词：'生成图集看板'、'在线编辑飞书HTML'、'图集密码保存'、'飞书HTML回写'、'架构图集在线保存桥'。"
license: MIT
platforms: [windows]
triggers:
  - "生成图集看板"
  - "在线编辑飞书HTML"
  - "图集密码保存"
  - "飞书HTML回写"
  - "架构图集在线保存桥"
  - "图集看板发布到飞书"
metadata:
  category: productivity
  tags: [feishu, mermaid, diagram, html, online-edit, password, lark-cli]
  related_skills: [lark-drive, lark-cli, markdown-diagram-board]
---

# 飞书图集看板在线编辑与密码保存工作流

## 适用场景

产品经理/架构师用 Markdown 写业务架构图集（含 Mermaid 流程图/ER图/用例图/状态机等），需要：
1. **生成**一个美观的交互式 HTML 看板（暗色主题、目录导航、图表缩放/聚焦、搜索）
2. **上传**到飞书云空间，获得在线预览链接分享给团队
3. **在线编辑**：在飞书预览页面里直接编辑 Markdown 源稿、应用预览
4. **评论标注**：框选正文 → 添加评论 → 高亮选文 → localStorage 持久化
5. **密码保存**：页面内密码弹窗验证 → 调用本机在线保存桥 → 原位覆盖飞书在线版

## 系统架构

```
Markdown 源稿 (.md)
    │
    ▼
gen-diagram-html.js  ← 生成器（Markdown → 交互式 HTML，内嵌 Mermaid + 评论 + 编辑器）
    │
    ├── 本地预览：直接打开 .html
    └── --upload：调 lark-cli drive +upload → 飞书云空间（原位覆盖，保留 token/链接）
                                        │
                                        ▼
                            飞书在线预览（iframe 内）
                                        │
    ┌───────────────────────────────────┘
    │
    ▼
用户点击"编辑源稿" → 修改 Markdown → "保存修改"
    │
    ├── 页面内密码弹窗（pwd-modal，非 window.prompt）
    │       └── 飞书 iframe 内 window.prompt 会被拦截/返回 null
    │           → 必须用页面内弹窗（z-index:70 backdrop + z-index:71 modal）
    │
    ├── 密码正确 → fetch POST http://127.0.0.1:8794/save
    │
    ▼
online-save-bridge.js（本机 HTTP 服务，端口 8794）
    │
    ├── 写入本地 .md 源稿
    └── 调 gen-diagram-html.js --upload → 重新生成 HTML + 上传飞书
                                        │
                                        ▼
                              返回 {ok:true} → toast "已保存到飞书在线版"
```

## 前置条件

- Node.js（Hermes 内置的 `%LOCALAPPDATA%\hermes\node\node.exe` 或系统 node）
- lark-cli 已安装并 `auth login`（`--upload` 需要飞书用户态凭据）
- Mermaid 运行库 `vendor/mermaid-10.9.1.min.js`（内嵌到 HTML，离线可用）
- 飞书云空间目标文件夹的 folder_token

## 核心文件清单

| 文件 | 作用 |
|------|------|
| `scripts/gen-diagram-html.js` | 生成器：Markdown → 交互式 HTML，支持 `--upload` 上传飞书 |
| `scripts/online-save-bridge.js` | 在线保存桥：本机 HTTP 服务(端口8794)，接收密码+Markdown → 回写飞书 |
| `scripts/启动在线保存桥.bat` | 启动保存桥的 Windows 批处理 |
| `scripts/重新生成图集看板.bat` | 重新生成 HTML 的 Windows 批处理 |
| `templates/pwd-modal-snippet.txt` | 页面内密码弹窗的 CSS+HTML+JS 代码片段（用于修复旧版 HTML） |
| `templates/feishu-upload-config.json` | 飞书文件夹 token 和已知文件 token 配置模板 |
| `references/pitfalls.md` | 踩坑记录（prompt 拦截、飞书上传回读、lark-cli 运行时定位等） |

## 快速开始

### 1. 首次生成并上传

```powershell
cd <图集目录>
# 生成 HTML（不上传）
node gen-diagram-html.js <markdown文件名>.md

# 生成并上传到飞书
node gen-diagram-html.js <markdown文件名>.md --upload
```

### 2. 启动在线保存桥

```powershell
# 双击或在终端运行
.\启动在线保存桥.bat
# 或直接：
node online-save-bridge.js
```

保存桥启动后显示 `Mozin 在线保存桥已启动：http://127.0.0.1:8794`

### 3. 在飞书在线编辑

1. 打开飞书云空间的 HTML 文件预览链接
2. 点击工具栏"编辑源稿"按钮 → 右侧滑出编辑器
3. 修改 Markdown → 点击"应用预览"查看效果
4. 点击"保存修改" → 弹出页面内密码弹窗
5. 输入密码（默认 7575）→ 确认 → toast 显示"已保存到飞书在线版"
6. 如果保存桥未启动 → toast 显示"在线版未保存：请先启动本机在线保存桥"

### 4. 评论功能

- 点击工具栏"评论"按钮 → 打开评论面板
- 鼠标框选正文中任意文本 → 弹出"评论选中内容"按钮
- 点击按钮 → 选文高亮 + 评论面板自动打开 → 输入评论 → 提交
- 评论存储在浏览器 localStorage，按锚点（章节/段落）分组
- 点击已有评论 → 自动滚动到对应位置并高亮

## 生成器配置

编辑 `gen-diagram-html.js` 顶部的常量：

```javascript
const DEFAULT_MD = '<你的Markdown文件名>.md';
const FEISHU_FOLDER_TOKEN = '<飞书文件夹token>';
const KNOWN_FEISHU_FILE_TOKENS = {
  '<HTML文件名>': '<飞书文件token>'  // 原位覆盖时必需
};
```

**获取 folder_token**：飞书云空间打开目标文件夹 → URL 中 `/folder/` 后面的字符串。

**获取 file_token**：上传后从 lark-cli 返回的 JSON 中获取，或从飞书文件分享链接中提取。

## 密码弹窗实现要点

### 为什么不能用 window.prompt

飞书 HTML 预览运行在 iframe 内，`window.prompt()` 会被飞书的安全策略拦截或返回 `null`，导致用户看到"已取消保存"而实际没有取消。

### 页面内弹窗方案

**CSS**（z-index 高于编辑器和评论面板）：
```css
.pwd-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:70}
.pwd-modal{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:71}
```

**HTML**（toast 元素之后）：
```html
<div class="pwd-backdrop" id="pwd-backdrop"></div>
<div class="pwd-modal" id="pwd-modal" role="dialog" aria-modal="true">
  <h3>输入保存密码</h3>
  <p>密码验证后通过在线保存桥同步到飞书在线版。</p>
  <input type="password" id="pwd-input" autocomplete="off">
  <div class="pwd-actions">
    <button id="pwd-cancel">取消</button>
    <button id="pwd-confirm">确认保存</button>
  </div>
</div>
```

**JS**（异步 Promise，替代同步 prompt）：
```javascript
function verifySavePassword(){
  return new Promise(function(resolve){
    // 显示弹窗 → 监听确认/取消 → resolve(true/false)
    // Enter=确认, Escape=取消, 点击backdrop=取消
  });
}
async function saveChanges(){
  var ok = await verifySavePassword();
  if(!ok) return;
  // fetch POST → online-save-bridge
}
```

## 在线保存桥工作原理

```
Browser (飞书iframe) --POST--> 127.0.0.1:8794/save
  body: {password:"7575", markdown:"<修改后的MD>"}
    │
    ▼
online-save-bridge.js
  1. 验证 password === '7575'
  2. fs.writeFileSync(本地.md, markdown)
  3. spawn('node gen-diagram-html.js <md> --upload')
  4. 返回 {ok:true, output:"飞书原位覆盖成功..."}
```

**关键点**：
- CORS 头已设置（`Access-Control-Allow-Origin: *`），飞书 iframe 可跨域请求
- 保存桥只在 `127.0.0.1` 监听，不暴露到外网
- 密码是前端硬编码 + 后端双重验证（前后端一致才放行）
- 保存桥调用生成器的 `--upload` 模式，自动重新生成 HTML + 上传飞书

## 飞书上传机制

生成器 `--upload` 标志触发 `uploadAndVerify()` 函数：

1. `lark-cli drive files list --folder-token <token>` → 列出文件夹内文件
2. 匹配同名文件 + 已知 token → 确定"覆盖"还是"新建"
3. `lark-cli drive +upload --folder-token <token> --file <file> --name <name> [--file-token <existing>]`
4. 如果覆盖：`lark-cli drive +move --file-token <token> --folder-token <token>` 确保归位
5. 再次 list 回读验证 → 返回文件信息

**lark-cli 运行时定位**：自动查找 `%LOCALAPPDATA%\hermes\node\` 下的 node.exe 和 @larksuite/cli runner。

## 分步操作

### 场景 A：新建图集看板并上传飞书

1. 准备 Markdown 源稿（含 mermaid 代码块）
2. 复制技能 `scripts/` 下所有文件到工作目录
3. 编辑 `gen-diagram-html.js`：改 `DEFAULT_MD`、`FEISHU_FOLDER_TOKEN`、`KNOWN_FEISHU_FILE_TOKENS`
4. 复制 `vendor/mermaid-10.9.1.min.js` 到工作目录 `vendor/` 下
5. 运行：`node gen-diagram-html.js <md文件> --upload`
6. 记录返回的飞书文件 token，填入 `KNOWN_FEISHU_FILE_TOKENS`（下次覆盖用）
7. 双击 `启动在线保存桥.bat` 启动桥
8. 在飞书预览页面测试编辑+保存

### 场景 B：修复已有 HTML 的 prompt 弹窗

1. 打开 `templates/pwd-modal-snippet.txt` 获取修复代码
2. 在 HTML 的 `<style>` 中追加密码弹窗 CSS（搜索 `.toast.show` 后面插入）
3. 在 HTML 的 `<div class="toast" id="toast">` 后追加弹窗 HTML
4. 替换 `verifySavePassword` 函数（搜索 `window.prompt('请输入保存密码')` 定位）
5. 替换 `saveChanges` 函数中的 `if(!verifySavePassword())return` 为 `var ok=await verifySavePassword();if(!ok)return`

### 场景 C：修改保存密码

1. 编辑 `gen-diagram-html.js`：改 `var SAVE_PASSWORD='7575'` 为新密码
2. 编辑 `online-save-bridge.js`：改 `const PASSWORD = '7575'` 为相同密码
3. 重新生成 HTML：`node gen-diagram-html.js <md文件>`
4. 重启在线保存桥

## 坑与排障

### 坑 1：window.prompt 在飞书 iframe 内被拦截
**症状**：点击"保存修改"立即显示"已取消保存"，没有密码框出现
**根因**：飞书 HTML 预览在 iframe 内运行，`window.prompt()` 返回 `null`
**修复**：改用页面内密码弹窗（见"密码弹窗实现要点"）

### 坑 2：保存桥未启动时保存失败
**症状**：输入密码后 toast 显示"在线版未保存：请先启动本机在线保存桥"
**根因**：`http://127.0.0.1:8794` 连接被拒（保存桥进程未运行）
**修复**：双击 `启动在线保存桥.bat`，确认终端显示"已启动"

### 坑 3：飞书上传报 token 未找到
**症状**：`Error: 飞书目标文件 token 未在指定文件夹中找到`
**根因**：`KNOWN_FEISHU_FILE_TOKENS` 中的 token 与实际文件夹内文件不匹配
**修复**：清空 `KNOWN_FEISHU_FILE_TOKENS` 对应条目 → 生成器自动创建新文件 → 记录新 token

### 坑 4：lark-cli 运行时未找到
**症状**：`Error: 未找到 lark-cli 运行时`
**根因**：Hermes 内置 node 路径变化或 lark-cli 未安装
**修复**：检查 `%LOCALAPPDATA%\hermes\node\node.exe` 和 `node_modules\@larksuite\cli\scripts\run.js` 是否存在；运行 `lark-cli auth login` 重新认证

### 坑 5：DEFAULT_MD 文件名过时
**症状**：`Error: 找不到 Markdown 源稿`
**根因**：生成器中 `DEFAULT_MD` 硬编码了旧文件名
**修复**：运行时显式传参 `node gen-diagram-html.js <实际md文件名>`，或更新 `DEFAULT_MD` 常量

### 坑 6：Mermaid 预渲染失败
**症状**：生成器报 `Mermaid SVG 预渲染失败`
**根因**：`prerender-diagram-html.js` 找不到无头浏览器或 Mermaid 语法错误
**修复**：检查 Mermaid 代码块语法；确认 `vendor/mermaid-10.9.1.min.js` 存在

### 坑 7：评论丢失
**症状**：刷新页面后评论消失
**根因**：评论存储在 localStorage，飞书预览 iframe 的 localStorage 可能被隔离
**说明**：这是预期行为——评论是本地评审辅助工具，不同步到飞书。需要正式评审记录时用飞书评论功能。

## 验证清单

- [ ] `node gen-diagram-html.js <md>` 成功生成 HTML，无报错
- [ ] 生成的 HTML 在浏览器打开后图表正常渲染
- [ ] HTML 中搜索 `window.prompt` 返回 0 结果
- [ ] HTML 中搜索 `pwd-modal` 返回 CSS + HTML + JS 三处
- [ ] `node online-save-bridge.js` 启动后显示端口 8794
- [ ] `curl http://127.0.0.1:8794/health` 返回 `{"ok":true}`
- [ ] 飞书预览页面点击"保存修改"弹出页面内密码弹窗
- [ ] 输入错误密码 → toast "保存密码错误"
- [ ] 输入正确密码 + 桥已启动 → toast "已保存到飞书在线版"
- [ ] 输入正确密码 + 桥未启动 → toast "在线版未保存：请先启动本机在线保存桥"

## 相关技能

- `lark-drive`：飞书云空间操作（上传/下载/移动/删除）
- `lark-cli`：飞书 CLI 安装与认证
- `markdown-diagram-board`：纯 Markdown → HTML 看板（无飞书回写）
