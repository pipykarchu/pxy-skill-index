@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Rebuilding HTML board from MD source...
node gen-diagram-html.js
echo.
echo Done. Press any key to close.
pause >nul
