#!/usr/bin/env node
/**
 * Local-only bridge for saving the edited Markdown back to the Feishu HTML.
 * The browser page posts to this bridge after the user enters the save password
 * (via the in-page modal, NOT window.prompt which gets blocked in Feishu iframes).
 *
 * Usage:
 *   node online-save-bridge.js
 *
 * Configuration: edit the constants below to match your project.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

// ─── CONFIG (edit these for your project) ───────────────────────────
const PORT = 8794;
const PASSWORD = '7575';
const ROOT = __dirname;
const SOURCE = path.join(ROOT, '<your-markdown>.md');  // ← edit this
const GENERATOR = path.join(ROOT, 'gen-diagram-html.js');
// ─── END CONFIG ──────────────────────────────────────────────────────

function send(res, status, payload) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  });
  res.end(JSON.stringify(payload));
}

function runGenerator() {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [GENERATOR, SOURCE, '--upload'], {
      cwd: ROOT,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe']
    });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => { stdout += chunk; });
    child.stderr.on('data', (chunk) => { stderr += chunk; });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code === 0) resolve(stdout.trim());
      else reject(new Error((stderr || stdout || '在线版同步失败').trim().slice(-4000)));
    });
  });
}

const server = http.createServer((req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, { ok: true });
  if (req.method === 'GET' && req.url === '/health') return send(res, 200, { ok: true, service: 'online-save-bridge' });
  if (req.method !== 'POST' || req.url !== '/save') return send(res, 404, { ok: false, error: 'not_found' });

  let body = '';
  req.on('data', (chunk) => {
    body += chunk;
    if (body.length > 2 * 1024 * 1024) req.destroy();
  });
  req.on('error', () => send(res, 400, { ok: false, error: 'request_error' }));
  req.on('end', async () => {
    try {
      const input = JSON.parse(body || '{}');
      if (input.password !== PASSWORD) return send(res, 403, { ok: false, error: 'password' });
      if (typeof input.markdown !== 'string' || !input.markdown.trim()) return send(res, 400, { ok: false, error: 'markdown_required' });
      fs.writeFileSync(SOURCE, input.markdown.replace(/^\uFEFF/, ''), 'utf8');
      const output = await runGenerator();
      send(res, 200, { ok: true, message: '在线版已原位更新', output });
    } catch (error) {
      send(res, 500, { ok: false, error: String(error.message || error) });
    }
  });
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('在线保存桥已启动：http://127.0.0.1:' + PORT);
  console.log('健康检查：http://127.0.0.1:' + PORT + '/health');
  console.log('保存接口：POST http://127.0.0.1:' + PORT + '/save');
});
