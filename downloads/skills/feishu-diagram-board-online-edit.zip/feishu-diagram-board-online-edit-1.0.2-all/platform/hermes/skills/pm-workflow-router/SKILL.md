---
name: pm-workflow-router
description: MUST use for 产品/PRD/Mozin/飞书/墨刀/工程交付 tasks on Hermes; routes to the best installed Skill and announces platform, purpose, and limits.
---

# PM Workflow Router for Hermes

Start every invocation with one concise line:

`已为你调用【技能名】（当前平台：Hermes）。本次用于：目的。`

If a required capability is unavailable, add: `当前 Hermes 缺少【能力/依赖】，将使用【替代方案】。`

## Route the task

| User intent | Load or invoke |
|---|---|
| Idea discovery and scope | `brainstorming` -> `product-planning-workflow` -> `prd-writer-agent` |
| Mozin full delivery | Prefer `mozin-product-delivery-pxy`; use `mozin-product-delivery` for the company baseline SOP |
| Feishu to prototype pipeline | `feishu-modao-product-workflow` or `feishu-modao-ai-workflow` with `lark-cli` and `modao-mcp` |
| Delivery planning | `writing-plans` -> `executing-plans` |
| Debugging and quality | `systematic-debugging` -> `test-driven-development` -> `verification-before-completion` |
| Code review and branch closeout | `requesting-code-review` -> `finishing-a-development-branch` |
| Dashboard/prototype | `dashboard-builder`; add the relevant `gsap-*` module only when animation is needed |
| Documents and media | Route to the installed format-specific skill; keep raw inputs and generated outputs |
| Local automation | Prefer Hermes local skills and CLI workflows; report any external account or MCP dependency first |

Load only the skills needed for the current task. Preserve the bottom-level skill instructions; this router selects and sequences them but does not replace them.

For cross-platform requests, state which steps must continue in Codex or Claude and why. Never claim that a skill is installed merely because an archived copy exists.
