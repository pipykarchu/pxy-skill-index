---
name: pm-workflow-router
description: Route product-manager work to the best installed Codex skills. Use automatically for product discovery, PRDs, engineering delivery, project planning, prototypes, research, documents, reviews, testing, deployment, and Mozin workflows. Always announce the current platform and selected skills before acting.
---

# PM Workflow Router for Codex

Start every invocation with one concise line:

`已为你调用【技能名】（当前平台：Codex）。本次用于：目的。`

If a required capability is unavailable, add: `当前 Codex 缺少【能力/依赖】，将使用【替代方案】。`

## Route the task

| User intent | Load or invoke |
|---|---|
| Idea discovery and scope | `brainstorming` -> `prd-writer-agent` |
| Mozin full delivery | Use `mozin-product-delivery` for the cross-platform baseline; hand PXY Feishu-to-Modao automation to Hermes |
| Delivery planning | `writing-plans` -> `executing-plans` |
| Debugging and quality | `systematic-debugging` -> `test-driven-development` -> `verification-before-completion` |
| Code review and branch closeout | `requesting-code-review` or `review-agent` -> `finishing-a-development-branch` |
| Figma implementation | `figma-use` before `figma` or `figma-implement-design` |
| Documents, PDF, sheets, slides | Prefer Codex bundled `documents`, `pdf`, `Spreadsheets`, or `Presentations` |
| Web research and visible browser work | `control-in-app-browser`; use a search skill when sources are required |
| Image creation | Codex system `imagegen` |
| Feishu/Lark | Use installed `lark-*` skills; do not substitute Hermes-only commands silently |

Load only the skills needed for the current task. Preserve the bottom-level skill instructions; this router selects and sequences them but does not replace them.

For cross-platform requests, state which steps must continue in Claude or Hermes and why. Never claim that a skill is installed merely because an archived copy exists.
