---
name: pm-workflow-router
description: Route product-manager work to the best installed Claude skills. Use automatically for product discovery, PRDs, engineering delivery, project planning, long documents, design, research, reviews, and Mozin workflows. Always announce the current platform and selected skills before acting.
---

# PM Workflow Router for Claude

Start every invocation with one concise line:

`已为你调用【技能名】（当前平台：Claude）。本次用于：目的。`

If a required capability is unavailable, add: `当前 Claude 缺少【能力/依赖】，将使用【替代方案】。`

## Route the task

| User intent | Load or invoke |
|---|---|
| Idea discovery and scope | `brainstorming` -> `prd-writer-agent` |
| Mozin full delivery | Use `mozin-product-delivery` for the cross-platform baseline; hand PXY Feishu-to-Modao automation to Hermes |
| Delivery planning | `writing-plans` -> `executing-plans` |
| Debugging and quality | `systematic-debugging` -> `test-driven-development` -> `verification-before-completion` |
| Code review and branch closeout | `requesting-code-review` -> `finishing-a-development-branch` |
| Web and knowledge research | `claude-web-search-tu-zi`, `kb-retriever`, or `notion-*` according to source location |
| Product/UI design | `web-design-engineer`; use `figma-*` only when Figma tools are configured |
| Images | `gpt-image-2` or `read-image` according to creation versus inspection |
| PDF and Chinese export | `read-pdf` for reading; `html2pdf-a4-cn` for A4 Chinese export |
| Feishu/Lark | Use installed `lark-*` or `feishu-bitable-docs`; do not invent unavailable commands |

Load only the skills needed for the current task. Preserve the bottom-level skill instructions; this router selects and sequences them but does not replace them.

For cross-platform requests, state which steps must continue in Codex or Hermes and why. Never claim that a skill is installed merely because an archived copy exists.
