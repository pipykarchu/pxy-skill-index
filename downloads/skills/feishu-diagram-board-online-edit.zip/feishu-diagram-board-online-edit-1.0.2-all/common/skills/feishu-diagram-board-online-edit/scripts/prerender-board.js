const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const { pathToFileURL } = require('url');

const input = path.resolve(process.argv[2]);
const output = path.resolve(process.argv[3] || input);
const browserCandidates = [
  process.env.PROGRAMFILES && path.join(process.env.PROGRAMFILES, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
  process.env['PROGRAMFILES(X86)'] && path.join(process.env['PROGRAMFILES(X86)'], 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
  process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Microsoft', 'Edge', 'Application', 'msedge.exe')
].filter(Boolean);
const browser = browserCandidates.find(candidate => fs.existsSync(candidate));
if (!browser) throw new Error('找不到 Microsoft Edge，无法预渲染 Mermaid SVG');

const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'architecture-board-'));
const profile = path.join(temp, 'profile');
const url = pathToFileURL(input).href;

function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

async function getDevTools() {
  const file = path.join(profile, 'DevToolsActivePort');
  for (let i = 0; i < 200; i += 1) {
    if (fs.existsSync(file)) {
      const lines = fs.readFileSync(file, 'utf8').trim().split(/\r?\n/);
      return { port: lines[0], socketPath: lines[1] };
    }
    await wait(100);
  }
  throw new Error('Edge DevTools 启动超时');
}

async function getPageSocket(port) {
  for (let i = 0; i < 200; i += 1) {
    try {
      const pages = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
      const page = pages.find(item => item.type === 'page' && item.url === url) || pages.find(item => item.type === 'page');
      if (page && page.webSocketDebuggerUrl) return page.webSocketDebuggerUrl;
    } catch (_) {}
    await wait(100);
  }
  throw new Error('没有找到 Mermaid 渲染页面');
}

function evaluate(socketUrl, expression) {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(socketUrl);
    const id = 1;
    const timer = setTimeout(() => {
      try { socket.close(); } catch (_) {}
      reject(new Error('页面执行超时'));
    }, 60000);
    socket.addEventListener('open', () => {
      socket.send(JSON.stringify({
        id,
        method: 'Runtime.evaluate',
        params: { expression, awaitPromise: true, returnByValue: true }
      }));
    });
    socket.addEventListener('message', event => {
      const message = JSON.parse(event.data);
      if (!message.result || message.id !== id) return;
      clearTimeout(timer);
      try { socket.close(); } catch (_) {}
      if (message.result.exceptionDetails) reject(new Error(message.result.exceptionDetails.text || '页面执行失败'));
      else resolve(message.result.result && message.result.result.value);
    });
    socket.addEventListener('error', () => {
      clearTimeout(timer);
      reject(new Error('DevTools WebSocket 连接失败'));
    });
  });
}

(async () => {
  const child = spawn(browser, [
    '--headless=new',
    '--disable-gpu',
    '--disable-extensions',
    '--no-first-run',
    `--user-data-dir=${profile}`,
    '--remote-debugging-port=0',
    '--allow-file-access-from-files',
    url
  ], { stdio: 'ignore', windowsHide: true });

  try {
    const devTools = await getDevTools();
    const socket = await getPageSocket(devTools.port);
    const rendered = await evaluate(socket, `new Promise((resolve, reject) => {
      const deadline = Date.now() + 60000;
      function check() {
        const panels = document.querySelectorAll('.diagram-panel');
        const svgs = document.querySelectorAll('.diagram-panel .mermaid svg');
        if (panels.length > 0 && svgs.length === panels.length) resolve(document.documentElement.outerHTML);
        else if (Date.now() > deadline) reject(new Error('Mermaid SVG 渲染数量不足'));
        else setTimeout(check, 100);
      }
      check();
    })`);
    if (!rendered || !rendered.includes('<svg')) throw new Error('没有得到 SVG 快照');
    fs.writeFileSync(output, '<!DOCTYPE html>\n' + rendered, 'utf8');
    console.log(JSON.stringify({
      ok: true,
      output,
      svg_count: (rendered.match(/<svg\b/g) || []).length,
      bytes: fs.statSync(output).size
    }));
  } finally {
    child.kill();
    await wait(500);
    try { fs.rmSync(temp, { recursive: true, force: true, maxRetries: 10, retryDelay: 200 }); } catch (_) {}
  }
})().catch(error => {
  console.error(error.stack || error.message || error);
  process.exitCode = 1;
});
