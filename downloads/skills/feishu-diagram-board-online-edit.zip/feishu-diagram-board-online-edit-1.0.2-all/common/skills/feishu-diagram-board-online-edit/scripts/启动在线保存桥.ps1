[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$Config
)

$ErrorActionPreference = 'Stop'
$configPath = [IO.Path]::GetFullPath($Config)
if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) { throw "找不到配置文件：$configPath" }
if (-not $env:BOARD_SAVE_PASSWORD) {
  $secure = Read-Host '请输入保存密码' -AsSecureString
  $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try { $env:BOARD_SAVE_PASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
}
& node (Join-Path $PSScriptRoot 'online-save-bridge.js') --config $configPath
exit $LASTEXITCODE
