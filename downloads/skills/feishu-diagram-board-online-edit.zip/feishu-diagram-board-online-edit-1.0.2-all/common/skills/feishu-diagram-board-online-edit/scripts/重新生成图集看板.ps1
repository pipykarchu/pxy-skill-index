[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$Config,
  [switch]$Upload
)

$ErrorActionPreference = 'Stop'
$configPath = [IO.Path]::GetFullPath($Config)
if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) { throw "找不到配置文件：$configPath" }
$arguments = @((Join-Path $PSScriptRoot 'gen-diagram-html.js'), '--config', $configPath)
if ($Upload) { $arguments += '--upload' }
& node @arguments
exit $LASTEXITCODE
