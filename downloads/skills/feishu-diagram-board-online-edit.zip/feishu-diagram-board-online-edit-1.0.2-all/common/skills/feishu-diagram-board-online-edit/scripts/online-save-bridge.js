#!/usr/bin/env node
/** Local-only bridge for publishing edits and anchored comments to Feishu. */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const crypto = require('crypto');

const args = process.argv.slice(2);
function argValue(name) {
  const index = args.indexOf(name);
  return index >= 0 ? args[index + 1] : '';
}

const ROOT = path.resolve(__dirname, '..');
const CONFIG_PATH = path.resolve(argValue('--config') || process.env.BOARD_CONFIG || path.join(process.cwd(), 'board.config.json'));
if (!fs.existsSync(CONFIG_PATH)) throw new Error('找不到配置文件：' + CONFIG_PATH);
const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8').replace(/^\uFEFF/, ''));
const configRoot = path.dirname(CONFIG_PATH);
if (!config.source) throw new Error('配置文件缺少 source');

const PORT = Number(process.env.BOARD_PORT || config.port || 8794);
const PASSWORD = String(process.env.BOARD_SAVE_PASSWORD || config.savePassword || '');
const BRIDGE_KEY = String(config.bridgeKey || 'architecture-board-v1');
const SOURCE = path.resolve(configRoot, config.source);
const HTML = path.resolve(configRoot, config.output || SOURCE.replace(/\.md$/i, '.html'));
const COMMENTS = path.resolve(configRoot, config.comments || SOURCE.replace(/\.md$/i, '.comments.json'));
const GENERATOR = path.join(__dirname, 'gen-diagram-html.js');
const FILE_TOKEN = String(config.feishuFileToken || '');
const FOLDER_TOKEN = String(config.feishuFolderToken || '');
const LARK_BASE = path.join(process.env.LOCALAPPDATA || '', 'hermes', 'node');
const LARK_NODE = path.resolve(config.larkNode || path.join(LARK_BASE, 'node.exe'));
const LARK_RUNNER = path.resolve(config.larkRunner || path.join(LARK_BASE, 'node_modules', '@larksuite', 'cli', 'scripts', 'run.js'));

if (!Number.isInteger(PORT) || PORT < 1024 || PORT > 65535) throw new Error('port 必须是 1024-65535 的整数');
if (!PASSWORD) throw new Error('请通过 BOARD_SAVE_PASSWORD 或 savePassword 配置保存密码');
if (!FILE_TOKEN) throw new Error('在线原位发布需要 feishuFileToken');
if (!fs.existsSync(SOURCE)) throw new Error('找不到 Markdown 源稿：' + SOURCE);

function send(res, status, payload) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, X-Architecture-Board',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  });
  res.end(JSON.stringify(payload));
}

function runProcess(executable, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(executable, args, {
      cwd: ROOT,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe']
    });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => { stdout += chunk; });
    child.stderr.on('data', (chunk) => { stderr += chunk; });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code === 0) resolve(stdout.trim());
      else reject(new Error((stderr || stdout || '在线版同步失败').trim().slice(-4000)));
    });
  });
}

async function publishOnline() {
  await runProcess(process.execPath, [GENERATOR, '--config', CONFIG_PATH]);
  if (!fs.existsSync(LARK_NODE) || !fs.existsSync(LARK_RUNNER)) throw new Error('未找到 lark-cli 运行时');
  const output = await runProcess(LARK_NODE, [
    LARK_RUNNER, 'drive', '+upload', '--file', HTML,
    '--file-token', FILE_TOKEN, '--name', path.basename(HTML), '--as', 'user', '--format', 'json'
  ]);
  if (!/"ok"\s*:\s*true/.test(output)) throw new Error('飞书上传未返回 ok=true：' + output.slice(-1200));
  const upload = JSON.parse(output);
  if (String(upload.data && upload.data.file_token || '') !== FILE_TOKEN) throw new Error('上传后 file token 发生变化');
  const readbackPath = path.join(configRoot, '.board-readback-' + process.pid + '-' + Date.now() + path.extname(HTML));
  try {
    const downloadOutput = await runProcess(LARK_NODE, [
      LARK_RUNNER, 'drive', '+download', '--file-token', FILE_TOKEN,
      '--output', readbackPath, '--overwrite', '--as', 'user', '--format', 'json'
    ]);
    const download = JSON.parse(downloadOutput);
    if (!download.ok || !fs.existsSync(readbackPath)) throw new Error('飞书下载回读失败');
    const localHash = crypto.createHash('sha256').update(fs.readFileSync(HTML)).digest('hex');
    const remoteHash = crypto.createHash('sha256').update(fs.readFileSync(readbackPath)).digest('hex');
    if (localHash !== remoteHash) throw new Error('飞书下载回读哈希与本地不一致');
    return JSON.stringify({ upload, readback: { fileToken: FILE_TOKEN, fileName: path.basename(HTML), size: fs.statSync(readbackPath).size, sha256: remoteHash } });
  } finally {
    if (fs.existsSync(readbackPath)) fs.unlinkSync(readbackPath);
  }
}

function readComments() {
  if (!fs.existsSync(COMMENTS)) return [];
  const value = JSON.parse(fs.readFileSync(COMMENTS, 'utf8').replace(/^\uFEFF/, ''));
  return Array.isArray(value) ? value : [];
}

let publishQueue = Promise.resolve();
function enqueuePublish(work) {
  const next = publishQueue.then(work, work);
  publishQueue = next.catch(() => {});
  return next;
}

const server = http.createServer((req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, { ok: true });
  if (req.method === 'GET' && req.url === '/health') return send(res, 200, { ok: true, service: 'interactive-architecture-board', fileToken: FILE_TOKEN, source: path.basename(SOURCE) });
  if (req.method === 'GET' && req.url === '/comments') return send(res, 200, { ok: true, comments: readComments() });
  if (req.method === 'GET' && req.url === '/preview') {
    if (!fs.existsSync(HTML)) return send(res, 404, { ok: false, error: 'preview_not_generated' });
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    return fs.createReadStream(HTML).pipe(res);
  }
  if (req.method !== 'POST' || !['/save', '/comment'].includes(req.url)) return send(res, 404, { ok: false, error: 'not_found' });
  if (req.headers['x-architecture-board'] !== BRIDGE_KEY) return send(res, 403, { ok: false, error: 'bridge_key' });

  let body = '';
  req.on('data', (chunk) => {
    body += chunk;
    if (body.length > 2 * 1024 * 1024) req.destroy();
  });
  req.on('error', () => send(res, 400, { ok: false, error: 'request_error' }));
  req.on('end', () => enqueuePublish(async () => {
    try {
      const input = JSON.parse(body || '{}');
      if (req.url === '/save') {
        if (input.password !== PASSWORD) return send(res, 403, { ok: false, error: 'password' });
        if (typeof input.markdown !== 'string' || !input.markdown.trim()) return send(res, 400, { ok: false, error: 'markdown_required' });
        const previous = fs.readFileSync(SOURCE, 'utf8');
        try {
          fs.writeFileSync(SOURCE, input.markdown.replace(/^\uFEFF/, ''), 'utf8');
          const output = await publishOnline();
          return send(res, 200, { ok: true, message: '在线版已原位更新', output });
        } catch (error) {
          fs.writeFileSync(SOURCE, previous, 'utf8');
          throw error;
        }
      }

      const comment = input.comment;
      if (!comment || typeof comment !== 'object') return send(res, 400, { ok: false, error: 'comment_required' });
      if (typeof comment.id !== 'string' || typeof comment.anchor !== 'string' || typeof comment.text !== 'string' || !comment.text.trim()) return send(res, 400, { ok: false, error: 'comment_invalid' });
      if (comment.text.length > 4000 || String(comment.quote || '').length > 1000) return send(res, 400, { ok: false, error: 'comment_too_long' });
      const previousComments = readComments();
      if (previousComments.some((item) => item.id === comment.id)) return send(res, 200, { ok: true, message: '评论已存在' });
      const nextComments = previousComments.concat(comment);
      try {
        fs.writeFileSync(COMMENTS, JSON.stringify(nextComments, null, 2), 'utf8');
        const output = await publishOnline();
        return send(res, 200, { ok: true, message: '评论已发布到在线图集', output });
      } catch (error) {
        fs.writeFileSync(COMMENTS, JSON.stringify(previousComments, null, 2), 'utf8');
        throw error;
      }
    } catch (error) {
      send(res, 500, { ok: false, error: String(error.message || error) });
    }
  }));
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('架构图集在线保存桥已启动：http://127.0.0.1:' + PORT);
  console.log('本地预览：http://127.0.0.1:' + PORT + '/preview');
});
