#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
const index = args.indexOf('--config');
const configPath = path.resolve(index >= 0 ? args[index + 1] : process.env.BOARD_CONFIG || path.join(process.cwd(), 'board.config.json'));
const checks = [];
function check(name, ok, detail) {
  checks.push({ name, ok: Boolean(ok), detail });
}

if (!fs.existsSync(configPath)) {
  console.error(JSON.stringify({ ok: false, error: 'config_not_found', configPath }, null, 2));
  process.exit(1);
}

const config = JSON.parse(fs.readFileSync(configPath, 'utf8').replace(/^\uFEFF/, ''));
const root = path.dirname(configPath);
const source = path.resolve(root, config.source || '');
const base = path.join(process.env.LOCALAPPDATA || '', 'hermes', 'node');
const larkNode = path.resolve(config.larkNode || path.join(base, 'node.exe'));
const larkRunner = path.resolve(config.larkRunner || path.join(base, 'node_modules', '@larksuite', 'cli', 'scripts', 'run.js'));
const edgeCandidates = [
  process.env.PROGRAMFILES && path.join(process.env.PROGRAMFILES, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
  process.env['PROGRAMFILES(X86)'] && path.join(process.env['PROGRAMFILES(X86)'], 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
  process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Microsoft', 'Edge', 'Application', 'msedge.exe')
].filter(Boolean);

check('config', true, configPath);
check('source', Boolean(config.source) && fs.existsSync(source) && fs.statSync(source).isFile(), source);
check('mermaidVendor', fs.existsSync(path.resolve(__dirname, '..', 'assets', 'vendor', 'mermaid-10.9.1.min.js.gz')), 'mermaid-10.9.1.min.js.gz');
check('edge', edgeCandidates.some((candidate) => fs.existsSync(candidate)), edgeCandidates.find((candidate) => fs.existsSync(candidate)) || 'not_found');
check('larkNode', fs.existsSync(larkNode), larkNode);
check('larkRunner', fs.existsSync(larkRunner), larkRunner);
const hasFileToken = Boolean(config.feishuFileToken && !String(config.feishuFileToken).startsWith('REPLACE_'));
const hasFolderToken = Boolean(config.feishuFolderToken && !String(config.feishuFolderToken).startsWith('REPLACE_'));
check('feishuFileToken', hasFileToken, config.feishuFileToken || 'missing');
check('publishTarget', hasFileToken || hasFolderToken, hasFileToken ? 'overwrite_by_file_token' : hasFolderToken ? 'create_or_lookup_by_folder_token' : 'missing');
check('savePassword', Boolean(process.env.BOARD_SAVE_PASSWORD || config.savePassword), process.env.BOARD_SAVE_PASSWORD ? 'environment' : config.savePassword ? 'config' : 'missing');

const ok = checks.every((item) => item.ok);
console.log(JSON.stringify({ ok, checks }, null, 2));
process.exitCode = ok ? 0 : 1;
