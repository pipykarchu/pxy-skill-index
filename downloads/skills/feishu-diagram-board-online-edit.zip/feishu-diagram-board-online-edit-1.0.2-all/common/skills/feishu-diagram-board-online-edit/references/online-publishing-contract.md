# 在线发布契约

## 文件角色

- Markdown：唯一正文源稿。
- HTML：由生成器产生的可交互看板。
- `*.comments.json`：评论源数据，生成时内嵌到 HTML。
- `board.config.json`：路径、品牌、端口、保存桥 key、飞书 file/folder token。

## 本机接口

保存桥只监听 `127.0.0.1`。

| 方法 | 路径 | 用途 | 成功条件 |
|---|---|---|---|
| GET | `/health` | 检查桥、源稿和目标 token | `ok=true` |
| GET | `/preview` | 打开当前生成 HTML | 返回 `text/html` |
| GET | `/comments` | 回读评论 JSON | `comments` 为数组 |
| POST | `/save` | 保存 Markdown、重生成、原位上传 | 密码正确且同一 file token 下载回读哈希一致 |
| POST | `/comment` | 追加锚点评论、重生成、原位上传 | 评论校验通过且同一 file token 下载回读哈希一致 |

写接口都要求 `X-Architecture-Board` 与配置的 `bridgeKey` 一致。这个 key 用于防误调用，不是机密凭据。

## 回滚

- `/save`：写入前保留旧 Markdown；生成、上传或回读任一步失败就恢复旧文件。
- `/comment`：写入前保留旧评论数组；生成、上传或回读任一步失败就恢复旧 JSON。
- 所有写操作进入同一发布队列，避免正文保存和评论发布互相覆盖。

## 安全边界

- 保存桥必须保持 `127.0.0.1` 监听，不开放到局域网或公网。
- 密码使用 `BOARD_SAVE_PASSWORD` 注入；静态 HTML 和公共技能包不保存真实密码。
- 飞书 token 是文件标识，不是访问凭据；`lark-cli` 用户态授权仍由本机安全配置提供。
- 评论发布默认不重复要求保存密码，以接近飞书评论体验；因此只在可信电脑上运行保存桥，离开时关闭进程。

## 发布完成证据

一次发布只有在以下证据都成立时才算完成：

1. 本地源稿或评论 JSON 写入成功。
2. 新 HTML 生成成功且静态 SVG 数量大于 0。
3. `lark-cli drive +upload` 返回 `ok=true`。
4. 已有 file token 时下载同一 token，回读文件 SHA256 与本地一致；新建时再验证 folder token 下的文件名和 token。
5. 浏览器刷新后能看到正文或评论变化。
