#!/usr/bin/env node
/**
 * Generate the interactive architecture board from Markdown.
 *
 * Usage:
 *   node gen-diagram-html.js
 *   node gen-diagram-html.js <markdown-path>
 *   node gen-diagram-html.js --upload
 *
 * Markdown remains the source of truth. The generated HTML embeds Mermaid and
 * can render without network access. --upload overwrites the existing Feishu
 * file in place, preserving its token and link.
 *
 * === CONFIGURATION ===
 * Edit the constants below to match your project:
 *   DEFAULT_MD              - your Markdown source file name
 *   FEISHU_FOLDER_TOKEN     - target Feishu Drive folder token
 *   KNOWN_FEISHU_FILE_TOKENS - map of HTML filename → Feishu file token (for in-place overwrite)
 *   SAVE_PASSWORD           - password for the in-page save modal
 */
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

// ─── CONFIG (edit these for your project) ───────────────────────────
const DEFAULT_MD = '<your-markdown>.md';
const MERMAID_VENDOR = path.join(__dirname, 'vendor', 'mermaid-10.9.1.min.js');
const FEISHU_FOLDER_TOKEN = '<your-folder-token>';
const FEISHU_FOLDER_URL = 'https://<your-tenant>.feishu.cn/drive/folder/' + FEISHU_FOLDER_TOKEN;
const KNOWN_FEISHU_FILE_TOKENS = {};
const SAVE_PASSWORD = '7575';
// ─── END CONFIG ──────────────────────────────────────────────────────

const args = process.argv.slice(2);
const shouldUpload = args.includes('--upload');
const mdArg = args.find((arg) => !arg.startsWith('--'));
const mdPath = path.resolve(mdArg || path.join(__dirname, DEFAULT_MD));
const htmlPath = mdPath.replace(/\.md$/i, '.html');

// ... (full generator logic — see the working copy in your project directory)
// This is a template. Copy the full gen-diagram-html.js from your working
// project and adjust the CONFIG block above.

/*
 * KEY FEATURES embedded in the generated HTML:
 *
 * 1. In-page password modal (NOT window.prompt):
 *    - .pwd-backdrop (z-index:70) + .pwd-modal (z-index:71)
 *    - verifySavePassword() returns Promise<boolean>
 *    - Enter=confirm, Escape=cancel, backdrop click=cancel
 *
 * 2. Online save bridge integration:
 *    - POST http://127.0.0.1:8794/save {password, markdown}
 *    - Toast feedback on success/failure
 *
 * 3. Comment system:
 *    - Text selection → popover → comment panel
 *    - localStorage persistence
 *    - Highlight selected text in document
 *
 * 4. Mermaid diagrams:
 *    - Inline mermaid.js (offline capable)
 *    - SVG prerender for static preview environments
 *    - Zoom/pan/focus per diagram
 *
 * 5. Feishu upload (--upload flag):
 *    - lark-cli drive +upload → folder token
 *    - In-place overwrite via --file-token
 *    - Post-upload verification (list + match)
 */

if (require.main === module && process.argv[1] && process.argv[1].endsWith('gen-diagram-html.js')) {
  if (!fs.existsSync(mdPath)) {
    console.error('找不到 Markdown 源稿：' + mdPath);
    console.error('请在 gen-diagram-html.js 顶部修改 DEFAULT_MD 或运行时传入文件名');
    process.exit(1);
  }
  console.log('请使用你工作目录中的完整 gen-diagram-html.js，并根据需要修改 CONFIG 块。');
  console.log('Markdown 源稿：' + mdPath);
  console.log('HTML 输出：' + htmlPath);
}
