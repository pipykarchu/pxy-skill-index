# 踩坑记录

## 1. window.prompt 在飞书 iframe 内被拦截（2026-09 实测）

**症状**：用户在飞书云空间预览 HTML 文件，点击"保存修改"按钮，立即显示"已取消保存"，没有任何密码输入框出现。

**根因**：飞书 HTML 预览运行在安全 iframe 内，`window.prompt()` 被飞书的安全策略拦截，直接返回 `null`。代码中 `if(entered===null){toast('已取消保存');return false;}` 被触发。

**修复**：改用页面内密码弹窗（`.pwd-backdrop` + `.pwd-modal`），`verifySavePassword()` 返回 `Promise<boolean>`，`saveChanges()` 用 `await` 等待。

**教训**：任何在飞书/第三方平台 iframe 内运行的 HTML，都不能依赖 `window.prompt()`、`window.confirm()`、`window.alert()`，必须用页面内组件替代。

## 2. DEFAULT_MD 硬编码旧文件名

**症状**：运行 `node gen-diagram-html.js`（无参数）报 `找不到 Markdown 源稿`。

**根因**：生成器顶部 `const DEFAULT_MD = 'Mozin-App2.0-业务架构图集-V2.1-20260826.md'` 硬编码了旧版本文件名，后续版本文件名变了但常量没更新。

**修复**：运行时显式传参 `node gen-diagram-html.js <实际md文件名>`，或更新 `DEFAULT_MD` 常量。

**教训**：生成器的默认文件名应该用通配符或从当前目录自动查找 `.md` 文件，不要硬编码版本号。

## 3. lark-cli 运行时路径

**症状**：`--upload` 时报 `未找到 lark-cli 运行时`。

**根因**：生成器查找 `%LOCALAPPDATA%\hermes\node\node.exe` 和 `node_modules\@larksuite\cli\scripts\run.js`，路径可能因 Hermes 版本更新而变化。

**修复**：
```powershell
# 检查路径
Test-Path "$env:LOCALAPPDATA\hermes\node\node.exe"
Test-Path "$env:LOCALAPPDATA\hermes\node\node_modules\@larksuite\cli\scripts\run.js"
```
如果路径变化，更新 `findLarkRuntime()` 函数中的 `base` 变量。

## 4. 飞书上传后文件不在文件夹内

**症状**：上传成功但文件出现在"我的空间"根目录而非目标文件夹。

**根因**：`lark-cli drive +upload` 上传到指定 folder-token，但覆盖模式下（`--file-token`）上传后文件可能移出文件夹，需要 `+move` 归位。

**修复**：生成器的 `uploadAndVerify()` 函数已包含 `+move` 步骤。如果仍丢失，手动 `lark-cli drive +move --file-token <token> --folder-token <folder>`。

## 5. Mermaid 预渲染需要无头浏览器

**症状**：生成器报 `Mermaid SVG 预渲染失败`。

**根因**：`prerender-diagram-html.js` 使用 Mermaid 的 `render()` API 生成静态 SVG，需要可用的 JS 运行时。如果 Mermaid 代码块有语法错误，预渲染也会失败。

**修复**：
1. 检查所有 mermaid 代码块语法（`graph TD` / `flowchart LR` 等声明正确）
2. 确认 `vendor/mermaid-10.9.1.min.js` 文件存在且完整
3. 预渲染失败不影响 HTML 生成，只是图表在禁用 JS 的环境中不显示静态 SVG

## 6. 评论 localStorage 在飞书 iframe 中被隔离

**症状**：在飞书预览页面添加的评论，刷新后消失。

**根因**：飞书 iframe 的 localStorage 可能被浏览器隔离（不同 origin），或飞书预览环境不持久化 iframe 的 localStorage。

**说明**：这是预期行为。评论是辅助评审工具，不是正式评审记录。需要持久化评审记录时用飞书文档评论功能。

## 7. 保存桥端口冲突

**症状**：`node online-save-bridge.js` 报 `EADDRINUSE` 端口被占用。

**修复**：
```powershell
# 找到占用 8794 端口的进程
netstat -ano | findstr :8794
# 杀掉进程
taskkill /PID <pid> /F
# 或修改 online-save-bridge.js 中的 PORT 常量（同时修改 HTML 中的 fetch URL）
```
