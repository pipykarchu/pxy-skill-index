#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
const jsonMode = args.includes('--json');
const forcedMode = valueAfter('--mode') || 'auto';
const fileArg = args.find((value, index) => !value.startsWith('--') && args[index - 1] !== '--mode');

function valueAfter(name) {
  const index = args.indexOf(name);
  return index >= 0 ? String(args[index + 1] || '') : '';
}

function usage(message) {
  if (message) console.error(message);
  console.error('用法：node scripts/verify-html-deliverable.js <html> [--mode auto|static|interactive] [--json]');
  process.exit(2);
}

if (!fileArg) usage('缺少 HTML 文件路径');
if (!['auto', 'static', 'interactive'].includes(forcedMode)) usage('--mode 只支持 auto、static、interactive');

const filePath = path.resolve(fileArg);
if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) usage('找不到 HTML 文件：' + filePath);

const html = fs.readFileSync(filePath, 'utf8').replace(/^\uFEFF/, '');
const markup = html
  .replace(/<script\b[\s\S]*?<\/script>/gi, '')
  .replace(/<style\b[\s\S]*?<\/style>/gi, '');
const nonSvgMarkup = markup.replace(/<svg\b[\s\S]*?<\/svg>/gi, '');
const styles = Array.from(html.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/gi), (match) => match[1]).join('\n');
const svgs = Array.from(markup.matchAll(/<svg\b[\s\S]*?<\/svg>/gi), (match) => match[0]);
const errors = [];
const warnings = [];
const checks = [];

function pass(name, detail) {
  checks.push({ name, ok: true, detail });
}

function fail(name, detail) {
  checks.push({ name, ok: false, detail });
  errors.push(detail);
}

function warn(detail) {
  warnings.push(detail);
}

function check(condition, name, okDetail, errorDetail) {
  if (condition) pass(name, okDetail);
  else fail(name, errorDetail);
}

check(/^\s*<!doctype\s+html>/i.test(html), 'doctype', 'DOCTYPE 正常', '缺少 <!DOCTYPE html>');
check(/<html\b/i.test(markup) && /<\/html>\s*$/i.test(html), 'html-closure', 'HTML 闭合正常', '缺少 html 根节点或 </html> 结尾');
check(/<meta\b[^>]*charset=/i.test(markup), 'charset', '字符集声明存在', '缺少 meta charset');
check(/<meta\b[^>]*name=["']viewport["']/i.test(markup), 'viewport', '移动端 viewport 存在', '缺少移动端 viewport');

const ids = Array.from(nonSvgMarkup.matchAll(/[\s<]id=["']([^"']+)["']/gi), (match) => match[1]);
const duplicateIds = Array.from(new Set(ids.filter((id, index) => ids.indexOf(id) !== index)));
check(duplicateIds.length === 0, 'duplicate-ids', '非 SVG DOM id 无重复', '存在重复 DOM id：' + duplicateIds.join(', '));

const idSet = new Set(Array.from(markup.matchAll(/[\s<]id=["']([^"']+)["']/gi), (match) => match[1]));
const fragmentTargets = Array.from(nonSvgMarkup.matchAll(/\bhref=["']#([^"']+)["']/gi), (match) => match[1]);
const missingTargets = Array.from(new Set(fragmentTargets.filter((target) => !idSet.has(target))));
check(missingTargets.length === 0, 'fragment-links', '页内链接均有目标', '页内链接目标缺失：' + missingTargets.join(', '));

const markerFailures = [];
svgs.forEach((svg, index) => {
  const defined = new Set(Array.from(svg.matchAll(/[\s<]id=["']([^"']+)["']/gi), (match) => match[1]));
  const referenced = Array.from(svg.matchAll(/url\(\s*#([^)\s]+)\s*\)/gi), (match) => match[1].replace(/["']/g, ''));
  const missing = Array.from(new Set(referenced.filter((id) => !defined.has(id))));
  if (missing.length) markerFailures.push('SVG ' + (index + 1) + ' 缺少本图 defs：' + missing.join(', '));
});
check(markerFailures.length === 0, 'svg-local-defs', svgs.length + ' 个 SVG 的引用均在本图定义', markerFailures.join('；'));

check(!/(?:^|[;{]\s*)rx\s*:/im.test(styles), 'css-rx', '未使用 CSS rx', '检测到 CSS rx；圆角请写在 SVG rect 的 rx 属性上');
const invalidCoordinates = Array.from(markup.matchAll(/\b(?:x|y|x1|x2|y1|y2|cx|cy|r|width|height)=["'][^"']*[?;][^"']*["']/gi), (match) => match[0]);
check(invalidCoordinates.length === 0, 'svg-coordinates', 'SVG 坐标未发现非法字符', 'SVG 坐标含 ? 或 ;：' + invalidCoordinates.slice(0, 5).join(', '));

const detectedInteractive = /id=["']comment-panel["']/i.test(markup) || /X-Architecture-Board/i.test(html);
const mode = forcedMode === 'auto' ? (detectedInteractive ? 'interactive' : 'static') : forcedMode;
if (mode === 'interactive') {
  check(/id=["']comment-delete-modal["']/i.test(markup), 'delete-modal', '页面内删除确认框存在', '交互模式缺少页面内删除确认框');
  check(/\bquoteStart\b/.test(html) && /\bquoteEnd\b/.test(html), 'precise-comment-anchor', '评论保存精确选文位置', '交互模式缺少 quoteStart/quoteEnd 精确选文位置');
  check(/\bcreate\b/.test(html) && /\bupdate\b/.test(html) && /\bdelete\b/.test(html), 'comment-crud', '评论新增、修改、删除入口齐全', '交互模式缺少评论 create/update/delete 能力');
  check(!/window\.(?:prompt|confirm)\s*\(/.test(html), 'blocked-dialogs', '未使用飞书可能拦截的原生弹窗', '检测到 window.prompt/window.confirm；请改为页面内弹窗');
}

const tocLinks = fragmentTargets.length;
const contentSections = (nonSvgMarkup.match(/<section\b/gi) || []).length;
if (tocLinks && contentSections && Math.abs(tocLinks - contentSections) > 3) warn('目录链接数 ' + tocLinks + ' 与 section 数 ' + contentSections + ' 差距较大，请人工复核');
if (!svgs.length) warn('未发现内联 SVG；纯文档可忽略，图集交付请确认预渲染已完成');

const result = {
  ok: errors.length === 0,
  file: filePath,
  mode,
  bytes: Buffer.byteLength(html),
  svgCount: svgs.length,
  checks,
  warnings,
  errors
};

if (jsonMode) {
  console.log(JSON.stringify(result, null, 2));
} else {
  console.log((result.ok ? 'PASS' : 'FAIL') + ' ' + path.basename(filePath) + ' [' + mode + ']');
  checks.forEach((item) => console.log((item.ok ? '  ✓ ' : '  ✗ ') + item.name + '：' + item.detail));
  warnings.forEach((item) => console.log('  ! 警告：' + item));
  console.log('汇总：' + checks.filter((item) => item.ok).length + '/' + checks.length + ' 项通过，SVG ' + svgs.length + ' 个，错误 ' + errors.length + ' 个');
}

process.exit(result.ok ? 0 : 1);
