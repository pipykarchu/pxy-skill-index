---
name: feishu-diagram-board-online-edit
description: 用于把 Markdown 文档生成经过质量校验的单文件 HTML，并按需升级为可编辑、可框选评论、可修改/删除评论且能原位发布到飞书的交互式图集；也用于修复保存显示取消、评论按钮无反应、评论发布不了或飞书预览丢图。Use when generating or repairing static or interactive Feishu HTML deliverables.
license: MIT
metadata:
  version: 1.1.0
  author: PXY Skill Library
  platforms: [windows]
  hermes:
    tags: [document-html, architecture, mermaid, dashboard, comments, feishu, online-editing, publishing, verification]
    related_skills: [architecture-diagram, dashboard-builder, feishu-selective-upload, multi-agent-task-harness]
---

# 飞书交互式 HTML 交付物

把 Markdown 作为唯一源稿，先生成离线可读、可独立校验的单文件 HTML；需要在线评审时，再启用图表编辑、精确框选评论、评论新增/修改/删除和飞书原位保存。文档模式、图表路由与主题策略见 [references/document-to-html-evolution.md](references/document-to-html-evolution.md)。

## 适用范围

- 从 Markdown + Mermaid 生成静态文档或可交互图集看板。
- 为制度、接口、联调、规格说明生成目录清晰、离线可读的静态 HTML。
- 修复“保存修改显示已取消”“评论只存在本机”“飞书链接被换掉”等问题。
- 修复“点击评论不定位”“删除评论没反应”“评论只能新增不能修改”等问题。
- 把编辑后的源稿和评论发布到同一个飞书 file token。
- 给 Codex、Hermes 或项目 `AGENTS.md` 提供可复用入口。

这不是真正的多人协同文档服务。在线保存依赖编辑者电脑上的本机桥；桥未启动时，飞书里的 HTML 只能查看和本地预览，不能写回。

## 必要输入

1. Markdown 源稿，Mermaid 代码块使用 ` ```mermaid `。
2. 交互模式需要 `board.config.json`，从 [templates/board.config.example.json](templates/board.config.example.json) 复制后填写。
3. 在线原位保存需要飞书目标文件的 `file token`；仅在新建或按文件名查找时需要 `folder token`。
4. 在线发布需要已登录用户态的 Hermes `lark-cli` 运行时。
5. 图集模式需要 Microsoft Edge，把 Mermaid 预渲染成静态 SVG。

保存密码优先通过环境变量 `BOARD_SAVE_PASSWORD` 注入。不要把真实密码、access token 或其他凭据提交到技能库。

## 工作流

1. 盘点主文档、外链、附件和版本，按 [references/document-to-html-evolution.md](references/document-to-html-evolution.md) 选择静态文档、交互图集或演示文稿模式。读取交互模式的源稿、当前 HTML、评论 JSON 和配置，确认目标 file token，避免覆盖错文件。
2. 执行环境检查。静态模式只要求 Markdown、Mermaid 运行库和 Edge；交互模式再检查 lark-cli、发布目标和保存密码。

```powershell
node scripts/check-env.js --config .\board.config.json --mode interactive
```

3. 生成本地看板。完成标准：输出 HTML 存在，脚本报告 SVG 数量，浏览器禁用网络时图仍能显示。

```powershell
node scripts/gen-diagram-html.js --config .\board.config.json
```

静态模式也可直接传入 Markdown，不要求 `board.config.json`：

```powershell
node scripts/gen-diagram-html.js .\source.md
```

4. 运行独立质量校验。完成标准：结构、页内链接、SVG 本图 defs、坐标和交互合同全部通过。

```powershell
node scripts/verify-html-deliverable.js .\output.html --mode auto
```

5. 需要在线保存时启动本机桥。完成标准：`/health` 返回 `ok=true`，`/preview` 能打开生成的 HTML。

```powershell
$env:BOARD_SAVE_PASSWORD = Read-Host '保存密码'
node scripts/online-save-bridge.js --config .\board.config.json
```

也可以运行 [scripts/启动在线保存桥.ps1](scripts/启动在线保存桥.ps1)，并通过 `-Config` 传入配置文件路径。

6. 浏览器验收：

- “保存修改”弹出页面内密码框，不使用 `window.prompt()`。
- 错误密码明确失败，源稿和线上文件不变化。
- 应用预览后输入正确密码，提示“已保存到飞书在线版”。
- 框选正文文字后出现“评论选中内容”；发布后选文高亮，刷新仍存在。
- 点击评论文字、气泡或卡片时对应文字发亮并双向定位。
- 评论可修改、可删除；删除使用页面内确认框，不调用飞书预览可能拦截的 `window.confirm()`。
- 上传失败时源稿或评论 JSON 自动回滚，不显示假成功。

7. 飞书回读。已有 `file token` 时直接原位覆盖并下载同一 token，比对本地与回读文件 SHA256；新建或仅按文件名定位时再使用 `folder token`。

8. 做模块拆解或状态图设计时，读取 [references/module-breakdown-and-status-display.md](references/module-breakdown-and-status-display.md)。沿用参考页的“总览矩阵 → 模块闭环 → 状态图+状态表 → TC/问题闭环”结构；先用产品线/型号边界和模块矩阵定范围，再为每个模块补齐输入、状态、异常恢复、输出和 TC 验收条件；状态图统一图例、颜色语义和证据边界。

## 关键约束

- Markdown 是唯一源稿；HTML 是生成物，不手工长期维护。
- 正文与评论发布必须串行，避免并发覆盖。
- 保存正文失败时恢复旧 Markdown；发布评论失败时恢复旧评论 JSON。
- 原位覆盖必须使用固定 file token，不能因为文件移动了文件夹就新建同名文件代替。
- 静态 HTML 中不嵌入保存密码。密码只从弹窗发送到 `127.0.0.1` 保存桥验证。
- 评论由章节或段落锚点、精确选文起止位置、评论内容组成；重新生成后仍能对齐并高亮，旧评论无精确位置时兼容按引文匹配。
- 静态 SVG 渲染成功只证明图集可读，不证明真实账号、AI、设备、支付或云服务已经接入。

## Codex 与 Hermes 入口

- Codex：直接说“用 feishu-diagram-board-online-edit 生成/修复在线架构图集”。
- Hermes：`/skill feishu-diagram-board-online-edit`，或启动时使用 `hermes -s feishu-diagram-board-online-edit`。
- 多智能体任务：先加载 `multi-agent-task-harness`，再让本技能负责图集生成、保存桥和验收边界。

## 故障处理

详细接口、状态码、回滚和安全边界见 [references/online-publishing-contract.md](references/online-publishing-contract.md)。

- 一点保存就“已取消”：检查 HTML 是否仍有 `window.prompt()`；重新生成并上传最新 HTML。
- 飞书 CLI 明明已有账号却返回 `not_configured`：启动子进程时显式传入 `HERMES_HOME`（通常为 `%LOCALAPPDATA%\hermes`），再用 `config show` / `auth status` 验证，不要重新绑定或覆盖已有账号配置。
- 保存提示桥未启动：先访问 `http://127.0.0.1:<port>/health`，再检查端口、配置和防火墙。
- 评论发布后刷新丢失：确认请求走 `/comment` 的 `create` 动作，评论 JSON 已更新，并且上传后回读成功。
- 删除评论没反应：确认生成 HTML 有 `comment-delete-modal`，没有 `window.confirm()`，保存桥支持 `action=delete`。
- 修改评论没保存：确认保存桥支持 `action=update`，成功响应包含最新 `comments` 数组。
- 上传成功但飞书没变：核对 file token，不要只看进程 exit code；必须检查飞书列表回读结果。
- 图在飞书里不见：确认生成日志包含静态 SVG 数量，HTML 内存在 `<svg`，再重新原位覆盖。
- 模块拆分过粗或状态图看不懂：按 [references/module-breakdown-and-status-display.md](references/module-breakdown-and-status-display.md) 复核产品线边界、模块矩阵、异常回路、图例和 TC 映射。

## 验收清单

- [ ] `node --check` 通过全部 JavaScript 脚本。
- [ ] `verify-html-deliverable.js --mode auto` 通过。
- [ ] `check-env.js` 通过。
- [ ] 本地生成与静态 SVG 预渲染通过。
- [ ] `/health`、`/preview`、`/comments` 可访问。
- [ ] 保存弹窗、正确/错误密码、取消行为正确。
- [ ] 框选、发布、精确选文高亮、气泡/评论卡片双向定位正确。
- [ ] 评论修改、页面内确认删除、刷新保留正确。
- [ ] 正文与评论失败路径均完成回滚测试。
- [ ] 飞书 file token、文件名、修改时间和文件大小完成结构化回读。
- [ ] Codex 可发现，Hermes `/skill` 可加载，GitHub Pages 下载包已回读。
