# 交互式 HTML 交付物入口

当用户说“文档转 HTML、生成图集看板、在线编辑架构图、框选评论、评论修改/删除、在线保存飞书图集”时，加载 `feishu-diagram-board-online-edit`。

执行顺序：

1. 盘点主文档、外链、附件和版本，未读取内容不猜测。
2. 按用途选择静态文档、交互图集或演示文稿模式。
3. Markdown 作为唯一源稿；Mermaid 预渲染为静态 SVG。
4. 交互模式使用页面内保存/删除确认框，不使用 `window.prompt()` 或 `window.confirm()`。
5. 评论必须支持新增、修改、删除、精确选文和双向定位。
6. 原位发布到固定飞书 file token，失败回滚，下载回读并比对 SHA256。
7. 运行 `scripts/verify-html-deliverable.js`，再做浏览器和飞书回读验收。

不要把本机保存桥写成云端多人协同；不要把 Mock 或静态图写成真实服务已经接入。
