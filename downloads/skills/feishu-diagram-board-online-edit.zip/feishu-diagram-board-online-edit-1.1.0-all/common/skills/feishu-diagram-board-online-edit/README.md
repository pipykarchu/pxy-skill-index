# Feishu Interactive HTML Deliverable

把 Markdown 文档稳定生成单文件 HTML，并按需要升级成可在线评审的飞书交互图集。

## 能力

- 静态交付：目录、搜索、明暗主题、Mermaid 静态 SVG、离线可读。
- 图集编辑：编辑 Markdown 或单张 Mermaid 图，重新生成而不是长期手改 HTML。
- 评论协作：框选文字、评论气泡双向定位、评论新增/修改/删除。
- 在线保存：本机桥串行发布，同一飞书 file token 原位覆盖，失败回滚并下载回读 SHA256。
- 质量校验：独立检查 HTML 结构、页内链接、SVG defs、非法坐标和交互合同。

## 快速开始

```powershell
Copy-Item .\templates\board.config.example.json .\board.config.json
node .\scripts\check-env.js --config .\board.config.json --mode interactive
node .\scripts\gen-diagram-html.js --config .\board.config.json
node .\scripts\verify-html-deliverable.js .\architecture-board.html --mode auto
```

只做静态单文件 HTML 时，可以直接运行：

```powershell
node .\scripts\gen-diagram-html.js .\source.md
```

需要从飞书预览里保存正文或评论时，再启动本机桥：

```powershell
$env:BOARD_SAVE_PASSWORD = Read-Host '保存密码'
node .\scripts\online-save-bridge.js --config .\board.config.json
```

完整流程、边界和验收清单见 [SKILL.md](SKILL.md)。文档类型和图表选择见 [references/document-to-html-evolution.md](references/document-to-html-evolution.md)。

## 安全与边界

- 不提交保存密码、访问令牌或用户路径。
- 保存桥只监听 `127.0.0.1`，不是云端多人协同服务。
- 静态 SVG 可读不代表真实账号、设备、AI 或云服务已经接入。

License: MIT
