@echo off
setlocal
cd /d "%~dp0"
echo Starting online save bridge...
node online-save-bridge.js
pause
