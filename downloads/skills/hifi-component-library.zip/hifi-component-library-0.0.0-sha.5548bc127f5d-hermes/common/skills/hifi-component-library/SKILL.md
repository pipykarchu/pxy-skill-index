---
name: "hifi-component-library"
description: "Generates structured Figma component specifications with precise dimensions, states, variants, and Auto Layout configurations for standard UI component libraries. Invoke when building design system components for HiFi prototypes."
license: MIT
---

# HiFi Component Library Generator

This skill generates **pixel-precise Figma component specification documents** for standard UI component libraries. Each component includes: exact dimensions, state variants, Auto Layout configurations, Figma Component Set naming conventions, and property definitions that designers can directly implement as Figma Variants.

## When to Invoke

- When building a Figma component library from scratch
- When user asks for button, input, card, modal, or other UI component specs
- When creating a design system component set with variants
- After generating style guide tokens (hifi-style-guide) — apply those tokens here

## Input Parameters (Ask User First)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `component_category` | Yes | all | One of: `buttons`, `inputs`, `cards`, `navigation`, `feedback`, `data_display`, `overlays`, `all` |
| `icon_library` | No | lucide | `lucide`, `material`, `phosphor`, `custom` |
| `include_states` | No | true | Include all interactive states (hover, pressed, disabled, focus, error)? |
| `include_dark_variant` | No | true | Include dark mode variant layer styles? |

---

## Global Component Foundations

### Figma Component Property Naming Convention

All Component Sets must use these standardized property names for consistency:

| Property | Type | Options |
|----------|------|---------|
| `State` | Variant | `Default`, `Hover`, `Pressed`, `Focus`, `Disabled`, `Loading`, `Error`, `Success` |
| `Size` | Variant | `XS`, `SM`, `MD`, `LG`, `XL` |
| `Variant` | Variant | `Primary`, `Secondary`, `Tertiary`, `Ghost`, `Destructive`, `Outline` |
| `IconLeft` | Boolean | `true`, `false` |
| `IconRight` | Boolean | `true`, `false` |
| `Label` | Text | editable |
| `FullWidth` | Boolean | `true`, `false` |

### Component Auto Layout Rules (Non-Negotiable)

Every component **MUST** be built with Figma Auto Layout:
- Set the correct `Resizing` values (Hug contents / Fill container)
- No manual frame widths unless absolutely fixed
- Use **padding properties** (not nested rectangles) for internal spacing
- All stacked elements use **gap** property (not manual offsets)

---

## Category 1: Buttons (`component_category: buttons`)

### Figma Component Set Name: `Button`

#### Base Size Specs

| Size | Height | Padding X | Padding Y | Gap (icon ↔ label) | Font Size | Icon Size |
|------|--------|-----------|-----------|---------------------|-----------|-----------|
| XS | 28px | 10px | 0 | 6px | Body SM (12px) | 14px |
| SM | 36px | 14px | 0 | 8px | Body SM (12px) | 16px |
| MD | 44px | 18px | 0 | 8px | Body MD (14px) | 18px |
| LG | 52px | 24px | 0 | 10px | Body LG (16px) | 20px |
| XL | 60px | 32px | 0 | 12px | Heading SM (18px) | 24px |

Radius: Use tokens from style guide (hifi-style-guide Section 4). Default: `radius-md` for MD size, scale proportionally.

#### Visual Variant Styles (State: Default)

| Variant | Background | Border | Text Color | Elevation |
|---------|-----------|--------|-----------|-----------|
| Primary | Brand/Primary/600 | none | White | elevation-sm |
| Secondary | Neutral/100 | none | Neutral/800 | none |
| Tertiary | Transparent | 1px Neutral/300 | Neutral/800 | none |
| Ghost | Transparent | none | Brand/Primary/600 | none |
| Destructive | Semantic/Error/600 | none | White | elevation-sm |
| Outline | Transparent | 1px Brand/Primary/600 | Brand/Primary/600 | none |

#### State Adjustments (apply on top of base)

| State | Background Change | Text/Icon Opacity | Border/Shadow |
|-------|------------------|-------------------|---------------|
| Hover | Darken 50-level (e.g., P700) | 100% | elevation-md (if elevated) |
| Pressed | Darken 100-level (e.g., P800) | 90% | Inner shadow 0 2px 4px rgba(0,0,0,0.15) |
| Focus | Same as Default | 100% | 2px outline Brand/Primary/300, offset 2px |
| Disabled | Neutral/200 | 40% opacity (text Neutral 400) | Neutral/200 border, elevation 0 |
| Loading | Same as Default | Label hidden, opacity label 0% | Same as default state |
| Success | Semantic/Success/600 | White | none |
| Error | Semantic/Error/600 | White | none |

#### Icon Button Variant

Component Set Name: `Button / IconOnly`

| Size | Frame Size | Icon Size | Padding |
|------|-----------|-----------|---------|
| SM | 32×32px | 16px | 8px |
| MD | 40×40px | 18px | 11px |
| LG | 48×48px | 20px | 14px |

Radius: `radius-full` (circle) by default. Toggle `Shape` property for `radius-sm` (square).

#### Loading State Implementation

Inside the component, add a **Spinner element** at center with constraints:
- Spinner size: same as Icon Size for that button size
- Spinner stroke width: 2px (size SM→MD), 3px (LG→XL)
- Spinner stroke: current text color
- Spinner track: text color at 20% opacity
- When `State = Loading`, set: Label opacity = 0%, Spinner opacity = 100%

---

## Category 2: Inputs & Forms (`component_category: inputs`)

### 2.1 Text Input Field

**Figma Component Set Name:** `Input / Text`

#### Size Specs

| Size | Total Height | Padding X | Padding Y | Font Size | Icon Size | Radius |
|------|-------------|-----------|-----------|-----------|-----------|--------|
| SM | 36px | 12px | 0 | Body SM (12px) | 16px | radius-sm |
| MD | 44px | 14px | 0 | Body MD (14px) | 18px | radius-md |
| LG | 52px | 16px | 0 | Body LG (16px) | 20px | radius-md |

#### Auto Layout Structure (Horizontal)

```
Input Frame (Auto Layout Horizontal, align: center, gap: 8px)
├── [Prefix Icon Frame] (only if has icon)
│   └── Icon (fixed size, constraints: center)
├── [Label / Value Text Frame] (flex-grow: fill, resizing: vertical hug)
│   ├── Placeholder Text (opacity 100% if empty, 0% if filled)
│   └── Value Text (opacity 100% if filled, 0% if empty) ─ above placeholder
├── [Suffix Icon Frame] (only if has icon)
│   └── Icon / Action Button
└── [Helper / Character Count] — actually in outer wrapper below
```

#### Outer Wrapper Structure (Vertical)

```
Input Field Group (Auto Layout Vertical, gap: 6px)
├── Label Row (Horizontal, gap: 4px)
│   ├── Label Text (Body SM, Semibold, Neutral 700)
│   └── Required Asterisk `*` (Body SM, Error 500)
├── Input Frame (from above)
└── Helper Row (Horizontal, justify: space-between)
    ├── Helper / Error Text (Caption)
    └── Character Count (Caption, Neutral 400)
```

#### State Visuals

| State | Border | Background | Focus Ring | Text Color | Helper Color |
|-------|--------|-----------|------------|-----------|--------------|
| Default | 1px Neutral/300 | White | none | Neutral/800 | Neutral/500 |
| Hover | 1px Neutral/400 | White | none | Neutral/800 | Neutral/500 |
| Focus | 1px Brand/Primary/500 | White | 2px Brand/Primary/100 | Neutral/900 | Neutral/500 |
| Disabled | 1px Neutral/200 | Neutral/50 | none | Neutral/400 | Neutral/400 |
| Error | 1px Semantic/Error/500 | White | 2px Semantic/Error/100 | Neutral/900 | Semantic/Error/600 |
| Success | 1px Semantic/Success/500 | White | 2px Semantic/Success/100 | Neutral/900 | Semantic/Success/600 |

### 2.2 Select / Dropdown

**Figma Component Set Name:** `Input / Select`

Base spec same as Text Input, but Suffix area always has:
- Caret Down Icon (16px for SM, 18px for MD, 20px for LG)
- Value area can show: placeholder, single value, or multi-value chips

**Multi-select variant** replaces value text with:
- Chip (Auto Layout horizontal, padding: 2px 4px 2px 8px, gap: 6px, bg: Neutral/100, radius: sm)
  - Chip label text (Body XS)
  - Remove X icon (12px, clickable)

### 2.3 Checkbox & Radio

**Figma Component Set Name:** `Form / Checkbox` and `Form / Radio`

#### Specs

| Size | Control Size | Hit Area | Gap (control↔label) |
|------|-------------|----------|---------------------|
| SM | 16px | 24×24px | 8px |
| MD | 20px | 32×32px | 10px |
| LG | 24px | 40×40px | 12px |

#### Checkbox States

| State | Visual |
|-------|--------|
| Unchecked | Border: 1.5px Neutral/300, bg: White, radius: sm (2px) |
| Checked | Border: none, bg: Brand/Primary/600, center: Check Icon (white) |
| Indeterminate | Border: none, bg: Brand/Primary/600, center: Horizontal bar (white, 8×1.5px) |
| Hover Unchecked | Border: 1.5px Brand/Primary/400, bg: Brand/Primary/50 |
| Disabled | Border: 1px Neutral/200, bg: Neutral/100, label opacity: 50% |
| Error | Border: 1.5px Semantic/Error/500 (unchecked) or bg: Error/500 (checked) |

#### Radio States

Same logic as checkbox, but shape = circle (radius: full).
Selected state: inner circle dot centered, diameter = 40% of control size.

### 2.4 Toggle Switch

**Figma Component Set Name:** `Form / Toggle`

| Size | Track W × H | Thumb Size | Thumb Offset (from edge) |
|------|-------------|-----------|---------------------------|
| SM | 36 × 20px | 16px | 2px |
| MD | 44 × 24px | 20px | 2px |
| LG | 52 × 28px | 24px | 2px |

States:
- OFF: Track bg Neutral/300, thumb: White, position: left
- ON: Track bg Brand/Primary/600, thumb: White, position: right (translate X = Track W - Thumb W - 2×offset)
- Disabled: Track opacity 50%, thumb opacity 80%

---

## Category 3: Cards (`component_category: cards`)

### Figma Component Set Name: `Card`

#### Structure Variants

| Variant Property | Structure |
|-----------------|-----------|
| `Layout` | `Basic`, `MediaTop`, `MediaLeft`, `StatCard`, `Profile` |
| `Padding` | `None`, `SM`, `MD`, `LG`, `XL` |
| `Elevation` | `0`, `1`, `2`, `3` |

#### Generic Card Sizes

| Padding Token | Internal Padding X | Internal Padding Y | Radius |
|---------------|-------------------|-------------------|--------|
| None | 0 | 0 | radius-sm |
| SM | 12px | 12px | radius-md |
| MD | 20px | 20px | radius-lg |
| LG | 28px | 28px | radius-lg |
| XL | 36px | 36px | radius-xl |

#### Layout: MediaTop (Most Common)

```
Card Frame (Auto Layout Vertical, gap: 0, hug contents)
├── Media Area (fixed aspect ratio)
│   └── Image / Illustration Placeholder
│       Size: 16:9 default (w: fill, h = w × 9/16)
│       Alt: 4:3, 1:1, 3:4 (via property)
├── Content Area (Auto Layout Vertical, padding: per Padding token, gap: 12px)
│   ├── Badge Row (Horizontal, gap: 8px)
│   │   └── Badge(s)
│   ├── Title Text (Heading SM/MD, 1-2 lines truncate)
│   ├── Description Text (Body MD, Neutral 500, 2-3 lines truncate)
│   └── Spacer (flex-grow: 1, pushes footer down)
├── Footer / Action Area (Auto Layout Horizontal, padding: per Padding token)
│   ├── Meta Stack (Horizontal, gap: 8px, align: center)
│   │   ├── Avatar
│   │   └── Name + Date Text
│   └── Action Buttons (Horizontal, gap: 8px, align: right, flex-grow fill justify end)
│       ├── [Ghost Button SM]
│       └── [Primary Button SM]
└── (External) Card Border: 1px Neutral/200 (inside Card frame, below elevation)
```

#### Layout: StatCard (Dashboard Stats)

```
Stat Card Frame (Auto Layout Vertical, padding: MD, gap: 16px, fill width)
├── Top Row (Horizontal, justify: space-between, align: flex-start)
│   ├── Label Stack (Vertical, gap: 4px)
│   │   ├── Metric Label (Caption, Neutral/500, UPPERCASE)
│   │   └── Metric Value (Heading LG/XL, 700, Neutral/900)
│   └── Icon Container (40×40px, Brand/Primary/50 or Semantic bg, radius: md)
│       └── Icon (20px, Brand/Primary/600 or Semantic color)
└── Bottom Row (Horizontal, gap: 8px, align: center)
    ├── Delta Indicator (Auto Layout horizontal, gap: 2px)
    │   ├── Trending Up/Down Icon (14px, Success or Error color)
    │   └── Delta Value % (Body SM, Semibold, Success/Error color)
    └── Context Text (Body SM, Neutral/500) — e.g., "vs last month"
```

---

## Category 4: Navigation (`component_category: navigation`)

### 4.1 Sidebar Navigation

**Figma Component Set Name:** `Nav / Sidebar`

```
Sidebar Frame (Width: 260px fixed, Min Height: fill, Auto Layout Vertical)
├── Brand / Logo Area (Height: 64px, padding: 0 20px, align: center)
│   └── Logo (Horizontal, gap: 10px)
│       ├── Logo Mark (32×32px, radius: sm)
│       └── Brand Name (Heading SM, 700)
├── Search / Quick Find (padding: 0 16px, margin-bottom: 8px)
│   └── Search Input SM (full width)
├── Nav Group (Vertical, gap: 4px, padding: 8px 12px)
│   ├── Nav Section Label (Overline, Neutral/500, padding: 0 8px, margin-top: 8px)
│   │   e.g., "MAIN", "WORKSPACE", "ADMIN"
│   └── Nav Item(s) — repeat for each link
│       └── Nav Item (Auto Layout Horizontal, padding: 10px 12px, gap: 12px, height: 40px, align: center)
│           ├── Nav Icon (18px, fill parent width/height 18)
│           ├── Nav Label (Body MD, flex: fill)
│           ├── Badge / Count (optional, right aligned)
│           └── Caret (if expandable, right aligned)
│       States:
│       └── Default: Neutral/600 text, hover: bg Neutral/100
│       └── Active: bg Brand/Primary/50, text Brand/Primary/700, left border 3px Brand/Primary/600
├── Collapsible Submenu (only if parent expanded)
│   └── Sub Nav Item (padding: 8px 12px 8px 44px, Body SM, Neutral/600)
└── User / Footer Area (Auto Layout Vertical, padding: 12px, margin-top: auto)
    ├── Divider (1px, Neutral/200, margin: 8px 0)
    └── User Menu Item (Horizontal, gap: 12px, padding: 8px, align: center)
        ├── Avatar (36×36px, radius: full)
        ├── User Info Stack (Vertical, flex: fill)
        │   ├── Name (Body MD, Semibold, truncate)
        │   └── Role / Email (Caption, Neutral/500, truncate)
        └── Settings Icon (18px, Neutral/500)
```

### 4.2 Top Navigation Bar

**Figma Component Set Name:** `Nav / Topbar`

```
Topbar Frame (Width: fill, Height: 64px fixed, Auto Layout Horizontal, padding: 0 24px, align: center, gap: 16px, bg: White or Transparent)
├── Left Side (Horizontal, gap: 16px, align: center)
│   ├── Menu Toggle Icon (24px, for mobile sidebar)
│   ├── Logo Mark / Wordmark (height: 28px max)
│   └── Breadcrumb Trail (Horizontal, gap: 6px)
│       └── [Crumb Text] / [Caret Right 14px Neutral/400] / [Current Page Bold]
├── Center / Grow Spacer (flex: 1, push left and right groups apart)
└── Right Side (Horizontal, gap: 12px, align: center)
    ├── Search (Icon or Input, w: 280px if expanded)
    ├── Notification IconButton (MD) + Badge
    ├── Messages IconButton (MD) + Badge
    ├── Theme Toggle (MD IconButton)
    ├── Divider (1px, Neutral/200, height: 24px)
    └── User Profile Stack (Horizontal, gap: 10px, padding: 4px 12px 4px 4px, Auto Layout, align: center)
        ├── Avatar (36×36px)
        ├── Name (Body SM, Semibold, desktop only — hide on mobile)
        └── Caret Down (14px, Neutral/500)
```

Compact variant: Height = 52px, padding: 0 16px, gap: 12px.

---

## Category 5: Feedback & Alerts (`component_category: feedback`)

### 5.1 Alert / Inline Banner

**Figma Component Set Name:** `Alert`

| Variant Property | Options |
|-----------------|---------|
| `Severity` | `Info`, `Success`, `Warning`, `Error` |
| `Variant` | `Filled`, `Outlined`, `Soft` |
| `Dismissible` | Boolean |
| `Actionable` | Boolean |

#### Base Structure

```
Alert Frame (Auto Layout Horizontal, padding: 16px, gap: 12px, align: flex-start, radius: lg)
├── Leading Icon (20px, fixed)
├── Content Stack (Vertical, flex: fill, gap: 4px)
│   ├── Alert Title (Body MD, Semibold) — only if title present
│   └── Alert Message (Body MD, regular weight, line-height 1.5)
│       Optional: Action Link inline (Brand Primary, underline on hover)
└── Trailing Stack (Horizontal, gap: 8px)
    ├── [Action Button SM] — if Actionable=true
    └── Close IconButton SM — if Dismissible=true
```

#### Color Scheme by Severity & Variant

| Severity | Soft Variant (bg | border | icon/text) | Filled Variant | Outlined Variant |
|----------|--------------------------------|----------------|------------------|
| Info | Brand/Primary/50 | Brand/Primary/200 | Brand/Primary/700 text + icon |
| Success | Semantic/Success/50 | Semantic/Success/200 | Semantic/Success/700 text + icon |
| Warning | Semantic/Warning/50 | Semantic/Warning/200 | Semantic/Warning/700 text + icon |
| Error | Semantic/Error/50 | Semantic/Error/200 | Semantic/Error/700 text + icon |

Filled: Solid severity 600 bg, White text + icon.
Outlined: White bg, 1px severity 300 border, severity 700 text.

### 5.2 Toast / Notification

**Figma Component Set Name:** `Toast`

Same internal structure as Alert, but:
- Fixed width: 380px (desktop), full width (mobile)
- Position variant: `Top-Right`, `Top-Center`, `Bottom-Right`, `Bottom-Center`
- Elevation: elevation-lg (E4)
- Auto Layout direction: Vertical stacking support (for toast group)

---

## Category 6: Overlays (`component_category: overlays`)

### 6.1 Modal / Dialog

**Figma Component Set Name:** `Modal`

#### Size Variants

| Size | Max Width | Default Height |
|------|-----------|---------------|
| SM | 400px | Hug |
| MD | 560px | Hug |
| LG | 720px | Hug |
| XL | 880px | Hug (max 80vh if scroll) |
| Fullscreen | 100vw - 64px margin | 100vh - 64px margin |

#### Layered Structure

```
┌─────────────────────────────────────────────────────────────┐
│  SCrim / Backdrop (Full screen, 0.5 opacity Neutral/900)    │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Modal Container (centered, Auto Layout Vertical)   │    │
│  │  Radius: lg, Elevation: E5, bg: White               │    │
│  │  Max-height: calc(100vh - 128px)                    │    │
│  ├─────────────────────────────────────────────────────┤    │
│  │  Header (Auto Layout Horizontal, padding: 20px 24px,│    │
│  │          align: center, gap: 16px,                  │    │
│  │          border-bottom: 1px Neutral/200)            │    │
│  │  ├── Icon (24px, optional, Brand/Primary/600)       │    │
│  │  ├── Title (Heading MD, flex: fill)                 │    │
│  │  └── Close IconButton (MD) — top right              │    │
│  ├─────────────────────────────────────────────────────┤    │
│  │  Body (Auto Layout Vertical, flex: fill/grow,       │    │
│  │        padding: 24px, gap: 16px,                    │    │
│  │        overflow: vertical scroll if tall)           │    │
│  │  └── Any form / content layout goes here            │    │
│  ├─────────────────────────────────────────────────────┤    │
│  │  Footer (Auto Layout Horizontal, padding: 16px 24px,│    │
│  │          justify: flex-end, gap: 12px,              │    │
│  │          border-top: 1px Neutral/200)               │    │
│  │  ├── [Secondary Button MD] — Cancel / Back          │    │
│  │  └── [Primary Button MD] — Confirm / Save           │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 6.2 Popover / Tooltip

**Tooltip** (small):
- Padding: 6px 10px, gap: 4px
- Radius: sm
- Content: Caption text
- Arrow: 6×6px triangle (CSS clip-path or Figma polygon, color matches bg)
- Max-width: 320px
- Placement props: Top, Bottom, Left, Right

**Popover** (larger, interactive):
- Padding: 16px
- Radius: lg
- Elevation: elevation-lg
- Min-width: 280px, Max-width: 440px
- Internal structure same as card (Auto Layout vertical)

---

## Category 7: Data Display (`component_category: data_display`)

### 7.1 Data Table

**Figma Component Set Name:** `Table` (Frame) + sub-components

```
Table Container (Auto Layout Vertical, width: fill, radius: lg, border: 1px Neutral/200, overflow: hidden)
├── Toolbar (Horizontal, padding: 12px 16px, gap: 12px, border-bottom: 1px Neutral/200, align: center)
│   ├── Bulk Selection Count (Body SM, Neutral/600)
│   ├── Spacer (flex: 1)
│   ├── [Action Buttons SM] — Delete, Export, etc.
│   ├── Divider (24px tall, 1px Neutral/200)
│   ├── Filter Chip(s)
│   ├── Search Input SM
│   └── View Toggle IconButtons
├── Table Scroll Area (vertical + horizontal, if needed)
│   └── Table Inner (Auto Layout Vertical, width: fill)
│       ├── Header Row (Horizontal, bg: Neutral/50, border-bottom: 1px Neutral/200)
│       │   ├── [Checkbox Column] w: 48px, padding: 12px 16px
│       │   ├── [TH Cell] Sortable Column Name (Body SM, Semibold, Neutral/700)
│       │   │   Content: Horizontal — [Label Text] + [Sort Icon Up/Down 12px Neutral/400]
│       │   │   Padding: 12px 16px
│       │   │   Resizing: Hug or Fill
│       │   └── [TH Cell(s) repeated...]
│       ├── Body Rows (repeat per data row)
│       │   └── TR (Horizontal, border-bottom: 1px Neutral/100, align: center)
│       │       ├── States: Default (bg white), Hover (bg Neutral/50), Selected (bg Brand/Primary/50)
│       │       ├── [Checkbox Cell]
│       │       ├── [TD Cell] Data content (Body MD, Neutral/800)
│       │       │   Padding: 14px 16px
│       │       │   Content types: Text, Badge, Avatar+Name, Progress Bar, Action Buttons
│       │       └── [TD Cell(s) repeated...]
│       └── Row Hover Action: Right side, visible only on hover: [... more IconButton]
└── Pagination Footer (Horizontal, justify: space-between, padding: 12px 16px, border-top: 1px Neutral/200)
    ├── Rows per page: [Select SM] + Info Text
    └── Pagination Controls (Horizontal, gap: 4px)
        ├── [First Page] [Prev] [Page 1] [Page 2] [active] [Next] [Last Page]
```

### 7.2 Badge / Tag

**Figma Component Set Name:** `Badge`

| Size | Height | Padding X/Y | Font | Radius |
|------|--------|-------------|------|--------|
| SM | 18px | 6px / 2px | Caption (11px, 500) | 4px (sm) |
| MD | 22px | 8px / 2px | Body SM (12px, 500) | 6px (sm-md) |
| LG | 28px | 12px / 4px | Body MD (14px, 600) | 8px (md) |

Variants:
- Tone: Neutral, Brand, Info, Success, Warning, Error
- Variant: Soft (default), Solid (filled + white text), Outline, Dot (left side colored circle indicator)

Dot variant adds: 8px circle, margin-right: 6px, before label.

---

## Figma Component Library Organization

After implementing all components, structure the Figma Pages as follows:

```
Figma File Structure:
├── 🎨 Foundations
│   ├── Color Palette (all tokens + swatches)
│   ├── Typography Scale (all text styles demo)
│   ├── Spacing Scale (visual spacing reference)
│   └── Elevation (shadow demo cards)
├── 🧩 Components
│   ├── Buttons (Button, Button/IconOnly)
│   ├── Inputs (Input/Text, Input/Select, Form/Checkbox, Form/Radio, Form/Toggle)
│   ├── Cards (Card, Card/MediaTop, Card/StatCard, etc.)
│   ├── Navigation (Nav/Sidebar, Nav/Topbar, Nav/Tabs, Nav/Breadcrumb)
│   ├── Feedback (Alert, Toast, ProgressBar, Skeleton)
│   ├── Overlays (Modal, Drawer, Popover, Tooltip, DropdownMenu)
│   ├── Data Display (Table, Badge, Avatar, List/Item, Pagination)
│   └── Icons (imported library as components)
├── 📑 Templates
│   ├── Dashboard Page
│   ├── List View Page
│   ├── Form Page
│   ├── Detail Page
│   ├── Settings Page
│   └── Marketing Landing
└── 🖼️ Design Examples (real pages composed from above)
```

## Implementation Checklist per Component

For **every component** in the library, verify:
- [ ] Component Set created with all Size × Variant × State combinations
- [ ] All property names match the standard naming convention (see Global Foundations)
- [ ] Auto Layout enabled with correct Hug/Fill resizing
- [ ] Padding and gap values match the spec exactly (no manual spacing)
- [ ] Constraints set so component resizes correctly in frames
- [ ] Text layers use exact Text Style tokens from style guide
- [ ] Colors, borders, shadows reference exact style tokens
- [ ] Interactive states visually distinct (Hover ↔ Default ↔ Pressed)
- [ ] Component description + documentation added in Figma "Description" field
- [ ] Layer names follow convention: meaningful names, no "Frame 123"
