---
name: hermes-provider-config-troubleshooting
description: "Configure custom OpenAI-compatible providers in Hermes and troubleshoot 'Provider returned an empty stream' / EmptyStreamError when the provider works via direct API calls but fails inside Hermes. Covers dual Hermes installs (CN Desktop + official) on this Windows machine, the new-api-relay /v1 base_url requirement, and the probe→capture→compare debugging path. Trigger keywords: 配模型, 配置provider, 兔子, tu-zi, ourzhishi, accspark, EmptyStreamError, empty stream, response_format type unavailable, hermes chat 空流, 模型配不上."
version: 1.0.0
license: MIT
---

# Hermes Provider 配置与排障

## When to use
- 用户要求给 Hermes（CN 桌面版或官方版）配置自定义模型/provider（兔子/ourzhishi、mozin/accspark、deepseek 等）
- Hermes 报 `Provider returned an empty stream with no finish_reason`（EmptyStreamError）
- provider 用 curl/urllib/直接 SDK 调用正常，但 Hermes 里同一配置报错
- 报 `HTTP 400: This response_format type is unavailable now`（标题生成失败）

## 本机双 Hermes 安装（关键环境事实）
本机有**两套独立 Hermes**，配置互不相通，操作前必须先确认目标：

| | CN 桌面版 | 官方版 v0.20.0 |
|---|---|---|
| HERMES_HOME | `D:\hermes\data\hermes-home` | `C:\Users\16543\AppData\Local\hermes` |
| config.yaml | `D:\hermes\data\hermes-home\config.yaml` | `C:\Users\16543\AppData\Local\hermes\config.yaml` |
| CLI | 无（桌面 app） | `C:\Users\16543\AppData\Local\hermes\hermes-agent\bin\hermes.exe` |
| venv python | `D:\hermes\data\versions\<ver>\node\node.exe`（node 环境） | `C:\Users\16543\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe` |

**坑**：官方版 `hermes.exe` 会继承当前 shell 的 `$env:HERMES_HOME`。若终端里 HERMES_HOME 是 CN 版的值（本会话常见），运行官方版 CLI 前必须 `$env:HERMES_HOME=""`，否则官方版会读 CN 版配置（报错或行为错乱）。

## 标准配置流程（复制 CN 版 provider 到官方版）
1. 从 CN 版 config.yaml 提取目标 provider 块（如 `custom:apisz-ourzhishi-top`，名字"兔子"）
2. 用 PowerShell 脚本（**全英文编写**，见 Pitfalls）提取 api_key，组装新配置写入官方版 config.yaml
3. **base_url 必须带 `/v1` 路径**（如 `https://apisz.ourzhishi.top/v1`）——new-api 类中转（New-Api 面板）只认 `/v1/chat/completions`；缺 `/v1` 时请求打到 `/chat/completions`，中转返回 **HTML 管理页面**（`<!doctype html>` + `New-Api-Version` meta），Hermes 解析失败 → EmptyStreamError
4. 写入用 UTF-8 无 BOM（`New-Object System.Text.UTF8Encoding($false)`）
5. 改前备份：`config.yaml.bak-<原因>-<时间戳>`

## 排障路径：provider 直连正常但 Hermes 报空流
**核心思路：抓 Hermes 实际发出的请求，与直连成功请求对比差异。**

### 步骤 1：直连探测（用官方版 venv python，勿用 PowerShell/curl）
写脚本（见 `scripts/probe_openai_endpoint.py`）测三类请求：
- plain（无 stream）
- `response_format: {"type":"json_object"}`（Hermes 标题生成用 `json_schema` 类型，new-api 中转可能 400）
- `stream: true` + tools

### 步骤 2：本地抓包代理（对比 Hermes 实际请求）
1. 写 Python 代理脚本转发到真实端点（见 `references/recording-proxy.md`），监听 127.0.0.1:8899
2. 临时把 config.yaml 的 base_url 改成 `http://127.0.0.1:8899`
3. 跑 `hermes chat -q "hi" --yolo -t safe`，看代理日志里 Hermes 发出的**实际路径**（重点：有没有 `/v1`！）和请求体
4. 修复后**恢复真实 base_url**（含 /v1）

### 步骤 3：修复 + 验证
- 修复 base_url 后实测：`hermes chat -q "..." --yolo`，确认返回正常
- 验证脚本也要测**最终用户路径**（hermes.exe chat -q 端到端），不能只测 API 直连

## Pitfalls
- **PowerShell 5.1 中文脚本乱码**：.ps1 含中文时按 ANSI 解析导致语法错误（`The string is missing the terminator`）。**脚本一律全英文写**，中文输出用 Write-Host 的 ASCII 替代或干脆去掉。
- **终端 `&` 调用符被误判**：PowerShell 里 `& "path\hermes.exe"` 会触发 "Foreground command uses '&' backgrounding" 错误。改用 `cmd /c "`"path`" args"`。
- **PS5.1 的 Invoke-RestMethod/curl 连不上目标**（TLS 握手被 reset），但 Python urllib 同环境能通——本机探测 API 用 venv python，别浪费时间在 PowerShell 网络栈上。
- **验证脚本正则坑**：从 YAML 提取 api_key 时用 `re.search(r'...([^'"]+)', cfg, re.S)` 会把换行后的 YAML 全吞进去。**按行遍历**，遇到 `api_key:` 行用 `line.split(":",1)[1].strip()`，安全。
- **标题生成失败 ≠ 主请求失败**：Hermes 的标题生成器（title_generator.py）发送 `response_format: {"type":"json_schema",...}`，有些中转只支持 `json_object`，报 `HTTP 400: This response_format type is unavailable now`。这只是警告（标题缺失），主对话不受影响——先解决主对话的空流，再回头看标题。
- **stream 响应里的 `: ping` 心跳行**：new-api 中转的 SSE 流以 `: ping\n\n` 开头（keep-alive），是合法的 SSE 注释行，不是异常。
- 抓包期间的大量请求可能触发中转临时限流（Connection error），等待 30-60s 或换路径重试。
- 临时文件（_tmp_*.py/.ps1）用完即删，代理进程用 background + watch_patterns 启动并记得 kill。

## Verification
```powershell
$env:HERMES_HOME=""
& exe... # 实际用 cmd /c 包装
# 1) 配置解析
hermes.exe config | Select-String "Model:|claude-opus"
# 2) 端到端对话（最终用户路径）
hermes.exe chat -q "Reply with exactly: HERMES_OK" --yolo
# 3) API 直连（venv python + urllib）
python probe_openai_endpoint.py https://apisz.ourzhishi.top/v1 <key> claude-opus-4-6
```

## Support files
- `scripts/probe_openai_endpoint.py` — 一键探测 OpenAI 兼容端点（plain/json_object/stream/tools 四类请求），区分"中转故障"与"Hermes 请求参数问题"
- `references/recording-proxy.md` — 本地抓包代理完整代码（含 gzip 处理、流式转发、POST-only 日志），用于对比 Hermes 实际请求
