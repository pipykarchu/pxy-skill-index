# Recording proxy for comparing Hermes actual requests vs direct API calls

## When to use
Provider works via urllib/SDK direct calls, but Hermes `chat -q` reports
`EmptyStreamError` / "Provider returned an empty stream". You need to see
the EXACT path + body Hermes sends to spot the difference (usually a
missing `/v1` in base_url, or an extra param the relay rejects).

## Setup
1. Save this script as `recording_proxy.py` (keep it ASCII-only).
2. Run it in background: `python recording_proxy.py` — listens on 127.0.0.1:8899.
3. Temporarily set the Hermes config `base_url` to `http://127.0.0.1:8899`
   (PS: `(Get-Content cfg -Raw) -replace 'https://apisz\.ourzhishi\.top','http://127.0.0.1:8899' | Set-Content cfg -NoNewline`).
4. Run: `hermes.exe chat -q "hi" --yolo -t safe` (remember to clear HERMES_HOME for the official install).
5. Read the proxy log: check `>>> POST <path>` — if path is `/chat/completions`
   (no `/v1`), that's the bug. Real endpoint must be `/v1/chat/completions`.
6. **Restore** base_url to the real one WITH `/v1`, then re-verify.

## Pitfalls
- The proxy must forward `Content-Encoding` / decompress gzip, or the
  relay's gzip'd error page arrives as garbage (looks like \x1f\x8b binary).
- new-api relays answer unknown paths with `200 text/html` (the web admin
  page, includes `<meta name="New-Api-Version">`). A JSON API client then
  fails to parse it → Hermes reports "empty stream". This is the fingerprint
  of a missing `/v1` prefix.
- Kill the proxy when done (`process kill`), and delete temp scripts.

```python
# recording_proxy.py — ASCII only, no non-ASCII chars in file
import http.server, json, urllib.request, gzip

REAL = "https://apisz.ourzhishi.top"   # <-- change to your relay

class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_GET(self):
        self.send_response(200); self.send_header("Content-Length", "2")
        self.end_headers(); self.wfile.write(b"ok")

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length else b""
        print("\n=== POST " + self.path)
        try:
            parsed = json.loads(body)
            print("BODY keys:", list(parsed.keys()))
            keep = {k: parsed[k] for k in parsed if k in (
                "model","stream","stream_options","response_format",
                "temperature","max_tokens","tools","tool_choice")}
            print("BODY:", json.dumps(keep, ensure_ascii=False)[:1500])
        except Exception:
            print("BODY(raw):", body[:500])
        fwd = {k: v for k, v in self.headers.items()
               if k.lower() not in ("host","connection","content-length",
                                    "accept-encoding","transfer-encoding")}
        req = urllib.request.Request(REAL + self.path, data=body,
                                     headers=fwd, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=180) as resp:
                data = resp.read()
                ctype = resp.headers.get("Content-Type","")
                cenc = resp.headers.get("Content-Encoding","")
                print("<<< HTTP %s CT=%s CEnc=%s len=%d" % (resp.status, ctype, cenc, len(data)))
                if cenc == "gzip":
                    try:
                        data = gzip.decompress(data)
                        print("  (decompressed -> %d bytes)" % len(data))
                    except Exception as e:
                        print("  gzip fail:", e)
                print("  head:", data[:400].decode("utf-8","replace"))
                self.send_response(resp.status)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers(); self.wfile.write(data); self.wfile.flush()
        except urllib.error.HTTPError as e:
            eb = e.read()
            print("<<< HTTP ERROR %s: %s" % (e.code, eb[:300].decode("utf-8","replace")))
            self.send_response(e.code)
            self.send_header("Content-Type","application/json")
            self.send_header("Content-Length", str(len(eb)))
            self.end_headers(); self.wfile.write(eb); self.wfile.flush()
        except Exception as e:
            print("forward error:", e)
            self.send_response(502); self.send_header("Content-Length","2")
            self.end_headers(); self.wfile.write(b"{}")

    def log_message(self, *a):
        pass

server = http.server.HTTPServer(("127.0.0.1", 8899), Handler)
print("proxy listening on 127.0.0.1:8899", flush=True)
server.serve_forever()
```

## Real-case result (2026-08-13, rabbit relay apisz.ourzhishi.top)
- CN config had base_url `https://apisz.ourzhishi.top` (no /v1) — Hermes
  POSTed `/chat/completions`, relay returned the HTML admin page → EmptyStreamError.
- Fix: base_url → `https://apisz.ourzhishi.top/v1` → chat works.
- Same fix needed wherever the rabbit relay is configured (CN + official installs).
