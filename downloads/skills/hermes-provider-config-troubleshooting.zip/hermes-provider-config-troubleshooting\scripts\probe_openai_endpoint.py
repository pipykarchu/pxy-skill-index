#!/usr/bin/env python3
"""Probe an OpenAI-compatible chat endpoint the way Hermes would call it.

Usage:
    python probe_openai_endpoint.py <base_url> <api_key> [model]

base_url MUST include the path prefix the relay expects (usually /v1),
e.g. https://apisz.ourzhishi.top/v1  (NOT https://apisz.ourzhishi.top)

Tests four request shapes:
  1. plain                — non-stream, no extras (sanity check)
  2. json_object          — response_format {"type":"json_object"}
  3. stream               — stream:true (what Hermes main loop sends)
  4. tools + stream       — tools array + stream (Hermes full request shape)

If plain works but tools+stream returns empty/HTML, the relay likely
rejects Hermes-specific parameters — compare captured requests next.
If everything fails, the relay/network is the problem, not Hermes.
"""
import json
import sys
import urllib.error
import urllib.request


def post(base_url, api_key, body):
    url = base_url.rstrip("/") + "/chat/completions"
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode(),
        headers={"Authorization": "Bearer " + api_key, "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=90) as resp:
            data = resp.read().decode("utf-8", "replace")
            ctype = resp.headers.get("Content-Type", "")
            head = data[:200].replace("\n", " ")
            print(f"[{resp.status}] CT={ctype} head={head}")
            return resp.status == 200 and "text/html" not in ctype
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")[:300]
        print(f"[HTTP {e.code}] {body}")
        return False
    except Exception as e:
        print(f"[ERR] {type(e).__name__}: {e}")
        return False


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(2)
    base = sys.argv[1]
    key = sys.argv[2]
    model = sys.argv[3] if len(sys.argv) > 3 else "claude-opus-4-6"

    tools = [{
        "type": "function",
        "function": {
            "name": "search_files",
            "description": "Search files",
            "parameters": {"type": "object", "properties": {"pattern": {"type": "string"}}},
        },
    }]

    cases = {
        "plain": {"model": model, "messages": [{"role": "user", "content": "hi"}], "max_tokens": 50},
        "json_object": {"model": model, "messages": [{"role": "user", "content": "hi"}],
                        "max_tokens": 50, "response_format": {"type": "json_object"}},
        "stream": {"model": model, "messages": [{"role": "user", "content": "hi"}],
                   "max_tokens": 50, "stream": True},
        "tools+stream": {"model": model,
                         "messages": [{"role": "system", "content": "You are helpful."},
                                      {"role": "user", "content": "hi"}],
                         "max_tokens": 4096, "stream": True, "tools": tools},
    }
    all_ok = True
    for name, body in cases.items():
        print(f"--- {name}: ", end="")
        ok = post(base, key, body)
        all_ok = all_ok and ok
    print("\n=== RESULT:", "ALL PASS" if all_ok else "SOME FAILED", "===")
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
