---
name: lark-cli-hermes-desktop-setup
description: "在 Hermes CN Desktop(Windows)环境中首次安装、绑定、排障 lark-cli 飞书 CLI。触发条件：新机器/新部署 PATH 无 node/npm/lark-cli、lark-cli auth status 报 not bound、需要拉取个人飞书数据(妙记/日历/云文档)但报身份错误、用户说'链接了飞书'或'允许安装 lark-cli'。含 Hermes 内置 node 定位、npm 安装、config bind 流程、本机路径备忘。"
license: MIT
---

# lark-cli × Hermes CN Desktop 安装与绑定（2026-08-12 验证）

> Hermes CN Desktop 自带 node，但系统 PATH 里通常没有 node/npm/python/lark-cli。新机器上配置飞书 CLI 需要走内置 node 安装 + 上下文绑定两步，缺一不可。

## 适用判断

| 信号 | 说明 |
|------|------|
| 用户说「允许安装 lark-cli」「链接了飞书」 | 本技能核心场景 |
| `lark-cli auth status` 报 `hermes context detected but lark-cli is not bound to it` | 装了但没绑定 → 走绑定步骤 |
| PATH 无 node/npm 但 Hermes 桌面版在运行 | 用 Hermes 内置 node |
| 需要拉个人妙记/日历/云文档 | 绑定必须用 `--identity user-default` |

## Step 1: 定位 Hermes 内置 node

无需安装系统 node。Hermes 运行时版本目录自带完整 node 工具链：

```powershell
# 目录结构：D:\hermes\data\versions\<版本号>\node\
# 含 node.exe + npm.cmd + npx.cmd（本机验证 v22.12.0）
Get-ChildItem "D:\hermes\data\versions" -Directory   # 找版本目录
```

## Step 2: 安装 @larksuite/cli（全局）

**必须先 PATH 前置 node 目录**，否则 postinstall 报 `'node' is not recognized`：

```powershell
$nodeDir = "D:\hermes\data\versions\0.19.0-cn.7\node"
$env:Path = "$nodeDir;$env:Path"
cmd /c "`"$nodeDir\npm.cmd`" install -g @larksuite/cli
# 成功输出：added N packages
# 装完 lark-cli.cmd 位于 $nodeDir\lark-cli.cmd（不在系统 PATH，后续用全路径调用）
```

陷阱：
- ❌ `& $node "$npm" ls -g` 直接用 node 跑 npm.cmd → SyntaxError（npm.cmd 是批处理不是 JS）
- ✅ 一律 `cmd /c "`"$npm`" install ..."` 方式
- ❌ 不在 PATH 前置时 npm 能下载但 postinstall 失败 → 报 `'node' is not recognized`

## Step 3: 绑定 Hermes 上下文（关键）

装完直接 `auth status --json` 返回：

```json
{"ok": false, "error": {"subtype": "not_configured",
 "message": "hermes context detected but lark-cli is not bound to it"}}
```

**解决**（先看 `lark-cli config bind --help`）：

```powershell
# 拉个人数据（妙记/日历/云文档）必须 user-default
lark-cli config bind --source hermes --identity user-default
# 保守模式（读不了个人资源）：
lark-cli config bind --source hermes --identity bot-only
```

**⚠️ 安全审批**：`bind` 是写操作（Risk: write），在 Hermes 中执行会触发安全审批。
- **先向用户确认意图 + 身份预设**，用户明确回复后才执行
- 被 BLOCKED（超时未确认）时**不要重试**，停下来问用户，用户说「确认绑定」再执行
- 用户目标是「拉取我的会议纪要和妙记」→ 直接确认 user-default（bot-only 拿不到个人资源）

## Step 4: 授权（auth login）

绑定后必须授权才能访问资源。**建议分两步走，避免 terminal 超时导致 device_code 作废：**

### 方式一（推荐）：两步异步模式

```powershell
# Step 4a: 获取 device_code + verification_url（不阻塞）
lark-cli auth login --recommend --no-wait --json
# 返回: { "device_code": "...", "verification_url": "...", "expires_in": 600 }
```

拿到 `verification_url` 后：
1. **生成二维码**（必须，不可跳过）：
   ```powershell
   lark-cli auth qrcode -o "feishu_auth_qr.png" "<verification_url>"
   ```
2. **展示二维码图片**给用户（生成文件不够，必须用 `MEDIA:/path` 内联展示）
3. **URL 输出规则**：verification_url 视为不透明字符串，不做任何修改
4. 告诉用户用飞书扫码/打开链接完成授权，完成后回来通知
5. 用户说「好了」后执行：
   ```powershell
   lark-cli auth login --device-code "<device_code>"
   ```

### 方式二：直接阻塞模式

```powershell
lark-cli auth login --recommend
# 最长阻塞 10 分钟等待用户扫码授权
# ⚠️ terminal timeout 必须 >= 120s，否则会超时断连
```

**关键陷阱：不要重复生成链接。** 每次 `lark-cli auth login` 调用都会使上一轮的 `device_code` 作废。用户扫码前不要重跑——否则用户扫的是旧链接，永远无法完成授权。

## Step 5: 验证

```powershell
lark-cli auth status --json        # ok: true 且显示当前用户
lark-cli contact +get-user --as user   # 返回 open_id/name 即就绪
lark-cli minutes +search --start <ISO日期> --as user   # 测试个人妙记访问
```

## 无 python 时读 Edge 浏览记录（PowerShell 替代）

系统无 python 时用 PowerShell 二进制扫描 + 正则提取 URL：

```powershell
# 1. 复制 History（Edge 运行中会锁库）
Copy-Item "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\History" "$env:TEMP\hist.db" -Force
# 2. 读字节转文本 + 正则提取
$bytes = [System.IO.File]::ReadAllBytes("$env:TEMP\hist.db")
$text = [System.Text.Encoding]::UTF8.GetString($bytes)
[regex]::Matches($text, 'https?://[a-zA-Z0-9\.\-_/\?=&%#~\:\+@]{8,200}')
```

- ⚠️ .NET 正则 `\_` 是**非法转义**（报 Unrecognized escape sequence），直接写 `_`
- ⚠️ 大二进制文件用**简单正则 + IndexOf 循环**，不要用贪婪长正则（会超时 60s+）
- ⚠️ terminal 工具里 `& $exe args` 会被误判为后台操作 → 写成 .ps1 文件用 `powershell -File` 执行

## 本机路径备忘（2026-08-12 验证）

| 项目 | 值 |
|------|-----|
| 工作目录 | `D:\pxy\AI产品工作\`（汇报/daily/、技能/skills/04-文档数据与汇报/） |
| Windows 用户 | `C:\Users\16543\`（旧文档的 `C:\Users\皮玺玉\` 是另一台机器） |
| Hermes 内置 node | `D:\hermes\data\versions\0.19.0-cn.7\node\` |
| lark-cli | 已装：`D:\hermes\data\versions\0.19.0-cn.7\node\lark-cli.cmd` |
| 日报技能注册名 | `daily-report-mozin`（不是 mozin-daily-report） |
| Hermes home | `D:\hermes\data\hermes-home\`（会话存 state.db，无独立 sessions 目录） |

## Pitfalls

1. **旧文档路径陷阱**：daily-report-mozin 技能内大量 `D:\pxy\...`、`C:\Users\皮玺玉\...` 路径来自旧机器，本机一律换成 `D:\pxy\...`、`C:\Users\16543\...`
2. **bind 与 auth login 不同**：`config bind` 是绑定 AI Agent 上下文（Hermes/OpenClaw），`auth login` 是 OAuth 授权。not bound 时走 bind，不要走 login
3. **identity 预设不可随意切换**：user-default → bot-only 切换属 risky transition 需 `--force`；绑定前想清楚
4. **审批阻塞 ≠ 命令错误**：被 BLOCKED 时等用户确认，重试同样会被拒
5. **无系统 node 的机器**：npm 全局装在 Hermes 版本目录下，重装/升级 Hermes 版本后 lark-cli 会消失，需重装

## Reference

- `references/2026-08-12-install-bind-troubleshooting.md` — 实际排障全记录：安装失败原因、bind 审批阻塞、环境探测命令、日报决策偏好
