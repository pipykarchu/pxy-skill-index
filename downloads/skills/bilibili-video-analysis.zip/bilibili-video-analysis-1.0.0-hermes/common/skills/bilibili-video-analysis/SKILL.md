---
license: MIT
name: bilibili-video-analysis
description: 视频 AI 学习助手（BiliLearn）：把 B站/抖音视频链接变成带时间戳逐字稿 + 学习纲要 + 思维导图 + PPT 大纲。转写走本地 SenseVoice（免费离线），LLM 整理走 OpenAI 兼容网关。当用户贴出 bilibili/B站/抖音视频链接要求分析、学习、总结、转笔记、做脑图/PPT 时使用。
version: 1.0.0
platforms: [windows]
---

# Bilibili / 抖音 视频 AI 学习分析

基于 BiliLearn CLI（`<BILI_HOME>`）的 Hermes 技能封装。支持 B站（BV 号/链接）和抖音（v.douyin.com 短链/完整链接）。

## 触发场景

- 用户贴出 B站视频链接（`https://www.bilibili.com/video/BV...` 或 `b23.tv` 短链）或抖音链接（`v.douyin.com/...`）要求分析/学习/总结
- 用户说「把这个视频转成笔记/大纲/思维导图/PPT」「视频讲了什么」
- 用户给 BV 号或抖音视频 ID 要求提取逐字稿

## 命令

```powershell
# 安装目录
$BILI = "<BILI_HOME>"
# 关键！Web 后端模块路径（cli.js 复用 Web 版 server 模块，必须设置）
$env:BILI_WEB_PROJECT = "<WEB_PROJECT>"

# 整段分析（推荐，默认本地免费转写）
node "$BILI\cli.js" "<B站链接|BV号>" --local-asr --out note.md

# 只分析指定区间（秒）
node "$BILI\cli.js" "BV1GJ411x7h7" --local-asr --range-start 60 --range-end 300 --json

# 只要元信息（标题/时长/UP，不下载不转写，最快验证）
node "$BILI\cli.js" "<链接>" --meta-only

# 查看配置（Key 打码）
node "$BILI\cli.js" --config
```

## 输出结构

Markdown 笔记包含：总结 / 学习纲要 / Mermaid 思维导图 / PPT 大纲 / 完整逐字稿（带时间戳）。
`--json` 输出机器可读 JSON（含逐字稿片段，供程序处理）。

## 配置（环境变量，可选）

| 变量 | 说明 | 默认 |
|---|---|---|
| `BILI_LLM_BASE_URL` | LLM 整理网关 | `https://api.tu-zi.com/v1` |
| `BILI_LLM_API_KEY` | LLM Key（不配则本地简版整理） | 空 |
| `BILI_LLM_MODEL` | 整理模型 | `gemini-2.5-flash-lite` |

## 已知限制

- 单次区间 ≤30 分钟，超长视频分段处理
- SenseVoice 中文效果最佳，重口音/英文歌曲一般
- B站视频需公开可访问
- **抖音需新鲜 cookies**：`bili-learn\dy_cookies.txt` 过期（yt-dlp 报 Fresh cookies needed）时，用无头 Edge 刷新：
  ```powershell
  # 启动无头 Edge（后台）→ 运行脚本 → 关闭 Edge
  & "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --headless=new --remote-debugging-port=9222 --user-data-dir="%TEMP%\edge-dy-profile" about:blank
  node "<BILI_HOME>\cdp_dy_cookies.js" "https://www.douyin.com/" "<BILI_HOME>\dy_cookies.txt"
  ```
- 首次转写前确认已跑过 `install.ps1`（装 yt-dlp + Python venv + SenseVoice 模型 ~230MB）

## 验证

```powershell
node "$BILI\cli.js" "BV1GJ411x7h7" --meta-only
```
能返回视频元信息即安装正常。
