# Skill 安装说明

包：`bilibili-video-analysis`　版本：`1.0.0`

## 安装前检查

1. 将 ZIP、同名 `.zip.sha256` 放在同一目录。
2. Windows PowerShell 运行 `Get-FileHash .\<包名>.zip -Algorithm SHA256`，与 `.zip.sha256` 第一列比较。
3. macOS/Linux 运行 `sha256sum <包名>.zip`，与 `.zip.sha256` 第一列比较。
4. 先解压到临时目录并阅读 `manifest.json`；发现同名 Skill 时停止，不要直接覆盖。

## 平台目录

- Hermes：`${HERMES_HOME}/skills`。先确认当前进程实际使用的 `HERMES_HOME`。

复制 `common/skills/bilibili-video-analysis` 到目标平台 Skill 根目录。此 Atomic 包不含 `pm-workflow-router` 或 `project-handoff-core`，不会提供跨平台路由提醒或 handoff 生命周期增强。完成后新开会话或按平台要求重启。

## 包含的 Skill

- `bilibili-video-analysis`，角色：primary

## 需要另行准备的依赖

- `yt-dlp`（tool，必需）。本包不会自动安装或登录。
- `ffmpeg`（tool，必需）。本包不会自动安装或登录。
- `Python 3.11 (venv + sherpa-onnx)`（runtime，必需）。本包不会自动安装或登录。
- `bili-learn CLI + Web 后端项目 (BILI_WEB_PROJECT)`（tool，必需）。本包不会自动安装或登录。
- `抖音 cookies (dy_cookies.txt, 无头 Edge 刷新)`（tool，可选）。本包不会自动安装或登录。

成功标志：新会话能发现目标 Skill；随后再按 `VERIFY-自动触发验收.md` 独立验证自动调用。
