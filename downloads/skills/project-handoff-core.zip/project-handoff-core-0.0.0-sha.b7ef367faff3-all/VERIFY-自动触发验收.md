# 自动触发验收

安装成功和自动触发成功是两个独立验收项。每个平台都在新会话完成以下检查：

1. 平台能发现目标 Skill。此 Atomic 包不包含 `pm-workflow-router`。
2. 用自然语言描述产品、PRD、交付或工程化任务，不显式点名 Skill。
3. 确认目标 Skill 被实际加载；Atomic 包不单独承诺跨平台路由提醒。
4. 缺少 CLI、MCP、账号或专属平台能力时必须提醒，不得静默跨平台。
5. 恢复已有项目时读取根 `handoff.md`；只读验收没有实质进展时不得改写它。

## Codex

查看任务中的 Skill 调用记录或明确路由提示；仅看到目录文件不算通过。

## Claude

必须看到 `Skill` 工具调用或等价运行时证据。只读取全局 `CLAUDE.md` 不等于 Skill 自动触发。

## Hermes

先确认 `${HERMES_HOME}`，再比较 `${HERMES_HOME}/skills/.usage.json` 中的调用计数或使用等价运行时证据。目录安装不等于自动触发。
全局 handoff 验收还需运行 `hermes hooks doctor`，并在已有项目的新会话中确认首轮使用了磁盘上的 `handoff.md`。
暂停或结束后的回写必须重新读取磁盘文件确认；模型回复中的“已更新”不能单独作为成功证据。

