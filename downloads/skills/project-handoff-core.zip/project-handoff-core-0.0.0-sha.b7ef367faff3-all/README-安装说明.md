# Skill 安装说明

包：`project-handoff-core`　版本：`0.0.0-sha.b7ef367faff3`

## 安装前检查

1. 将 ZIP、同名 `.zip.sha256` 放在同一目录。
2. Windows PowerShell 运行 `Get-FileHash .\<包名>.zip -Algorithm SHA256`，与 `.zip.sha256` 第一列比较。
3. macOS/Linux 运行 `sha256sum <包名>.zip`，与 `.zip.sha256` 第一列比较。
4. 先解压到临时目录并阅读 `manifest.json`；发现同名 Skill 时停止，不要直接覆盖。

## 平台目录

- Codex：`${CODEX_HOME}/skills`；未设置时使用 `~/.codex/skills`。
- Claude：`~/.claude/skills`。
- Hermes：`${HERMES_HOME}/skills`。先确认当前进程实际使用的 `HERMES_HOME`。

复制 `common/skills/project-handoff-core` 到目标平台 Skill 根目录。本包不含 `pm-workflow-router`，不会额外提供产品工作流路由提醒。完成后新开会话或按平台要求重启。

## Hermes 全局 handoff 加载

1. 单次确定性加载可运行 `hermes chat -s project-handoff-core`。
2. 如需每个已有项目在首轮自动读取 `handoff.md`，把下面配置加入 `${HERMES_HOME}/config.yaml`；将 `<HERMES_HOME>` 替换为当前进程实际使用的绝对目录。

```yaml
hooks:
  pre_llm_call:
    - command: 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<HERMES_HOME>/skills/project-handoff-core/scripts/hermes-preload-handoff.ps1"'
      timeout: 10
```

3. 重启 Hermes；首次提示时只批准上面这一条精确命令，不要开启 Hook 全局免确认。
4. 运行 `hermes hooks doctor`。成功标志：`pre_llm_call` Hook 已获批准、脚本时间戳一致、JSON 有效且合成执行通过。

## 包含的 Skill

- `project-handoff-core`，角色：primary

成功标志：新会话能发现目标 Skill；随后再按 `VERIFY-自动触发验收.md` 独立验证自动调用。
