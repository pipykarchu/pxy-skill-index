---
name: project-handoff-core
version: 1.0.0
description: Keep every project task continuous across Codex, Claude, Hermes, and other agents. Use automatically whenever entering or resuming an existing project, switching models or agents, pausing or interrupting work, or ending a session. Read the project-root handoff.md before work; after material progress, write back the current task, completed and verified work, unfinished items and blockers, next steps in order, pitfalls and decisions, and exact paths, commands, ports, errors, and versions needed to continue.
---

# Project Handoff Core

Keep one practical `handoff.md` at the project root so the next task or AI can continue from the real stopping point instead of asking the user to repeat the background.

Announce briefly when this skill acts:

`已调用【project-handoff-core】（当前平台：平台名），正在读取/更新项目交接。`

## On project entry or resume

1. Locate the existing project root. Prefer the Git root; otherwise use the workspace root containing the project files.
2. Look for `handoff.md` at that root before planning, editing, or running project commands.
3. Read it completely and reconcile it with current files and state. Treat stale claims as context, not proof.
4. Continue from the recorded task, blockers, next steps, commands, ports, errors, and decisions.

If no `handoff.md` exists, continue normally. Create one only when the task produces material project progress or continuity information.

## On pause, interruption, handoff, or session end

Update the project-root `handoff.md` before stopping. Keep it concise, concrete, and executable. Include:

- Current task
- Completed work and verification evidence
- Blockers or unfinished checks
- Next steps in dependency order
- Pitfalls and decisions
- Exact paths, commands, ports, error text, and relevant versions

Do not invent progress. If nothing materially changed, leave the file unchanged. Never record secrets, tokens, passwords, private keys, or sensitive payloads.

If multiple projects were materially changed, update each affected project root separately.

## Hermes deterministic loading

- `hermes chat -s project-handoff-core` deterministically preloads this Skill for a CLI/TUI session.
- For global first-turn handoff reading, register `scripts/hermes-preload-handoff.ps1` as a Hermes `pre_llm_call` Hook in each active `HERMES_HOME`. Approve only that exact command; do not enable blanket Hook auto-approval.
- The Hook reads only the nearest `handoff.md`, only on the first turn, rejects reparse points and files larger than 128 KiB, and injects the body as untrusted project data.
- Hermes cannot generate a reliable semantic handoff after the model response has already ended. Pause/end updates therefore remain a model action governed by this Skill and must be verified from the file, not from the assistant's claim.

## Claude deterministic loading

- For global session-start handoff reading, register `scripts/claude-preload-handoff.ps1` as a Claude Code `SessionStart` command Hook in the active user `settings.json`.
- The Hook reads only the nearest `handoff.md`, rejects reparse points and files larger than 128 KiB, and returns the body as untrusted `hookSpecificOutput.additionalContext`.
- Verify the command Hook with a UTF-8 payload that includes a Chinese project path before treating the Claude runtime trigger as accepted. Pause/end updates remain a model action governed by this Skill.

This is a foundational lifecycle skill. Business workflow routers may add task-specific context but must not replace or suppress it.
