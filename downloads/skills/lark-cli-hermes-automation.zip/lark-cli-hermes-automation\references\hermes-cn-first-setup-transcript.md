# Hermes CN 桌面版 lark-cli 接入实录(2026-08-13)

场景:Hermes CN 桌面版(0.19.0-cn.7)运行中,系统无 node/python/lark-cli,用户称"链接了飞书了,有会议纪要和妙记",需拉飞书数据补日报。

## 环境探测顺序(发现问题用)

1. `where.exe lark-cli` / `where.exe node` / `npm root -g` → 全无
2. 旧脚本(scan_tasks.py 等)引用 `C:\Users\皮玺玉\AppData\Roaming\npm\...` → 旧机器路径,本机无效
3. Hermes 进程:`hermes-agent-cn-desktop.exe`(D:\hermes)+ runtime(`D:\hermes\data\versions\0.19.0-cn.7\hermes-agent-cn-runtime-win32-x64.exe`)
4. **关键发现**:runtime 目录自带 `node\`(node.exe v22.12.0 + npm.cmd);`_internal\` 里有 `lark_oapi-1.6.8.dist-info`(Hermes CN 打包了飞书 SDK)
5. `hermes mcp list` → No MCP servers;`hermes tools list` → 无飞书工具;`desktop-ui.sqlite` 无 feishu 字段 → 飞书不是 Hermes 内置集成,需自装 lark-cli

## 安装(踩坑:postinstall 找不到 node)

```powershell
# ❌ 失败:node 不在 PATH,npm postinstall scripts/install.js 报 'node' is not recognized
# ✅ 正确:先注入 PATH 再装
$nodeDir = "D:\hermes\data\versions\0.19.0-cn.7\node"
$env:Path = "$nodeDir;$env:Path"
cmd /c "`"$nodeDir\npm.cmd`" install -g @larksuite/cli"   # added 7 packages in 18s
# 产物:D:\hermes\data\versions\0.19.0-cn.7\node\lark-cli.cmd + lark-cli
```

注意:不能 `node npm.cmd ls`(npm.cmd 是 cmd 脚本,node 直接跑会 SyntaxError);必须 `cmd /c "npm.cmd ..."`。

## 绑定

```powershell
$env:HERMES_HOME = "D:\hermes\data\hermes-home"
lark-cli config bind --source hermes --identity user-default
# 输出:{"app_id":"cli_aadcbfdb323adcb3","identity":"user-default","message":"已绑定应用 cli_aadcbfdb323adcb3 到 Hermes。请接着运行 lark-cli auth login --recommend",...}
```

错误特征:未绑定时 `auth status` 返回 `{"ok":false,"error":{"subtype":"not_configured","message":"hermes context detected but lark-cli is not bound to it"}}`。

审批坑:`config bind` 是写操作,Hermes terminal 工具 3 次尝试均超时 BLOCKED(即使聊天里用户已确认)。解法:把命令给用户在自己的 PowerShell 手动执行(用户终端无审批),或 `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned -Force` 解决 .ps1 执行策略后手动跑。

## 授权

```powershell
# 用户手动窗口:
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned -Force   # 解决 lark-cli.ps1 无法加载
lark-cli config bind --source hermes --identity user-default
# → 绑定成功后提示运行 auth login
```

`auth login --recommend` 后台运行时 stderr 输出:
```
在浏览器中打开以下链接进行认证:
  https://accounts.feishu.cn/oauth/v1/device/verify?flow_id=...&user_code=XXXX-XXXX
```

二维码生成(踩坑:--output 必须相对路径):
```
❌ lark-cli auth qrcode "<url>" --output D:\pxy\...\qr.png
   → {"ok":false,"error":{"subtype":"invalid_argument","message":"unsafe output path: --output must be a relative path within the current directory"}}
✅ cd 到目标目录后:lark-cli auth qrcode "<url>" --output ./qr.png
```

授权成功:`auth status --json` → `"userName": "皮玺玉"`,open_id `ou_7d05b327389c521f51426312ac5c9e2b`,`"tokenStatus": "valid"`。

## 妙记采集(日报证据来源)

```powershell
# 搜索(找今天的会):--participant-ids 用自己 open_id,--start 用 ISO 日期(不接受 "7d")
lark-cli minutes +search --participant-ids ou_7d05b327389c521f51426312ac5c9e2b --start 2026-08-05 --as user
# → items[] 含 display_info(标题/所有者/开始时间/时长)、app_link、token

# 详情(要产物必须显式加 flag;--minute-tokens 复数,逗号分隔)
lark-cli minutes +detail --minute-tokens obcndu76pwh52i182so913me --summary --todo --chapter --as user
# → artifacts.summary(完整 AI 总结)、artifacts.todos[](含 content + todo_id)、artifacts.chapters[](每段标题+摘要)
```

本次命中:「Mozin APP 2.0 边界对齐会」2026-08-12 10:31,1h26m42s,24 章节,2 条待办。

坑:终端输出大 JSON 被截断 → `cmd /c "... > minute_full.json 2>&1"` 落盘;lark-cli 进度行(`[minutes +detail] ...`)混在 JSON 前,解析时 `indexOf('{')` 起、`lastIndexOf('}')` 止再 JSON.parse。

## 中文路径 .ps1 乱码(全程最痛的坑)

- `write_file` 写含中文路径的 `.ps1` → PS5.1 按 ANSI 读 → `D:\pxy\AI产品工作\汇报` 变 `D:\pxy\AI浜у搧宸ヤ綔\姹囨姤`
- `Set-Location "中文路径"` 在 .ps1 内直接 DirectoryNotFound;`Get-Content` 目标也错
- 连 `[System.IO.File]::WriteAllText("中文路径")` 都失败
- 解法:**中文内容一律用 node 脚本**(write_file 写 .js 是 UTF-8),内置 node 执行;脚本放 ASCII 路径(如 `C:\Users\16543\AppData\Local\Temp\`)再用 `cmd /c "node <path>"` 跑
- lark-cli 的 `--output`/`--file` 等参数也要相对路径(cwd 内),配合 `Set-Location` 在 PowerShell 会话(非 .ps1)执行

## 日报修正模式(妙记内容进日报前必须核对)

用户对妙记提取内容的批量修正(本次实录):
- 「智书」「智数」→ 实际是「智枢」:妙记 AI 总结团队名错,用户一句话纠正,全局替换
- 「与莫总沟通 AI 语音控制是否保留」(妙记待办)→ 用户直接拍板「不要 AI 语音控制」,删除该待办
- 两条高光剪辑对接待办 → 重复,合并成一条
- 「技术侧文件云同步」「配置情况跟进」→ 用户指示不列入,删除
- 「协调帮助」→ 用户指定「只要高光剪辑给智枢」+「Ultra 按键唤醒 AI 功能增加要和成提」,其余行全删

执行要点:用户修正按「全局替换 / 删除(含衍生条目)/ 合并 / 只留点名项」执行,不重写全文;改完校验总览计数、明日计划、协调帮助一致性;交付物验证用 node 脚本断言(应存在项 + 应删除项),临时脚本 `Temp/hermes-verify-*.js` 跑完即删。
