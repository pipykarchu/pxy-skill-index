---
name: lark-cli-hermes-automation
description: "在 Hermes(尤其 CN 桌面版、无系统 node/python)环境中接入 lark-cli 并自动化采集飞书数据:内置 node 安装 @larksuite/cli、config bind 绑定 Hermes 上下文、device flow 授权、妙记/任务/日历采集、中文路径乱码规避。当 lark-cli 报 not_configured、找不到 node、需要从飞书拉妙记/纪要/任务生成内容时使用。"
license: MIT
---

# lark-cli 在 Hermes 环境中的接入与飞书数据采集

> 场景:Hermes CN 桌面版运行时自带 node 但系统 PATH 没有 node/npm/lark-cli;`lark-cli auth status` 报 `not_configured`;需要从飞书拉妙记、任务、日历生成日报/纪要等。本技能覆盖「装得上、绑得住、采得到」三件事。

## 触发条件

- `lark-cli` 命令不存在 / PATH 里找不到 node、npm
- `lark-cli auth status --json` 返回 `{"ok": false, "error": {"subtype": "not_configured"}}`
- 需要拉取飞书妙记(minutes)、任务(task)、日历(calendar)、会议纪要内容
- 用户说"链接了飞书"但本地无法执行飞书命令

## 核心流程:安装 → 绑定 → 授权 → 采集

### 1. 安装(用 Hermes 自带 node,无需系统安装)

```powershell
# 定位内置 node(版本号目录以实际为准)
$nodeDir = "D:\hermes\data\versions\0.19.0-cn.7\node"
# npm 的 postinstall 脚本需要 node 在 PATH,必须先注入
$env:Path = "$nodeDir;$env:Path"
# npm.cmd 必须用 cmd /c 调,不能 `node npm.cmd`(npm.cmd 是 cmd 脚本)
cmd /c "`"$nodeDir\npm.cmd`" install -g @larksuite/cli"
# 验证:where.exe lark-cli → 应指向 $nodeDir\lark-cli.cmd
```

### 2. 绑定 Hermes 上下文(not_configured 时的必做步骤)

```powershell
$env:HERMES_HOME = "D:\hermes\data\hermes-home"
lark-cli config bind --source hermes --identity user-default
```

- `--identity user-default` 才能读**个人**妙记/日历/云文档;`bot-only` 读不到个人资源,只适合纯机器人场景
- 绑定成功输出 `{"app_id":"cli_xxx","identity":"user-default","workspace":"hermes"}` 后,提示继续 `lark-cli auth login --recommend`

### 3. 授权(device flow)

```powershell
lark-cli auth login --recommend
# stderr 打出 verification_url(如 accounts.feishu.cn/oauth/v1/device/verify?flow_id=...&user_code=...)
# 命令阻塞约 10 分钟等待用户浏览器授权
```

- **verification_url 是 opaque string,原样发给用户,不要修改/编码/加标点**
- 生成二维码:`lark-cli auth qrcode "<url>" --output ./qr.png` — **--output 必须相对路径,绝对路径报 `unsafe output path`**
- 授权完成后 `lark-cli auth status --json` 应显示 `userName` + `tokenStatus: valid`
- device_code 10 分钟有效;超时后重新 `--no-wait --json` 拿新码,不要缓存旧码

### 4. 采集(以妙记为例)

```powershell
# 搜索参与的妙记(--participant-ids 传自己 open_id;--start 必须 ISO 日期)
lark-cli minutes +search --participant-ids <open_id> --start YYYY-MM-DD --as user
# 妙记详情(--minute-tokens 复数;要什么产物就显式加什么 flag)
lark-cli minutes +detail --minute-tokens <token> --summary --todo --chapter --as user
```

- 妙记 token 从 URL 末尾提取(如 `.../minutes/obcnxxx` 的 `obcnxxx`)
- 任务:`lark-cli task +get-my-tasks --as user`;日历:`lark-cli calendar +agenda --as user`(缺 `calendar:calendar.event:read` scope 会报 missing_scope)

## ⚠️ 关键陷阱

### 中文路径在 .ps1 中必乱码(本次反复踩坑)

- `write_file` 写含中文的 `.ps1`,PowerShell 5.1 按 ANSI 解析 → 路径/字符串全乱码(如 `D:\pxy\AI产品工作\汇报` 变 `D:\pxy\AI浜у搧宸ヤ綔\姹囨姤`)
- 连带效应:脚本内 `Set-Location`、文件路径、JSON 关键字全部失效
- **解法:凡含中文路径/中文内容的脚本,改用 node 脚本**(原生 UTF-8 无此问题),用内置 node 执行:
  ```powershell
  $node = "D:\hermes\data\versions\0.19.0-cn.7\node\node.exe"
  cmd /c "`"$node`" `"C:\path\to\script.js`" 2>&1"
  ```
- node 脚本放 ASCII 路径(Temp)可避免 `cmd /c` 中文路径二次乱码;node 内读文件用绝对路径字符串没问题
- lark-cli 大 JSON 输出会被终端截断 → 先 `> file.json` 落盘再读,或用 node 解析提取关键字段

### 安全审批会拦截写操作

- `config bind` 等写操作在 Hermes terminal 工具里可能触发安全审批,超时即 `BLOCKED`
- 聊天里用户说"确认"**不等于**通过审批;被拦后停止重试,把命令交给用户在自己的 PowerShell 手动执行(用户终端无审批限制),或等审批弹窗
- 只读命令(`--help`、`auth status`)一般能过,写操作(bind、install -g)风险高

### 旧脚本里的硬编码路径不可信

- 历史脚本常引用旧机器路径(如 `C:\Users\皮玺玉\AppData\Roaming\npm\...`),在本机是无效路径
- 以 `where.exe lark-cli` / `auth status` 实测结果为准,不要沿用旧脚本路径

## 飞书数据可信度规则

- **妙记 AI 总结/待办是草稿,不是权威事实**:团队名、人名、功能决策可能错(实测:「智书」「智数」实为「智枢」;妙记待办"与莫总沟通 AI 语音控制"用户直接拍板"不要")
- 从妙记提取内容前,把团队名/人名/决策/待办列清单给用户核对
- 用户批量修正模式:改称呼→全局替换;删除项→从正文+明日计划+协调帮助全删;合并项→合成一条;「协调帮助只要 X 和 Y」→只留点名行
- 修正后检查总览计数、明日计划、协调帮助三处一致性

## 验证

- 授权验证:`lark-cli auth status --json` → `userName` + `tokenStatus: valid`
- 采集验证:妙记能 `+detail` 出 summary/todos 即通道通
- 交付物验证:用 node 脚本(UTF-8)读回文件断言关键字段,临时验证脚本放 `Temp/hermes-verify-*.js`,跑完即删

## 参考文件

- `references/hermes-cn-first-setup-transcript.md` — 2026-08-13 完整接入实录(安装/绑定/授权/妙记采集/日报修正全过程)
