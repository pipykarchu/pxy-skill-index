---
name: redskill-offline-installer
description: "When RedSkill CLI is unavailable (no Python) or RedSkill store returns 500, download skill ZIPs via edith backend API and install to Hermes and/or Codex skills directories."
license: MIT
---

# RedSkill Offline Installer

Trigger when user says "装技能 / 安装RedSkill / 装小红书技能 / install redskill skill <id>" and RedSkill CLI is not available.

Windows PowerShell workflows below. Replace `<ID>` with skill identifier (e.g. `89674`).

## Step 1: Get download URL via edith API

```powershell
curl.exe -s "https://edith.xiaohongshu.com/api/sns/v1/creator/red_skill/get_skill_bundle?identifier=<ID>"
```

Returns JSON with `zip_url`.

## Step 2: Download and extract

```powershell
$url = "<zip_url>"
curl.exe -sL -o "$env:TEMP\skill_<ID>.zip" $url

$extractDir = "$env:TEMP\skill_<ID>"
New-Item -ItemType Directory -Force -Path $extractDir | Out-Null
tar.exe -xf "$env:TEMP\skill_<ID>.zip" -C "$extractDir"
```

## Step 3: Inspect contents

```powershell
Get-ChildItem -Path $extractDir -Recurse | Select-Object FullName, Length
```

## Step 4: Install to agents

**Hermes (CN Desktop):**
```powershell
Copy-Item -Recurse -Force "$extractDir\<SkillFolder>" D:\hermes\data\hermes-home\skills\
```

**Codex:**
```powershell
Copy-Item -Recurse -Force "$extractDir\<SkillFolder>" C:\Users\16543\.codex\skills\
```

## Step 5: Verify

```powershell
# Hermes
hermes skills list | Select-String "<skill-name>"

# Codex
Get-ChildItem C:\Users\16543\.codex\skills | Where-Object Name -like "*<keyword>*"
```

## Known API endpoints

| Endpoint | Purpose |
|----------|---------|
| `https://edith.xiaohongshu.com/api/sns/v1/creator/red_skill/get_skill_bundle?identifier=<ID>` | Get skill download URL |
| `https://edith.xiaohongshu.com/api/sns/v1/creator/red_skill/search_published_skills?q=<keywords>` | Search skills |
| `https://edith.xiaohongshu.com/api/sns/v1/creator/red_skill/get_cli_manifest` | CLI version manifest |
| `https://redskill.xiaohongshu.net/install.md` | Official install docs |

## Pitfalls

- edith API accepts query param `identifier`, POST body `{"identifier":"..."}` gives 404 — use GET with query param
- `%{http_code}` for curl -w needs careful quoting in PS
- After installing to Codex, restart Codex or it may not pick up new skills
- Hermes picks up skills on next `/reset` or new session