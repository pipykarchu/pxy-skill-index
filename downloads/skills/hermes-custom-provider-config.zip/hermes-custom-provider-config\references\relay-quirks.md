# Relay quirks & dual-install map (from 2026-08-13 debugging session)

## Endpoint behavior notes

### 兔子 / rabbit — https://apisz.ourzhishi.top (new-api relay, user-paid daily quota)
- **API only under `/v1`**: `/v1/chat/completions` → JSON; `/chat/completions` → HTML admin page (HTTP 200) → Hermes `EmptyStreamError`.
- Model: `claude-opus-4-6` (Claude via relay, OpenAI-compatible wire). Accepts `json_schema` response_format.
- **Intermittently slow/hangs**: 4.6s OK ⇄ 45s+ timeouts alternating within minutes; streaming can drop mid-turn. Retry before blaming config.
- **Daily quota**: user-paid, limited per day. Heavy probing can exhaust it → connection reset / long timeouts. Do NOT use for auxiliary tasks (user preference, confirmed 2026-08-13: 兔子是自购限额，辅助任务走公司模型).
- Windows network note: curl → schannel handshake fails; PowerShell Invoke-RestMethod → TLS error; **urllib via Hermes venv python works** (use this for probes).

### mozin — https://api.accspark.cn (company relay)
- Model name is **`DeepSeek-V4-Flash`** (case-sensitive; `deepseek-v4-flash` → `MODEL_NOT_FOUND`). Response reports `DeepSeek-V4-Flash-INT8` (model mismatch flag normal).
- **Accepts `json_schema` response_format** — the reason title_generation is routed here.
- Fast (~0.7s). Company-paid.

### deepseek official — https://api.deepseek.com/v1
- **Rejects `json_schema` response_format**: HTTP 400 `"This response_format type is unavailable now"` (only `json_object`). This is why title_generation must NOT use deepseek official.
- `deepseek-v4-flash`: 1M context (model_metadata hardcoded), cheap. Good for compression/web_extract.
- Company-paid.

## Dual Hermes install on this machine (Windows, user 16543)

| Install | Version | HERMES_HOME / config | Notes |
|---|---|---|---|
| Official | 0.20.0 | `C:\Users\16543\AppData\Local\hermes` (config.yaml, .env at root) | hermes.exe: `...\hermes-agent\bin\hermes.exe`; venv python: `...\hermes-agent\venv\Scripts\python.exe`; logs: `...\logs\agent.log` |
| CN desktop | 0.19.0-cn.7 | `D:\hermes\data\hermes-home` | Packaged runtime `hermes-agent-cn-runtime-win32-x64.exe`; config edit needs app restart to take effect |

- The same `hermes.exe` CLI resolves HERMES_HOME from env var — **unset `HERMES_HOME` before invoking official exe** or it picks up CN home.
- When editing config.yaml by script: **backup first**, write **UTF-8 without BOM** (PS: `New-Object System.Text.UTF8Encoding($false)`), PowerShell 5.1 reads .ps1 scripts as ANSI → keep scripts ASCII-only or garbled Chinese corrupts parsing.
- Verify with a tempfile-prefixed `hermes-verify-*` script (config parse + endpoint probe + `hermes chat -q "Reply with exactly: X" --yolo`), then delete.

## Config keys touched in this fix
- `providers.custom:apisz-ourzhishi-top.base_url` → `https://apisz.ourzhishi.top/v1`
- `model.base_url` → same
- Removed `agent.service_tier: fast` (breaks relays with `speed` kwarg)
- Added `_config_version: 34`
- Added `auxiliary.{compression,web_extract}` → deepseek / `deepseek-v4-flash`; `auxiliary.title_generation` → custom mozin
