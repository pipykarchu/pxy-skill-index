---
name: hermes-custom-provider-config
description: "Configure Hermes (CLI/desktop/CN edition) with custom OpenAI-compatible relay providers (new-api style endpoints like apisz.ourzhishi.top, api.accspark.cn). Use when a custom base_url 404s or returns an HTML page, Hermes reports EmptyStreamError against a relay, you hit the speed kwarg error, or you need cost-optimal auxiliary models (auxiliary task provider/model/base_url). Trigger keywords: 兔子, 中转, new-api, custom provider, base_url /v1, EmptyStreamError, auxiliary 辅助模型, service_tier."
license: MIT
---

# Hermes Custom Provider Config

Configuring Hermes against custom OpenAI-compatible relay endpoints (new-api / one-api style) and routing auxiliary models for cost. Written from real debugging on Windows with a dual Hermes install (official v0.20.0 + CN desktop).

## When to use
- Adding/switching Hermes to a relay endpoint (e.g. `apisz.ourzhishi.top`, `api.accspark.cn`) — not an official provider.
- Diagnosis: `EmptyStreamError`, HTTP 400, HTML page returned, or `got an unexpected keyword argument` against a custom endpoint.
- Cost tuning: auxiliary tasks (title generation, compression, web extract) should NOT burn an expensive/limited main model.
- Setting up auxiliary task routing: `auxiliary.<task>.provider`, `.model`, `.base_url`, `.api_key`.

## Pitfall 1 — base_url MUST end in /v1 (the big one)
new-api class relays serve the API at `https://host/v1/chat/completions`. If base_url is `https://host` (no `/v1`), Hermes/OpenAI-SDK hits `https://host/chat/completions` which returns the relay's **HTML admin page with HTTP 200** — Hermes parses it as an empty/malformed stream → `EmptyStreamError` (or `HTTP 400: ...` variants).

Fix: set base_url to `https://host/v1` in BOTH the `providers.<name>.base_url` block and `model.base_url`.

Fast probe (urllib, not PowerShell/curl — see Verification):
```
/v1/chat/completions -> JSON (good)
/chat/completions    -> `<!doctype html>` (bad, missing /v1)
```

## Pitfall 2 — agent.service_tier: fast breaks third-party relays
Hermes writes `agent.service_tier: fast` to config.yaml when the `/fast` command is used. For OpenAI-compatible custom endpoints this translates to a `speed` kwarg → `Completions.create() got an unexpected keyword argument 'speed'`, killing the main conversation. Remove `agent.service_tier` (and the whole `agent:` block if it only contains that) for custom relays. Check after any Hermes run — it can re-add itself.

## Pitfall 3 — auxiliary "auto" uses the MAIN model
Default `auxiliary.<task>.provider: auto` routes side tasks to the user's main chat model — expensive. Cost-optimal recipe (verified):
```yaml
auxiliary:
  compression:
    provider: deepseek
    model: deepseek-v4-flash
  web_extract:
    provider: deepseek
    model: deepseek-v4-flash
  title_generation:
    provider: custom
    model: DeepSeek-V4-Flash
    base_url: https://api.accspark.cn/v1
    api_key: sk-...   # relay that ACCEPTS json_schema, see Pitfall 4
```
Leave `vision` on auto → main model when main is Claude-class (DeepSeek has no vision; see Pitfall 5).

## Pitfall 4 — json_schema response_format support varies by relay
Hermes `title_generation` hardcodes `response_format: {type: json_schema, ...}` (title_generator.py `_TITLE_RESPONSE_FORMAT`). 
- DeepSeek official (`api.deepseek.com`) rejects it: `HTTP 400 "This response_format type is unavailable now"` (supports only `json_object`).
- new-api relays (e.g. `api.accspark.cn`) accept it.
Failure is non-fatal (title falls back to local `derive_title`), but logs a warning every session. Route `title_generation` to a relay that accepts json_schema, or live with the fallback.

## Pitfall 5 — vision needs a multimodal model
DeepSeek models are text-only; don't point vision at them. Keep `auxiliary.vision.provider: auto` when the main model is Claude (relay) — it falls back to the main provider.

## Pitfall 6 — _config_version missing from hand-written config
Hand-written config.yaml without `_config_version` shows up as `⚠ Config version outdated (v0 → v34)` in `hermes doctor`. Add `_config_version: 34` (match `DEFAULT_CONFIG._config_version` in hermes_cli/config_defaults.py for the installed version).

## Verification workflow
1. Probe endpoints with the Hermes venv python + urllib (NOT PowerShell `Invoke-RestMethod` — TLS failures on some relays; NOT curl on Windows — schannel handshake failures; both false-negative):
   `C:\Users\<user>\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe` — post `/v1/chat/completions` with the relay key, expect JSON.
2. End-to-end: `hermes chat -q "Reply with exactly: X" --yolo -t safe` (clear `HERMES_HOME` first so the right install's config is used).
3. Check `logs/agent.log` for routing lines like `Auxiliary title_generation: using custom (DeepSeek-V4-Flash) at https://...` — confirms aux routing.
4. Relays can be intermittently slow/hang (45s+ timeouts alternating with 4s success) — retry before concluding a config defect. Heavy probing can also exhaust a daily-quota relay; wait and retry.

## Support files
- `scripts/recording_proxy.py` — local MITM-style proxy that logs the exact request bodies/headers Hermes sends, to see what the endpoint actually receives (how the missing `/v1` was caught).
- `references/relay-quirks.md` — per-relay behavior notes (rabbit/apisz.ourzhishi.top, mozin/api.accspark.cn, deepseek official) + dual-install path map.
