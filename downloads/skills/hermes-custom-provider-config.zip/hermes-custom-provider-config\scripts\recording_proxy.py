# Recording proxy for debugging Hermes -> custom relay requests
#
# Use when Hermes fails against a custom OpenAI-compatible endpoint but direct
# SDK/urllib calls succeed: this proxy logs the EXACT request body/headers
# Hermes sends, and relays to the real endpoint. Set the relay's base_url in
# Hermes config to http://127.0.0.1:8899 (temporarily), run hermes, then read
# the printed POST bodies. Restore the real base_url afterwards.
#
# Pitfall this caught: Hermes requested /chat/completions (no /v1) and the
# new-api relay returned its HTML admin page with HTTP 200 -> EmptyStreamError.
# The real fix was base_url ending in /v1, not the proxy.
#
# Run: python recording_proxy.py   (uses the Hermes venv python to match TLS stack)
# Edit REAL below to the target relay host.

import http.server
import json
import urllib.request

REAL = "https://apisz.ourzhishi.top"  # <-- target relay host


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Length", "2")
        self.end_headers()
        self.wfile.write(b"ok")

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length else b""
        print(f"\n{'='*70}\n>>> POST {self.path}")
        try:
            parsed = json.loads(body)
            print("BODY keys:", list(parsed.keys()))
            print("BODY:", json.dumps(parsed, ensure_ascii=False)[:1200])
        except Exception:
            print("BODY(raw):", body[:800])

        fwd_headers = {k: v for k, v in self.headers.items()
                       if k.lower() not in ("host", "connection", "content-length",
                                            "accept-encoding", "transfer-encoding")}
        req = urllib.request.Request(REAL + self.path, data=body,
                                     headers=fwd_headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=180) as resp:
                data = resp.read()
                ctype = resp.headers.get("Content-Type", "")
                print(f"<<< HTTP {resp.status} CT={ctype} len={len(data)}")
                print("  head:", data[:300].decode("utf-8", "replace"))
                self.send_response(resp.status)
                self.send_header("Content-Type", ctype)
                self.send_header("Transfer-Encoding", "chunked")
                self.end_headers()
                for chunk in [data[i:i + 8192] for i in range(0, len(data), 8192)]:
                    if chunk:
                        self.wfile.write(f"{len(chunk):X}\r\n".encode() + chunk + b"\r\n")
                self.wfile.write(b"0\r\n\r\n")
                self.wfile.flush()
        except urllib.error.HTTPError as e:
            err = e.read()
            print(f"<<< HTTP ERROR {e.code}: {err[:300].decode('utf-8','replace')}")
            self.send_response(e.code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)
            self.wfile.flush()
        except Exception as e:
            print("forward error:", e)
            self.send_response(502)
            self.send_header("Content-Length", "2")
            self.end_headers()
            self.wfile.write(b"{}")

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    server = http.server.HTTPServer(("127.0.0.1", 8899), Handler)
    print("recording proxy on 127.0.0.1:8899", flush=True)
    server.serve_forever()
