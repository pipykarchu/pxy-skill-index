# Skill 安装说明

包：`skill-bundle`　版本：`0.0.0-sha.37878fcec3d4`

## 安装前检查

1. 将 ZIP、同名 `.zip.sha256` 放在同一目录。
2. Windows PowerShell 运行 `Get-FileHash .\<包名>.zip -Algorithm SHA256`，与 `.zip.sha256` 第一列比较。
3. macOS/Linux 运行 `sha256sum <包名>.zip`，与 `.zip.sha256` 第一列比较。
4. 先解压到临时目录并阅读 `manifest.json`；发现同名 Skill 时停止，不要直接覆盖。

## 平台目录

- Codex：`${CODEX_HOME}/skills`；未设置时使用 `~/.codex/skills`。

复制 `common/skills/<技能名>` 到目标平台 Skill 根目录。此 Atomic 包不含 `pm-workflow-router` 或 `project-handoff-core`，不会提供跨平台路由提醒或 handoff 生命周期增强。完成后新开会话或按平台要求重启。

## 包含的 Skill

- `create-plan`，角色：primary
- `gh-address-comments`，角色：primary
- `gh-fix-ci`，角色：primary
- `hatch-pet`，角色：primary
- `humanizer`，角色：primary
- `imagegen`，角色：primary
- `mcp-builder`，角色：primary
- `pdf`，角色：primary
- `security-ownership-map`，角色：primary
- `skill-installer`，角色：primary
- `speech`，角色：primary
- `transcribe`，角色：primary
- `vercel-deploy`，角色：primary

## 人工复核警告

- `RISK_RECURSIVE_DELETE`：High-risk command guidance requires manual review. 路径：`skills/03-原型设计与视觉/mcp-builder/reference/node_mcp_server.md`
- `RISK_RECURSIVE_DELETE`：High-risk command guidance requires manual review. 路径：`skills/07-研发交付与质量/vercel-deploy/scripts/deploy.sh`

成功标志：新会话能发现目标 Skill；随后再按 `VERIFY-自动触发验收.md` 独立验证自动调用。
